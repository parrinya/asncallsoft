﻿Imports Microsoft.VisualBasic
Imports System.Data.SqlClient
Imports System.Data

Public Class callAPI_pdpa_
    Public Function callapi_check(ByVal phoneid As String, ByVal iduser As Integer, ByVal createid As Integer) As String
        Dim callapipdpa As New call_consent.CallServiceClient
        Dim str_res As String = ""
        str_res = callapipdpa.Service_Check(3, phoneid, "", iduser, createid)
        Dim ListData() As String = str_res.Split("|")

        If ListData.Count > 1 Then
            'มีข้อมูลในถัง
            str_res = ListData(0).ToString()
            Dim data As String = ListData(1).ToString()
            Dim Detail() As String = data.Split(",")
            Dim row_call As Int16 = Detail.Count()
            If row_call > 0 Then
                Dim crun As Int16 = 0
                While row_call > crun
                    Dim Detailshow() As String = Detail(crun).ToString().Split("=")
                    If Detailshow(0).ToString() = "consent_flag" Then
                        str_res = Detailshow(1).ToString()
                        Return str_res
                        Exit Function
                    End If
                    crun = crun + 1
                End While
            End If
        Else
            Dim ListData01() As String = str_res.Split(":")
            If ListData01.Count > 1 Then
                str_res = ListData01(0).ToString()

                If str_res.Trim.ToLower = "fail" And ListData01(1).ToString().Trim = "ไม่พบข้อมูล หมายเลขบัตรประชาชน" Then
                    str_res = "consent"
                ElseIf ((str_res.Trim.ToLower) = "error" Or (str_res.Trim.ToLower) = "erroe") Then

                    If ListData01(1).ToString() = "Call API Token[access_token is null][Check]." Then
                        str_res = "! ไม่สามารถ ตรวจสอบสถานะ การยินยอมให้ติดต่อได้ ตรวจสอบใหม่->"
                    Else
                        str_res = "! " & ListData01(1).ToString()
                    End If
                Else

                    If ListData01(1).ToString() = "Call API Token[access_token is null][Check]." Then
                        str_res = "! ไม่สามารถ ตรวจสอบสถานะ การยินยอมให้ติดต่อได้ ตรวจสอบใหม่->"
                    Else
                        str_res = "! " & ListData01(1).ToString()
                    End If
                End If
            End If
        End If

        Return str_res
    End Function
	
	
    Public Function callapi_insert(ByVal phoneid As String, ByVal iduser As Integer, ByVal name As String, ByVal lname As String, ByVal status As Integer) As Array
        Dim callapipdpa As New call_consent.CallServiceClient

        Dim data(1) As String
        Dim str_res As String = ""
        str_res = callapipdpa.Service_Consent(name, lname, "", phoneid, "", 1, "", iduser, status, 3, 4)
        'callService_Consent( txtfirstname,txtlastname,txtidcard, txttelephone,txtemail, string txtversion, txtcomments, int id,int tmpstatus,int tmptype, int tmpuserid)

        'str_res = "success:บันทึกเรียบร้อย"
        Dim ListData() As String = str_res.Split(":")
        If ListData.Length > 2 Then
            data(0) = "error"
            data(1) = str_res
        Else
            data(0) = ListData(0).ToString()
            data(1) = str_res

        End If


        Return data
    End Function

    Public Function callfunction_insertpdpa_all(ByVal idcus As Int64, ByVal fnamecus As String, ByVal lnamecus As String, ByVal idtsr As Int32, ByVal phone As String, ByVal status As Int16) As String
        'status=>1=consent,0=unconsent
        Dim logid As Int64 = i_LogConsent(idcus, idtsr, phone, status)
        Dim reponse(1) As String
        Dim result As String = ""
        Try
            Dim callapi As New callAPI_pdpa_
            reponse = callapi.callapi_insert(phone, idcus, fnamecus, lnamecus, status)
            result = u_LogConsent(reponse, logid)

        Catch ex As Exception
            If logid <> 0 And reponse(0).ToString() = "" And reponse(1).ToString() = "" Then
                Dim exx As String = Replace(ex.ToString().Substring(0, 100), "'", "")
                Dim err(1) As String
                err(0) = "error[Catch]"
                err(1) = exx
                result = u_LogConsent(err, logid)
            End If

        End Try
        Return result

    End Function

    Function u_LogConsent(ByVal respone As Array, ByVal logid As Int64) As String
        Dim str As String = "update TbllogConsent set response_status=@response_status ,response_message= @response_message where LogID=@LogID"
        Dim Conn As SqlConnection
        Dim com As SqlCommand
        Dim strConn = ConfigurationManager.ConnectionStrings("asnbroker").ConnectionString
        Conn = New SqlConnection()
        Try
            With Conn
                If .State = ConnectionState.Open Then .Close()
                .ConnectionString = strConn
                .Open()

            End With
            com = New SqlCommand(str, Conn)
            With com
                .Parameters.Clear()
                .Parameters.Add("@LogID", SqlDbType.BigInt).Value = logid
                .Parameters.Add("@response_message", SqlDbType.VarChar).Value = respone(1).ToString()
                .Parameters.Add("@response_status", SqlDbType.VarChar).Value = respone(0).ToString()
                .ExecuteNonQuery()
            End With

            If respone(0).ToString() = "success" Then
                Return respone(1).ToString()
            Else
                Return "ไม่สามารถบันทึกได้เนื่องจาก : " & respone(1).ToString()
            End If

        Catch ex As Exception
            Return "ไม่สามารถบันทึกได้เนื่องจาก : " & Replace(ex.ToString().Substring(0, 100), "'", "")
        Finally
            Conn.Close()
        End Try


    End Function

    Public Function i_LogConsent(ByVal idcus As Int64, ByVal idtsr As Int32, ByVal phone As String, ByVal status As Int16) As Int64
        'frmCus.DataKey.Item(0),Request.Cookies("userID").Value,phone,status
        Dim str As String = "INSERT INTO TbllogConsent(CusID ,status,CreateID,phone_number) VALUES (@CusID ,@status,@CreateID,@phone_number);SELECT Scope_Identity();"

        Dim logid As Int64 = 0
        Dim Conn As SqlConnection
        Dim com As SqlCommand
        Dim strConn = ConfigurationManager.ConnectionStrings("asnbroker").ConnectionString
        Conn = New SqlConnection()
        Try

            With Conn
                If .State = ConnectionState.Open Then .Close()
                .ConnectionString = strConn
                .Open()
            End With
            com = New SqlCommand(str, Conn)
            With com
                .Parameters.Clear()
                .Parameters.Add("@CusID", SqlDbType.VarChar).Value = idcus
                .Parameters.Add("@CreateID", SqlDbType.VarChar).Value = idtsr
                .Parameters.Add("@status", SqlDbType.VarChar).Value = status '1=consent,0=unconsent
                .Parameters.Add("@phone_number", SqlDbType.VarChar).Value = phone

            End With

            Dim obj As Object = com.ExecuteScalar()
            If obj IsNot Nothing AndAlso obj IsNot DBNull.Value Then
                logid = Convert.ToInt64(obj)
            End If
        Catch ex As Exception

        Finally
            Conn.Close()
        End Try

        Return logid
    End Function
	

End Class
