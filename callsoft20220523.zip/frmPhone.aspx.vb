﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Globalization

Imports System.Drawing
Imports System.Diagnostics
Imports System.ComponentModel
Imports GenCode128
Imports System.IO
Imports CrystalDecisions.CrystalReports.Engine

Partial Class Modules_Sale_Phone_frmPhone
    Inherits System.Web.UI.Page
    Dim FunAll As New FuntionAll
    Dim StrQryProvince As New QueryProvince
    Public strsrc As String
    Public TelAjax As String = ""
    Dim ISODate As New ISODate
    Dim StrQuery As New QueryPhone
    Dim com As SqlCommand
    Dim Conn As New SqlConnection(ConfigurationManager.ConnectionStrings("asnbroker").ConnectionString)
    Public strProtype As String
    Dim dt As New DataTable
    Dim DataAccess As New DataAccess
    Dim dtGetAppPhotos As DataTable
    Public strRecoving As String
    Private strappid As String = ""
    Dim myReport As New ReportDocument


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim mnList As Menu = CType(Master.FindControl("NavigationMenu"), Menu)
        mnList.Visible = False
        If Not IsPostBack Then
            ViewState("StartTime") = DateTime.Now
            If Request.Cookies("TypeTsr").Value = 6 Then
                frmRecruit.Visible = True
            Else
                frmRecruit.Visible = False
            End If
        End If
        ' 
        If Request.Cookies("TypeTsr").Value = 3 Then 'sale ปีต่อ จะเห็นข้อมูลปีต่อ
            FormViewDetailRenew.Visible = True
            If frmApp.DataItemCount > 0 Then
                TmpRenew.Visible = False
            Else
                TmpRenew.Visible = True
            End If

        ElseIf Request.Cookies("TypeTsr").Value = 101 Then
            FormViewDetailRenew.Visible = True
            If frmApp.DataItemCount > 0 Then
                TmpRenew.Visible = False
            Else
                TmpRenew.Visible = True
            End If
        Else
            FormViewDetailRenew.Visible = False
            TmpRenew.Visible = False
        End If

        'การมองเห็น Recoving
        Select Case Request.Cookies("TypeTsr").Value
            Case 3
                strRecoving = "frmHistoryRecoving.aspx?IdCar=" & Request.QueryString("IdCar")
            Case Else
                strRecoving = ""
        End Select
    End Sub

#Region "Address"
    Protected Sub frmAddr_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmAddr.DataBound
        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)

        FunAll.ListDropDown(ddDist, StrQryProvince.TblZipCodeBindDist(ddProvince.SelectedValue), "Dist", "Dist")
        'Dim str As String = frmAddr.DataKey.Item(0)
        FunAll.ListDropDown(ddSubDist, StrQryProvince.TblZipCodeBindSubDist(frmAddr.DataKey.Item(0).ToString.Trim, ddProvince.SelectedValue), "SubDist", "SubDist")

        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(frmAddr.DataKey.Item(1).ToString.Trim, ddProvince.SelectedValue, frmAddr.DataKey.Item(0).ToString.Trim), "ZipCode", "ZipCode")

        If ddDist.Items.Count > 0 Then
            ddDist.SelectedValue = frmAddr.DataKey.Item(0).ToString.Trim

        End If

        If ddSubDist.Items.Count > 0 Then
            ddSubDist.SelectedValue = frmAddr.DataKey.Item(1).ToString.Trim

        End If

        If ddZipCode.Items.Count > 0 Then
            ddZipCode.SelectedValue = frmAddr.DataKey.Item(2).ToString.Trim

        End If
    End Sub

    Protected Sub ddProvince_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)

        FunAll.ListDropDown(ddDist, StrQryProvince.TblZipCodeBindDist(ddProvince.SelectedValue), "Dist", "Dist")
        FunAll.ListDropDown(ddSubDist, StrQryProvince.TblZipCodeBindSubDist(ddDist.SelectedValue, ddProvince.SelectedValue), "SubDist", "SubDist")
        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(ddSubDist.SelectedValue, ddProvince.SelectedValue, ddDist.SelectedValue), "ZipCode", "ZipCode")


    End Sub

    Protected Sub ddDist_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)
        FunAll.ListDropDown(ddSubDist, StrQryProvince.TblZipCodeBindSubDist(ddDist.SelectedValue, ddProvince.SelectedValue), "SubDist", "SubDist")
        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(ddSubDist.SelectedValue, ddProvince.SelectedValue, ddDist.SelectedValue), "ZipCode", "ZipCode")

    End Sub

    Protected Sub ddSubDist_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)

        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(ddSubDist.SelectedValue, ddProvince.SelectedValue, ddDist.SelectedValue), "ZipCode", "ZipCode")

    End Sub
#End Region

#Region "Tel Call"
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Try
            UpdateTblUser()
            GetSoftPhone()

        Catch ex As Exception
            ScriptManager.RegisterClientScriptBlock(UpdatePanel1, GetType(UpdatePanel), UpdatePanel1.ClientID, "alert('ไม่สามารถโทรออกได้เนื่องจาก : " & ex.Message & "');", True)
        End Try

    End Sub
    Protected Sub UpdateTblUser()
        'update Tbluser TsrTel=เบอร์ลูกค้าที่โทรออก GetPhoneNumber(),TsrFlagCall=0 where Userid=Request.Cookies("userID").Value
        Dim strq As String = "Update tbluser set TsrFlagCall=0 ,TsrTel='" & GetPhoneNumber() & "' where userid=" & Request.Cookies("userID").Value
        CheckConnectionState()
        com = New SqlCommand(strq, Conn)
        com.ExecuteNonQuery()
    End Sub
    Protected Function checkPhoneNumber() As Boolean
        dt = New DataTable
        Dim strqry As String
        strqry = "Select * from TblBlackListCALL Where Mobile = '" & GetPhoneNumber() & "'"
        dt = DataAccess.DataRead(strqry)
        If dt.Rows.Count > 0 Then
            ScriptManager.RegisterClientScriptBlock(UpdatePanel1, GetType(UpdatePanel), UpdatePanel1.ClientID, "alert('เบอร์โทรติด Blacklist ไม่สามารถโทรออกได้');", True)
            Return False
        Else
            Return True
        End If
    End Function


    Protected Function GetPhoneNumber() As String
        Select Case ddCall.SelectedValue
            Case 1

                Return frmTel.DataKey.Item(0).ToString
            Case 2

                Return frmTel.DataKey.Item(1).ToString
            Case 3

                Return frmTel.DataKey.Item(2).ToString
            Case 4

                Return frmTel.DataKey.Item(3).ToString
            Case 5

                Return frmTel.DataKey.Item(4).ToString
            Case Else
                Return ""
        End Select
    End Function

    Protected Sub GetSoftPhone()
        If checkPhoneNumber() = True Then
		
			Dim str As String = ""
            str = check_conent()
            If str = "consent" Then
			
				Dim CallUrl As String = ""

				CallUrl += Replace(ConfigurationManager.AppSettings("WebCall"), "@IpAsserisk", Request.Cookies("IpAsterisk").Value) & "to=" & GetPhoneNumber() & "&&from=" & Request.Cookies("Extension").Value & "&&refer1=" & Request.QueryString("IdCar").ToString
				CallUrl += "&refer2=" & Request.Cookies("userID").Value
				TelAjax = CallUrl
				LinkSoftPhone()
			
			End If
            If str = "" Then
                lblPhone.Text = ""
                ImageButton1.Visible = False
                btntryit.Visible = False
            Else
                ToShow(str)
            End If
		Else
            lblPhone.Text = ""
            ImageButton1.Visible = False
            btntryit.Visible = False	
			
        End If
    End Sub

    Protected Sub LinkSoftPhone()
        If Request.QueryString("Call").ToString = 1 And Request.Cookies("Extension").Value <> "0000" And Request.Cookies("Extension").Value <> "" And Request.Cookies("TypeTsr").Value <> 3 And Request.Cookies("TypeTsr").Value <> 6 And Request.Cookies("TypeTsr").Value <> 11 Then
            strsrc = "SoftPhone.aspx?" & Request.ServerVariables("QUERY_STRING").ToString() & "&CallID=" & GetPhoneNumber()
        Else
            strsrc = ""
        End If
    End Sub


    Protected Sub frmTel_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmTel.DataBound
        If Not IsPostBack Then
            If Request.QueryString("Call").ToString = 1 And Request.Cookies("Extension").Value <> "0000" And Request.Cookies("Extension").Value <> "" And Request.Cookies("TypeTsr").Value <> 3 And Request.Cookies("TypeTsr").Value <> 6 And Request.Cookies("TypeTsr").Value <> 11 Then
                UpdateTblUser()
                GetSoftPhone()
            End If
        End If
    End Sub

    Protected Sub ddStatus_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddStatus.SelectedIndexChanged
        ShowAppoint()
        'LinkSoftPhone()
    End Sub

#End Region


    'Show เวลานัด
    Protected Sub ShowAppoint()
        If ddStatus.SelectedValue = 5 Or ddStatus.SelectedValue = 9 Or ddStatus.SelectedValue = 41 Or ddStatus.SelectedValue = 12 Or ddStatus.SelectedValue = 11 Or ddStatus.SelectedValue = 7 Or ddStatus.SelectedValue = 27 Or ddStatus.SelectedValue = 38 Then
            If Request.Cookies("TypeTsr").Value = 3 And ddStatus.SelectedValue = 9 Then
                Panel1.Visible = True
            Else
                Panel1.Visible = False
            End If
        Else
            Panel1.Visible = True
        End If
    End Sub

    Protected Sub ddStatus_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddStatus.DataBound
        ShowAppoint()
    End Sub


#Region "Save Tblcustomer TblCar"

    'Address
    Protected Sub WebImageButton1_Click3(sender As Object, e As System.EventArgs)
        Try
            SaveTblCustomerAddr()
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('บันทึกข้อมูลเรียบร้อย');", True)
        Catch ex As Exception
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้เนื่องจาก : " & ex.Message & "');", True)
        End Try
    End Sub

    Protected Sub SaveTblCustomerAddr()
        Dim txtAddr As TextBox = FunAll.ObjFindControl("txtAddr", frmAddr)
        Dim txtMoo As TextBox = FunAll.ObjFindControl("txtMoo", frmAddr)
        Dim txtViilege As TextBox = FunAll.ObjFindControl("txtViilege", frmAddr)
        Dim txtRoad As TextBox = FunAll.ObjFindControl("txtRoad", frmAddr)
        Dim txtSoi As TextBox = FunAll.ObjFindControl("txtSoi", frmAddr)

        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)

        With SqlCustomer
            .UpdateParameters("Address").DefaultValue = txtAddr.Text.Trim
            .UpdateParameters("Villege").DefaultValue = txtViilege.Text.Trim
            .UpdateParameters("Moo").DefaultValue = txtMoo.Text.Trim
            .UpdateParameters("Soi").DefaultValue = txtSoi.Text.Trim
            .UpdateParameters("Road").DefaultValue = txtRoad.Text.Trim
            .UpdateParameters("Dist").DefaultValue = ddDist.SelectedValue
            .UpdateParameters("Province").DefaultValue = ddProvince.SelectedValue
            .UpdateParameters("Zip").DefaultValue = ddZipCode.SelectedValue
            .UpdateParameters("SubDist").DefaultValue = ddSubDist.SelectedValue
            .UpdateParameters("CusID").DefaultValue = frmCus.DataKey.Item(0)
            .Update()
        End With
		'log Customer
        Dim data02 As New data_customer
        data02.address = txtAddr.Text.Trim
        data02.villege = txtViilege.Text.Trim
        data02.moo = txtMoo.Text.Trim
        data02.soi = txtSoi.Text.Trim
        data02.dist = ddDist.SelectedValue
        data02.province = ddProvince.SelectedValue
        data02.zip = ddZipCode.SelectedValue
        data02.subdist = ddSubDist.SelectedValue
        data02.createid = Request.Cookies("userID").Value
        data02.cusid = frmCus.DataKey.Item(0)
        data02.comment = "TM4_Modules_Sale_Phone_frmPhone.aspx.vb"
        Dim callcar As New callAPI_log
        callcar.log_customer(data02)


    End Sub


    Protected Sub WebImageButton1_Click(sender As Object, e As System.EventArgs)
        Try
            Dim txtCarBuyDate As TextBox = FunAll.ObjFindControl("txtCarBuyDate", frmCar)
            With SqlApp
                .UpdateParameters("CarBuyDate").DefaultValue = ISODate.SetISODate("en", txtCarBuyDate.Text.Trim)
                .Update()
            End With

            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('บันทึกข้อมูลเรียบร้อย');", True)
        Catch ex As Exception
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้เนื่องจาก : " & ex.Message & "');", True)

        End Try


    End Sub

#End Region

    Protected Sub ImageButton2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(1)
    End Sub

    Protected Sub ImageButton3_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(2)
    End Sub

    Protected Sub ImageButton4_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(5)
    End Sub

    Protected Sub ImageButton5_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(4)
    End Sub

    Protected Sub ImageButton6_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(3)
    End Sub

    Protected Sub ImageButton7_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(7)
    End Sub

    Protected Sub ImageButton8_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(8)
    End Sub

    Protected Sub UpdateTblCustomer(ByVal UpdateID As Integer)

        Try
            Dim txtTel As TextBox = FunAll.ObjFindControl("txtTel", frmTel)
            Dim txtTelExt As TextBox = FunAll.ObjFindControl("txtTelExt", frmTel)
            Dim txtOTel As TextBox = FunAll.ObjFindControl("txtOTel", frmTel)
            Dim txtOTelExt As TextBox = FunAll.ObjFindControl("txtOTelExt", frmTel)
            Dim txtMobile As TextBox = FunAll.ObjFindControl("txtMobile", frmTel)
            Dim txtFax As TextBox = FunAll.ObjFindControl("txtFax", frmTel)
            Dim txtOther As TextBox = FunAll.ObjFindControl("txtOther", frmTel)
            Dim txtOtherExt As TextBox = FunAll.ObjFindControl("txtOtherExt", frmTel)
            Dim txtEmail As TextBox = FunAll.ObjFindControl("txtEmail", frmTel)
            Dim txtOther3 As TextBox = FunAll.ObjFindControl("txtOther3", frmTel)
            Dim txtOtherExt3 As TextBox = FunAll.ObjFindControl("txtOtherExt3", frmTel)
            CheckConnectionState()
            com = New SqlCommand(StrQuery.UpdateTblCustomer(UpdateID), Conn)
            With com
                .Parameters.Clear()
                .Parameters.Add("@Tel", SqlDbType.VarChar).Value = txtTel.Text.Trim
                .Parameters.Add("@TelExt", SqlDbType.VarChar).Value = txtTelExt.Text.Trim
                .Parameters.Add("@OTel", SqlDbType.VarChar).Value = txtOTel.Text.Trim
                .Parameters.Add("@OTelExt", SqlDbType.VarChar).Value = txtOTelExt.Text.Trim
                .Parameters.Add("@Mobile", SqlDbType.VarChar).Value = txtMobile.Text.Trim
                .Parameters.Add("@OthTel1", SqlDbType.VarChar).Value = txtOther.Text.Trim
                .Parameters.Add("@OthTel1Ext", SqlDbType.VarChar).Value = txtOtherExt.Text.Trim
                .Parameters.Add("@OthTel2", SqlDbType.VarChar).Value = txtOther3.Text.Trim
                .Parameters.Add("@OthTel2Ext", SqlDbType.VarChar).Value = txtOtherExt3.Text.Trim
                .Parameters.Add("@Fax", SqlDbType.VarChar).Value = txtFax.Text.Trim
                .Parameters.Add("@Email", SqlDbType.VarChar).Value = txtEmail.Text.Trim
                .Parameters.Add("@CusID", SqlDbType.VarChar).Value = frmCus.DataKey.Item(0)
                .ExecuteNonQuery()

            End With
			


            frmTel.ChangeMode(FormViewMode.ReadOnly)
            frmTel.DataBind()
			
			If UpdateID = 1 Or UpdateID = 2 Or UpdateID = 5 Then
                Dim str As String = ""
                Dim data02 As New data_customer
                If UpdateID = 1 Then
                    str = "บ้าน"
                    data02.tel = txtTel.Text.Trim
                ElseIf UpdateID = 2 Then
                    str = "ทำงาน"
                    data02.otel = txtOTel.Text.Trim
                ElseIf UpdateID = 5 Then
                    str = "มือถือ"
                    data02.mobile = txtMobile.Text.Trim
                End If
                data02.createid = Request.Cookies("userID").Value
                data02.cusid = frmCus.DataKey.Item(0)
                data02.comment = "TM4_Modules_Sale_Phone_frmPhone.aspx.vb|" & str
                Dim callcar As New callAPI_log
                callcar.log_customer(data02)
            End If

            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('บันทึกข้อมูลเรียบร้อย');", True)
        Catch ex As Exception
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้เนื่องจาก : " & ex.Message & "');", True)

        End Try


        'BindLink()
    End Sub

    Public Sub CheckConnectionState()
        If Conn.State = ConnectionState.Open Then
            Conn.Close()
        Else
            Conn.Open()
        End If
    End Sub


    Protected Sub LinkButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton2.Click
        strProtype = "../Product/frmProType2.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    End Sub

    Protected Sub LinkButton3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton3.Click
        strProtype = "../Product/frmProType3Plus.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    End Sub

    Protected Sub LinkButton4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton4.Click
        strProtype = "../Product/frmProType3.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        strProtype = "../Product/frmProType1.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    End Sub

    Protected Sub LinkButton5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton5.Click
        'strProtype = "../Product/frmProType1.aspx?IdCar=" & frmCar.DataKey.Item(0)

        strProtype = "../Product/frmSendFax.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)

    End Sub


    Protected Sub WebImageButton3_Click(sender As Object, e As System.EventArgs) Handles WebImageButton3.Click
        frmAddr.DataBind()
        frmApp.DataBind()
        frmTel.DataBind()
        frmCar.DataBind()

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim strLink As String = "Edit=1&Buy=2"
        strLink += "&IdCar=" & frmCar.DataKey.Item(0)
        strLink += "&AppID=" & frmApp.DataKey.Item(0)
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.open('../Application/frmApplication.aspx?" & strLink & "','Application');</script>")
    End Sub



#Region "Save Status"
    Protected Sub WebImageButton1_Click2(sender As Object, e As System.EventArgs) Handles WebImageButton1.Click
        'Try
        If ChkData() = True And CheckAppointDate() = True And chkSelectLINE() = True Then
            If chk90() = True And chkFollow2D() = True Then

                frmApp.DataBind()
                CheckConnectionState()
                If ChkRider() = True Then

                    'สำหรับลงสถานะ Success
                    If ddStatus.SelectedValue = 3 Or ddStatus.SelectedValue = 4 Then
                        If chkAutoPassQC() Then
                            UpdateApplicationAutoPass()
                        Else
                            UpdateApplication()
                        End If

                    End If
                    InsertTblRecruit()
                    btnSaveCus()


                    SqlStatus.Update()
                    UpdateLINEID()
                    'สำหรับ DataMining
                    'If ddStatus.SelectedValue = 3 Then
                    '    InsertBaseDataMinning_bk()
                    '    UpdateBaseDataMinning_bk()
                    'End If

                    Select Case Request.Cookies("UserLevel").Value
                        Case 5
                            Response.Redirect("frmCase.aspx")
                        Case 12
                            Response.Redirect("frmCase.aspx")

                        Case Else
                            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.close();</script>")
                    End Select
                End If
            Else
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้ เนื่องจากวันคุ้มครองน้อยกว่า 20 วัน ไม่สามารถเลือกสถานะ Follow/CallBack ได้');", True)
            End If
        Else
            If chkSelectLINE() = False Then
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('กรุณาเลือกข้อมูล LIND');", True)
            End If
        End If
        'Catch ex As Exception
        '    MsgBox(ex.Message)
        'End Try

        DaiNgernPoll()

    End Sub

    'Protected Sub InsertBaseDataMinning_bk()
    '    With SqlDataMining
    '        .InsertParameters("FNameTH").DefaultValue = frmCus.DataKey.Item(7)
    '        .InsertParameters("LNameTH").DefaultValue = frmCus.DataKey.Item(8)
    '        .Insert()
    '    End With
    'End Sub
    Protected Function chk90() As Boolean
        Dim chk As Boolean
        Conn.Open()
        If (ddStatus.SelectedValue = 6 Or ddStatus.SelectedValue = 8) And (Request.Cookies("TypeTsr").Value = 1) Then
            Dim strqrychk As String = ""
            strqrychk += " SELECT case when year(carbuydate) <YEAR(GETDATE()) then datediff(day,getdate(),DATEADD(year,datediff(YEAR,CarBuyDate,GETDATE()),CarBuyDate)) else datediff(day,GETDATE(),carbuydate) end as cday FROM TblCar  where IdCar=" & frmCar.DataKey.Item(0)
            Dim Command As SqlCommand
            Dim DataReader As SqlDataReader
            Dim cday As Integer = 0
            Command = New SqlCommand(strqrychk, Conn)
            DataReader = Command.ExecuteReader()
            If DataReader.HasRows Then
                While DataReader.Read
                    If IsDBNull(DataReader("cday")) = False Then
                        cday = DataReader("cday")
                    End If
                End While
            End If
            DataReader.Close()
            If cday > 20 Then
                chk = True
            Else
                chk = False
            End If
        Else
            chk = True
        End If
        Conn.Close()
        Return chk
    End Function
    Protected Function chkFollow2D() As Boolean
        Dim chk As Boolean
        'Follow and typetsr=1
        If (Request.Cookies("TypeTsr").Value = 1) And (ddStatus.SelectedValue = 6) Then

            Dim AppointDate As DateTime = CDate(SortDateAppoint())
            Dim DateNow As DateTime = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy")) & " " & Now.Hour.ToString & ":" & Now.Minute.ToString)
            Dim nday As Integer
            nday = DateDiff(DateInterval.Day, CDate(DateNow), CDate(AppointDate))

            If nday > 2 Then
                chk = False
                MsgBox("ไม่สามารถนัดเวลาดังกล่าวได้เนื่องจากสถานะ Follow ระยะห่างในการนัดได้สูงสุด 2 วัน , ซึ่งขณะนี้ห่าง  " & nday & " วัน ")
            Else
                chk = True
            End If

        Else
            chk = True
        End If
        Return chk
    End Function

    'Protected Sub UpdateBaseDataMinning_bk()
    '    'Tel2,OTel2,Mobile2,OthTel2,OthTel3,TelExt,OTelExt,OthTel1,OthTel1Ext,OthTel3Ext
    '    With SqlDataMining
    '        .UpdateParameters("Tel").DefaultValue = frmTel.DataKey.Item(0).ToString
    '        .UpdateParameters("TelExt").DefaultValue = frmTel.DataKey.Item(5).ToString
    '        .UpdateParameters("OTel").DefaultValue = frmTel.DataKey.Item(1).ToString
    '        .UpdateParameters("OTelExt").DefaultValue = frmTel.DataKey.Item(6).ToString
    '        .UpdateParameters("Mobile").DefaultValue = frmTel.DataKey.Item(2).ToString
    '        .UpdateParameters("OthTel1").DefaultValue = frmTel.DataKey.Item(7).ToString
    '        .UpdateParameters("OthTel2").DefaultValue = frmTel.DataKey.Item(4).ToString
    '        .UpdateParameters("creditCARD").DefaultValue = frmApp.DataKey.Item(5).ToString
    '        .UpdateParameters("ACQ_FNAME").DefaultValue = frmCus.DataKey.Item(7)
    '        .UpdateParameters("ACQ_LNAME").DefaultValue = frmCus.DataKey.Item(8)
    '        .Update()
    '    End With
    'End Sub


    ''คำนวณ Status ของ Customer
    Protected Sub btnSaveCus()
        Dim CntStatusDB As Integer = frmCus.DataKey.Item(2)
        Dim CurStatusDB As String = frmCus.DataKey.Item(1)
        Dim StatusCur As String = ddStatus.SelectedValue


        If StatusCur = CurStatusDB Then

            If StatusCur = "8" And CntStatusDB >= 5 And Request.Cookies("TypeTsr").Value <> 6 And Request.Cookies("TypeTsr").Value <> 3 And Request.Cookies("TypeTsr").Value <> 11 Then 'CallBack = 7 to AbanDon ยกเว้น webasn ปีต่อ
                UpdateStatus("13", "0")
            ElseIf StatusCur = "8" And CntStatusDB >= 10 And Request.Cookies("TypeTsr").Value = 6 Then 'CallBack = 10 to AbanDon TypeTsr 6 (WebAsn)
                UpdateStatus("13", "0")

            ElseIf StatusCur = "6" And CntStatusDB >= 10 And Request.Cookies("TypeTsr").Value <> 6 And Request.Cookies("TypeTsr").Value <> 3 Then 'Follow Unlimit to Three Plus
                UpdateStatus("15", "0")
            ElseIf StatusCur = "7" And CntStatusDB >= 3 And Request.Cookies("TypeTsr").Value <> 3 And Request.Cookies("TypeTsr").Value <> 11 Then 'NoContact = 7 to Unreach ยกเว้นปีต่อ
                UpdateStatus("14", "0")
            Else
                UpdateStatus(StatusCur, (CntStatusDB + 1).ToString)
            End If

        Else
            UpdateStatus(StatusCur, "0")
        End If

    End Sub

    'Update Status Customer
    Protected Sub UpdateStatus(ByVal CurStatus As String, ByVal CntStatus As String)

        com = New SqlCommand(StrQuery.UpdateCus, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@CurStatus", SqlDbType.Int).Value = CurStatus
            .Parameters.Add("@CntStatus", SqlDbType.Int).Value = CntStatus
            .Parameters.Add("@Comments", SqlDbType.VarChar).Value = DirectCast(frmComments.FindControl("txtComments"), TextBox).Text.Trim
            .Parameters.Add("@AppointDate", SqlDbType.DateTime).Value = SortDateAppoint()
            .Parameters.Add("@IsAppoint", SqlDbType.Bit).Value = 1
            .Parameters.Add("@UpdateID", SqlDbType.Int).Value = Request.Cookies("userID").Value
            .Parameters.Add("@IDCar", SqlDbType.Int).Value = Request.QueryString("IdCar").ToString
            .Parameters.Add("@RefNo", SqlDbType.VarChar).Value = GetRefNo()
            .CommandTimeout = 50
            .ExecuteNonQuery()

        End With

        SaveTblCall(CurStatus, CntStatus)

        With SqlCaseAppointFirst
            .UpdateParameters("IdCar").DefaultValue = Request.QueryString("IdCar").ToString
            .Update()
        End With

        If (CurStatus = "3" Or CurStatus = "4") And chkAutoPassQC() Then
            'TblLogAutoPassQC-5677
            With SqlTblLogAutoPassQC
                .UpdateParameters("UpdateID").DefaultValue = Request.Cookies("userID").Value
                .UpdateParameters("IDCar").DefaultValue = Request.QueryString("IdCar").ToString
                .Update()
            End With
            With SqlTblLogAutoPassQC
                .InsertParameters("AppID").DefaultValue = frmApp.DataKey.Item(0)
                .InsertParameters("IDcar").DefaultValue = Request.QueryString("IdCar").ToString
                .InsertParameters("StausCar_Old").DefaultValue = CurStatus
                .Insert()
            End With


            With SqlLogQC
                .UpdateParameters("UpdateID").DefaultValue = Request.Cookies("userID").Value
                .UpdateParameters("AppID").DefaultValue = frmApp.DataKey.Item(0)
                .Update()
            End With

            ''''''''''''''''''''''' ส่งไปตัดบัตร
            Dim strqry As String = "  SELECT TblAppPay.AppID,tblapplication.cusid, TblAppCard.Bankid, TblAppCard.CardNo1, TblAppCard.CardNo2, TblAppCard.CardExp, TblAppPay.TotalPay, TblAppPay.PayID,tblapplication.idcar " + _
                      " FROM TblAppPay INNER JOIN TblAppCard ON TblAppPay.AppID = TblAppCard.Appid   inner join tblapplication on tblapppay.appid = tblapplication.appid" + _
                      " Where (TblAppPay.Typepay = 2) And (tblapppay.ispaid = 0) and (TblAppPay.PayID = 1) and len(tblappcard.cardno1) = 16 and len(tblappcard.cardexp) = 4  and tblappcard.cardrun = 1 and TblAppPay.appid = '" & frmApp.DataKey.Item(0) & "' "
            Dim dt As DataTable = New DataTable
            dt = DataAccess.DataRead(strqry)


            strqry = " SELECT TblApplication.AppID, TblApplication.statusqc,TblUser.TypeTsr,TblApplication.flagsend,TblApplication.ProDuctID FROM TblApplication INNER JOIN TblUser ON TblApplication.CreateID = TblUser.UserID Where (TblApplication.appid = '" & frmApp.DataKey.Item(0) & "') "

            Dim dt3 As DataTable = New DataTable
            dt3 = New DataTable
            dt3 = DataAccess.DataRead(strqry)

            strqry = "select * from tblcardapprove where appid = '" & frmApp.DataKey.Item(0) & "' and comment = 'QC' and appvSTATUS = 2"

            Dim dt9 As DataTable = New DataTable
            dt9 = New DataTable
            dt9 = DataAccess.DataRead(strqry)


            'Update AppNo กรณีเป็นบริษัท TPB เพื่อลงเลขรับแจ้ง
            If dt3.Rows(0).Item("ProDuctID") = 71 Then
                Dim Str As String = "update tblapplication set  AppNo = '" & frmApp.DataKey.Item(0) & "'where appid = '" & frmApp.DataKey.Item(0) & "'"
                com = New SqlCommand(Str, Conn)
                With com
                    .CommandTimeout = 50
                    .ExecuteNonQuery()
                End With
            End If

            Dim StrQueryApplication As New QueryApplication
            com = New SqlCommand(StrQueryApplication.UpdateTblApplicationAutoQC, Conn)
            With com
                .Parameters.Clear()
                .Parameters.Add("@updateid", SqlDbType.Int).Value = Request.Cookies("userID").Value
                .Parameters.Add("@appid", SqlDbType.Int).Value = frmApp.DataKey.Item(0)
                .CommandTimeout = 50
                .ExecuteNonQuery()
            End With

            With SqlLogQC
                .InsertParameters("appid").DefaultValue = frmApp.DataKey.Item(0)
                .InsertParameters("useridqc").DefaultValue = "3293"
                .InsertParameters("comment1").DefaultValue = "Qc ผ่าน [AUTO]"
                .Insert()
            End With
            If dt.Rows.Count <> 0 And dt9.Rows.Count <= 0 And dt3.Rows(0).Item("statusqc") <> 0 And dt3.Rows(0).Item("statusqc") <> 9 And dt3.Rows(0).Item("statusqc") <> 2 And dt3.Rows(0).Item("statusqc") <> 3 And dt3.Rows(0).Item("statusqc") <> 10 Then
                com = New SqlCommand(StrQueryApplication.InsertTblcardapproveAutoQC, Conn)
                With com
                    .Parameters.Clear()
                    .Parameters.Add("@CusID", SqlDbType.Int).Value = dt.Rows(0).Item("cusid")
                    .Parameters.Add("@idCAR", SqlDbType.Int).Value = dt.Rows(0).Item("idcar")
                    .Parameters.Add("@appID", SqlDbType.Int).Value = frmApp.DataKey.Item(0)
                    .Parameters.Add("@bankID", SqlDbType.Int).Value = dt.Rows(0).Item("bankid")
                    .Parameters.Add("@cardNO1", SqlDbType.VarChar).Value = dt.Rows(0).Item("CardNo1")
                    .Parameters.Add("@cardNO2", SqlDbType.VarChar).Value = dt.Rows(0).Item("CardNo2")
                    .Parameters.Add("@cardEXP", SqlDbType.VarChar).Value = dt.Rows(0).Item("CardExp")
                    .Parameters.Add("@payVALUE", SqlDbType.Money).Value = dt.Rows(0).Item("TotalPay")
                    .Parameters.Add("@payNO", SqlDbType.Int).Value = dt.Rows(0).Item("PayID")
                    .Parameters.Add("@appvSTATUS", SqlDbType.Int).Value = 1
                    .Parameters.Add("@appvCODE", SqlDbType.VarChar).Value = "WA"
                    .Parameters.Add("@createID", SqlDbType.Int).Value = Request.Cookies("userID").Value
                    .Parameters.Add("@comment", SqlDbType.VarChar).Value = "QC"
                    .CommandTimeout = 50
                    .ExecuteNonQuery()
                End With

            End If
            If dt3.Rows(0).Item("statusqc") <> 0 And dt3.Rows(0).Item("statusqc") <> 9 And dt3.Rows(0).Item("statusqc") <> 2 And dt3.Rows(0).Item("statusqc") <> 3 And dt3.Rows(0).Item("statusqc") <> 10 Then
                If dt3.Rows(0).Item("typetsr") = 100 Or dt3.Rows(0).Item("typetsr") = 200 Or dt3.Rows(0).Item("typetsr") = 201 Then

                Else
                    '0=ไม่ส่งเอกสาร ,1=ส่งเอกสารปกติ
                    If dt3.Rows(0).Item("flagsend") = 1 Then
                        Print_CV_Payment(frmApp.DataKey.Item(0))
                    End If
                    Auto_File(frmApp.DataKey.Item(0))

                End If
            End If

        End If
    End Sub
    'Insert TblCall
    Protected Sub SaveTblCall(ByVal CurStatus As String, ByVal Cntstatus As String)
        Dim txtComments As TextBox = DirectCast(frmComments.FindControl("txtComments"), TextBox)

        'Try

        com = New SqlCommand(StrQuery.SaveTblCall(), Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@CarID", SqlDbType.Int).Value = frmCus.DataKey.Item(3)
            .Parameters.Add("@IsOutbound", SqlDbType.Int).Value = 1
            .Parameters.Add("@CallOrder", SqlDbType.Int).Value = 0
            .Parameters.Add("@SubStatusID", SqlDbType.Int).Value = ddSubStatus.SelectedValue
            .Parameters.Add("@CntSubStatus", SqlDbType.Int).Value = Cntstatus
            .Parameters.Add("@CallDetail", SqlDbType.VarChar).Value = txtComments.Text.Trim
            .Parameters.Add("@StartTime", SqlDbType.DateTime).Value = ViewState("StartTime")
            .Parameters.Add("@CreateID", SqlDbType.Int).Value = Request.Cookies("userID").Value
            .Parameters.Add("@UpdateID", SqlDbType.Int).Value = Request.Cookies("userID").Value
            .Parameters.Add("@StatusID", SqlDbType.Int).Value = CurStatus
            .Parameters.Add("@telNUMBER", SqlDbType.VarChar).Value = GetPhoneNumber()
            .Parameters.Add("@IsNew", SqlDbType.VarChar).Value = frmCus.DataKey.Item(6)
            .Parameters.Add("@perCloseApp", SqlDbType.VarChar).Value = ddPercent.SelectedValue
            .CommandTimeout = 50
            .ExecuteNonQuery()
        End With

        'Catch ex As Exception
        '    MsgBox(ex.ToString)
        'End Try


    End Sub

    'Update Application
    Protected Sub UpdateApplication()
        com = New SqlCommand(StrQuery.UpdateApp, Conn)
        Dim userqc As String = GetUserQc()
        With com
            .Parameters.Clear()
            .Parameters.Add("@userIDQc", SqlDbType.VarChar).Value = userqc
            .Parameters.Add("@AppIP", SqlDbType.NVarChar).Value = "\\" & Request.ServerVariables("REMOTE_ADDR") & "\Recorder"
            .Parameters.Add("@userID", SqlDbType.NVarChar).Value = Request.Cookies("userID").Value
            .Parameters.Add("@TypeTsr", SqlDbType.NVarChar).Value = Request.Cookies("TypeTsr").Value
            .Parameters.Add("@AppID", SqlDbType.VarChar).Value = frmApp.DataKey.Item(0)
            .ExecuteNonQuery()
        End With

        'ลบลำดับ

        If userqc <> "684" Then
            Dim strqrychk As String = ""
            strqrychk += " select autoid,useridqc from tbl_LogAssignSaleQc where useridqc=" & userqc
            Dim dt1 As New DataTable
            dt1 = DataAccess.DataRead(strqrychk)

            If dt1.Rows.Count > 0 Then
                strqrychk = " DELETE FROM tbl_LogAssignSaleQc WHERE useridqc=@userID "
                com = New SqlCommand(strqrychk, Conn)
                With com
                    .Parameters.Clear()
                    .Parameters.Add("@userID", SqlDbType.VarChar).Value = userqc
                    .ExecuteNonQuery()
                End With
            End If
            strqrychk = " INSERT INTO tbl_LogAssignSaleQc (useridqc) VALUES ( @userID )"
            com = New SqlCommand(strqrychk, Conn)
            With com
                .Parameters.Clear()
                .Parameters.Add("@userID", SqlDbType.VarChar).Value = userqc
                .ExecuteNonQuery()
            End With
        End If
        'จบ



    End Sub
    Protected Sub UpdateApplicationAutoPass()
        com = New SqlCommand(StrQuery.UpdateApp, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@userIDQc", SqlDbType.VarChar).Value = "3293"
            .Parameters.Add("@AppIP", SqlDbType.NVarChar).Value = "\\" & Request.ServerVariables("REMOTE_ADDR") & "\Recorder"
            .Parameters.Add("@userID", SqlDbType.NVarChar).Value = Request.Cookies("userID").Value
            .Parameters.Add("@TypeTsr", SqlDbType.NVarChar).Value = Request.Cookies("TypeTsr").Value
            .Parameters.Add("@AppID", SqlDbType.VarChar).Value = frmApp.DataKey.Item(0)
            .ExecuteNonQuery()
        End With

    End Sub

    'TblRecruit
    Protected Sub InsertTblRecruit()
        If frmRecruit.DataItemCount = 0 And Request.Cookies("TypeTsr").Value = 6 Then
            Dim ddStatus As DropDownList = FunAll.ObjFindControl("ddStatus", frmRecruit)
            Dim txtComments As TextBox = FunAll.ObjFindControl("txtComments", frmRecruit)
            If ddStatus.SelectedValue > 0 Then
                With SqlRecruit
                    .InsertParameters("StatusID").DefaultValue = ddStatus.SelectedValue
                    .InsertParameters("ReDesc").DefaultValue = txtComments.Text.Trim
                    .Insert()
                End With
            End If

        End If

    End Sub

    'Check การกรอกข้อมูล
    Protected Function ChkData() As Boolean

        frmTel.DataBind()
        If frmTel.DataKey.Item(0).ToString = "" And frmTel.DataKey.Item(1).ToString = "" And frmTel.DataKey.Item(2).ToString = "" And frmTel.DataKey.Item(3).ToString = "" And frmTel.DataKey.Item(4).ToString = "" Then
            MsgBox("กรุณากรอกเบอร์ลูกค้าอย่างน้อย 1 เบอร์ในระบบ")
            Return False

        End If

        If ddStatus.SelectedValue = 6 And ddPercent.SelectedValue = 0 Then
            MsgBox("กรุณาใส่ Percent (%) การปิดApp")
            Return False
        End If

        If ddStatus.SelectedValue = 99 Then
            MsgBox("กรุณาเลือกสถานะ")
            Return False
        ElseIf ddStatus.SelectedValue <> 3 And ddStatus.SelectedValue <> 4 And ddStatus.SelectedValue <> 5 And ddStatus.SelectedValue <> 27 And ddStatus.SelectedValue <> 9 And ddStatus.SelectedValue <> 41 And ddStatus.SelectedValue <> 12 And ddStatus.SelectedValue <> 11 And ddStatus.SelectedValue <> 7 And ddStatus.SelectedValue <> 38 Then

            If txtMin.Text.Trim = "" Or txtHour.Text.Trim = "" Then
                MsgBox("กรุณากรอกวันและเวลาให้ครบ")
                Return False

            ElseIf txtMin.Text.Trim > 60 Then
                MsgBox("เวลาของคุณผิดพลาด : นาทีต้องไม่เกิน 60")
                Return False
            ElseIf txtHour.Text.Trim > 24 Then
                MsgBox("เวลาของคุณผิดพลาด : ชั่วโมงต้องไม่เกิน 24")
                Return False
            Else
                Return True
            End If
        ElseIf ddStatus.SelectedValue = 3 Or ddStatus.SelectedValue = 4 Or ddStatus.SelectedValue = 25 Or ddStatus.SelectedValue = 26 Then

            If txtMin.Text.Trim = "" Or txtHour.Text.Trim = "" Then
                MsgBox("กรุณาระบุวันที่")
                Return False
            ElseIf txtMin.Text.Trim > 59 Or txtHour.Text > 24 Then
                MsgBox("กรุณาระบุเวลาผิดพลาด")
                Return False
            End If

            frmApp.DataBind()
            If frmApp.DataItemCount = 0 Then
                MsgBox("ไม่สามารถบันทึกได้เนื่องจากยังไม่มี App")
                Return False
            Else
                If frmApp.DataKey.Item(6).ToString = "" And frmApp.DataKey.Item(8) = "True" Then
                    MsgBox("กรุณาระบุเลขบัตรประชาชน ประกันสมัครใจ")
                    Return False
                End If

                If frmApp.DataKey.Item(7).ToString = "" And frmApp.DataKey.Item(9) = "True" Then
                    MsgBox("กรุณาระบุเลขบัตรประชาชน พรบ.")
                    Return False
                End If

                If checkAppPay() = False Then
                    MsgBox("ไม่มีข้อมูลงวดชำระเงิน")
                    Return False
                End If


                Return True

            End If
        Else
            Return True
        End If
    End Function

    Protected Function checkAppPay() As Boolean
        SqlAppPay.SelectParameters("appid").DefaultValue = frmApp.DataKey.Item(0)
        Dim dvSql As DataView = DirectCast(SqlAppPay.Select(DataSourceSelectArguments.Empty), DataView)
        If dvSql.Count > 0 Then

            Return True
        Else
            Return False
        End If
    End Function

    'Check การกรอกวันที่
    Protected Function CheckAppointDate() As Boolean
        Try

            If ddStatus.SelectedValue <> 5 And ddStatus.SelectedValue <> 38 And ddStatus.SelectedValue <> 27 And ddStatus.SelectedValue <> 9 And ddStatus.SelectedValue <> 41 And ddStatus.SelectedValue <> 12 And ddStatus.SelectedValue <> 11 Or ddStatus.SelectedValue <> 7 Then
                Dim AppointDate As DateTime = CDate(SortDateAppoint())
                Dim DateNow As DateTime = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy")) & " " & Now.Hour.ToString & ":" & Now.Minute.ToString)

                If AppointDate < DateNow Then
                    MsgBox("ไม่สามารถนัดเวลาน้อยกว่าเวลาปัจจุบันได้ : " & DateNow & " < " & AppointDate)
                    Return False

                Else
                    Return True
                End If
            Else
                Return True
            End If
        Catch ex As Exception
            MsgBox("fotmat วันที่ผิดพลาด : จะต้องเป็น วัน/เดือน/ปี")
            Return False
        End Try


    End Function

    'จัดการเรียง วันที่นัด  วว ดด ปปปป  hh:mm
    Protected Function SortDateAppoint() As String
        'Dim AppointDateCV As String = ISODate.SetISODate("th", tbDay.Text.Trim & "/" & ddMonth.SelectedValue & "/" & ddYear.SelectedValue) & " " & tbHour.Text.Trim & ":" & tbMin.Text.Trim

        Dim AppointDateCV As String = ""
        If ddStatus.SelectedValue <> 5 And ddStatus.SelectedValue <> 27 And ddStatus.SelectedValue <> 9 And ddStatus.SelectedValue <> 41 And ddStatus.SelectedValue <> 12 And ddStatus.SelectedValue <> 11 And ddStatus.SelectedValue <> 7 And ddStatus.SelectedValue <> 38 Then
            Dim strdate As DateTime = ISODate.SetISODate("th", txtAppoint.Text)
            AppointDateCV = ISODate.SetISODate("th", strdate.ToString("dd/MM/yyyy")) & " " & txtHour.Text.Trim & ":" & txtMin.Text.Trim
        ElseIf ddStatus.SelectedValue = 7 Then
            Dim date1 As DateTime
            If Date.Now.DayOfWeek = DayOfWeek.Friday And DateTime.Now.Hour >= 14 Then
                date1 = DateTime.Now.AddDays(2)
            Else
                date1 = DateTime.Now.AddHours(4)
            End If
            AppointDateCV = ISODate.SetISODate("th", date1.ToString("dd/MM/yyyy")) & " " & date1.Hour & ":" & date1.Minute
        Else
            AppointDateCV = ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy")) & " " & DateTime.Now.Hour & ":" & DateTime.Now.Minute
        End If


        Return AppointDateCV

    End Function

    'Script MsgBox
    Public Sub MsgBox(ByVal sMsg As String)

        Dim sb As New StringBuilder()
        Dim oFormObject As System.Web.UI.Control
        sMsg = sMsg.Replace("'", "\'")
        sMsg = sMsg.Replace(Chr(34), "\" & Chr(34))
        sMsg = sMsg.Replace(vbCrLf, "\n")
        sMsg = "<script language=javascript>alert(""" & sMsg & """)</script>"

        sb = New StringBuilder()
        sb.Append(sMsg)

        For Each oFormObject In Me.Controls
            If TypeOf oFormObject Is HtmlForm Then
                Exit For
            End If
        Next

        ' Add the javascript after the form object so that the 
        ' message doesn't appear on a blank screen.
        oFormObject.Controls.AddAt(oFormObject.Controls.Count, New LiteralControl(sb.ToString()))
    End Sub

    'gen RefNo
    Protected Function GetRefNo() As String
        If frmCus.DataKey.Item(5).ToString.Length <> 13 Then
            Return FunAll.GetRefCar(frmCus.DataKey.Item(3))
        Else
            Return frmCus.DataKey.Item(5)
        End If
    End Function

    'GetQc
    Protected Function GetUserQc() As String
        dt = New DataTable
        dt = DataAccess.DataRead(StrQuery.SelectUserQc(GetTblAppPay))
        If dt.Rows.Count > 0 Then
            Dim str As String = dt.Rows(0).Item("useridqc").ToString
            Return dt.Rows(0).Item("useridqc")
        Else
            dt = New DataTable
            dt = DataAccess.DataRead(StrQuery.SelectUserQc("5"))
            If dt.Rows.Count > 0 Then
                Return dt.Rows(0).Item("useridqc")
            Else
                Return "3293"  'Nusataqc
            End If


        End If
    End Function

    Protected Function GetTblAppPay() As String
        dt = New DataTable
        dt = DataAccess.DataRead(StrQuery.SelectTblTypetsr(frmApp.DataKey.Item(0)))
        Dim strAppPay As String = ""
        If dt.Rows.Count > 0 Then
            If dt.Rows(0).Item("TypeTsr") = 3 Then
                strAppPay = "1" 'renew
            Else
                strAppPay = "2" 'out
            End If
        Else
            MsgBox("ไม่พบข้อมูล")
        End If


        Return strAppPay
    End Function

#Region "TakePhoto"
    'CheckProTypeID
    Protected Function ChkProType(ByVal ProID As String) As Boolean

        dt = New DataTable
        dt = DataAccess.DataRead(StrQuery.SelectTblProduct(ProID))
        If dt.Rows.Count > 0 And frmApp.DataKey.Item(2) = 1 Then
            If dt.Rows(0).Item("StatusPhoto") = True Then
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If

    End Function

    Protected Function ChkRider() As Boolean
        If ddStatus.SelectedValue = 4 Or ddStatus.SelectedValue = 3 Then
            If ChkProType(frmApp.DataKey.Item(1)) = True And frmApp.DataKey.Item(2) = 1 And TakePhotoOldApp() = True Then
                Return ChkTblAppointTakePhoto(frmCar.DataKey.Item(0), frmApp.DataKey.Item(0))
            Else
                Return True
            End If
        Else
            Return True
        End If
    End Function

    'Check App Photo สำหรับ ปีต่ออายุ
    Protected Function TakePhotoOldApp() As Boolean
        If Request.Cookies("TypeTsr").Value = 3 Or Request.Cookies("TypeTsr").Value = 11 Then
            Dim strqry As String = "select * from  TmpApp_CustRenew a1 Where IdCar =  " & frmCar.DataKey.Item(0)
            strqry += "  and a1.AppStatus = 1 and a1.FlagNewApp = 0"
            strqry += "  order by a1.CreateDate DESC "
            dt = New DataTable
            dt = DataAccess.DataRead(strqry)
            If dt.Rows.Count > 0 Then
                If dt.Rows(0).Item("ProductID") = frmApp.DataKey.Item(1) Then
                    'กรณีต่ออายุ และบริษัทประกันเดิมไม่ต้องให้ ASN ถ่ายรูป
                    Return False
                Else
                    Return True
                End If
            Else
                Return True
            End If
        Else
            Return True

        End If
    End Function

    'Check TblAppointTakePhoto
    Protected Function ChkTblAppointTakePhoto(ByVal IdCar As Integer, ByVal AppID As Integer) As Boolean
        Dim dtChk As New DataTable
        dtChk = GetTblAppointPhotos(IdCar)
        If dtChk.Rows.Count > 0 Then
            If dtChk.Rows(0).Item("Flag") <> 0 Then
                SqlRecruitStatus.DeleteParameters("appID").DefaultValue = AppID
                SqlRecruitStatus.Delete()
                InsertTblTakePhoto(dtChk, AppID)
                Return True
            Else
                Return True
            End If

        Else
            MsgBox("ไม่สามารถบันทึกได้ ไม่มีข้อมูลถ่ายรูปรถ")
            Return False
        End If
    End Function

    'ค้นหา TblAppointTakephoto
    Protected Function GetTblAppointPhotos(ByVal IdCar As String) As DataTable
        dtGetAppPhotos = New DataTable
        dtGetAppPhotos = DataAccess.DataRead(StrQuery.BindTblAppointTakephoto(IdCar))
        Return dtGetAppPhotos
    End Function

    Protected Sub InsertTblTakePhoto(ByVal dtPhoto As DataTable, ByVal AppID As Integer)
        com = New SqlCommand(StrQuery.InsertTblTakePhoto, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@CusID", SqlDbType.VarChar).Value = frmCus.DataKey.Item(0)
            .Parameters.Add("@idCAR", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("IdCar")
            .Parameters.Add("@appID", SqlDbType.VarChar).Value = AppID
            .Parameters.Add("@phID", SqlDbType.VarChar).Value = 2
            .Parameters.Add("@tID", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("tID")
            .Parameters.Add("@createID", SqlDbType.VarChar).Value = Request.Cookies("userID").Value
            .Parameters.Add("@appointDATE", SqlDbType.DateTime).Value = ISODate.SetISODate("th", CDate(dtPhoto.Rows(0).Item("appointDATE")).ToString("dd/MM/yyyy"))
            .Parameters.Add("@appointCOMMENT", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("Name")
            .Parameters.Add("@provinceDEST", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("Province")
            .Parameters.Add("@mainDEST", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("Dist")
            .Parameters.Add("@Destination", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("SubDist")
            .ExecuteNonQuery()
        End With


        com = New SqlCommand(StrQuery.UpdateAppTakePhoto, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@AppID", SqlDbType.VarChar).Value = AppID
            .ExecuteNonQuery()
        End With
    End Sub

#End Region
#End Region

    Protected Sub WebImageButton2_Click(ByVal sender As Object, e As System.EventArgs) Handles WebImageButton2.Click
        Select Case Request.Cookies("UserLevel").Value
            Case 5
                Response.Redirect("frmCase.aspx")
            Case 12
                Response.Redirect("frmCase.aspx")
            Case Else
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.close();</script>")
        End Select

    End Sub

    Protected Sub frmComments_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmComments.DataBound
        Dim txtComments As TextBox = FunAll.ObjFindControl("txtComments", frmComments)
        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)
        Dim strAddr As String = ""
        If ddDist.Items.Count = 0 Then

            strAddr += "|" & frmAddr.DataKey.Item(0).ToString.Trim
        End If

        If ddSubDist.Items.Count = 0 Then

            strAddr += "|" & frmAddr.DataKey.Item(1).ToString.Trim
        End If

        If ddZipCode.Items.Count = 0 Then

            strAddr += "|" & frmAddr.DataKey.Item(2).ToString.Trim
        End If

        If InStr(txtComments.Text.Trim, strAddr) Then
            txtComments.Text = Replace(txtComments.Text, strAddr, strAddr)
        Else
            txtComments.Text += strAddr
        End If
    End Sub

    Protected Sub WebImageButton4_Click(sender As Object, e As System.EventArgs) Handles WebImageButton4.Click
        Dim strlink As String = ""
        strlink = Request.QueryString("IdCar").ToString
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script> window.open ('http://10.17.1.230/tm4/" & strlink & "');</script>")
        'Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script> window.open ('file:///D:/" & strlink & "');</script>")
    End Sub

    Protected Sub WebImageButton5_Click(sender As Object, e As System.EventArgs) Handles WebImageButton5.Click
        Dim strLink As String = "Edit=0&Buy=3"
        strLink += "&IdCar=" & frmCar.DataKey.Item(0)
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.open('../Application/frmApplication.aspx?" & strLink & "','Application');</script>")
    End Sub


    Protected Sub ddSubStatus_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddSubStatus.SelectedIndexChanged
        'LinkSoftPhone()
    End Sub



    'Protected Sub Button3_Click(sender As Object, e As System.EventArgs) Handles Button3.Click
    '    With SqlDataMining
    '        .SelectParameters("FNameTH").DefaultValue = frmCus.DataKey.Item(7)
    '        .SelectParameters("LNameTH").DefaultValue = frmCus.DataKey.Item(8)
    '        .SelectParameters("BRAND_D").DefaultValue = frmCar.DataKey.Item(1)
    '    End With
    '    GvDataMind.Visible = True
    '    GvDataMind.DataBind()
    'End Sub

    Protected Sub frmCar_DataBound(sender As Object, e As System.EventArgs) Handles frmCar.DataBound
        If frmCar.DataItemCount > 0 Then
            SqlStatus.SelectParameters("StatusID").DefaultValue = frmCar.DataKey.Item(2)
        End If
    End Sub
    Protected Sub btnScript_Click(sender As Object, e As System.EventArgs) Handles btnScript.Click
        '1.ค้นหา APP
        Dim dtAppID As New System.Data.DataTable
        Dim dv As DataView = DirectCast(SqlAppConfirm.Select(DataSourceSelectArguments.Empty), DataView)
        dtAppID = dv.ToTable()
        If dtAppID.Rows.Count > 0 Then
            strappid = dtAppID.Rows(0)("AppID").ToString()
            '2.
            SetScript(strappid)
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "sett", "sett();", True)
        Else
            SetScript(0)
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "sett", "sett();", True)
            'Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ค้นหา APP ไม่พบกรุณาตรวจสอบ');", True)
        End If

    End Sub
    Protected Sub SetScript(ByVal strappid As String)

        Dim query = New System.Text.StringBuilder()
        query.Append(" select a.AppID,a.Idcar,d.InitTH+' '+c.FNameTH+' '+c.LNameTH as cusname,b.CarID, ")
        query.Append(" b.CarBrand,")
        query.Append(" b.CarSeries,")
        query.Append(" isnull(b.CarSize,'') as CarSize")
        query.Append(" ,e.ProTypeName,a7.TypeName,")
        query.Append(" case a.IsCarpet when 1 then a.CarPet else 0 end as Carpet,")
        query.Append(" case a.IsCarpet when 1 then CONVERT(VARCHAR,a.ProtectDateCarpet,103) else 'ไม่ระบุ'  end as ProtectDateCarpet,")
        query.Append(" case a.IsCarpet when 1 then 'โดยเริ่มคุ้มครองวันที่(พรบ.)' else ''  end as lblProtectDateCarpet,")
        query.Append(" case a.IsCarpet when 1 then 'รวม พรบ.' else 'ไม่รวม พรบ.'  end as lblCarpet,")
        query.Append(" CAST(a.ProValue as money)+ CAST(a.CarPet as money) as ProValue,")
        query.Append(" case a.IsProvalue when 1 then CONVERT(VARCHAR,a.ProtectDate,103) else 'ไม่ระบุ' end as ProtectDate,")
        query.Append(" case a.IsProvalue when 1 then CAST(a.Car_Fire as money) else 0 end as Car_Fire,")
        query.Append(" case b.CarFixIn when '1' then 'ซ่อมอู่'  else 'ซ่อมห้าง' end as IsFixIn ,")
        query.Append(" (select count(*) from tblapppay where appid=a.AppID) as CPay,")
        query.Append(" case b.CarDriverNo when 0  then 'ไม่เป็นแบบระบุชื่อผู้ขับขี่'  else 'เป็นแบบระบุชื่อผู้ขับขี่' end as lblCarDriverNo ,")
        query.Append(" case b.CarDriverNo when 0  then ''  else CAST(b.CarDriverNo as varchar) end as CarDriverNo , ")
        query.Append(" case b.CarDriverNo when 0  then ''  else 'ท่าน(กรณีทำประกันประเภทระบุชื่อผู้ขับขี่)' end as lbl ,")
        query.Append(" case f.IsPayDate when 1 then CONVERT(VARCHAR, f.PayDate,103) else 'ไม่ระบุ' end as PayDate ")
        query.Append(" from tblapplication a  ")
        query.Append(" inner join tblcar b on a.Idcar=b.idcar ")
        query.Append(" inner join tblcustomer c on b.CusID=c.cusid ")
        query.Append(" inner join TblCustomerInit d on d.InitID=c.InitID")
        query.Append(" Inner Join Tbl_ProductType a6 on a.ProductID = a6.ProTypeID")
        query.Append(" Inner Join Tbl_Type a7 on a.Typeprovalue = a7.TypeID")
        query.Append(" Left  Join Tbl_ProductType e on  e.ProTypeID=a.ProDuctID")
        query.Append(" Left  Join TblAppCard f on a.AppID=f.AppID")
        query.Append(" where a.AppID =" & strappid)


        Dim da As SqlDataAdapter = New SqlDataAdapter(query.ToString, Conn)
        Dim table As DataTable = New DataTable
        da.Fill(table)
        If table.Rows.Count > 0 Then
            HFAppID.Value = table.Rows(0)("AppID").ToString
            txtCarID.Text = table.Rows(0)("CarID").ToString
            txtCarBrand.Text = table.Rows(0)("CarBrand").ToString
            txtCarSeries.Text = table.Rows(0)("CarSeries").ToString
            txtCarSize.Text = table.Rows(0)("CarSize").ToString
            txtProTypeName.Text = table.Rows(0)("ProTypeName").ToString
            txtTypeName.Text = table.Rows(0)("TypeName").ToString
            txtProtectDate.Text = table.Rows(0)("ProtectDate").ToString
            lblProtectDateCarprt.Text = table.Rows(0)("lblProtectDateCarpet").ToString
            txtProtectDateCarprt.Text = table.Rows(0)("ProtectDateCarpet").ToString
            lblCarDriverNo.Text = table.Rows(0)("lblCarDriverNo").ToString
            txtCarDriverNo.Text = table.Rows(0)("CarDriverNo").ToString
            Label13.Text = table.Rows(0)("lbl").ToString
            lblCarpet.Text = table.Rows(0)("lblCarpet").ToString
            txtCar_Fire.Text = String.Format(CultureInfo.InvariantCulture, "{0:0,0.00}", table.Rows(0)("Car_Fire"))
            txtIsFixIn.Text = table.Rows(0)("IsFixIn").ToString
            txtProValue.Text = String.Format(CultureInfo.InvariantCulture, "{0:0,0.00}", table.Rows(0)("ProValue"))
            txtPayDate.Text = table.Rows(0)("PayDate").ToString

            SqlAppPayDGVPay.SelectParameters("AppID").DefaultValue = strappid
            DGVPay.DataSource = SqlAppPayDGVPay
            DGVPay.DataBind()

            SqltblapplicationPa.SelectParameters("AppID").DefaultValue = strappid
            FormView1.DataSource = SqltblapplicationPa
            FormView1.DataBind()


            frmAddrConfirm.DataSource = SqlCustomerConfirm
            frmAddrConfirm.DataBind()

            DGVAppCard.DataSource = SqlAppCard2Confirm
            DGVAppCard.DataBind()

            frmCusNameConfirm.DataSource = SqlCustomerConfirm
            frmCusNameConfirm.DataBind()

        Else

            query = New System.Text.StringBuilder()
            query.Append(" select b.Idcar,b.CarID, ")
            query.Append(" b.CarBrand,")
            query.Append(" b.CarSeries,")
            query.Append(" isnull(b.CarSize,'') as CarSize")
            query.Append(" From  tblcar b ")
            query.Append(" inner join tblcustomer c on b.CusID=c.cusid ")
            query.Append(" where b.Idcar =" & Request.QueryString("IdCar").ToString())
            Dim da1 As SqlDataAdapter = New SqlDataAdapter(query.ToString, Conn)
            Dim table1 As DataTable = New DataTable
            da1.Fill(table1)
            HFAppID.Value = "0"
            ' HFidCar.Value = table1.Rows(0)("Idcar").ToString
            '3.
            txtCarID.Text = table1.Rows(0)("CarID").ToString
            txtCarBrand.Text = table1.Rows(0)("CarBrand").ToString
            txtCarSeries.Text = table1.Rows(0)("CarSeries").ToString
            txtCarSize.Text = table1.Rows(0)("CarSize").ToString
            '4.
            txtProTypeName.Text = ""
            txtTypeName.Text = ""
            '5.
            txtProtectDate.Text = ""
            lblProtectDateCarprt.Text = ""
            txtProtectDateCarprt.Text = ""
            lblCarDriverNo.Text = "การระบุผู้ขับขี่"
            txtCarDriverNo.Text = ""
            Label13.Text = ""
            lblCarpet.Text = ""
            txtCar_Fire.Text = ""
            txtIsFixIn.Text = ""
            txtProValue.Text = ""
            txtPayDate.Text = ""

            'DGVPay.DataSource = SqlAppPayDGVPay
            'DGVPay.DataBind()
            frmAddrConfirm.DataSource = SqlCustomerConfirm
            frmAddrConfirm.DataBind()
            DGVAppCard.DataSource = SqlAppCard2Confirm
            DGVAppCard.DataBind()
            frmCusNameConfirm.DataSource = SqlCustomerConfirm
            frmCusNameConfirm.DataBind()
        End If

    End Sub

    Public Sub DaiNgernPoll()
        Dim IsDaiNgern As Int32
        Dim strSQL As String
        Dim dtReader As SqlDataReader
        Conn.Open()
        strSQL = "SELECT * FROM tblDaiNgern_poll where IdCar =" + Convert.ToString(frmCar.DataKey.Item(0))
        com = New SqlCommand(strSQL, Conn)
        dtReader = com.ExecuteReader()

        If dtReader.HasRows Then

            Try
                If RdPollDaiNgern.SelectedValue = 1 Then
                    IsDaiNgern = 1
                ElseIf RdPollDaiNgern.SelectedValue = 2 Then
                    IsDaiNgern = 0
                Else
                    Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('เลือกคำตอบความสนใจโปรเจค-ได้เงิน-ด้วยค่ะ');", True)
                End If
            Catch ex As Exception
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้เนื่องจาก : " & ex.Message & "');", True)
            End Try

            With pollDaiNgern
                .UpdateParameters("IsDaiNgern").DefaultValue = IsDaiNgern
                .Update()
            End With
        Else

            Try

                If RdPollDaiNgern.SelectedValue = 1 Then
                    IsDaiNgern = 1
                ElseIf RdPollDaiNgern.SelectedValue = 2 Then
                    IsDaiNgern = 0
                Else
                    Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('เลือกคำตอบความสนใจโปรเจค-ได้เงิน-ด้วยค่ะ');", True)
                End If

                With pollDaiNgern
                    .InsertParameters("IsDaiNgern").DefaultValue = IsDaiNgern
                    .InsertParameters("IdCar").DefaultValue = IsDaiNgern
                    .Insert()
                End With

            Catch ex As Exception
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้เนื่องจาก : " & ex.Message & "');", True)
            End Try


            dtReader.Close()
            dtReader = Nothing
            Conn.Close()
            Conn = Nothing
        End If
    End Sub
    Protected Function chkSelectLINE() As Boolean
        Dim txtLINEID As TextBox = FunAll.ObjFindControl("txtLINEID", formviewLine)
        Dim RBSelectConditionLINE As RadioButtonList = FunAll.ObjFindControl("RBSelectConditionLINE", formviewLine)
        Dim chk As Boolean
        If RBSelectConditionLINE.SelectedValue = "1" Or RBSelectConditionLINE.SelectedValue = "2" Or RBSelectConditionLINE.SelectedValue = "3" Or RBSelectConditionLINE.SelectedValue = "4" Then
            If (RBSelectConditionLINE.SelectedValue = "1" Or RBSelectConditionLINE.SelectedValue = "2" ) And txtLINEID.Text <> "" Then
                chk = True
            ElseIf (RBSelectConditionLINE.SelectedValue = "3" Or RBSelectConditionLINE.SelectedValue = "4") Then
                chk = True
            Else
                chk = False
            End If

        Else
            chk = False
        End If
        Return chk
    End Function
    'SqlDataSourceLineID
    Protected Sub UpdateLINEID()
        Dim txtLINEID As TextBox = FunAll.ObjFindControl("txtLINEID", formviewLine)
        Dim RBSelectConditionLINE As RadioButtonList = FunAll.ObjFindControl("RBSelectConditionLINE", formviewLine)
        'Dim chklineOff As CheckBox = FunAll.ObjFindControl("chklineOff", formviewLine)
        'Dim intline As Integer = 0
        'If chklineOff.Checked Then
        '    intline = 1
        'End If

        If RBSelectConditionLINE.SelectedValue = "3" Or RBSelectConditionLINE.SelectedValue = "4" Then
            With SqlDataSourceLineID
                .UpdateParameters("LINEID").DefaultValue = ""
                .UpdateParameters("FlagLINE").DefaultValue = RBSelectConditionLINE.SelectedValue
                .UpdateParameters("CusID").DefaultValue = frmCus.DataKey.Item(0)
                .UpdateParameters("flaglineofficial").DefaultValue = 0
                .Update()
            End With
        Else
            With SqlDataSourceLineID
                .UpdateParameters("LINEID").DefaultValue = txtLINEID.Text
                .UpdateParameters("FlagLINE").DefaultValue = RBSelectConditionLINE.SelectedValue
                .UpdateParameters("CusID").DefaultValue = frmCus.DataKey.Item(0)
                .UpdateParameters("flaglineofficial").DefaultValue = 0
                .Update()
            End With
        End If

    End Sub
    Protected Sub RBSelectConditionLINE_SelectedIndexChanged(sender As Object, e As System.EventArgs)
        DefalutLINEID()
    End Sub

    Protected Sub RBSelectConditionLINE_SelectedIndexChanged1(sender As Object, e As System.EventArgs)
        DefalutLINEID()
    End Sub
    Private Sub DefalutLINEID()
        Dim txtLINEID As TextBox = FunAll.ObjFindControl("txtLINEID", formviewLine)
        Dim RBSelectConditionLINE As RadioButtonList = FunAll.ObjFindControl("RBSelectConditionLINE", formviewLine)

        If RBSelectConditionLINE.SelectedValue = "3" Then
            txtLINEID.Text = ""
        End If
    End Sub
    'เอา พรบ.หรือไม่
    Protected Function GetCarPet() As Integer
        If ChkCMI.Checked = True Then
            Return 1
        Else
            Return 0
        End If
    End Function
    Protected Sub btnRenew_Click(sender As Object, e As System.EventArgs) Handles btnRenew.Click
        If FormViewDetailRenew.DataItemCount > 0 Then
            If Request.Cookies("TypeTsr").Value = "3" And FormViewDetailRenew.DataKey.Item(1) <> "0" Then
                'If Request.Cookies("TypeTsr").Value = "3" And FormViewDetailRenew.DataKey.Item(0) <> "0" And FormViewDetailRenew.DataKey.Item(1) <> "0" Then
                'Dim strlink As String = "AppsubmitID=" & FormViewDetailRenew.DataKey.Item(0)
                Dim strlink As String = ""
                strlink += "&Edit=1&Buy=5&TypeID=" & FormViewDetailRenew.DataKey.Item(1)
                strlink += "&IdCar=" & Request.QueryString("IdCar").ToString
                strlink += "&ProValue=" & FormViewDetailRenew.DataKey.Item(2)
                strlink += "&ProPrice=" & FormViewDetailRenew.DataKey.Item(3)
                strlink += "&CarPet=" & GetCarPet()
                ScriptManager.RegisterClientScriptBlock(UpdatePanel1, GetType(UpdatePanel), UpdatePanel1.ClientID, "window.open('../Application/frmApplication.aspx?" & strlink & "','Application');", True)
            End If

        End If
    End Sub
    Protected Sub FormViewDetailRenew_DataBound(sender As Object, e As System.EventArgs) Handles FormViewDetailRenew.DataBound
        If FormViewDetailRenew.DataItemCount > 0 Then
            If frmApp.DataItemCount > 0 Then
                TmpRenew.Visible = False
            Else
                If ((Request.Cookies("TypeTsr").Value = "3" Or Request.Cookies("TypeTsr").Value = "101") And (FormViewDetailRenew.DataKey.Item(1) > 0 And FormViewDetailRenew.DataKey.Item(2) And FormViewDetailRenew.DataKey.Item(3) > 0 And FormViewDetailRenew.DataKey.Item(4) > 0 And FormViewDetailRenew.DataKey.Item(5) > 0 And FormViewDetailRenew.DataKey.Item(6) > 0 And FormViewDetailRenew.DataKey.Item(7) > 0 And FormViewDetailRenew.DataKey.Item(8) > 0 And FormViewDetailRenew.DataKey.Item(9) > 0 And FormViewDetailRenew.DataKey.Item(10) > 0 And FormViewDetailRenew.DataKey.Item(11) > 0)) Then
                    TmpRenew.Visible = True
                Else
                    TmpRenew.Visible = False
                End If
            End If
        Else
            TmpRenew.Visible = False
        End If
    End Sub

    Protected Sub LinkButton6_Click(sender As Object, e As System.EventArgs) Handles LinkButton6.Click
        strProtype = "../Product/frmProType1Plus.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    End Sub




    Private Sub Print_CV_Payment(ByVal tmpappid As String)


        Dim Appbar As String
        Dim str As String
        Dim Command As SqlCommand
        Dim DataReader As SqlDataReader

        Dim users As String = "sa"
        Dim pass As String = "asn@sr1"

        'print CV

        SetappAcc(tmpappid)

        Conn.Open()

        'Gen QR_Codr and Barcode use on CV version 2020
        Dim dttmprefno As New DataTable
        Dim query = New System.Text.StringBuilder()
        query.Append(" select tblapplication.appid,tblcar.RefNo")
        query.Append(" from tblapplication ")
        query.Append(" inner join tblcar on tblapplication.idcar=tblcar.idcar")
        query.Append(" where tblapplication.appid='" & tmpappid & "'")



        dttmprefno = DataAccess.DataRead(query.ToString)
        If dttmprefno.Rows.Count = 1 Then
            Dim refno As String = dttmprefno.Rows(0)("RefNo").ToString()
            Dim appid As String = dttmprefno.Rows(0)("appid").ToString()

            Dim barcodestr As String = "|010755800027000" & Chr(13) & refno & Chr(13) & appid & Chr(13) & "0"
            Dim myimgQRCode As Image = Code128Rendering.MakeBarcodeImage(barcodestr, 2, True)
            Dim QRCode As MessagingToolkit.QRCode.Codec.QRCodeEncoder = New MessagingToolkit.QRCode.Codec.QRCodeEncoder
            Dim myimgbarcode As Image = QRCode.Encode(barcodestr)
            Dim CreateFolder1 As String = "D:\LINE\" + tmpappid
            CreateFolder(CreateFolder1)

            'save barcode
            Dim destPathbarcode As String = "D:\\LINE\\" + tmpappid + "\barcode.bmp"
            Dim bmbarcode As New Bitmap(myimgQRCode)
            bmbarcode.Save(destPathbarcode)
            bmbarcode.Dispose()

            'save barCode
            Dim destPathqrCode As String = "D:\\LINE\\" + tmpappid + "\qrcode.bmp"
            Dim bmqrCode As New Bitmap(myimgbarcode)
            bmqrCode.Save(destPathqrCode)
            bmqrCode.Dispose()
        End If



        str = "select  ProDuctID,dateadd(year,542,protectdate) as expProtectDate,createid ,senddoc from tblapplication where appid = '" & tmpappid & "'"
        Command = New SqlCommand(str, Conn)
        DataReader = Command.ExecuteReader()
        dt = New DataTable

        dt.Columns.Add("createid")
        dt.Columns.Add("senddoc")

        If DataReader.HasRows Then
            While DataReader.Read
                Dim dtr As DataRow = dt.NewRow

                If IsDBNull(DataReader("createid")) = False Then
                    dtr("createid") = DataReader("createid")
                End If
                If IsDBNull(DataReader("senddoc")) = False Then
                    dtr("senddoc") = DataReader("senddoc")
                Else
                    dtr("senddoc") = 0
                End If
                dt.Rows.Add(dtr)
            End While
        End If
        DataReader.Close()

        Dim rptx1 As String = ""
        Appbar = tmpappid


        rptx1 = "*" & Trim(Appbar) & "*"
        Dim tsrid As String = "TSR NO. : " + dt.Rows(0).Item("createid")

        str = "INSERT INTO TblAutoPrint (appid,[type],flag,payno,createid) VALUES('" & tmpappid & "','1','0','0'," & Request.Cookies("UserID").Value & ")"

        Command = New SqlCommand(str, Conn)
        Dim chk As Integer = Command.ExecuteNonQuery()

        Dim reportname As String = Server.MapPath("acv_lm2.rpt")
        myReport.Load(reportname)
        myReport.SetDatabaseLogon(users, pass)

        myReport.SetParameterValue("bcode", rptx1)
        myReport.SetParameterValue("tsrid", tsrid)
        myReport.SetParameterValue("pd1", Session("pd1"))

        myReport.SetParameterValue("UserID", Request.Cookies("UserID").Value)


        myReport.PrintOptions.PrinterName = "cvRPT" '"cvRPT" '"cvRPT"RICOH MP6055 10.17.3.243
        myReport.PrintToPrinter(1, False, 1, 1)

        Conn.Close()
    End Sub
    Private Sub Auto_File(ByVal tmpAppID As String)
        '1.AppID
        '2.Idcar
        Conn.Open()
        'Request.Cookies("userID").Value = 268
        Dim dttmpLine As New DataTable
        Dim query = New System.Text.StringBuilder()

        query.Append(" SELECT   tmp_QC_PayCredit.UserID as gg,   tmp_QC_PayCredit.*, tmp_QC_app02.*, tmp_QC_app01.* ,tblcar.refno,tmp_QC_app01.AppID as appid01,isnull(Tbl_ProductType.hotLINE,'') as 'hotLINE01' ")
        query.Append(" FROM     tmp_QC_PayCredit ")
        query.Append(" INNER JOIN	tmp_QC_app02 ON tmp_QC_PayCredit.AppID = tmp_QC_app02.AppID ")
        query.Append(" INNER JOIN	tmp_QC_app01 ON tmp_QC_app02.AppID = tmp_QC_app01.AppID")
        query.Append(" inner join tblapplication on tmp_QC_app01.AppID=tblapplication.appid")
        query.Append(" inner join tblcar on tblapplication.idcar=tblcar.idcar")
        query.Append(" inner join Tbl_ProductType on Tbl_ProductType.ProTypeID=tblapplication.ProDuctID ")


        query.Append(" WHERE tmp_QC_PayCredit.UserID = " & Request.Cookies("userID").Value)
        query.Append(" AND tmp_QC_app02.UserID = " & Request.Cookies("userID").Value)
        query.Append(" AND tmp_QC_app01.UserID = " & Request.Cookies("userID").Value)
        query.Append(" order by tmp_QC_PayCredit.UserID")


        dttmpLine = DataAccess.DataRead(query.ToString)
        If dttmpLine.Rows.Count = 1 Then
            '1.File background 
            Dim P_Server As String = "~/images/LINE/covernote.jpg"
            Dim folder As String = Server.MapPath(P_Server)

            '2.Process 

            Dim bm As New Bitmap(folder)
            Dim FontName As String = "Angsana New"
            Dim gra As Graphics = Graphics.FromImage(bm)

            Dim B1 As String = ""
            Dim B2 As String = ""
            LINE_Address(dttmpLine, B1, B2)
            'New Data 
            Dim A1 As String = dttmpLine.Rows(0)("sname").ToString()
            Dim refno As String = dttmpLine.Rows(0)("refno").ToString()
            Dim appid01 As String = dttmpLine.Rows(0)("appid01").ToString()


            A1 = "เรียน " & A1 & Environment.NewLine & B1
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(200, 450)) '12

            Dim barcodestr As String = "|010755800027000" & Chr(13) & refno & Chr(13) & appid01 & Chr(13) & "0"
            Dim myimg As Image = Code128Rendering.MakeBarcodeImage(barcodestr, 2, True)
            gra.DrawImage(myimg, 750, 3380, myimg.Width, 75)

            gra.DrawString("สำหรับชำระค่าเบี้ยประกันภัย", New Font(FontName, 36), Brushes.Black, New PointF(2040, 3435)) '10
            Dim qe As MessagingToolkit.QRCode.Codec.QRCodeEncoder = New MessagingToolkit.QRCode.Codec.QRCodeEncoder
            Dim myimg1 As Image = qe.Encode(barcodestr)
            gra.DrawImage(myimg1, 2140, 3260, 170, 170)
            gra.DrawString(barcodestr, New Font(FontName, 36), Brushes.Black, New PointF(920, 3435)) '12
            'barcodestr


            Dim myimgappid As Image = Code128Rendering.MakeBarcodeImage(appid01, 2, True)

            gra.DrawImage(myimgappid, 1100, 630, myimgappid.Width, 50) 'myimgappid.Height


            gra.DrawString(appid01, New Font(FontName, 30), Brushes.Black, New PointF(1180, 670)) '10


            A1 = ""
            A1 = If((dttmpLine.Rows(0)("initth").ToString() <> "[ไม่ทราบ]"), dttmpLine.Rows(0)("initth").ToString(), "") & dttmpLine.Rows(0)("FNameTH").ToString() & " " & dttmpLine.Rows(0)("LNameTH").ToString()
            A1 = A1 & Environment.NewLine & B2
            gra.DrawString(A1, New Font(FontName, 30), Brushes.Black, New PointF(1490, 520)) '10


            A1 = dttmpLine.Rows(0)("ProTypeBrand").ToString()
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(350, 740))



            A1 = dttmpLine.Rows(0)("hotLINE01").ToString()
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1265, 740))


            If dttmpLine.Rows(0)("CarDriver1").ToString() <> " " Then
                B1 = "X"
                B2 = ""
            End If
            If dttmpLine.Rows(0)("CarDriver1").ToString() = " " Then
                B1 = ""
                B2 = "X"
            End If

            gra.DrawString(B1, New Font(FontName, 36), Brushes.Black, New PointF(1582, 740))
            gra.DrawString(B2, New Font(FontName, 36), Brushes.Black, New PointF(1985, 740))

            A1 = dttmpLine.Rows(0)("CarDriver1").ToString()

            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(270, 825))
            A1 = ""
            If dttmpLine.Rows(0)("CarDriver1").ToString() <> " " Then
                A1 = dttmpLine.Rows(0)("CarDriverBorn1").ToString()
            End If

            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(995, 825))

            A1 = ""
            If dttmpLine.Rows(0)("CarDriver1").ToString() <> " " Then
                A1 = dttmpLine.Rows(0)("DBornNO1").ToString()
            End If

            gra.DrawString(A1, New Font(FontName, 30), Brushes.Black, New PointF(1350, 830))

            A1 = ""

            If dttmpLine.Rows(0)("CarDriver1").ToString() <> " " Then
                A1 = dttmpLine.Rows(0)("DBornDate1").ToString()
            End If

            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1660, 825))

            A1 = ""
            'D5
            If dttmpLine.Rows(0)("CarDriver1").ToString() <> " " Then
                A1 = dttmpLine.Rows(0)("DBornAddr1").ToString()
            End If
            'A1 = "กรุงเทพมหานคร"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(2070, 825))

            A1 = ""
            'E1
            A1 = dttmpLine.Rows(0)("CarDriver2").ToString()

            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(270, 900))

            A1 = ""
            If dttmpLine.Rows(0)("CarDriver2").ToString() <> " " Then
                A1 = dttmpLine.Rows(0)("CarDriverBorn2").ToString()
            End If
            'A1 = "06/09/2523"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(995, 900))

            A1 = ""
            If dttmpLine.Rows(0)("CarDriver2").ToString() <> " " Then
                A1 = dttmpLine.Rows(0)("DBornNO2").ToString()
            End If
            'A1 = "XXXXXXXX"
            gra.DrawString(A1, New Font(FontName, 30), Brushes.Black, New PointF(1350, 900))

            A1 = ""
            If dttmpLine.Rows(0)("CarDriver2").ToString() <> " " Then
                A1 = dttmpLine.Rows(0)("DBornDate2").ToString()
            End If
            'A1 = "11/03/2548"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1660, 900))


            A1 = ""
            If dttmpLine.Rows(0)("CarDriver2").ToString() <> " " Then
                A1 = dttmpLine.Rows(0)("DBornAddr2").ToString()
            End If
            ' A1 = "กรุงเทพมหานคร"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(2070, 900))

            A1 = ""
            If dttmpLine.Rows(0)("CarDriver1").ToString() <> " " Then
                A1 = dttmpLine.Rows(0)("IdCard1").ToString()
            End If

            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(490, 975))

            A1 = ""

            'Dim F2 As String = ""
            If dttmpLine.Rows(0)("CarDriver2").ToString() <> " " Then
                A1 = dttmpLine.Rows(0)("IdCard2").ToString()
            End If

            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1400, 975))
            A1 = ""

            If dttmpLine.Rows(0)("ProDuctID").ToString() <> "15" Then
                A1 = dttmpLine.Rows(0)("AppNO").ToString()
            Else
                A1 = dttmpLine.Rows(0)("PolicyNO").ToString()
            End If

            'gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(2070, 1050))

            A1 = ""
            If dttmpLine.Rows(0)("IsProvalue").ToString() = "1" Then
                A1 = dttmpLine.Rows(0)("ProtectDate").ToString() & "  -  " & dttmpLine.Rows(0)("expprotectdate").ToString()
            End If
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(450, 1050)) '1130
            A1 = ""

            '    'If dttmpLine.Rows(0)("IsProvalue").ToString() = "1" Then
            '    '    A1 = dttmpLine.Rows(0)("ProtectDate").ToString() & "-" & dttmpLine.Rows(0)("expprotectdate").ToString()
            'End If
            A1 = Session("pd1")
            'A1 = "21/09/2560 - 21/09/2561"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1330, 1050))
            gra.DrawString("1", New Font(FontName, 36), Brushes.Black, New PointF(140, 1280)) '1360

            'I2
            A1 = ""
            If dttmpLine.Rows(0)("discounttype").ToString() > "0" Then
                A1 = dttmpLine.Rows(0)("discounttype").ToString()
            End If
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(250, 1280))

            A1 = ""

            If dttmpLine.Rows(0)("CarBrand").ToString() <> "" And dttmpLine.Rows(0)("CarSeries").ToString() <> "" Then
                A1 = dttmpLine.Rows(0)("CarBrand").ToString() & "/" & Chr(10) & Chr(13) & dttmpLine.Rows(0)("CarSeries").ToString()
            ElseIf dttmpLine.Rows(0)("CarBrand").ToString() <> "" And dttmpLine.Rows(0)("CarSeries").ToString() = "" Then
                A1 = dttmpLine.Rows(0)("CarBrand").ToString() & "/" & Chr(10) & Chr(13) & "-"
            ElseIf dttmpLine.Rows(0)("CarBrand").ToString() = "" And dttmpLine.Rows(0)("CarSeries").ToString() <> "" Then
                A1 = "-" & "/" & Chr(10) & Chr(13) & dttmpLine.Rows(0)("CarSeries").ToString()
            End If
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(375, 1280))
            'I4
            A1 = ""
            A1 = dttmpLine.Rows(0)("CarID").ToString()
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(840, 1280))

            'I5
            A1 = ""
            If dttmpLine.Rows(0)("CarNo").ToString() <> "" And dttmpLine.Rows(0)("CarBoxNo").ToString() <> "" Then
                A1 = dttmpLine.Rows(0)("CarBoxNo").ToString() & "/" & Chr(10) & Chr(13) & dttmpLine.Rows(0)("CarNo").ToString()

            ElseIf dttmpLine.Rows(0)("CarNo").ToString() <> "" And dttmpLine.Rows(0)("CarBoxNo").ToString() = "" Then
                A1 = "-" & "/" & Chr(10) & Chr(13) & dttmpLine.Rows(0)("CarNo").ToString()
            ElseIf dttmpLine.Rows(0)("CarNo").ToString() = "" And dttmpLine.Rows(0)("CarBoxNo").ToString() <> "" Then
                A1 = dttmpLine.Rows(0)("CarBoxNo").ToString() & "/" & "-"
            End If
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1120, 1280))

            'I6
            A1 = ""
            A1 = dttmpLine.Rows(0)("CarYear").ToString()
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1570, 1280))

            'I7
            A1 = ""
            A1 = dttmpLine.Rows(0)("cartypename").ToString()
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1720, 1280))

            'I8
            A1 = ""
            A1 = "- / " & dttmpLine.Rows(0)("CarSize").ToString() & " / -"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1970, 1280))


            'J1
            A1 = ""
            A1 = dttmpLine.Rows(0)("Lost_Car1").ToString()
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1068, 1570))
            'J2
            A1 = ""
            A1 = dttmpLine.Rows(0)("Acc_Lost1").ToString()
            ' A1 = "999999"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1820, 1629))

            'J3
            A1 = ""
            A1 = dttmpLine.Rows(0)("Acc_Lost4").ToString()
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1970, 1629))

            'K1
            A1 = ""
            A1 = dttmpLine.Rows(0)("Lost_Life1").ToString()
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(375, 1634)) '1706


            'K4
            A1 = ""
            If dttmpLine.Rows(0)("IsProvalue").ToString() = "1" Then
                A1 = dttmpLine.Rows(0)("Lost_Life2").ToString()
            End If
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(375, 1699)) '1771
            'K2
            A1 = ""
            A1 = dttmpLine.Rows(0)("Lost_Car2").ToString()
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1068, 1699))

            'K3
            A1 = ""
            A1 = dttmpLine.Rows(0)("Acc_Lost3").ToString()
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1850, 1699))

            'k4
            A1 = ""
            A1 = dttmpLine.Rows(0)("Acc_Lost4").ToString()
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1970, 1699))


            'L1
            A1 = "L1"
            A1 = dttmpLine.Rows(0)("Lost_Prop1").ToString()
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(375, 1849)) '1921

            'L2
            A1 = ""
            A1 = dttmpLine.Rows(0)("Car_Fire").ToString()
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1068, 1849))


            'L3
            A1 = "0"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1850, 1825)) '1895
            'L4
            A1 = "0.00"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1970, 1825))

            'M1
            A1 = "0"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1850, 1890)) '1965
            'M2
            A1 = "0.00"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1970, 1890))
            ' N1()
            A1 = "0.00"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(375, 1970)) '2050
            'N2()
            A1 = ""
            A1 = dttmpLine.Rows(0)("Lost_Prop2").ToString()
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1068, 2020)) '2100

            'N3
            A1 = ""
            A1 = dttmpLine.Rows(0)("Maintain").ToString()
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1970, 1966)) '2040

            'O1
            A1 = ""
            A1 = dttmpLine.Rows(0)("Insure").ToString()
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1970, 2050)) '2130


            'P1
            A1 = ""
            A1 = If(dttmpLine.Rows(0)("IsProvalue").ToString() = "1", dttmpLine.Rows(0)("ProValue").ToString(), "0.00")
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(350, 2240)) '2300
            'P2
            A1 = ""
            A1 = If(dttmpLine.Rows(0)("IsCarpet").ToString() = "1", dttmpLine.Rows(0)("CarPet").ToString(), "0.00")
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1068, 2240))
            'P3
            A1 = ""

            Dim AA As Decimal = dttmpLine.Rows(0)("ProValue")
            Dim AB As Decimal = dttmpLine.Rows(0)("CarPet")
            AA = Math.Round(AA + AB, 2)
            gra.DrawString(AA.ToString("N2"), New Font(FontName, 36), Brushes.Black, New PointF(1850, 2240))
            'Q1
            A1 = ""

            Dim TmpQ1 As String = ""

            If dttmpLine.Rows(0)("Typeprovalue").ToString() = "1" Then
                TmpQ1 = "ชั้น1"
            ElseIf dttmpLine.Rows(0)("Typeprovalue").ToString() = "2" Then
                TmpQ1 = "ชั้น3"
            ElseIf dttmpLine.Rows(0)("Typeprovalue").ToString() = "3" Then
                TmpQ1 = "ชั้น3+"
            ElseIf dttmpLine.Rows(0)("Typeprovalue").ToString() = "4" Then
                TmpQ1 = "ชั้น2+"
            End If

            If dttmpLine.Rows(0)("IsProvalue").ToString() = "1" And dttmpLine.Rows(0)("IsCarpet").ToString() = "1" Then
                A1 = "ประกันภัย " & TmpQ1 & " รวม พ.ร.บ."
            ElseIf dttmpLine.Rows(0)("IsProvalue").ToString() = "1" And dttmpLine.Rows(0)("IsCarpet").ToString() = "0" Then
                A1 = "ประกันภัย " & TmpQ1 & " ไม่รวม พ.ร.บ."
            ElseIf dttmpLine.Rows(0)("IsProvalue").ToString() = "0" And dttmpLine.Rows(0)("IsCarpet").ToString() = "1" Then
                A1 = "พ.ร.บ."
            End If
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(500, 2300)) '2380

            A1 = ""
            AA = dttmpLine.Rows(0)("YearPay")
            AB = dttmpLine.Rows(0)("ProValue")
            If AA - AB > 0 Then

                A1 = "* ส่วนลด    " & (AA - AB).ToString("N2") & "   บาท"
            End If

            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1100, 2300))
            Dim Q3 As String = If(dttmpLine.Rows(0)("CarFixIn").ToString() = "1", "X", "")
            Dim Q4 As String = If(dttmpLine.Rows(0)("CarFixIn").ToString() = "0", "X", "")

            gra.DrawString(Q3, New Font(FontName, 36), Brushes.Black, New PointF(1530, 2300))
            gra.DrawString(Q4, New Font(FontName, 36), Brushes.Black, New PointF(1990, 2300))

            'R1
            A1 = ""

            'Dim R1 As String = ""
            Dim TmpR1 As String = Replace(dttmpLine.Rows(0)("discounttype").ToString(), " ", "")

            If dttmpLine.Rows(0)("IsProvalue").ToString() = "1" And TmpR1 = "320" Then
                A1 = "ใช้เพื่อการพาณิชย์ ไม่ใช้เพื่อการบรรทุก และขนส่งสินค้าที่มี ความเสี่ยงภัยสูง เช่น เชื้อเพลิง"
            ElseIf dttmpLine.Rows(0)("IsProvalue").ToString() = "1" And TmpR1 = "220" Then
                A1 = "ใช้เพื่อการพาณิชย์ ไม่ใช้รับจ้างสาธารณะ"
            ElseIf dttmpLine.Rows(0)("IsProvalue") = "1" And TmpR1 = "110" Then
                A1 = "ใช้ส่วนบุคคล ไม่ใช้รับจ้าง หรือให้เช่า"
            ElseIf dttmpLine.Rows(0)("IsProvalue").ToString() = "1" And TmpR1 = "210" Then
                A1 = "ใช้ส่วนบุคคล ไม่ใช้รับจ้าง หรือให้เช่า"
            ElseIf dttmpLine.Rows(0)("IsProvalue").ToString() = "0" Then
                A1 = "ความคุ้มครองตามเงื่อนไข กรมธรรม์ประกันภัยคุ้มครองผู้ประสบภัยจากรถยนต์"
            End If

            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(400, 2387)) '2460

            'R2
            A1 = ""
            A1 = dttmpLine.Rows(0)("createdate").ToString()
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1850, 2387))
            'Dim R2 As String = dttmpLine.Rows(0)("createdate").ToString()
            ''PayNo1
            A1 = ""
            A1 = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("payid1").ToString(), dttmpLine.Rows(0)("payid1").ToString())
            'A1 = "1"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(150, 2570))

            A1 = ""
            A1 = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("AppointDate1").ToString(), dttmpLine.Rows(0)("AppointDate1").ToString())
            'A1 = "1"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(350, 2570))

            A1 = ""
            A1 = If(dttmpLine.Rows(0)("totalpay1").ToString() <> "  ", dttmpLine.Rows(0)("totalpay1").ToString() & ".00", "")
            'A1 = "1"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(680, 2570))

            A1 = ""
            A1 = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", "เงินสด", If(dttmpLine.Rows(0)("Typepay1").ToString() = "2", "บัตรเครดิต", ""))
            'A1 = "1"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(980, 2570))

            A1 = ""
            A1 = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("payid4").ToString(), dttmpLine.Rows(0)("payid4").ToString())
            'A1 = "4"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1310, 2570))

            A1 = ""
            A1 = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("AppointDate4").ToString(), dttmpLine.Rows(0)("AppointDate4").ToString())
            ' A1 = "4"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1510, 2570))

            A1 = ""
            A1 = If(dttmpLine.Rows(0)("totalpay4").ToString() <> "  ", dttmpLine.Rows(0)("totalpay4").ToString() & ".00", "")
            'A1 = "4"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1840, 2570))

            A1 = ""
            A1 = If(dttmpLine.Rows(0)("Typepay4").ToString() = "1", "เงินสด", If(dttmpLine.Rows(0)("Typepay4").ToString() = "2", "บัตรเครดิต", ""))
            ' A1 = "4"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(2140, 2570))
            'pAYID2
            'Dim t1 As String = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("payid2").ToString(), dttmpLine.Rows(0)("payid2").ToString())
            'Dim t2 As String = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("AppointDate2").ToString(), dttmpLine.Rows(0)("AppointDate2").ToString())
            'Dim t3 As String = If(dttmpLine.Rows(0)("totalpay2").ToString() <> "", dttmpLine.Rows(0)("totalpay2").ToString() & ".00", "")
            'Dim t4 As String = If(dttmpLine.Rows(0)("Typepay2").ToString() = "1", "เงินสด", If(dttmpLine.Rows(0)("Typepay2").ToString() = "2", "บัตรเครดิต", ""))

            A1 = ""
            A1 = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("payid2").ToString(), dttmpLine.Rows(0)("payid2").ToString())
            'A1 = "2"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(150, 2650))

            A1 = ""
            A1 = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("AppointDate2").ToString(), dttmpLine.Rows(0)("AppointDate2").ToString())
            'A1 = "2"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(350, 2650))

            A1 = ""
            A1 = If(dttmpLine.Rows(0)("totalpay2").ToString() <> "  ", dttmpLine.Rows(0)("totalpay2").ToString() & ".00", "")
            'A1 = "2"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(680, 2650))

            A1 = ""
            A1 = If(dttmpLine.Rows(0)("Typepay2").ToString() = "1", "เงินสด", If(dttmpLine.Rows(0)("Typepay2").ToString() = "2", "บัตรเครดิต", ""))
            'A1 = "2"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(980, 2650))
            ''payid3
            'Dim U1 As String = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("payid3").ToString(), dttmpLine.Rows(0)("payid3").ToString())
            'Dim U2 As String = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("AppointDate3").ToString(), dttmpLine.Rows(0)("AppointDate3").ToString())
            'Dim U3 As String = If(dttmpLine.Rows(0)("totalpay3").ToString() <> "", dttmpLine.Rows(0)("totalpay3").ToString() & ".00", "")
            'Dim U4 As String = If(dttmpLine.Rows(0)("Typepay3").ToString() = "1", "เงินสด", If(dttmpLine.Rows(0)("Typepay3").ToString() = "2", "บัตรเครดิต", ""))
            A1 = ""
            A1 = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("payid3").ToString(), dttmpLine.Rows(0)("payid3").ToString())
            'A1 = "3"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(150, 2730))

            A1 = ""
            A1 = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("AppointDate3").ToString(), dttmpLine.Rows(0)("AppointDate3").ToString())
            'A1 = "3"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(350, 2730))

            A1 = ""
            A1 = If(dttmpLine.Rows(0)("totalpay3").ToString() <> "  ", dttmpLine.Rows(0)("totalpay3").ToString() & ".00", "")
            'A1 = "3"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(680, 2730))

            A1 = ""
            A1 = If(dttmpLine.Rows(0)("Typepay3").ToString() = "1", "เงินสด", If(dttmpLine.Rows(0)("Typepay3").ToString() = "2", "บัตรเครดิต", ""))
            'A1 = "3"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(980, 2730))

            ''PayNo4
            'Dim S5 As String = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("payid4").ToString(), dttmpLine.Rows(0)("payid4").ToString())
            'Dim S6 As String = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("AppointDate4").ToString(), dttmpLine.Rows(0)("AppointDate4").ToString())
            'Dim S7 As String = If(dttmpLine.Rows(0)("totalpay4").ToString() <> "", dttmpLine.Rows(0)("totalpay4").ToString() & ".00", "")
            'Dim S8 As String = If(dttmpLine.Rows(0)("Typepay4").ToString() = "1", "เงินสด", If(dttmpLine.Rows(0)("Typepay4").ToString() = "2", "บัตรเครดิต", ""))
            ''payid5
            'Dim t5 As String = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("payid5").ToString(), dttmpLine.Rows(0)("payid5").ToString())
            'Dim t6 As String = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("AppointDate5").ToString(), dttmpLine.Rows(0)("AppointDate5").ToString())
            'Dim t7 As String = If(dttmpLine.Rows(0)("totalpay5").ToString() <> "", dttmpLine.Rows(0)("totalpay5").ToString() & ".00", "")
            'Dim t8 As String = If(dttmpLine.Rows(0)("Typepay5").ToString() = "1", "เงินสด", If(dttmpLine.Rows(0)("Typepay5").ToString() = "2", "บัตรเครดิต", ""))
            A1 = ""
            A1 = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("payid5").ToString(), dttmpLine.Rows(0)("payid5").ToString())
            'A1 = "5"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1310, 2650))

            A1 = ""
            A1 = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("AppointDate5").ToString(), dttmpLine.Rows(0)("AppointDate5").ToString())
            'A1 = "5"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1510, 2650))

            A1 = ""
            A1 = If(dttmpLine.Rows(0)("totalpay5").ToString() <> "  ", dttmpLine.Rows(0)("totalpay5").ToString() & ".00", "")
            'A1 = "5"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1840, 2650))

            A1 = ""
            A1 = If(dttmpLine.Rows(0)("Typepay5").ToString() = "1", "เงินสด", If(dttmpLine.Rows(0)("Typepay5").ToString() = "2", "บัตรเครดิต", ""))
            'A1 = "5"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(2140, 2650))

            ''payid6
            'Dim U5 As String = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("payid6").ToString(), dttmpLine.Rows(0)("payid6").ToString())
            'Dim U6 As String = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("AppointDate6").ToString(), dttmpLine.Rows(0)("AppointDate6").ToString())
            'Dim U7 As String = If(dttmpLine.Rows(0)("totalpay6").ToString() <> "", dttmpLine.Rows(0)("totalpay6").ToString() & ".00", "")
            'Dim U8 As String = If(dttmpLine.Rows(0)("Typepay6").ToString() = "1", "เงินสด", If(dttmpLine.Rows(0)("Typepay6").ToString() = "2", "บัตรเครดิต", ""))
            A1 = ""
            A1 = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("payid6").ToString(), dttmpLine.Rows(0)("payid6").ToString())

            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1310, 2730))

            A1 = ""
            A1 = If(dttmpLine.Rows(0)("Typepay1").ToString() = "1", dttmpLine.Rows(0)("AppointDate6").ToString(), dttmpLine.Rows(0)("AppointDate6").ToString())
            ' A1 = "6"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1510, 2730))

            A1 = ""
            A1 = If(dttmpLine.Rows(0)("totalpay6").ToString() <> "  ", dttmpLine.Rows(0)("totalpay6").ToString() & ".00", "")
            ' A1 = "6"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(1840, 2730))

            A1 = ""
            A1 = If(dttmpLine.Rows(0)("Typepay6").ToString() = "1", "เงินสด", If(dttmpLine.Rows(0)("Typepay6").ToString() = "2", "บัตรเครดิต", ""))
            'A1 = "6"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(2140, 2730))

            A1 = "*** บริษัทฯ ขอสงวนสิทธิ์ในการคิดค่าธรรมเนียมยกเลิกทั่วไป 350 บาท, ขายรถ 500 บาท"
            gra.DrawString(A1, New Font(FontName, 36), Brushes.Black, New PointF(680, 2810))



            '3.save To Server 
            '3.1 สร้าง Folder

            Dim CreateFolder1 As String = "D:\LINE\" + tmpAppID
            CreateFolder(CreateFolder1)
            'Dim destPath2 As String = Server.MapPath("~/LINE/") + lblApp.Text + "\" + lblApp.Text + "_ใบคำขอเอาประกัน.jpg"
            CreateFolder1 = CreateFolder1 + "\" + tmpAppID + "_ใบคำขอเอาประกัน.jpg"
            bm.Save(CreateFolder1)
            gra.Dispose()
            bm.Dispose()



            Dim queryRefNO = New System.Text.StringBuilder()
        
            LINEGenPayment(tmpAppID)

           
        End If
        ' Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.open('GenPaymentDatail.aspx?AppID=" & tmpAppID & "','Application');</script>")
        Conn.Close()

    End Sub
    Private Sub LINEGenPayment(ByVal tmpAppID As String)

        Dim dttmpRefNO As New DataTable
        Dim queryRefNO = New System.Text.StringBuilder()

        queryRefNO.Append(" Select  tblcar.refno As 'refno1' ")
        queryRefNO.Append(", tblapplication.AppID as 'refno2'")
        queryRefNO.Append(" , isnull(Tbl_ProductType.ProTypeName,'') as 'Desc'")
        queryRefNO.Append(" , Tbl_Type.TypeName as 'Desc1'")
        queryRefNO.Append(" , TblCustomerInit.InitTH+' '+ isnull(tblcustomer.FNameTH,'')+' '+isnull(tblcustomer.LNameTH,'') as 'customername'")
        queryRefNO.Append(" , tblcar.Carid")
        queryRefNO.Append(", (select count(*) from tblapppay where appid=tblapplication.AppID) As CountR  ")

        queryRefNO.Append(" , cast(p1.TotalPay As Decimal(10,2)) As 'Pay1'")
        queryRefNO.Append(" , SUBSTRING(convert(varchar,p1.AppointDate,103), 1, 2) + '/'")
        queryRefNO.Append(" + SUBSTRING(convert(varchar,p1.AppointDate,103), 4, 2)")
        queryRefNO.Append("   + '/'+convert(varchar, (SUBSTRING(convert(varchar,p1.AppointDate,103), 7, 4)+543)) as 'AppointDate1' ")


        queryRefNO.Append(" , cast(p2.TotalPay As Decimal(10,2)) As 'Pay2'")
        queryRefNO.Append(" , SUBSTRING(convert(varchar,p2.AppointDate,103), 1, 2) + '/'")
        queryRefNO.Append(" + SUBSTRING(convert(varchar,p2.AppointDate,103), 4, 2)")
        queryRefNO.Append("   + '/'+convert(varchar, (SUBSTRING(convert(varchar,p2.AppointDate,103), 7, 4)+543)) as 'AppointDate2' ")

        queryRefNO.Append(" , cast(p3.TotalPay As Decimal(10,2)) As 'Pay3'")
        queryRefNO.Append(" , SUBSTRING(convert(varchar,p3.AppointDate,103), 1, 2) + '/'")
        queryRefNO.Append(" + SUBSTRING(convert(varchar,p3.AppointDate,103), 4, 2)")
        queryRefNO.Append("   + '/'+convert(varchar, (SUBSTRING(convert(varchar,p3.AppointDate,103), 7, 4)+543)) as 'AppointDate3' ")

        queryRefNO.Append(" , cast(p4.TotalPay As Decimal(10,2)) As 'Pay4'")
        queryRefNO.Append(" , SUBSTRING(convert(varchar,p4.AppointDate,103), 1, 2) + '/'")
        queryRefNO.Append(" + SUBSTRING(convert(varchar,p4.AppointDate,103), 4, 2)")
        queryRefNO.Append("   + '/'+convert(varchar, (SUBSTRING(convert(varchar,p4.AppointDate,103), 7, 4)+543)) as 'AppointDate4' ")
        queryRefNO.Append(" , cast(p5.TotalPay As Decimal(10,2)) As 'Pay5'")
        queryRefNO.Append(" , SUBSTRING(convert(varchar,p5.AppointDate,103), 1, 2) + '/'")
        queryRefNO.Append(" + SUBSTRING(convert(varchar,p5.AppointDate,103), 4, 2)")
        queryRefNO.Append("   + '/'+convert(varchar, (SUBSTRING(convert(varchar,p5.AppointDate,103), 7, 4)+543)) as 'AppointDate5' ")

        queryRefNO.Append(" , cast(p6.TotalPay As Decimal(10,2)) As 'Pay6'")
        queryRefNO.Append(" , SUBSTRING(convert(varchar,p6.AppointDate,103), 1, 2) + '/'")
        queryRefNO.Append(" + SUBSTRING(convert(varchar,p6.AppointDate,103), 4, 2)")
        queryRefNO.Append("   + '/'+convert(varchar, (SUBSTRING(convert(varchar,p6.AppointDate,103), 7, 4)+543)) as 'AppointDate6' ")

        queryRefNO.Append(" ,case when tblapplication.isprovalue=1 then ")
        queryRefNO.Append(" 	  SUBSTRING(Convert(varchar, tblapplication.protectdate, 103), 1, 2) + '/' ")
        queryRefNO.Append("       + SUBSTRING(convert(varchar,tblapplication.protectdate,103), 4, 2)")
        queryRefNO.Append("       + '/'+convert(varchar, (SUBSTRING(convert(varchar,tblapplication.protectdate,103), 7, 4)+543))")
        queryRefNO.Append("      when tblapplication.IsCarpet=1 then ")
        queryRefNO.Append(" 	 SUBSTRING(Convert(varchar, tblapplication.ProtectDateCarpet, 103), 1, 2) + '/'")
        queryRefNO.Append("      + SUBSTRING(convert(varchar,tblapplication.ProtectDateCarpet,103), 4, 2)")
        queryRefNO.Append("      + '/'+convert(varchar, (SUBSTRING(convert(varchar,tblapplication.ProtectDateCarpet,103), 7, 4)+543))")
        queryRefNO.Append(" 	Else")
        queryRefNO.Append("            '' end as 'protectdate'")

        queryRefNO.Append(",case when tblapplication.isprovalue=1 then tblapplication.ProValue else '0.00' end as 'provalue'")
        queryRefNO.Append(",case when tblapplication.IsCarpet=1 then tblapplication.CarPet else '0.00' end as 'CarPet',isnull(p1.PayID,0) as 'p1',   isnull(p2.PayID,0) as 'p2', isnull(p3.PayID,0) as 'p3', isnull(p4.PayID,0) as 'p4', isnull(p5.PayID,0) as 'p5', isnull(p6.PayID,0) as 'p6'")
        queryRefNO.Append("         From tblapplication  ")
        queryRefNO.Append(" inner Join Tbl_ProductType on tblapplication.ProDuctID=Tbl_ProductType.ProTypeID ")
        queryRefNO.Append(" inner Join Tbl_Type on Tbl_Type.Typeid=tblapplication.Typeprovalue")
        queryRefNO.Append(" inner Join tblcar on tblapplication.idcar=tblcar.idcar ")
        queryRefNO.Append(" inner Join tblcustomer on tblapplication.cusid=tblcustomer.cusid ")
        queryRefNO.Append(" inner Join TblCustomerInit on tblcustomer.InitID=TblCustomerInit.InitID ")
        queryRefNO.Append(" inner Join TblApppay p1 on tblapplication.appid=p1.AppID And p1.PayID=1 ")
        queryRefNO.Append(" Left  Join TblApppay p2 on tblapplication.appid=p2.AppID And p2.PayID=2 ")
        queryRefNO.Append(" Left  Join TblApppay p3 on tblapplication.appid=p3.AppID And p3.PayID=3 ")
        queryRefNO.Append(" Left  Join TblApppay p4 on tblapplication.appid=p4.AppID And p4.PayID=4 ")
        queryRefNO.Append(" Left  Join TblApppay p5 on tblapplication.appid=p5.AppID And p5.PayID=5 ")
        queryRefNO.Append(" Left  Join TblApppay p6 on tblapplication.appid=p6.AppID And p6.PayID=6 ")
        queryRefNO.Append(" where  tblapplication.AppID=" & tmpAppID)


        dttmpRefNO = DataAccess.DataRead(queryRefNO.ToString)
        If dttmpRefNO.Rows.Count = 1 Then

            Dim refno As String = dttmpRefNO.Rows(0)("refno1").ToString()
            Dim refno2 As String = dttmpRefNO.Rows(0)("refno2").ToString()
            Dim CountR As String = dttmpRefNO.Rows(0)("CountR").ToString()
            Dim ProTypeName As String = dttmpRefNO.Rows(0)("Desc").ToString()
            Dim Desc1 As String = dttmpRefNO.Rows(0)("Desc1").ToString()
            Dim customername As String = dttmpRefNO.Rows(0)("customername").ToString()
            Dim Carid As String = dttmpRefNO.Rows(0)("Carid").ToString()
            Dim protectdate As String = dttmpRefNO.Rows(0)("protectdate").ToString()
            Dim provalue As Decimal = dttmpRefNO.Rows(0)("provalue")
            Dim CarPet As Decimal = dttmpRefNO.Rows(0)("CarPet")
            Dim SumTotal As Decimal = provalue + CarPet

            Dim Pay1 As Decimal = dttmpRefNO.Rows(0)("Pay1")
            Dim AppointDate1 As String = dttmpRefNO.Rows(0)("AppointDate1").ToString()

            Dim strMoney As String = "0"
            Dim P_Server As String = ""
            If CountR = "1" Then
                P_Server = "~/images/LINE/pay01.jpg"
            ElseIf dttmpRefNO.Rows(0)("CountR") < 4 Then
                P_Server = "~/images/LINE/pay03.jpg"
            Else
                P_Server = "~/images/LINE/pay04.jpg"
            End If
            strMoney = Replace(strMoney, ".", "")
            strMoney = Replace(strMoney, ",", "")

            Dim barcodestr As String = "|010755800027000" & Chr(13) & refno & Chr(13) & tmpAppID & Chr(13) & strMoney
            Dim myimg As Image = Code128Rendering.MakeBarcodeImage(barcodestr, 1, True)
            Dim barcodesre1 As String = "|010755800027000" & refno & tmpAppID & strMoney

            Dim folder As String = Server.MapPath(P_Server)

            Dim bm As New Bitmap(folder)
            Dim FontName As String = "Prompt Medium"
            Dim gra As Graphics = Graphics.FromImage(bm)

            gra.DrawString(customername, New Font(FontName, 22), Brushes.Navy, New PointF(75, 204))
            gra.DrawString(Carid, New Font(FontName, 22), Brushes.Navy, New PointF(210, 255))
            gra.DrawString(protectdate, New Font(FontName, 22), Brushes.Navy, New PointF(190, 305))
            gra.DrawString(ProTypeName, New Font(FontName, 18), Brushes.Black, New PointF(55, 400))

            If provalue = 0 Then
                gra.DrawString(provalue.ToString("N2"), New Font(FontName, 18), Brushes.Black, New PointF(560, 440))
            ElseIf provalue > 9999 Then
                gra.DrawString(provalue.ToString("N2"), New Font(FontName, 18), Brushes.Black, New PointF(500, 440))
            Else
                gra.DrawString(provalue.ToString("N2"), New Font(FontName, 18), Brushes.Black, New PointF(520, 440))
            End If

            gra.DrawString(" บาท", New Font(FontName, 18), Brushes.Black, New PointF(620, 440))
            gra.DrawString("ประกันภาคสมัครใจ " + Desc1, New Font(FontName, 18), Brushes.Black, New PointF(55, 440))
            gra.DrawString("ประกันภาคบังคับ (พ.ร.บ)", New Font(FontName, 18), Brushes.Black, New PointF(55, 480))

            If CarPet = 0 Then
                gra.DrawString(CarPet.ToString("N2"), New Font(FontName, 18), Brushes.Black, New PointF(560, 480))
            ElseIf CarPet > 999 Then
                gra.DrawString(CarPet.ToString("N2"), New Font(FontName, 18), Brushes.Black, New PointF(500, 480))
            Else
                gra.DrawString(CarPet.ToString("N2"), New Font(FontName, 18), Brushes.Black, New PointF(535, 480))
            End If

            gra.DrawString(" บาท", New Font(FontName, 18), Brushes.Black, New PointF(620, 480))
            gra.DrawString("ยอดเงินรวมที่ต้องชำระ", New Font(FontName, 18), Brushes.Black, New PointF(55, 530))
            gra.DrawString("(ยอดเงินรวมที่ต้องชำระ)", New Font(FontName, 14), Brushes.Black, New PointF(55, 560))

            If CountR = "1" Then
                If SumTotal > 9999 Then
                    gra.DrawString(SumTotal.ToString("N2"), New Font(FontName, 24), Brushes.Black, New PointF(460, 520))
                Else
                    gra.DrawString(SumTotal.ToString("N2"), New Font(FontName, 24), Brushes.Black, New PointF(480, 520))
                End If
            Else
                If SumTotal > 9999 Then
                    gra.DrawString(SumTotal.ToString("N2"), New Font(FontName, 24), Brushes.Black, New PointF(460, 520))
                Else
                    gra.DrawString(SumTotal.ToString("N2"), New Font(FontName, 24), Brushes.Black, New PointF(490, 520))
                End If
            End If


            gra.DrawString(" บาท", New Font(FontName, 18), Brushes.Black, New PointF(620, 530))

            Dim qe As MessagingToolkit.QRCode.Codec.QRCodeEncoder = New MessagingToolkit.QRCode.Codec.QRCodeEncoder
            Dim L1_T1 As String = "|010755800027000" & Chr(13) & refno & Chr(13) & refno2 & Chr(13) & strMoney
            Dim ALL As String = L1_T1
            Dim myimg1 As Image = qe.Encode(ALL)

            If CountR = "1" Then

                gra.DrawString(refno, New Font(FontName, 18), Brushes.Black, New PointF(200, 990))
                gra.DrawString(refno2, New Font(FontName, 18), Brushes.Black, New PointF(550, 990))

                gra.DrawImage(myimg1, 450, 650, 150, 150)
                gra.DrawImage(myimg, 120, 880, myimg.Width, myimg.Height)

            Else
                gra.DrawString("ผ่อนชำระ", New Font(FontName, 18), Brushes.Navy, New PointF(55, 580))
                gra.DrawString(CountR, New Font(FontName, 18), Brushes.Navy, New PointF(600, 580))
                gra.DrawString(" งวด", New Font(FontName, 18), Brushes.Navy, New PointF(620, 580))

                gra.DrawString("งวดแรกที่ต้องชำระ", New Font(FontName, 18), Brushes.Navy, New PointF(55, 620))



                If Pay1 > 9999 Then
                    gra.DrawString(Pay1.ToString("N2"), New Font(FontName, 18), Brushes.Navy, New PointF(500, 620))
                Else
                    gra.DrawString(Pay1.ToString("N2"), New Font(FontName, 18), Brushes.Navy, New PointF(520, 620))
                End If
                gra.DrawString(" บาท", New Font(FontName, 18), Brushes.Navy, New PointF(620, 620))

                gra.DrawString("ผ่อน 0 % " & CountR & " งวด", New Font(FontName, 20, FontStyle.Bold), Brushes.Black, New PointF(280, 700))


                If dttmpRefNO.Rows(0)("p1").ToString() <> "0" Then
                    gra.DrawString("งวดที่ 1", New Font(FontName, 18), Brushes.Black, New PointF(140, 750))
                    gra.DrawString(AppointDate1, New Font(FontName, 18), Brushes.Black, New PointF(280, 750))
                    gra.DrawString(Pay1.ToString("N2") + " บาท", New Font(FontName, 18), Brushes.Black, New PointF(450, 750))
                End If
                If dttmpRefNO.Rows(0)("p2").ToString() <> "0" Then
                    Dim Pay2 As Decimal = dttmpRefNO.Rows(0)("Pay2")
                    Dim AppointDate2 As String = dttmpRefNO.Rows(0)("AppointDate2").ToString()

                    gra.DrawString("งวดที่ 2", New Font(FontName, 18), Brushes.Black, New PointF(140, 790))
                    gra.DrawString(AppointDate2, New Font(FontName, 18), Brushes.Black, New PointF(280, 790))
                    gra.DrawString(Pay2.ToString("N2") + " บาท", New Font(FontName, 18), Brushes.Black, New PointF(450, 790))
                End If
                If dttmpRefNO.Rows(0)("p3").ToString() <> "0" Then
                    Dim Pay3 As Decimal = dttmpRefNO.Rows(0)("Pay3")
                    Dim AppointDate3 As String = dttmpRefNO.Rows(0)("AppointDate3").ToString()

                    gra.DrawString("งวดที่ 3", New Font(FontName, 18), Brushes.Black, New PointF(140, 830))
                    gra.DrawString(AppointDate3, New Font(FontName, 18), Brushes.Black, New PointF(280, 830))
                    gra.DrawString(Pay3.ToString("N2") + " บาท", New Font(FontName, 18), Brushes.Black, New PointF(450, 830))
                End If



                If dttmpRefNO.Rows(0)("p4").ToString() <> "0" Then
                    Dim Pay4 As Decimal = dttmpRefNO.Rows(0)("Pay4")
                    Dim AppointDate4 As String = dttmpRefNO.Rows(0)("AppointDate4").ToString()

                    gra.DrawString("งวดที่ 4", New Font(FontName, 18), Brushes.Black, New PointF(140, 870))
                    gra.DrawString(AppointDate4, New Font(FontName, 18), Brushes.Black, New PointF(280, 870))
                    gra.DrawString(Pay4.ToString("N2") + " บาท", New Font(FontName, 18), Brushes.Black, New PointF(450, 870))
                End If
                If dttmpRefNO.Rows(0)("p5").ToString() <> "0" Then
                    Dim Pay5 As Decimal = dttmpRefNO.Rows(0)("Pay5")
                    Dim AppointDate5 As String = dttmpRefNO.Rows(0)("AppointDate5").ToString()

                    gra.DrawString("งวดที่ 5", New Font(FontName, 18), Brushes.Black, New PointF(140, 910))
                    gra.DrawString(AppointDate5, New Font(FontName, 18), Brushes.Black, New PointF(280, 910))
                    gra.DrawString(Pay5.ToString("N2") + " บาท", New Font(FontName, 18), Brushes.Black, New PointF(450, 910))
                End If
                If dttmpRefNO.Rows(0)("p6").ToString() <> "0" Then
                    Dim Pay6 As Decimal = dttmpRefNO.Rows(0)("Pay6")
                    Dim AppointDate6 As String = dttmpRefNO.Rows(0)("AppointDate6").ToString()
                    gra.DrawString("งวดที่ 6", New Font(FontName, 18), Brushes.Black, New PointF(140, 950))
                    gra.DrawString(AppointDate6, New Font(FontName, 18), Brushes.Black, New PointF(280, 950))
                    gra.DrawString(Pay6.ToString("N2") + " บาท", New Font(FontName, 18), Brushes.Black, New PointF(450, 950))
                End If

                If dttmpRefNO.Rows(0)("CountR") < 4 Then
                    gra.DrawString(refno, New Font(FontName, 18), Brushes.Black, New PointF(200, 1300))
                    gra.DrawString(refno2, New Font(FontName, 18), Brushes.Black, New PointF(550, 1300))

                    gra.DrawImage(myimg1, 450, 950, 150, 150)
                    gra.DrawImage(myimg, 120, 1180, myimg.Width, myimg.Height)
                Else
                    gra.DrawString(refno, New Font(FontName, 18), Brushes.Black, New PointF(200, 1440))
                    gra.DrawString(refno2, New Font(FontName, 18), Brushes.Black, New PointF(550, 1440))

                    gra.DrawImage(myimg1, 450, 1100, 150, 150)
                    gra.DrawImage(myimg, 120, 1310, myimg.Width, myimg.Height)
                End If


            End If




            Dim destPath As String = "D:\\LINE\\" + tmpAppID + "\" + tmpAppID + "_Payment.jpg"

            bm.Save(destPath)
            gra.Dispose()
            bm.Dispose()

            'Ref.IT Service XXXXX GEN Give PBIG Use in Payment Form
            Dim destPathQR As String = "D:\\LINE\\" + tmpAppID + "\qr.bmp"
            Dim bm1 As New Bitmap(myimg1)
            bm1.Save(destPathQR)
            bm1.Dispose()

        End If
    End Sub

    Private Sub LINE_Address(ByVal dttmp As DataTable, ByRef B1 As String, ByRef B2 As String)
        Dim str_Adress As String = ""
        Dim str_Adress2 As String = ""

        If dttmp.Rows(0)("Address").ToString() <> "" Then
            str_Adress += "เลขที่ " & dttmp.Rows(0)("Address").ToString() & " "
        End If

        If dttmp.Rows(0)("Moo").ToString() <> "" Then
            str_Adress += "ม." & dttmp.Rows(0)("Moo").ToString() & " "
        End If

        If dttmp.Rows(0)("Villege").ToString() <> "" Then
            str_Adress += dttmp.Rows(0)("Villege").ToString() & " "
        End If

        If dttmp.Rows(0)("Building").ToString() <> "" Then
            str_Adress += dttmp.Rows(0)("Building").ToString() & " "
        End If

        If dttmp.Rows(0)("HomeFloor").ToString() <> "" Then
            str_Adress += dttmp.Rows(0)("HomeFloor").ToString() & " "
        End If

        If dttmp.Rows(0)("HomeRoom").ToString() <> "" Then
            str_Adress += dttmp.Rows(0)("HomeRoom").ToString() & " "
        End If

        'crlf = chr(13) ; 
        If dttmp.Rows(0)("Moo").ToString() <> "" Or dttmp.Rows(0)("Address").ToString() <> "" Or dttmp.Rows(0)("Villege").ToString() <> "" Or dttmp.Rows(0)("Building").ToString() <> "" Or dttmp.Rows(0)("HomeFloor").ToString() <> "" Or dttmp.Rows(0)("HomeRoom").ToString() <> "" Then
            str_Adress += Chr(13)
        End If
        If dttmp.Rows(0)("Soi").ToString() <> "" Then
            str_Adress += "ซ." & dttmp.Rows(0)("Soi").ToString() & " "
        End If
        If dttmp.Rows(0)("Road").ToString() <> "" Then
            str_Adress += "ถ." & dttmp.Rows(0)("Road").ToString() & " "
        End If
        If dttmp.Rows(0)("Soi").ToString() <> "" Or dttmp.Rows(0)("Road").ToString() <> "" Then
            str_Adress += Chr(13)
        End If
        If dttmp.Rows(0)("Province").ToString() <> "กรุงเทพมหานคร" Then
            If dttmp.Rows(0)("SubDist").ToString() <> "" Then
                str_Adress += Environment.NewLine & "ต." & dttmp.Rows(0)("SubDist").ToString() & " "
            End If
        End If
        If dttmp.Rows(0)("Province").ToString() = "กรุงเทพมหานคร" Then
            If dttmp.Rows(0)("SubDist").ToString() <> "" Then
                str_Adress += Environment.NewLine & "แขวง" & dttmp.Rows(0)("SubDist").ToString() & " "
            End If
        End If

        If dttmp.Rows(0)("Province").ToString() <> "กรุงเทพมหานคร" Then
            If dttmp.Rows(0)("Dist").ToString() <> "" Then
                str_Adress += "อ." & dttmp.Rows(0)("Dist").ToString() & " "
            End If
        End If
        If dttmp.Rows(0)("Province").ToString() = "กรุงเทพมหานคร" Then
            If dttmp.Rows(0)("Dist").ToString() <> "" Then
                str_Adress += "เขต" & dttmp.Rows(0)("Dist").ToString() & " "
            End If
        End If
        str_Adress += Chr(13)
        If dttmp.Rows(0)("Province").ToString() <> "กรุงเทพมหานคร" Then
            If dttmp.Rows(0)("Province").ToString() <> "" Then
                str_Adress += Environment.NewLine & "จ." & dttmp.Rows(0)("Province").ToString() & " "
            End If
        End If
        If dttmp.Rows(0)("Province").ToString() = "กรุงเทพมหานคร" Then
            If dttmp.Rows(0)("Province").ToString() <> "" Then
                str_Adress += Environment.NewLine & dttmp.Rows(0)("Province").ToString() & " "
            End If
        End If

        If dttmp.Rows(0)("Zip").ToString() <> "" Then
            str_Adress += dttmp.Rows(0)("Zip").ToString() & " "
        End If

        '------
        If dttmp.Rows(0)("SAddress").ToString() <> "" Then
            str_Adress2 += "เลขที่ " & dttmp.Rows(0)("SAddress").ToString() & " "
        End If

        If dttmp.Rows(0)("SMoo").ToString() <> "" Then
            str_Adress2 += "ม." & dttmp.Rows(0)("SMoo").ToString() & " "
        End If

        If dttmp.Rows(0)("SVillege").ToString() <> "" Then
            str_Adress2 += dttmp.Rows(0)("SVillege").ToString() & " "
        End If

        If dttmp.Rows(0)("SBuilding").ToString() <> "" Then
            str_Adress2 += dttmp.Rows(0)("SBuilding").ToString() & " "
        End If

        If dttmp.Rows(0)("SHomeFloor").ToString() <> "" Then
            str_Adress2 += dttmp.Rows(0)("SHomeFloor").ToString() & " "
        End If

        If dttmp.Rows(0)("SHomeRoom").ToString() <> "" Then
            str_Adress2 += dttmp.Rows(0)("SHomeRoom").ToString() & " "
        End If

        'crlf = chr(13) ; 
        If dttmp.Rows(0)("SMoo").ToString() <> "" Or dttmp.Rows(0)("SAddress").ToString() <> "" Or dttmp.Rows(0)("SVillege").ToString() <> "" Or dttmp.Rows(0)("SBuilding").ToString() <> "" Or dttmp.Rows(0)("SHomeFloor").ToString() <> "" Or dttmp.Rows(0)("SHomeRoom").ToString() <> "" Then
            str_Adress2 += Chr(13)
        End If
        If dttmp.Rows(0)("SSoi").ToString() <> "" Then
            str_Adress2 += "ซ." & dttmp.Rows(0)("SSoi").ToString() & " "
        End If
        If dttmp.Rows(0)("SRoad").ToString() <> "" Then
            str_Adress2 += "ถ." & dttmp.Rows(0)("SRoad").ToString() & " "
        End If
        If dttmp.Rows(0)("SSoi").ToString() <> "" Or dttmp.Rows(0)("SRoad").ToString() <> "" Then
            str_Adress2 += Chr(13)
        End If
        If dttmp.Rows(0)("SProvince").ToString() <> "กรุงเทพมหานคร" Then
            If dttmp.Rows(0)("SSubDist").ToString() <> "" Then
                str_Adress2 += Environment.NewLine & "ต." & dttmp.Rows(0)("SSubDist").ToString() & " "
            End If
        End If
        If dttmp.Rows(0)("SProvince").ToString() = "กรุงเทพมหานคร" Then
            If dttmp.Rows(0)("SSubDist").ToString() <> "" Then
                str_Adress2 += Environment.NewLine & "แขวง" & dttmp.Rows(0)("SSubDist").ToString() & " "
            End If
        End If

        If dttmp.Rows(0)("SProvince").ToString() <> "กรุงเทพมหานคร" Then
            If dttmp.Rows(0)("SDist").ToString() <> "" Then
                str_Adress2 += "อ." & dttmp.Rows(0)("SDist").ToString() & " "
            End If
        End If
        If dttmp.Rows(0)("SProvince").ToString() = "กรุงเทพมหานคร" Then
            If dttmp.Rows(0)("SDist").ToString() <> "" Then
                str_Adress2 += "เขต" & dttmp.Rows(0)("SDist").ToString() & " "
            End If
        End If
        str_Adress2 += Chr(13)
        If dttmp.Rows(0)("SProvince").ToString() <> "กรุงเทพมหานคร" Then
            If dttmp.Rows(0)("SProvince").ToString() <> "" Then
                str_Adress2 += Environment.NewLine & "จ." & dttmp.Rows(0)("SProvince").ToString() & " "
            End If
        End If
        If dttmp.Rows(0)("SProvince").ToString() = "กรุงเทพมหานคร" Then
            If dttmp.Rows(0)("SProvince").ToString() <> "" Then
                str_Adress2 += Environment.NewLine & dttmp.Rows(0)("SProvince").ToString() & " "
            End If
        End If

        If dttmp.Rows(0)("SZip").ToString() <> "" Then
            str_Adress2 += dttmp.Rows(0)("SZip").ToString() & " "
        End If

        B1 = str_Adress
        B2 = str_Adress2
    End Sub

    Private Sub LINE_Phone(ByVal productid As String, ByRef C2 As String)

        If productid = "14" Then
            C2 = "0-2285-8000"
        ElseIf productid = "8" Then
            C2 = "0-2670-4444"
        ElseIf productid = "20" Then
            C2 = "0-2640-4500"
        ElseIf productid = "84" Then
            C2 = "0-2695-0700"
        ElseIf productid = "83" Then
            C2 = "1748"
        ElseIf productid = "10" Then
            C2 = "02-022-1100"
        ElseIf productid = "18" Then
            C2 = "0-2792-5500"
        ElseIf productid = "9" Then
            C2 = "1557"
        ElseIf productid = "13" Then
            C2 = "1790"
        ElseIf productid = "15" Then
            C2 = "0-2869-3333"
        ElseIf productid = "63" Then
            C2 = "02-624-1111"
        ElseIf productid = "24" Then
            C2 = "02-257-8080"
        ElseIf productid = "71" Then
            C2 = "02-209-3299"
        ElseIf productid = "52" Then
            C2 = "1726"
        End If
    End Sub

    Public Sub CreateFolder(ByVal DirInfo_1 As String)

        Dim DirInfo = New DirectoryInfo(DirInfo_1)
        If Not DirInfo.Exists Then
            DirInfo.Create()
        End If
    End Sub
    Private Sub SetappAcc(ByVal tmpAppID As String)

        Dim tmpdate1 As String
        Dim Count As Integer = 0
        Dim str As String
        Dim Command As SqlCommand
        Dim DataReader As SqlDataReader
        Dim reportX, ex1 As String
        reportX = "1"
        dt = New DataTable

        dt.Columns.Add("0")
        dt.Columns.Add("1")
        dt.Columns.Add("2")
        dt.Columns.Add("3")
        dt.Columns.Add("4")
        dt.Columns.Add("5")
        dt.Columns.Add("6")
        dt.Columns.Add("7")
        dt.Columns.Add("8")
        dt.Columns.Add("9")
        dt.Columns.Add("10")
        dt.Columns.Add("11")
        dt.Columns.Add("12")
        dt.Columns.Add("13")
        dt.Columns.Add("14")
        dt.Columns.Add("15")
        dt.Columns.Add("16")
        dt.Columns.Add("17")
        dt.Columns.Add("18")
        dt.Columns.Add("19")
        dt.Columns.Add("20")
        dt.Columns.Add("21")
        dt.Columns.Add("22")
        dt.Columns.Add("23")
        dt.Columns.Add("24")
        dt.Columns.Add("25")
        dt.Columns.Add("26")
        dt.Columns.Add("27")
        dt.Columns.Add("28")
        dt.Columns.Add("29")
        dt.Columns.Add("30")
        dt.Columns.Add("31")
        dt.Columns.Add("32")
        dt.Columns.Add("33")
        dt.Columns.Add("34")
        dt.Columns.Add("35")
        dt.Columns.Add("36")
        dt.Columns.Add("37")
        dt.Columns.Add("38")
        dt.Columns.Add("39")
        dt.Columns.Add("40")
        dt.Columns.Add("41")
        dt.Columns.Add("42")
        dt.Columns.Add("43")
        dt.Columns.Add("44")
        dt.Columns.Add("45")
        dt.Columns.Add("46")
        dt.Columns.Add("47")
        dt.Columns.Add("48")
        dt.Columns.Add("49")
        dt.Columns.Add("50")
        dt.Columns.Add("51")
        dt.Columns.Add("52")
        dt.Columns.Add("53")
        dt.Columns.Add("54")
        dt.Columns.Add("55")
        dt.Columns.Add("56")
        dt.Columns.Add("57")
        dt.Columns.Add("58")
        dt.Columns.Add("59")
        dt.Columns.Add("60")
        dt.Columns.Add("61")
        dt.Columns.Add("63")
        dt.Columns.Add("64")
        dt.Columns.Add("65")
        dt.Columns.Add("66")
        dt.Columns.Add("67")
        dt.Columns.Add("68")
        dt.Columns.Add("69")
        dt.Columns.Add("70")
        dt.Columns.Add("71")
        dt.Columns.Add("72")
        dt.Columns.Add("73")
        dt.Columns.Add("74")
        dt.Columns.Add("75")
        dt.Columns.Add("76")
        dt.Columns.Add("77")
        dt.Columns.Add("78")
        dt.Columns.Add("87")
        dt.Columns.Add("88")
        dt.Columns.Add("89")
        dt.Columns.Add("90")
        dt.Columns.Add("91")
        dt.Columns.Add("92")
        dt.Columns.Add("93")
        dt.Columns.Add("94")
        dt.Columns.Add("95")
        dt.Columns.Add("96")
        dt.Columns.Add("expprotectdate")
        dt.Columns.Add("sname")
        dt.Columns.Add("DetDeviceAdd")
        dt.Columns.Add("Old_Insu")
        dt.Columns.Add("Old_PolicyNo")
        dt.Columns.Add("ASNComment")
        dt.Columns.Add("IDCARD")
        dt.Columns.Add("Status")




        If (Format$(Date.Now, "yyyy") > 2300) Then
            tmpdate1 = Format$(Date.Now, "yyyy") - 543 & Format$(Date.Now, "MMdd")
        Else
            tmpdate1 = Format$(Date.Now, "yyyymmdd")
        End If

        str = "delete from  tmp_QC_app01 where UserID = '" & Request.Cookies("UserID").Value & "'"
        Command = New SqlCommand(str, Conn)
        Command.ExecuteNonQuery()
        str = "delete from tmp_QC_PayCredit where UserID = '" & Request.Cookies("UserID").Value & "'"
        Command = New SqlCommand(str, Conn)
        Command.ExecuteNonQuery()
        str = "delete from tmp_QC_app02 where UserID = '" & Request.Cookies("UserID").Value & "'"
        Command = New SqlCommand(str, Conn)
        Command.ExecuteNonQuery()

        str = "select a.* from (select a.*,b.initth from (select  a.*,ProTypeBrand, Addr + ' ' + b.Road AS a1, b.SubDist + ' ' + b.Dist + ' ' + b.Province + ' ' + b.Zip AS a2, '  ' AS a3 from (select a.*,b.fname,b.lname from (select a.*,b.cartypename  from  (SELECT a.initid,a.FNameTH, a.LNameTH, a.Address, a.SAddress, a.Villege, a.Svillege, " + _
                              "a.Building, a.SBuilding, a.HomeFloor, a.SHomeFloor, a.HomeRoom, " + _
                              "a.SHomeRoom, a.Moo, a.SMoo, a.Soi, a.SSoi, a.Road, a.SRoad, " + _
                              "a.SubDist, a.SSubDist, a.Dist, a.SDist, a.Province, a.SProvince, a.Zip, " + _
                              "a.SZip, b.AssignTo, b.CarDriverNo, b.CarDriver1 + ' ' + b.CarDriverLname1 as  CarDriver1, b.CarDriverBorn1, b.CarDriver2 + ' ' + b.CarDriverLname2 as  CarDriver2, b.CarDriverBorn2, " + _
                             "b.DBornNO1, b.DBornDate1, b.DBornAddr1, b.DBornNO2, b.DBornDate2, b.DBornAddr2, b.CarID, " + _
                             "b.CarBuyDate, b.CarFixIn, b.CarSize, b.CarNo, b.CarBoxNo, b.CarType, b.CarYear, b.CarBrand, " + _
                              "b.CarSeries,c.AppID, c.AppNO, c.ProDuctID, c.ProDuctIDCarpet, c.AppStatus, " + _
                              "c.ProtectDate, c.ProPrice, c.IsProvalue, c.ProValue,c.discounttype,  " + _
                              "c.Typeprovalue, c.IsCarpet, c.CarPet, c.FirstPay, c.YearPay, c.Lost_Life1, " + _
                              "c.Lost_Life2, c.Lost_Prop1, c.Lost_Prop2, c.Lost_Car1, c.Lost_Car2, " + _
                              "c.Car_Fire, c.Acc_Lost1, c.Acc_Lost2, c.Acc_Lost3, c.Acc_Lost4, " + _
                              "c.Maintain, c.Insure, c.Apprela, c.Pledge, c.PolicyNO, " + _
                              "c.PolicyDate, c.SendPolicyDate, a.sname, c.expprotectdate,  " + _
                              "c.CarPetNO , c.CarPetDate,c.successdate as createdate,c.appcomment as ASNcomt,'" & reportX & "' as typereport " & ex1 & ", c.Comments,c.Old_Insu,c.Old_PolicyNo,c.appcomment,a.IDCard,z.StatusCode " + _
                              "FROM TblCustomer a INNER JOIN " + _
                              "TblCar b ON a.CusID = b.CusID INNER JOIN " + _
                              " TblApplication c ON b.IdCar = c.Idcar  " + _
                              " LEFT JOIN TblStatus z ON b.curstatus = z.StatusID where  appid = '" & tmpAppID & "'" + _
                              " ) a inner join  Tbl_Cartype b  on a.cartype =  b.cartypeid) a inner join tbluser b on a.assignto = b.userid ) a inner join Tbl_ProductType b on a.productid = b.protypeid )  a  inner join TblCustomerInit b  on a.initid = b.initid) a where a.appid not in (SELECT distinct appid  From TblAppDoc Where  Docid = 99 ) order by fnameth,lnameth "

        Command = New SqlCommand(str, Conn)
        DataReader = Command.ExecuteReader()
        If DataReader.HasRows Then
            While DataReader.Read
                Dim dtr As DataRow = dt.NewRow
                If IsDBNull(DataReader(0)) = False Then
                    dtr("0") = DataReader(0)
                End If
                If IsDBNull(DataReader(1)) = False Then
                    dtr("1") = DataReader(1)
                End If
                If IsDBNull(DataReader(2)) = False Then
                    dtr("2") = DataReader(2)
                End If
                If IsDBNull(DataReader(3)) = False Then
                    dtr("3") = DataReader(3)
                End If
                If IsDBNull(DataReader(4)) = False Then
                    dtr("4") = DataReader(4)
                End If
                If IsDBNull(DataReader(5)) = False Then
                    dtr("5") = DataReader(5)
                End If
                If IsDBNull(DataReader(6)) = False Then
                    dtr("6") = DataReader(6)
                End If
                If IsDBNull(DataReader(7)) = False Then
                    dtr("7") = DataReader(7)
                End If
                If IsDBNull(DataReader(8)) = False Then
                    dtr("8") = DataReader(8)
                End If
                If IsDBNull(DataReader(9)) = False Then
                    dtr("9") = DataReader(9)
                End If
                If IsDBNull(DataReader(10)) = False Then
                    dtr("10") = DataReader(10)
                End If
                If IsDBNull(DataReader(11)) = False Then
                    dtr("11") = DataReader(11)
                End If
                If IsDBNull(DataReader(12)) = False Then
                    dtr("12") = DataReader(12)
                End If
                If IsDBNull(DataReader(13)) = False Then
                    dtr("13") = DataReader(13)
                End If
                If IsDBNull(DataReader(14)) = False Then
                    dtr("14") = DataReader(14)
                End If
                If IsDBNull(DataReader(15)) = False Then
                    dtr("15") = DataReader(15)
                End If
                If IsDBNull(DataReader(16)) = False Then
                    dtr("16") = DataReader(16)
                End If
                If IsDBNull(DataReader(17)) = False Then
                    dtr("17") = DataReader(17)
                End If
                If IsDBNull(DataReader(18)) = False Then
                    dtr("18") = DataReader(18)
                End If
                If IsDBNull(DataReader(19)) = False Then
                    dtr("19") = DataReader(19)
                End If
                If IsDBNull(DataReader(20)) = False Then
                    dtr("20") = DataReader(20)
                End If
                If IsDBNull(DataReader(21)) = False Then
                    dtr("21") = DataReader(21)
                End If
                If IsDBNull(DataReader(22)) = False Then
                    dtr("22") = DataReader(22)
                End If
                If IsDBNull(DataReader(23)) = False Then
                    dtr("23") = DataReader(23)
                End If
                If IsDBNull(DataReader(24)) = False Then
                    dtr("24") = DataReader(24)
                End If
                If IsDBNull(DataReader(25)) = False Then
                    dtr("25") = DataReader(25)
                End If
                If IsDBNull(DataReader(26)) = False Then
                    dtr("26") = DataReader(26)
                End If
                If IsDBNull(DataReader(27)) = False Then
                    dtr("27") = DataReader(27)
                End If
                If IsDBNull(DataReader(28)) = False Then
                    dtr("28") = DataReader(28)
                End If
                If IsDBNull(DataReader(29)) = False Then
                    dtr("29") = DataReader(29)
                End If
                If IsDBNull(DataReader(30)) = False Then
                    dtr("30") = Format(DataReader(30), "dd/MM/yyyy")
                End If
                If IsDBNull(DataReader(31)) = False Then
                    dtr("31") = DataReader(31)
                End If
                If IsDBNull(DataReader(32)) = False Then
                    dtr("32") = Format(DataReader(32), "dd/MM/yyyy")
                End If
                If IsDBNull(DataReader(33)) = False Then
                    dtr("33") = DataReader(33)
                End If
                If IsDBNull(DataReader(34)) = False Then
                    dtr("34") = Format(DataReader(34), "dd/MM/yyyy")
                End If
                If IsDBNull(DataReader(35)) = False Then
                    dtr("35") = DataReader(35)
                End If
                If IsDBNull(DataReader(36)) = False Then
                    dtr("36") = DataReader(36)
                End If
                If IsDBNull(DataReader(37)) = False Then
                    dtr("37") = Format(DataReader(37), "dd/MM/yyyy")
                End If
                If IsDBNull(DataReader(38)) = False Then
                    dtr("38") = DataReader(38)
                End If
                If IsDBNull(DataReader(39)) = False Then
                    dtr("39") = DataReader(39)
                End If
                If IsDBNull(DataReader(40)) = False Then
                    dtr("40") = Format(DataReader(40), "dd/MM/yyyy")
                End If
                If IsDBNull(DataReader(41)) = False Then
                    dtr("41") = DataReader(41)
                End If
                If IsDBNull(DataReader(42)) = False Then
                    dtr("42") = DataReader(42)
                End If
                If IsDBNull(DataReader(43)) = False Then
                    dtr("43") = DataReader(43)
                End If
                If IsDBNull(DataReader(44)) = False Then
                    dtr("44") = DataReader(44)
                End If
                If IsDBNull(DataReader(45)) = False Then
                    dtr("45") = DataReader(45)
                End If
                If IsDBNull(DataReader(46)) = False Then
                    dtr("46") = DataReader(46)
                End If
                If IsDBNull(DataReader(47)) = False Then
                    dtr("47") = DataReader(47)
                End If
                If IsDBNull(DataReader(48)) = False Then
                    dtr("48") = DataReader(48)
                End If
                If IsDBNull(DataReader(49)) = False Then
                    dtr("49") = DataReader(49)
                End If
                If IsDBNull(DataReader(50)) = False Then
                    dtr("50") = DataReader(50)
                End If
                If IsDBNull(DataReader(51)) = False Then
                    dtr("51") = DataReader(51)
                End If
                If IsDBNull(DataReader(52)) = False Then
                    dtr("52") = DataReader(52)
                End If
                If IsDBNull(DataReader(53)) = False Then
                    dtr("53") = DataReader(53)
                End If
                If IsDBNull(DataReader(54)) = False Then
                    dtr("54") = Format(DataReader(54), "dd/MM/yyyy")
                End If
                If IsDBNull(DataReader(55)) = False Then
                    dtr("55") = Format(DataReader(55), "###,###,##0.#0") 'proprice
                End If
                If IsDBNull(DataReader(56)) = False Then 'IsProvalue
                    dtr("56") = DataReader(56)
                End If
                If IsDBNull(DataReader(57)) = False Then
                    dtr("57") = Format(DataReader(57), "###,###,##0.#0") 'เบี้ยประกันภัย (provalue)
                End If
                If IsDBNull(DataReader(58)) = False Then 'discounttype
                    dtr("58") = DataReader(58)
                End If
                If IsDBNull(DataReader(59)) = False Then 'typeProvalue
                    dtr("59") = DataReader(59)
                End If
                If IsDBNull(DataReader(60)) = False Then
                    dtr("60") = DataReader(60) 'IsCarpet
                End If
                If IsDBNull(DataReader(61)) = False Then
                    dtr("61") = Format(DataReader(61), "###,###,##0.#0") 'พรบ.(carpet)
                End If
                If IsDBNull(DataReader(63)) = False Then
                    dtr("63") = Format(DataReader(63), "###,###,##0.#0") ' จ่ายรวม(totalx)
                End If
                If IsDBNull(DataReader(64)) = False Then
                    dtr("64") = Format(DataReader(64), "###,###,##0.#0") 'ความเสียหายต่อชีวิต / คน (Lost_life1)
                End If
                If IsDBNull(DataReader(65)) = False Then
                    dtr("65") = Format(DataReader(65), "###,###,##0.#0") 'ความเสียหายต่อชีวิต / ครั้ง (Lost_Life2)
                End If
                If IsDBNull(DataReader(66)) = False Then
                    dtr("66") = Format(DataReader(66), "###,###,##0.#0") 'ความเสียหายต่อทรัพย์สิน/ครั้ง (Lost_Prop)1)
                End If
                If IsDBNull(DataReader(67)) = False Then
                    dtr("67") = Format(DataReader(67), "###,###,##0.#0") 'Lost_prop2
                End If
                If IsDBNull(DataReader(68)) = False Then
                    dtr("68") = Format(DataReader(68), "###,###,##0.#0") ' Lost_Car1
                End If
                If IsDBNull(DataReader(69)) = False Then
                    dtr("69") = Format(DataReader(69), "###,###,##0.#0") 'Lost_car2
                End If
                If IsDBNull(DataReader(70)) = False Then
                    dtr("70") = Format(DataReader(70), "###,###,##0.#0") 'car_fire
                End If
                If IsDBNull(DataReader(71)) = False Then
                    dtr("71") = DataReader(71) 'acc_lost
                End If
                If IsDBNull(DataReader(72)) = False Then
                    dtr("72") = Format(DataReader(72), "###,###,##0.#0")
                End If
                If IsDBNull(DataReader(73)) = False Then
                    dtr("73") = DataReader(73)
                End If
                If IsDBNull(DataReader(74)) = False Then
                    dtr("74") = Format(DataReader(74), "###,###,##0.#0")
                End If
                If IsDBNull(DataReader(75)) = False Then
                    dtr("75") = Format(DataReader(75), "###,###,##0.#0")
                End If
                If IsDBNull(DataReader(76)) = False Then
                    dtr("76") = Format(DataReader(76), "###,###,##0.#0")
                End If
                If IsDBNull(DataReader(77)) = False Then
                    dtr("77") = DataReader(77)
                End If
                If IsDBNull(DataReader(78)) = False Then
                    dtr("78") = DataReader(78)
                End If
                If IsDBNull(DataReader(87)) = False Then
                    dtr("87") = DataReader(87)
                End If
                If IsDBNull(DataReader(88)) = False Then
                    dtr("88") = DataReader(88)
                End If
                If IsDBNull(DataReader(89)) = False Then
                    dtr("89") = DataReader(89)
                End If
                If IsDBNull(DataReader(90)) = False Then
                    dtr("90") = DataReader(90)
                End If
                If IsDBNull(DataReader(91)) = False Then
                    dtr("91") = DataReader(91)
                End If
                If IsDBNull(DataReader(92)) = False Then
                    dtr("92") = DataReader(92)
                End If
                If IsDBNull(DataReader(93)) = False Then
                    dtr("93") = DataReader(93)
                End If
                If IsDBNull(DataReader(94)) = False Then
                    dtr("94") = DataReader(94)
                End If
                If IsDBNull(DataReader(95)) = False Then
                    dtr("95") = DataReader(95)
                End If
                If IsDBNull(DataReader(96)) = False Then
                    dtr("96") = DataReader(96)
                End If
                If IsDBNull(DataReader("expprotectdate")) = False Then
                    dtr("expprotectdate") = Format(DataReader("expprotectdate"), "dd/MM/yyyy")
                End If
                If IsDBNull(DataReader("sname")) = False Then
                    dtr("sname") = DataReader("sname")
                End If
                If IsDBNull(DataReader("Comments")) = False Then
                    dtr("DetDeviceAdd") = DataReader("Comments")
                End If
                If IsDBNull(DataReader("Old_Insu")) = False Then
                    dtr("Old_Insu") = DataReader("Old_Insu")
                End If
                If IsDBNull(DataReader("Old_PolicyNo")) = False Then
                    dtr("Old_PolicyNo") = DataReader("Old_PolicyNo")
                End If
                If IsDBNull(DataReader("appcomment")) = False Then
                    dtr("ASNComment") = DataReader("appcomment")
                End If
                If IsDBNull(DataReader("IDCard")) = False Then
                    dtr("IDCard") = DataReader("IDCard")
                End If
                If IsDBNull(DataReader("StatusCode")) = False Then
                    dtr("Status") = DataReader("StatusCode")
                End If

                dt.Rows.Add(dtr)
            End While
        End If
        DataReader.Close()

        Dim sName As String = dt.Rows(0).Item("sname")


        str = "insert into tmp_QC_app01 ( " +
        " initid, FNameTH, LNameTH, Address, SAddress, Villege, Svillege, Building, SBuilding, HomeFloor, SHomeFloor, HomeRoom, SHomeRoom, Moo, " +
        " SMoo, Soi, SSoi, Road, SRoad, SubDist, SSubDist, Dist, SDist, Province, SProvince, Zip, SZip, AssignTo, CarDriverNo, CarDriver1,CarDriverBorn1, " +
        " CarDriver2, CarDriverBorn2, DBornNO1, DBornDate1, DBornAddr1, DBornNO2, DBornDate2, DBornAddr2, CarID, CarBuyDate, CarFixIn, CarSize, " +
        " CarNo, CarBoxNo, CarType, CarYear, CarBrand, CarSeries, AppID, AppNO, ProDuctID, ProDuctIDCarpet, AppStatus, ProtectDate, ProPrice, IsProvalue , " +
        " ProValue, discounttype, Typeprovalue, IsCarpet, CarPet, FirstPay, YearPay, Lost_Life1, Lost_Life2, Lost_Prop1, Lost_Prop2, Lost_Car1, Lost_Car2 ," +
        " Car_Fire, Acc_Lost1, Acc_Lost2, Acc_Lost3, Acc_Lost4, Maintain, Insure, Apprela, Pledge,ASNcomt, typereport,  cartypename, fname, lname, ProTypeBrand,  a1 , a2, a3, initth,expprotectdate,sname,UserID,DetDeviceAdd,Old_Insu,Old_PolicyNo,ASNComment,IDCard,CurStatus ) " +
        " values ( " +
          " '" & dt.Rows(0).Item("0") & "','" & dt.Rows(0).Item("1") & "','" & dt.Rows(0).Item("2") & "','" & dt.Rows(0).Item("3") & "','" & dt.Rows(0).Item("4") & "','" & dt.Rows(0).Item("5") & "','" & dt.Rows(0).Item("6") & "','" & dt.Rows(0).Item("7") & "','" & dt.Rows(0).Item("8") & "','" & dt.Rows(0).Item("9") & "' ," +
        " '" & dt.Rows(0).Item("10") & "','" & dt.Rows(0).Item("11") & "','" & dt.Rows(0).Item("12") & "','" & dt.Rows(0).Item("13") & "','" & dt.Rows(0).Item("14") & "','" & dt.Rows(0).Item("15") & "','" & dt.Rows(0).Item("16") & "','" & dt.Rows(0).Item("17") & "','" & dt.Rows(0).Item("18") & "','" & dt.Rows(0).Item("19") & "', " +
        " '" & dt.Rows(0).Item("20") & "','" & dt.Rows(0).Item("21") & "','" & dt.Rows(0).Item("22") & "','" & dt.Rows(0).Item("23") & "','" & dt.Rows(0).Item("24") & "','" & dt.Rows(0).Item("25") & "','" & dt.Rows(0).Item("26") & "'," & dt.Rows(0).Item("27") & ",'" & dt.Rows(0).Item("28") & "','" & dt.Rows(0).Item("29") & "'," +
        " '" & dt.Rows(0).Item("30") & "','" & dt.Rows(0).Item("31") & "','" & (dt.Rows(0).Item("32")) & "','" & dt.Rows(0).Item("33") & "','" & (dt.Rows(0).Item("34")) & "','" & dt.Rows(0).Item("35") & "','" & dt.Rows(0).Item("36") & "','" & (dt.Rows(0).Item("37")) & "','" & dt.Rows(0).Item("38") & "','" & dt.Rows(0).Item("39") & "' ," +
        " '" & (dt.Rows(0).Item("40")) & "','" & dt.Rows(0).Item("41") & "','" & dt.Rows(0).Item("42") & "','" & dt.Rows(0).Item("43") & "','" & dt.Rows(0).Item("44") & "','" & dt.Rows(0).Item("45") & "','" & dt.Rows(0).Item("46") & "','" & dt.Rows(0).Item("47") & "','" & dt.Rows(0).Item("48") & "','" & dt.Rows(0).Item("49") & "' ," +
        " '" & dt.Rows(0).Item("50") & "','" & dt.Rows(0).Item("51") & "','" & dt.Rows(0).Item("52") & "','" & dt.Rows(0).Item("53") & "','" & (dt.Rows(0).Item("54")) & "','" & dt.Rows(0).Item("55") & "','" & dt.Rows(0).Item("56") & "','" & dt.Rows(0).Item("57") & "','" & dt.Rows(0).Item("58") & "','" & dt.Rows(0).Item("59") & "' ," +
        " '" & dt.Rows(0).Item("60") & "','" & dt.Rows(0).Item("61") & "',0,'" & dt.Rows(0).Item("63") & "','" & dt.Rows(0).Item("64") & "','" & dt.Rows(0).Item("65") & "','" & dt.Rows(0).Item("66") & "','" & dt.Rows(0).Item("67") & "','" & dt.Rows(0).Item("68") & "','" & dt.Rows(0).Item("69") & "' ," +
        " '" & dt.Rows(0).Item("70") & "','" & dt.Rows(0).Item("71") & "','" & dt.Rows(0).Item("72") & "','" & dt.Rows(0).Item("73") & "','" & dt.Rows(0).Item("74") & "','" & dt.Rows(0).Item("75") & "','" & dt.Rows(0).Item("76") & "','" & dt.Rows(0).Item("77") & "','" & dt.Rows(0).Item("78") & "','" & Replace(dt.Rows(0).Item("87"), "'", "") & "' ," +
        " '" & dt.Rows(0).Item("88") & "','" & Replace(dt.Rows(0).Item("89"), "'", "") & "','" & dt.Rows(0).Item("90") & "','" & dt.Rows(0).Item("91") & "','" & Replace(dt.Rows(0).Item("92"), "'", "") & "','" & dt.Rows(0).Item("93") & "','" & dt.Rows(0).Item("94") & "','" & dt.Rows(0).Item("95") & "','" & dt.Rows(0).Item("96") & "'," +
        "'" & dt.Rows(0).Item("expprotectdate") & "','" & sName & "','" & Request.Cookies("UserID").Value & "','" & Replace(dt.Rows(0).Item("DetDeviceAdd"), "'", "") & "','" & dt.Rows(0).Item("Old_Insu") & "','" & dt.Rows(0).Item("Old_PolicyNo") & "','" & Replace(dt.Rows(0).Item("ASNComment"), "'", "") & "','" & dt.Rows(0).Item("IDCard") & "','" & dt.Rows(0).Item("Status") & "') "

        Command = New SqlCommand(str, Conn)
        Command.ExecuteNonQuery()

        '''''''''''''''''''
        'Call SetCodePrint()


        str = "select  m.*,a.*,b.*,c.*,d.*, e.*,f.*  from  (select a.*,b.initth   from (select  a.*,ProTypeBrand, Addr + ' ' + b.Road AS a1, b.SubDist + ' ' + b.Dist + ' ' + b.Province + ' ' + b.Zip AS a2, 'â·Ã : ' + b.Tel + '  ' AS a3 from (select a.*,b.fname,b.lname from (select a.*,b.cartypename  from  (SELECT      " + _
                        "c.AppID,b.CarType,b.assignto,c.ProDuctID,a.initid," + _
                        "c.CarPetNO , c.CarPetDate,c.successdate as createdate,c.appcomment as ASNcomt,'" & reportX & "' as typereport " & ex1 + _
              "FROM TblCustomer a INNER JOIN " + _
                        "TblCar b ON a.CusID = b.CusID INNER JOIN " + _
                      " TblApplication c ON b.IdCar = c.Idcar  where appid = '" & tmpAppID & "'" + _
  " ) a inner join  Tbl_Cartype b  on a.cartype =  b.cartypeid) a inner join tbluser b on a.assignto = b.userid ) a inner join Tbl_ProductType b on a.productid = b.protypeid )  a  inner join TblCustomerInit b  on a.initid = b.initid ) m left join " + _
   " (select appid appid1 ,Typepay Typepay1,convert(int,payid) payid1,AppointDate AppointDate1,totalpay totalpay1 from tblapppay where payid = 1) a on m.appid = a.appid1 left join " + _
      " (select appid appid2 ,Typepay Typepay2,convert(int,payid) payid2,AppointDate AppointDate2,totalpay totalpay2 from tblapppay where payid = 2) b on m.appid = b.appid2 left join " + _
      " (select appid appid3 ,Typepay Typepay3,convert(int,payid) payid3,AppointDate AppointDate3,totalpay totalpay3 from tblapppay where payid = 3) c on m.appid = c.appid3 left join " + _
      " (select appid appid4 ,Typepay Typepay4,convert(int,payid) payid4,AppointDate AppointDate4,totalpay totalpay4 from tblapppay where payid = 4) d on m.appid = d.appid4  left join " + _
          " (select appid appid5 ,Typepay Typepay5,convert(int,payid) payid5,AppointDate AppointDate5,totalpay totalpay5 from tblapppay where payid = 5) e on m.appid = e.appid5 left join " + _
      " (select appid appid6 ,Typepay Typepay6,convert(int,payid) payid6,AppointDate AppointDate6,totalpay totalpay6 from tblapppay where payid = 6) f on m.appid = f.appid6 "
        Command = New SqlCommand(str, Conn)
        DataReader = Command.ExecuteReader()
        Dim dt2 As DataTable
        dt2 = New DataTable

        dt2.Columns.Add("0")
        dt2.Columns.Add("1")
        dt2.Columns.Add("2")
        dt2.Columns.Add("3")
        dt2.Columns.Add("4")
        dt2.Columns.Add("5")
        dt2.Columns.Add("7")
        dt2.Columns.Add("8")
        dt2.Columns.Add("9")
        dt2.Columns.Add("10")
        dt2.Columns.Add("11")
        dt2.Columns.Add("12")
        dt2.Columns.Add("13")
        dt2.Columns.Add("14")
        dt2.Columns.Add("15")
        dt2.Columns.Add("16")
        dt2.Columns.Add("17")
        dt2.Columns.Add("18")
        dt2.Columns.Add("19")
        dt2.Columns.Add("20")
        dt2.Columns.Add("22")
        dt2.Columns.Add("23")
        dt2.Columns.Add("24")
        dt2.Columns.Add("25")
        dt2.Columns.Add("27")
        dt2.Columns.Add("28")
        dt2.Columns.Add("29")
        dt2.Columns.Add("30")
        dt2.Columns.Add("32")
        dt2.Columns.Add("33")
        dt2.Columns.Add("34")
        dt2.Columns.Add("35")
        dt2.Columns.Add("37")
        dt2.Columns.Add("38")
        dt2.Columns.Add("39")
        dt2.Columns.Add("40")
        dt2.Columns.Add("42")
        dt2.Columns.Add("43")
        dt2.Columns.Add("44")
        dt2.Columns.Add("45")
        dt2.Columns.Add("47")
        dt2.Columns.Add("AppointDate1")
        dt2.Columns.Add("AppointDate2")
        dt2.Columns.Add("AppointDate3")
        dt2.Columns.Add("AppointDate4")
        dt2.Columns.Add("AppointDate5")
        dt2.Columns.Add("AppointDate6")

        Dim d1, d2, d3, d4, d5, d6 As String

        If DataReader.HasRows Then
            While DataReader.Read
                Dim dtr As DataRow = dt2.NewRow
                If IsDBNull(DataReader(0)) = False Then
                    dtr("0") = DataReader(0)
                End If
                If IsDBNull(DataReader(1)) = False Then
                    dtr("1") = DataReader(1)
                End If
                If IsDBNull(DataReader(2)) = False Then
                    dtr("2") = DataReader(2)
                End If
                If IsDBNull(DataReader(3)) = False Then
                    dtr("3") = DataReader(3)
                End If
                If IsDBNull(DataReader(4)) = False Then
                    dtr("4") = DataReader(4)
                End If
                If IsDBNull(DataReader(5)) = False Then
                    dtr("5") = DataReader(5)
                End If

                If IsDBNull(DataReader(7)) = False Then
                    dtr("7") = Format(DataReader(7), "dd/MM/yyyy")
                End If
                If IsDBNull(DataReader(8)) = False Then
                    dtr("8") = DataReader(8)
                End If
                If IsDBNull(DataReader(9)) = False Then
                    dtr("9") = DataReader(9)
                End If
                If IsDBNull(DataReader(10)) = False Then
                    dtr("10") = DataReader(10)
                End If
                If IsDBNull(DataReader(11)) = False Then
                    dtr("11") = DataReader(11)
                End If
                If IsDBNull(DataReader(12)) = False Then
                    dtr("12") = DataReader(12)
                End If
                If IsDBNull(DataReader(13)) = False Then
                    dtr("13") = DataReader(13)
                End If
                If IsDBNull(DataReader(14)) = False Then
                    dtr("14") = DataReader(14)
                End If
                If IsDBNull(DataReader(15)) = False Then
                    dtr("15") = DataReader(15)
                End If
                If IsDBNull(DataReader(16)) = False Then
                    dtr("16") = DataReader(16)
                End If
                If IsDBNull(DataReader(17)) = False Then
                    dtr("17") = DataReader(17)
                End If
                If IsDBNull(DataReader(18)) = False Then
                    dtr("18") = DataReader(18)
                End If
                If IsDBNull(DataReader(19)) = False Then
                    dtr("19") = DataReader(19)
                End If
                If IsDBNull(DataReader(20)) = False Then
                    dtr("20") = DataReader(20)
                End If

                If IsDBNull(DataReader(22)) = False Then
                    dtr("22") = DataReader(22)
                End If
                If IsDBNull(DataReader(23)) = False Then
                    dtr("23") = DataReader(23)
                End If
                If IsDBNull(DataReader(24)) = False Then
                    dtr("24") = DataReader(24)
                End If
                If IsDBNull(DataReader(25)) = False Then
                    dtr("25") = DataReader(25)
                End If

                If IsDBNull(DataReader(27)) = False Then
                    dtr("27") = DataReader(27)
                End If
                If IsDBNull(DataReader(28)) = False Then
                    dtr("28") = DataReader(28)
                End If
                If IsDBNull(DataReader(29)) = False Then
                    dtr("29") = DataReader(29)
                End If
                If IsDBNull(DataReader(30)) = False Then
                    dtr("30") = DataReader(30)
                End If

                If IsDBNull(DataReader(32)) = False Then
                    dtr("32") = DataReader(32)
                End If
                If IsDBNull(DataReader(33)) = False Then
                    dtr("33") = DataReader(33)
                End If
                If IsDBNull(DataReader(34)) = False Then
                    dtr("34") = DataReader(34)
                End If
                If IsDBNull(DataReader(35)) = False Then
                    dtr("35") = DataReader(35)
                End If

                If IsDBNull(DataReader(37)) = False Then
                    dtr("37") = DataReader(37)
                End If
                If IsDBNull(DataReader(38)) = False Then
                    dtr("38") = DataReader(38)
                End If
                If IsDBNull(DataReader(39)) = False Then
                    dtr("39") = DataReader(39)
                End If
                If IsDBNull(DataReader(40)) = False Then
                    dtr("40") = DataReader(40)
                End If

                If IsDBNull(DataReader(42)) = False Then
                    dtr("42") = DataReader(42)
                End If
                If IsDBNull(DataReader(43)) = False Then
                    dtr("43") = DataReader(43)
                End If
                If IsDBNull(DataReader(44)) = False Then
                    dtr("44") = DataReader(44)
                End If
                If IsDBNull(DataReader(45)) = False Then
                    dtr("45") = DataReader(45)
                End If

                If IsDBNull(DataReader(47)) = False Then
                    dtr("47") = DataReader(47)
                End If
                dt2.Rows.Add(dtr)
                '-----------------------------------------------------------------------------------------
                '--------------------------------------------------------------------------------
                If IsDBNull(DataReader("AppointDate1")) = True Then
                    d1 = "  "
                Else
                    d1 = Format(DataReader("AppointDate1"), "dd/MM/yyyy")
                End If
                If IsDBNull(DataReader("AppointDate2")) = True Then
                    d2 = "  "
                Else
                    d2 = Format(DataReader("AppointDate2"), "dd/MM/yyyy")
                End If

                If IsDBNull(DataReader("AppointDate3")) = True Then
                    d3 = "  "
                Else
                    d3 = Format(DataReader("AppointDate3"), "dd/MM/yyyy")
                End If

                If IsDBNull(DataReader("AppointDate4")) = True Then
                    d4 = "  "
                Else
                    d4 = Format(DataReader("AppointDate4"), "dd/MM/yyyy")
                End If
                If IsDBNull(DataReader("AppointDate5")) = True Then
                    d5 = "  "
                Else
                    d5 = Format(DataReader("AppointDate5"), "dd/MM/yyyy")
                End If
                If IsDBNull(DataReader("AppointDate6")) = True Then
                    d6 = "  "
                Else
                    d6 = Format(DataReader("AppointDate6"), "dd/MM/yyyy")
                End If

            End While
        End If
        DataReader.Close()

        str = " insert  into  tmp_QC_PayCredit (" +
         " AppID, CarType, assignto, ProDuctID, initid, CarPetNO, createdate, ASNcomt, typereport, cartypename, " +
        " fname, lname, ProTypeBrand, a1, a2, a3, initth, appid1, Typepay1, payid1, AppointDate1, totalpay1, appid2, Typepay2, payid2, AppointDate2, totalpay2, " +
        " appid3 , Typepay3, payid3, AppointDate3, totalpay3, appid4, Typepay4, payid4, AppointDate4, totalpay4 , appid5, Typepay5, payid5, AppointDate5, totalpay5, appid6, Typepay6, payid6, AppointDate6, totalpay6,UserID  )" +
        " values ( " +
          " '" & dt2.Rows(0).Item("0") & "','" & dt2.Rows(0).Item("1") & "','" & dt2.Rows(0).Item("2") & "','" & dt2.Rows(0).Item("3") & "','" & dt2.Rows(0).Item("4") & "','" & dt2.Rows(0).Item("5") & "','" & (dt2.Rows(0).Item("7")) & "','" & Replace(dt2.Rows(0).Item("8"), "'", "") & "','" & dt2.Rows(0).Item("9") & "' ," +
        " '" & dt2.Rows(0).Item("10") & "','" & dt2.Rows(0).Item("11") & "','" & dt2.Rows(0).Item("12") & "','" & dt2.Rows(0).Item("13") & "','" & dt2.Rows(0).Item("14") & "','" & dt2.Rows(0).Item("15") & "','" & dt2.Rows(0).Item("16") & "','" & dt2.Rows(0).Item("17") & "','" & chkNull(dt2.Rows(0).Item("18"), 0) & "','" & chkNull(dt2.Rows(0).Item("19"), 0) & "', " +
        " '" & chkNull(dt2.Rows(0).Item("20"), 0) & "','" & d1 & "','" & chkNull(dt2.Rows(0).Item("22"), 1) & "','" & chkNull(dt2.Rows(0).Item("23"), 0) & "','" & chkNull(dt2.Rows(0).Item("24"), 0) & "','" & chkNull(dt2.Rows(0).Item("25"), 0) & "','" & d2 & "','" & chkNull(dt2.Rows(0).Item("27"), 1) & "','" & chkNull(dt2.Rows(0).Item("28"), 0) & "','" & chkNull(dt2.Rows(0).Item("29"), 0) & "', " +
        " '" & chkNull(dt2.Rows(0).Item("30"), 0) & "','" & d3 & "','" & chkNull(dt2.Rows(0).Item("32"), 1) & "','" & chkNull(dt2.Rows(0).Item("33"), 0) & "','" & chkNull(dt2.Rows(0).Item("34"), 0) & "','" & chkNull(dt2.Rows(0).Item("35"), 0) & "','" & d4 & "','" & chkNull(dt2.Rows(0).Item("37"), 1) & "' ,'" & chkNull(dt2.Rows(0).Item("38"), 0) & "','" & chkNull(dt2.Rows(0).Item("39"), 0) & "'," +
        " '" & chkNull(dt2.Rows(0).Item("40"), 0) & "','" & d5 & "','" & chkNull(dt2.Rows(0).Item("42"), 1) & "' ,'" & chkNull(dt2.Rows(0).Item("43"), 0) & "','" & chkNull(dt2.Rows(0).Item("44"), 0) & "','" & chkNull(dt2.Rows(0).Item("45"), 0) & "','" & d6 & "','" & chkNull(dt2.Rows(0).Item("47"), 1) & "','" & Request.Cookies("UserID").Value & "' ) "
        Command = New SqlCommand(str, Conn)
        Command.ExecuteNonQuery()


        Dim pd1 As String = ""
        str = " SELECT TblApplication.AppID, TblCar.IdCard1, TblCar.TypeCard1, TblCar.IdCard2, TblCar.TypeCard2, TblCustomer.AddressRemark, ProtectDateCarpet, expProtectDateCarpet, " + _
                             " ' ' AS tmp3, ' ' AS tmp4, ' ' AS tmp5 , ' ' AS tmp6, ' ' AS tmp7, ' ' AS tmp8,iscarpet " + _
      "    FROM TblCustomer INNER JOIN " + _
                            " TblCar ON TblCustomer.CusID = TblCar.CusID INNER JOIN " + _
                            " TblApplication ON TblCar.IdCar = TblApplication.Idcar where  appid = '" & tmpAppID & "'"
        Command = New SqlCommand(str, Conn)
        DataReader = Command.ExecuteReader()
        Dim dt3 As DataTable
        dt3 = New DataTable

        dt3.Columns.Add("0")
        dt3.Columns.Add("1")
        dt3.Columns.Add("2")
        dt3.Columns.Add("3")
        dt3.Columns.Add("4")
        dt3.Columns.Add("5")
        dt3.Columns.Add("6")
        dt3.Columns.Add("7")
        dt3.Columns.Add("8")
        dt3.Columns.Add("9")
        dt3.Columns.Add("10")
        dt3.Columns.Add("11")
        dt3.Columns.Add("12")
        dt3.Columns.Add("13")
        dt3.Columns.Add("iscarpet")
        dt3.Columns.Add("ProtectDateCarpet")
        dt3.Columns.Add("expProtectDateCarpet")

        If DataReader.HasRows Then
            While DataReader.Read
                Dim dtr As DataRow = dt3.NewRow
                If IsDBNull(DataReader(0)) = False Then
                    dtr("0") = DataReader(0)
                End If
                If IsDBNull(DataReader(1)) = False Then
                    dtr("1") = DataReader(1)
                End If
                If IsDBNull(DataReader(2)) = False Then
                    dtr("2") = DataReader(2)
                End If
                If IsDBNull(DataReader(3)) = False Then
                    dtr("3") = DataReader(3)
                End If
                If IsDBNull(DataReader(4)) = False Then
                    dtr("4") = DataReader(4)
                End If
                If IsDBNull(DataReader(5)) = False Then
                    dtr("5") = DataReader(5)
                End If
                If IsDBNull(DataReader(6)) = False Then
                    dtr("6") = Format(DataReader(6), "dd/MM/yyyy")
                End If
                If IsDBNull(DataReader(7)) = False Then
                    dtr("7") = Format(DataReader(7), "dd/MM/yyyy")
                End If
                If IsDBNull(DataReader(8)) = False Then
                    dtr("8") = DataReader(8)
                End If
                If IsDBNull(DataReader(9)) = False Then
                    dtr("9") = DataReader(9)
                End If
                If IsDBNull(DataReader(10)) = False Then
                    dtr("10") = DataReader(10)
                End If
                If IsDBNull(DataReader(11)) = False Then
                    dtr("11") = DataReader(11)
                End If
                If IsDBNull(DataReader(12)) = False Then
                    dtr("12") = DataReader(12)
                End If
                If IsDBNull(DataReader(13)) = False Then
                    dtr("13") = DataReader(13)
                End If
                If IsDBNull(DataReader("iscarpet")) = False Then
                    dtr("iscarpet") = DataReader("iscarpet")
                End If
                If IsDBNull(DataReader("ProtectDateCarpet")) = False Then
                    dtr("ProtectDateCarpet") = Format(DataReader("ProtectDateCarpet"), "dd/MM/yyyy")
                End If
                If IsDBNull(DataReader("expProtectDateCarpet")) = False Then
                    dtr("expProtectDateCarpet") = Format(DataReader("expProtectDateCarpet"), "dd/MM/yyyy")
                End If
                dt3.Rows.Add(dtr)
            End While
        End If
        DataReader.Close()

        If dt3.Rows(0).Item("iscarpet") = 1 Then
            Session("pd2") = "ระยะเวลา พรบ.:  " + dt3.Rows(0).Item("ProtectDateCarpet") + " - " + dt3.Rows(0).Item("expProtectDateCarpet")
            Session("pd1") = dt3.Rows(0).Item("ProtectDateCarpet") + " - " + dt3.Rows(0).Item("expProtectDateCarpet")
        Else
            Session("pd2") = "ระยะเวลา พรบ.: - "
            Session("pd1") = "-"
        End If

        str = "insert into tmp_QC_app02 ( AppID, IdCard1, TypeCard1, IdCard2, TypeCard2, AddressRemark, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8,UserID) values ( " + _
        " '" & dt3.Rows(0).Item("0") & "','" & dt3.Rows(0).Item("1") & "','" & dt3.Rows(0).Item("2") & "','" & dt3.Rows(0).Item("3") & "','" & dt3.Rows(0).Item("4") & "','" & dt3.Rows(0).Item("5") & "','" & dt3.Rows(0).Item("6") & "','" & dt3.Rows(0).Item("7") & "','" & dt3.Rows(0).Item("8") & "' ," + _
       " '" & dt3.Rows(0).Item("9") & "','" & dt3.Rows(0).Item("10") & "','" & dt3.Rows(0).Item("11") & "','" & dt3.Rows(0).Item("12") & "','" & dt3.Rows(0).Item("13") & "','" & Request.Cookies("UserID").Value & "')"
        Command = New SqlCommand(str, Conn)
        Command.ExecuteNonQuery()

        str = "select  distinct payid from tblapppay where appid = '" & tmpAppID & "'"
        Dim Count2 As Integer = 0
        Command = New SqlCommand(str, Conn)
        DataReader = Command.ExecuteReader()
        If DataReader.HasRows Then
            While DataReader.Read
                Count2 += 1
            End While
        End If
        DataReader.Close()

        str = "update  tmp_QC_PayCredit set  asncomt = '" & Count2 & "' WHERE UserID = '" & Request.Cookies("UserID").Value & "'"
        Command = New SqlCommand(str, Conn)
        Command.ExecuteNonQuery()

        str = " SELECT TblCustomer.Sname " + _
              " FROM TblCar INNER JOIN " + _
              " TblApplication TblApplication_1 ON TblCar.IdCar = TblApplication_1.Idcar INNER JOIN " + _
              " TblCustomer ON TblCar.CusID = TblCustomer.CusID " + _
              " where appid = '" & tmpAppID & "'"
        Command = New SqlCommand(str, Conn)
        DataReader = Command.ExecuteReader()
        Dim dt4 As DataTable
        dt4 = New DataTable
        dt4.Columns.Add("sName")

        If DataReader.HasRows Then
            While DataReader.Read
                Dim dtr As DataRow = dt4.NewRow
                If IsDBNull(DataReader("sName")) = False Then
                    dtr("sName") = DataReader("sName")
                End If
                dt4.Rows.Add(dtr)
            End While
        End If
        DataReader.Close()

        str = "update  tmp_QC_PayCredit set  a1 = '" & dt4.Rows(0).Item("sName") & "' WHERE UserID = '" & Request.Cookies("UserID").Value & "'"
        Command = New SqlCommand(str, Conn)
        Command.ExecuteNonQuery()

        Conn.Close()
    End Sub
    Function chkNull(ByVal f1 As Object, ByVal flag As Byte) As String
        If IsDBNull(f1) = True Then
            chkNull = "  "
        Else
            If flag = 1 Then
                chkNull = Format(CInt(f1), "###,###")
            Else
                chkNull = f1
            End If
        End If
        Return chkNull
    End Function
    
    Protected Function chkAutoPassQC() As Boolean

        Dim chk As Boolean = False
        Dim dtchkAutoPassQC = New DataTable
        dtchkAutoPassQC = DataAccess.DataRead("select UserID from TblLogUserQc where statusID = 1  and UserID = " & Request.Cookies("userID").Value)
        If dtchkAutoPassQC.Rows.Count > 0 Then
            chk = True
        Else
            chk = False
        End If

        Return chk
    End Function
	
	
	
	
	Private Sub ToShow(ByVal str As String)

        lblPhone.Font.Bold = True
        lblPhone.Font.Name = "PROMPT-MEDIUM"
        btntryit.Font.Name = "PROMPT-MEDIUM"

        If str = "consent" Then
            lblPhone.Text = "[ยินยอมให้ติดต่อ]"
            lblPhone.ForeColor = System.Drawing.Color.Green
            ImageButton1.Visible = True
            btntryit.Visible = False
        ElseIf str = "unconsent" Then
            lblPhone.Text = "[ไม่ยินยอมให้ติดต่อ]"
            lblPhone.ForeColor = System.Drawing.Color.Red
            ImageButton1.Visible = False
            btntryit.Visible = False
        Else
            lblPhone.Text = str
            lblPhone.Font.Bold = True
            lblPhone.ForeColor = System.Drawing.Color.Coral
            ImageButton1.Visible = False
            btntryit.Visible = True
        End If

    End Sub
   

    Protected Function check_conent() As String
        Dim strr As String = ""
        If IsNumeric(GetPhoneNumber()) AndAlso GetPhoneNumber() Is Nothing = False Then
            Dim callapi As New callAPI_pdpa_
            strr = callapi.callapi_check(GetPhoneNumber(), Request.Cookies("userID").Value, 0)
        End If

        Return strr
    End Function

    Protected Sub ddCall_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddCall.SelectedIndexChanged
        check_data_toconsent()
    End Sub
	Protected Sub btntryit_Click(sender As Object, e As System.EventArgs) Handles btntryit.Click
        check_data_toconsent()
    End Sub
	Private Sub check_data_toconsent()
        Dim strr As String = ""
        strr = check_conent()
        If strr = "" Then
            lblPhone.Text = ""
            ImageButton1.Visible = False
            btntryit.Visible = False
        Else
            ToShow(strr)
        End If
    End Sub
	
	
    Protected Function usercreateid() As Integer

        Dim createid As Integer = 0
        Dim dtc = New DataTable
        Dim strqry As String
        strqry = " SELECT createid FROM TblCar  where IdCar=" & Request.QueryString("IdCar").ToString
        dt = DataAccess.DataRead(strqry)
        If dtc.Rows.Count > 0 Then
            createid = dtc.Rows(0).Item("createid")
        End If
		
        Return createid
    End Function
	' add new start 03/05/2022
    Protected Sub btnscriptopen_Click(sender As Object, e As System.EventArgs) Handles btnscriptopen.Click
        Dim Query = New System.Text.StringBuilder()

        Query.Append(" select top 1 isnull(a1.fname ,'')+' '+isnull(a1.lname ,'') as 'emp'")
        Query.Append(" ,isnull(a4.InitTH ,'คุณ')+ isnull(a3.FNameTH ,'')+' '+isnull(a3.LNameTH ,'') as 'cus'")
        Query.Append(" ,isnull(a2.CarBrand,'') as 'brand',isnull(a2.CarSeries,'') as 'model',isnull(a2.CarYear,'') as 'caryears'")
        Query.Append(" from tbluser a1 inner join tblcar a2 on a1.userid=a2.assignto")
        Query.Append(" inner join tblcustomer a3 on a2.cusid=a3.cusid ")
        Query.Append(" inner join TblCustomerInit a4 on a4.InitID=a3.InitID")
        Query.Append(" where a2.Idcar =" & Request.QueryString("IdCar").ToString())

        Dim adapter_openscript As SqlDataAdapter = New SqlDataAdapter(Query.ToString, Conn)
        Dim dt_openscript As DataTable = New DataTable
        adapter_openscript.Fill(dt_openscript)

        Dim emp As String = "" & dt_openscript.Rows(0)("emp").ToString()
        Dim cus As String = "" & dt_openscript.Rows(0)("cus").ToString()
        'Dim car As String = dt_openscript.Rows(0)("brand").ToString() & "" & dt_openscript.Rows(0)("model").ToString() & "" & dt_openscript.Rows(0)("caryears").ToString()

        Dim html As New System.Text.StringBuilder()
        html.Append("<table >")
        html.Append("<tr><td valign=\'top\'>พนักงานขาย :</td><td style=\'border-bottom: 1pt dashed;\' >สวัสดี (ค่ะ / ครับ) <font color=\'red\'>" & emp & "</font> ติดต่อจากบริษัท ASN Broker (นะคะ /นะครับ) ปัจจุบัน <font color=\'red\'>" & emp & "</font><br> เรียนสายอยู่กับ <font color=\'red\'>" & cus & "</font> ถูกต้อง (นะคะ / นะครับ)</td></tr>")
        html.Append("<tr><td valign=\'top\'><font color=\'green\'>ลูกค้า :</font></td><td style=\'border-bottom: 1pt dashed;\' >ค่ะ / ครับ</td></tr>")
        html.Append("<tr><td valign=\'top\'>พนักงานขาย :</td><td style=\'border-bottom: 1pt dashed;\' >จากข้อมูลรถยนต์ ยี่ห้อ <font color=\'red\'>" & dt_openscript.Rows(0)("brand").ToString() & "</font> รุ่น <font color=\'red\'>" & dt_openscript.Rows(0)("model").ToString() & "</font> ปี <font color=\'red\'>" & dt_openscript.Rows(0)("caryears").ToString() & "</font> เป็นรถยนต์ของ <font color=\'red\'>" & cus & "</font> ถูกต้อง (นะคะ / นะครับ)</td></tr>")
        html.Append("<tr><td valign=\'top\'>พนักงานขาย :</td><td style=\'border-bottom: 1pt dashed;\' ><font color=\'red\'>" & cus & "</font> สะดวกให้ข้อมูลกับเจ้าหน้าที่เพื่อเสนอนำผลิตภัณฑ์ประกันรถยนต์ที่หมาะสมกับลูกค้า (นะคะ/นะครับ)</td></tr>")
        html.Append("<tr><td valign=\'top\'><font color=\'green\'>ลูกค้า :</font></td><td style=\'border-bottom: 1pt dashed;\' >ค่ะ / ครับ</td></tr>")
        html.Append("<tr><td valign=\'top\'>พนักงานขาย :</td><td style=\'border-bottom: 1pt dashed;\' >ทางบริษัทฯ ขออนุญาตินำเสนอประกันภัยรถยนต์ของบริษัทฯ (ชื่อบริษัทประกันที่จะนำเสนอ <br> พร้อมชี้แจงความ  คุ้มครอง , ทุนประกัน , ราคาเบี้ยประกันภัยและโปรโมชั่นต่างๆ)</td></tr>")
        html.Append("<tr><td valign=\'top\'><font color=\'green\'>ลูกค้า :</font></td><td style=\'border-bottom: 1pt dashed;\' >สนใจ , ขอคิดดูก่อน หรือเหตุผลอื่นๆ</td></tr>")
        html.Append("</table>")

        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "scriptopen", "scriptopen('" & html.ToString() & "');", True)
    End Sub
   
    Protected Sub btnunconsent1_Click(sender As Object, e As System.EventArgs) Handles btnunconsent1.Click
        call_pdpa_insertuncon()
    End Sub
    Protected Sub btnunconsent2_Click(sender As Object, e As System.EventArgs) Handles btnunconsent2.Click
        call_pdpa_insertuncon()
    End Sub
    Protected Sub btnconcent_Click(sender As Object, e As System.EventArgs) Handles btnconcent.Click
        'consent 
        Dim callapi As New callAPI_pdpa_
        Dim logid As Int64 = callapi.i_LogConsent(frmCus.DataKey.Item(0), Request.Cookies("userID").Value, GetPhoneNumber(), 1) ''1=consent,0=unconsent      
        If logid > 0 Then
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('บันทึกเรียบร้อย');", True)
        End If

    End Sub
    Private Sub call_pdpa_insertuncon() 'unconsent
        Dim reponse As String
        Dim callapi As New callAPI_pdpa_
        reponse = callapi.callfunction_insertpdpa_all(frmCus.DataKey.Item(0), FunAll.ObjFindControl("Label1", frmCus).Text, FunAll.ObjFindControl("Label2", frmCus).Text,
                                                      Request.Cookies("userID").Value, GetPhoneNumber(), 0)
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('" & reponse & "');", True)
    End Sub
	
End Class
