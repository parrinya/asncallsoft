﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Partial Class Modules_Sale_Phone_frmCall
    Inherits System.Web.UI.Page
    Dim FunAll As New FuntionAll
    Dim ISODate As New ISODate
    Dim Conn As SqlConnection
    Dim com As SqlCommand
    Dim StrQuery As New QueryPhone
    Dim dt As DataTable
    Dim DataAccess As New DataAccess
    Public TelAjax As String = ""
    Protected Sub rbApp_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        For Each oldRow As GridViewRow In GvApp.Rows
            DirectCast(oldRow.FindControl("rbApp"), RadioButton).Checked = False
        Next

        Dim rb As RadioButton = DirectCast(sender, RadioButton)
        Dim row As GridViewRow = DirectCast(rb.NamingContainer, GridViewRow)
        DirectCast(row.FindControl("rbApp"), RadioButton).Checked = True
        SearchAppDetail()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
			typeeditapp.Visible = False
            If GvApp.Rows.Count > 0 Then
                If Request.QueryString("SType") = 3 Then
                    For i As Integer = 0 To GvApp.Rows.Count - 1
                        If Request.QueryString("AppID").ToString = GvApp.DataKeys(i).Item(0) Then
                            Dim rb As RadioButton = FunAll.ObjFindControl("rbApp", GvApp.Rows(i).Cells(0))
                            rb.Checked = True
                        End If
                    Next
                Else
                    Dim rb As RadioButton = FunAll.ObjFindControl("rbApp", GvApp.Rows(0).Cells(0))
                    rb.Checked = True

                End If
                SearchAppDetail()
            End If


            txtAppoint.Text = Date.Today.Day & "/" & Date.Today.Month & "/" & Date.Today.Year
            txtHour.Text = Date.Now.Hour
            txtMin.Text = Date.Now.Minute
            ViewState("StatusPhone") = 1
            Try
                lblTel.Text = Request.QueryString("Tel").ToString
            Catch ex As Exception

            End Try

        End If

        Dim strConn = ConfigurationManager.ConnectionStrings("asnbroker").ConnectionString
        Conn = New SqlConnection()
        With Conn
            If .State = ConnectionState.Open Then .Close()
            .ConnectionString = strConn
            .Open()
        End With
    End Sub

    Protected Sub SearchAppDetail()
        Dim rb As RadioButton
        For i As Integer = 0 To GvApp.Rows.Count - 1
            rb = FunAll.ObjFindControl("rbApp", GvApp.Rows(i).Cells(0))
            If rb.Checked = True Then
                BindAppDetail(GvApp.DataKeys(i).Item(0))
                BindPayment(GvApp.DataKeys(i).Item(0))
                BindPhStatus(GvApp.DataKeys(i).Item(0))
                BindDocument(GvApp.DataKeys(i).Item(0))
            End If
        Next
    End Sub



    Protected Sub BindAppDetail(ByVal AppID As String)
        SqlApp2.SelectParameters("AppID").DefaultValue = AppID

    End Sub

    Protected Sub BindPayment(ByVal AppID As String)
        SqlPayment.SelectParameters("AppID").DefaultValue = AppID
        ddPayment.DataBind()
    End Sub
    Protected Sub BindDocument(ByVal AppID As String)
        SqlDocument.SelectParameters("AppID").DefaultValue = AppID
        GvDoc.DataBind()
    End Sub

    Protected Sub BindPhStatus(ByVal AppID As String)
        'SqlPhStatus.SelectParameters("AppID").DefaultValue = AppID

    End Sub

#Region "ผูกข้อมูลหมายเหตุการโทร"
    Protected Sub ddInType_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddInType.DataBound
        BindMainStatus()
        BindSubStatus()
    End Sub

    Protected Sub ddInType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddInType.SelectedIndexChanged
        BindMainStatus()
        BindSubStatus()
    End Sub

    Protected Sub ddMain_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddMain.SelectedIndexChanged
        BindSubStatus()
		ddMainEdit.DataBind()
        BindEdit()
    End Sub

    Protected Sub BindMainStatus()
        SqlMainStatus.SelectParameters("MType").DefaultValue = ddInType.SelectedValue
        ddMain.DataBind()
		BindEdit()
    End Sub

    Protected Sub BindSubStatus()
        SqlSubStatus.SelectParameters("MCaseID").DefaultValue = ddMain.SelectedValue
        ddSub.DataBind()
    End Sub
#End Region




    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        'If ViewState("StatusPhone") = 0 Then
        '    Response.Redirect("frmPhone.aspx?Tel=" & Request.QueryString("Tel").ToString & "&TypeSearch=" & Request.QueryString("TypeSearch").ToString & "&StatusPhone=0&QueueID=0")
        'Else
        '    Response.Redirect("frmPhone.aspx?Tel=" & Request.QueryString("Tel").ToString & "&TypeSearch=" & Request.QueryString("TypeSearch").ToString & "&StatusPhone=" & Request.QueryString("StatusPhone") & "&QueueID=" & Request.QueryString("QueueID").ToString)
        'End If

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        InsertTblCallCenter_Tmp()
        GvCase.DataBind()
        txtComments.Text = ""
    End Sub

    Protected Sub InsertTblCallCenter_Tmp()
	
        
		Dim editmstatus As Int16 = 0
        Dim editsstatus As Int16 = 0
        Dim editbytsr As Int16 = 1

        If ddMain.SelectedValue = "63" Then
            editmstatus = ddMainEdit.SelectedValue
            editsstatus = ddSubEdit.SelectedValue
            editbytsr = RBSelect.SelectedValue

        End If


        With SqlGvCaseCall
            .InsertParameters("MStatus").DefaultValue = ddMain.SelectedValue
            .InsertParameters("SStatus").DefaultValue = ddSub.SelectedValue
            .InsertParameters("Comments").DefaultValue = txtComments.Text
            .InsertParameters("CallType").DefaultValue = ddBound.SelectedValue
            .InsertParameters("CaseStatus").DefaultValue = ddStatusCall.SelectedValue
            .InsertParameters("AppointDate").DefaultValue = SortDateAppoint()
            .InsertParameters("EditMStatus").DefaultValue = editmstatus
            .InsertParameters("EditSStatus").DefaultValue = editsstatus
            .InsertParameters("EditbyTsr").DefaultValue = editbytsr
            .Insert()
        End With
    End Sub

    Protected Sub ddStatusCall_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddStatusCall.SelectedIndexChanged
        If ddStatusCall.SelectedValue = "P" Then
            PanelAppoint.Visible = True
        Else
            PanelAppoint.Visible = False

        End If
    End Sub

    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click
        If CheckAppointDate() = True Then
            SaveTblCallCenter()
  	    TblPendingCaseTsr()
            DeleteTblCallCenter_Tmp()
            GvCase.DataBind()
            GvCallHistory.DataBind()
            GvCallHistory2.DataBind()
            GvCall.DataBind()
            MsgBox("บันทึกเรียบร้อย...")
            ViewState("StatusPhone") = 0
            ddBound.SelectedValue = 0
            'Response.Redirect("frmPhone.aspx?Tel=" & Request.QueryString("Tel").ToString & "&TypeSearch=" & Request.QueryString("TypeSearch").ToString)

        End If
    End Sub

    Protected Sub SaveTblCallCenter()
        For i As Integer = 0 To GvCase.Rows.Count - 1
            com = New SqlCommand(StrQuery.SaveTblCall, Conn)
            With com
                .Parameters.Clear()
                .Parameters.Add("@CusID", SqlDbType.VarChar).Value = Request.QueryString("CusID").ToString
                .Parameters.Add("@IdCar", SqlDbType.VarChar).Value = Request.QueryString("IdCar").ToString
                .Parameters.Add("@AppId", SqlDbType.VarChar).Value = GetApp()
                .Parameters.Add("@Detail", SqlDbType.VarChar).Value = GvCase.DataKeys(i).Item(3)
                .Parameters.Add("@CaseStatus", SqlDbType.VarChar).Value = GvCase.DataKeys(i).Item(5)
                .Parameters.Add("@MCase1", SqlDbType.VarChar).Value = GvCase.DataKeys(i).Item(1)
                .Parameters.Add("@SCase1", SqlDbType.VarChar).Value = GvCase.DataKeys(i).Item(2)
                .Parameters.Add("@CreateID", SqlDbType.VarChar).Value = Request.Cookies("userID").Value
                .Parameters.Add("@callTYPE", SqlDbType.VarChar).Value = GvCase.DataKeys(i).Item(4)
                .Parameters.Add("@Appointdate", SqlDbType.DateTime).Value = GvCase.DataKeys(i).Item(6)
                .Parameters.Add("@QueueID", SqlDbType.NVarChar).Value = GetQueueID()
                '.ExecuteNonQuery()

            End With
			
			Dim obj As Object = com.ExecuteScalar()
            Dim callid As Int64
            If obj IsNot Nothing AndAlso obj IsNot DBNull.Value Then
                callid = Convert.ToInt64(obj)
                If GvCase.DataKeys(i).Item(1) = 63 Then
                    'tbleditapp to admin
                    With SqlDataSource1
                        .InsertParameters("Appid").DefaultValue = GetApp()
                        .InsertParameters("Comments").DefaultValue = GvCase.DataKeys(i).Item(3) & " (จาก ฝ่าย CallCenter)"
                        .InsertParameters("maineditdataid").DefaultValue = GvCase.DataKeys(i).Item(7)
                        .InsertParameters("submaineditdataid").DefaultValue = GvCase.DataKeys(i).Item(8)
                        .InsertParameters("EditbyTsr").DefaultValue = GvCase.DataKeys(i).Item(9)
                        .InsertParameters("CallID").DefaultValue = callid
                        .Insert()
                    End With
                End If
            End If
        Next

    End Sub

    Protected Function GetQueueID() As String
        If ddBound.SelectedValue = 0 Then
            Return Request.QueryString("QueueID").ToString
        Else
            Return CheckMySQL()
        End If
    End Function

    Protected Function CheckMySQL() As String

        dt = New DataTable
        dt = DataAccess.DataReadMySQL(GetQueryMySql)

        If dt.Rows.Count > 0 Then
            'CheckSQLSever(dt)
            Return dt.Rows(0).Item("queueid")

        Else
            Return 0
        End If


    End Function

    Protected Function GetQueryMySql() As String
        Dim strqry As String = ""
        strqry = "Select queueid"
        strqry += " from queuenow "
        strqry += " Where queuecarid = " & frmCar.DataKey.Item(0)
        strqry += " and queueagent = " & Request.Cookies("Extension").Value
        strqry += " and queuechkup=0 "
        strqry += " Order BY queuetimein DESC"
        Return strqry
    End Function

    Protected Sub DeleteTblCallCenter_Tmp()
        With SqlCallCenter
            .DeleteParameters("IdCar").DefaultValue = Request.QueryString("IdCar").ToString
            .Delete()
        End With
    End Sub

    Protected Function GetApp() As String
        If GvApp.Rows.Count > 0 Then
            Dim rb As RadioButton
            For i As Integer = 0 To GvApp.Rows.Count - 1
                rb = FunAll.ObjFindControl("rbApp", GvApp.Rows(i).Cells(0))
                If rb.Checked = True Then
                    Return GvApp.DataKeys(i).Item(0)
                End If
            Next
        Else
            Return 0
        End If
    End Function

    'จัดการเรียง วันที่นัด  วว ดด ปปปป  hh:mm
    Protected Function SortDateAppoint() As DateTime

        Dim AppointDateCV As DateTime
        Try
            If ddStatusCall.SelectedValue = "P" Then
                AppointDateCV = ISODate.SetISODate("th", txtAppoint.Text) & " " & txtHour.Text.Trim & ":" & txtMin.Text.Trim
            Else
                AppointDateCV = ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy")) & " " & DateTime.Now.Hour & ":" & DateTime.Now.Minute
            End If
            Return AppointDateCV
        Catch ex As Exception
            MsgBox("Format วันที่ผิดพลาด...")
        End Try


    End Function

    'Check การกรอกวันที่
    Protected Function CheckAppointDate() As Boolean
        Try
            Dim AppointDate As Date = SortDateAppoint()
            Dim DateNow As Date = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy")))

            If ddStatusCall.SelectedValue = "P" Then
                If AppointDate < DateNow Then
                    MsgBox("ไม่สามารถนัดเวลาน้อยกว่าเวลาปัจจุบันได้ : " & DateNow & " < " & AppointDate)
                    Return False
                Else
                    Return True
                End If
            Else
                Return True
            End If
        Catch ex As Exception
            MsgBox("fotmat วันที่ผิดพลาด : จะต้องเป็น วัน/เดือน/ปี")
            Return False
        End Try


    End Function

    Protected Sub Button6_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim strlink As String = ""
        strlink += "?Class=" & GetDataKey(1)
        strlink += "&&IdCar=" & Request.QueryString("IdCar").ToString
        strlink += "&&CusID=" & Request.QueryString("CusID").ToString
        strlink += "&&AppID=" & GetDataKey(0)
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script> window.open ('../Application/frmApplicationEdit.aspx" & strlink & "','Application');</script>")

    End Sub

    Protected Function GetDataKey(ByVal KeyValues As Integer) As String
        If frmApplication.DataItemCount > 0 Then
            Return frmApplication.DataKey.Item(KeyValues)
        Else
            Return 0
        End If
    End Function

    Protected Sub Button7_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button7.Click
        Dim strlink As String = ""
        strlink += "?AppID=" & frmApplication.DataKey.Item(0)
        strlink += "&PayID=" & ddPayment.SelectedValue
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script> window.open ('../Report/frmRptPayment.aspx" & strlink & "','PrintReport');</script>")

    End Sub

    'Script MsgBox
    Public Sub MsgBox(ByVal sMsg As String)

        Dim sb As New StringBuilder()
        Dim oFormObject As System.Web.UI.Control
        sMsg = sMsg.Replace("'", "\'")
        sMsg = sMsg.Replace(Chr(34), "\" & Chr(34))
        sMsg = sMsg.Replace(vbCrLf, "\n")
        sMsg = "<script language=javascript>alert(""" & sMsg & """)</script>"

        sb = New StringBuilder()
        sb.Append(sMsg)

        For Each oFormObject In Me.Controls
            If TypeOf oFormObject Is HtmlForm Then
                Exit For
            End If
        Next

        ' Add the javascript after the form object so that the 
        ' message doesn't appear on a blank screen.
        oFormObject.Controls.AddAt(oFormObject.Controls.Count, New LiteralControl(sb.ToString()))
    End Sub

    Protected Sub Button8_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button8.Click
        Dim strlink As String = ""
        strlink += "?AppID=" & frmApplication.DataKey.Item(0)
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script> window.open ('../Report/frmRptCoverNote.aspx" & strlink & "','PrintReport');</script>")

    End Sub


    Protected Sub Button9_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button9.Click
        Dim strlink As String = ""
        strlink = frmApplication.DataKey.Item(0)
        Dim SuccessDate As DateTime = frmApplication.DataKey.Item(2)
        If SuccessDate.Year < 2013 Then
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script> window.open ('file:///H:/" & strlink & "');</script>")
        Else
            'Dim strFolderDate As String = SuccessDate.Year & "/" & SuccessDate.ToString("MM") & "/"
            'Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script> window.open ('file:///H:/" & strFolderDate & strlink & "');</script>")
            ScriptManager.RegisterStartupScript(Page, Page.GetType, "AppStore", "OpenAppStore(" & strlink & ",0," & Request.Cookies("UserID").Value & ")", True)
        End If

    End Sub

    Protected Sub Button10_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button10.Click
        Dim strlink As String = ""
        strlink += "?Class=" & GetDataKey(1)
        strlink += "&&IdCar=" & Request.QueryString("IdCar").ToString
        strlink += "&&CusID=" & Request.QueryString("CusID").ToString
        strlink += "&&AppID=" & GetDataKey(0)
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script> window.open ('../Application/frmDocument.aspx" & strlink & "','Application');</script>")

    End Sub

    Protected Sub frmApplication_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmApplication.DataBound
        If frmApplication.DataItemCount > 0 Then
            BindBilling()
        End If

    End Sub

    Protected Sub BindBilling()
        Dim strqry As String = " Select UpdateDate from TblBilling_Detail where IsComplete = 1 and notPass= 0 and DispType in(0,1) and AppID=" & frmApplication.DataKey.Item(0)
        strqry += " Order by UpdateDate desc"
        Dim lblBilling As Label = FunAll.ObjFindControl("lblBilling", frmApplication)
        dt = New DataTable
        dt = DataAccess.DataRead(strqry)
        If dt.Rows.Count > 0 Then
            lblBilling.Text = dt.Rows(0).Item("UpdateDate").ToString
        Else
            lblBilling.Text = "ไม่มีการวางบิล"
        End If

    End Sub

    Protected Sub Button11_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button11.Click
        ddBound.SelectedValue = 1
        TelAjax = GetSoftPhoneUrl(GetPhoneNumber)
    End Sub

    Protected Function GetPhoneNumber() As String
        Select Case ddTel.SelectedValue
            Case 1
                Return frmTel.DataKey.Item(0)
            Case 2
                Return frmTel.DataKey.Item(1)
            Case 3
                Return frmTel.DataKey.Item(2)
            Case 4
                Return frmTel.DataKey.Item(3)
            Case 5
                Return frmTel.DataKey.Item(4)
            Case Else
                Return ""
        End Select
    End Function

    Protected Function GetSoftPhoneUrl(ByVal PhoneNumber As String) As String

        Dim CallUrl As String = ""

        CallUrl = "https://10.17.1.231/webcall/index.php?from=" & Request.Cookies("Extension").Value & "&to=" & PhoneNumber & "&carid=" & frmCar.DataKey.Item(0)

        Return CallUrl

    End Function

    Protected Sub Button13_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button13.Click
        Dim strlink As String = ""
        strlink += "?Class=" & GetDataKey(1)
        strlink += "&&IdCar=" & Request.QueryString("IdCar").ToString
        strlink += "&&CusID=" & Request.QueryString("CusID").ToString
        strlink += "&&AppID=" & GetDataKey(0)
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script> window.open ('../Application/frmPayment.aspx" & strlink & "','Application');</script>")

    End Sub

    Protected Sub Button14_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button14.Click
        txtComments.Text = ddSub.SelectedItem.ToString
    End Sub

    Protected Sub Button15_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button15.Click
        frmTel.DataBind()
    End Sub
    Protected Sub GvCallHistory_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvCallHistory.RowCommand
        If e.CommandName = "History" Then
            SqlDataSource1.SelectParameters("CallID").DefaultValue = GvCallHistory.DataKeys(e.CommandArgument).Item(0)
            GvDetail.DataSource = SqlDataSource1
            GvDetail.DataBind()
        End If
    End Sub



 Protected Sub TblPendingCaseTsr()
        Dim Ch As Boolean = False
        For i As Integer = 0 To GvCase.Rows.Count - 1
            If GvCase.DataKeys(i).Item(2) = 58 Or GvCase.DataKeys(i).Item(2) = 74 Or GvCase.DataKeys(i).Item(2) = 75 Or GvCase.DataKeys(i).Item(2) = 199 Or GvCase.DataKeys(i).Item(2) = 173 Then
                Ch = True
                With SqlCall
                    .InsertParameters("Appid").DefaultValue = GetDataKey(0)
                    .InsertParameters("Comments").DefaultValue = GvCase.DataKeys(i).Item(3)
                    .Insert()
                End With
            End If
        Next
        If Ch Then
            Savetblcalllisttsr()
        End If
    End Sub
    Protected Sub Savetblcalllisttsr()
        With SqlCallCenter
            .InsertParameters("IdCar").DefaultValue = Request.QueryString("IdCar").ToString
            .InsertParameters("AppId").DefaultValue = GetApp()
            .InsertParameters("statusid").DefaultValue = frmCar.DataKey.Item(1)
            .InsertParameters("divisionid").DefaultValue = "4"
            .InsertParameters("flag_list").DefaultValue = "0"
            .InsertParameters("createid").DefaultValue = Request.Cookies("userID").Value
            .Insert()
        End With
    End Sub
	Protected Sub ddMainEdit_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddMainEdit.SelectedIndexChanged
        BindEdit()
    End Sub
    Protected Sub SubMainBind()
        SqlSubEdit.SelectParameters("MainID").DefaultValue = ddMainEdit.SelectedValue
        ddSubEdit.DataBind()
    End Sub
	Protected Sub BindEdit()
        SubMainBind()
        If ddMain.SelectedValue = 63 Then
            typeeditapp.Visible = True

        Else
            typeeditapp.Visible = False
        End If
    End Sub
	Protected Sub Button16_Click(sender As Object, e As System.EventArgs) Handles Button16.Click
        Dim strlink As String = "AppID=" & frmApplication.DataKey.Item(0)

        ScriptManager.RegisterClientScriptBlock(UpdatePanel2, GetType(UpdatePanel), UpdatePanel2.ClientID, "window.open ('../../Sale/Phone/frmSMS.aspx?" & strlink & "','SMS','width=750,height=600,toolbar=0, menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=250,top=100') ;", True)
    End Sub
	
	
	
    Protected Sub frmTel_DataBound(sender As Object, e As System.EventArgs) Handles frmTel.DataBound
        frmTelDataBound()
    End Sub

    'frmTelDataBound()
    Private Sub frmTelDataBound()
        If frmTel.DataItemCount > 0 Then

            Dim str_res As String = ""
            If IsNumeric(frmTel.DataKey.Item(0)) AndAlso frmTel.DataKey.Item(0) Is Nothing = False Then
                Dim callapi As New callAPI_pdpa_
                ToShow(callapi.callapi_check(frmTel.DataKey.Item(0), Request.Cookies("userID").Value), "lbltel_pdpa")
            End If
            If IsNumeric(frmTel.DataKey.Item(1)) AndAlso frmTel.DataKey.Item(1) Is Nothing = False Then
                Dim callapi As New callAPI_pdpa_
                ToShow(callapi.callapi_check(frmTel.DataKey.Item(1), Request.Cookies("userID").Value), "lblotel_pdpa")
            End If
            If IsNumeric(frmTel.DataKey.Item(2)) AndAlso frmTel.DataKey.Item(2) Is Nothing = False Then
                Dim callapi As New callAPI_pdpa_
                ToShow(callapi.callapi_check(frmTel.DataKey.Item(2), Request.Cookies("userID").Value), "lblmobile_pdpa")
            End If

            If IsNumeric(frmTel.DataKey.Item(3)) AndAlso frmTel.DataKey.Item(3) Is Nothing = False Then
                Dim callapi As New callAPI_pdpa_
                ToShow(callapi.callapi_check(frmTel.DataKey.Item(3), Request.Cookies("userID").Value), "lbltel1_pdpa")
            End If
            If IsNumeric(frmTel.DataKey.Item(4)) AndAlso frmTel.DataKey.Item(4) Is Nothing = False Then
                Dim callapi As New callAPI_pdpa_
                ToShow(callapi.callapi_check(frmTel.DataKey.Item(4), Request.Cookies("userID").Value), "lbltel2_pdpa")
            End If
        End If
    End Sub

    Private Sub ToShow(ByVal str As String, ByVal lbltext As String)
        Dim lbltel As Label = FunAll.ObjFindControl(lbltext, frmTel)
        lbltel.Font.Bold = True
        lbltel.Font.Name = "PROMPT-MEDIUM"

        Dim strr As String = lbltext.Replace("lbl", "btn")
        Dim btn As Button = FunAll.ObjFindControl(strr, frmTel)

        If str = "consent" Then
            lbltel.Text = "[ยินยอมให้ติดต่อ]"
            lbltel.ForeColor = System.Drawing.Color.Green
           
            btn.Visible = True
        ElseIf str = "unconsent" Then
            lbltel.Text = "[ไม่ยินยอมให้ติดต่อ]"
            lbltel.ForeColor = System.Drawing.Color.Red
            btn.Visible = False
        Else
            lbltel.Text = str
            lbltel.ForeColor = System.Drawing.Color.Coral
            btn.Visible = False
        End If

    End Sub
    
    Protected Sub btntel_pdpa_Click(sender As Object, e As System.EventArgs)
        call_pdpa_insertuncon(0)
    End Sub
    Protected Sub btnotel_pdpa_Click(sender As Object, e As System.EventArgs)
        call_pdpa_insertuncon(1)
    End Sub
    Protected Sub btnmoile_pdpa_Click(sender As Object, e As System.EventArgs)
        call_pdpa_insertuncon(2)
    End Sub
    Protected Sub btntel1_pdpa_Click(sender As Object, e As System.EventArgs)
        call_pdpa_insertuncon(3)
    End Sub
    Protected Sub btntel2_pdpa_Click(sender As Object, e As System.EventArgs)
        call_pdpa_insertuncon(4)
    End Sub
    Private Sub call_pdpa_insertuncon(ByVal id As Int16)

        Dim phone As String = frmTel.DataKey.Item(id)
        Dim logid As Int64 = pdpa_log(phone)
        Dim reponse(1) As String
        Try
            Dim callapi As New callAPI_pdpa_
            reponse = callapi.callapi_insert(phone, Request.Cookies("userID").Value, FunAll.ObjFindControl("Label1", FormView1).Text, FunAll.ObjFindControl("Label2", FormView1).Text, 0)
            pdpa_update(reponse, logid)
            frmTelDataBound()
        Catch ex As Exception
            If logid <> 0 And reponse(0).ToString() = "" And reponse(1).ToString() = "" Then
                Dim exx As String = Replace(ex.ToString().Substring(0, 100), "'", "")
                Dim err(1) As String
                err(0) = "error[Catch]"
                err(1) = exx
                pdpa_update(err, logid)
            End If

        End Try
       
    End Sub
    Function pdpa_log(ByVal phone As String) As Int64
        Dim str As String = "INSERT INTO TbllogConsent(CusID ,status,CreateID,phone_number) VALUES (@CusID ,@status,@CreateID,@phone_number);SELECT Scope_Identity();"
        com = New SqlCommand(str, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@CusID", SqlDbType.VarChar).Value = Request.QueryString("CusID").ToString
            .Parameters.Add("@CreateID", SqlDbType.VarChar).Value = Request.Cookies("userID").Value
            .Parameters.Add("@status", SqlDbType.VarChar).Value = 0 '1=consent,0=unconsent
            .Parameters.Add("@phone_number", SqlDbType.VarChar).Value = phone

        End With

        Dim obj As Object = com.ExecuteScalar()
        Dim logid As Int64 = 0
        If obj IsNot Nothing AndAlso obj IsNot DBNull.Value Then
            logid = Convert.ToInt64(obj)
        End If

        Return logid

    End Function

    Protected Sub pdpa_update(ByVal respone As Array, ByVal logid As Int64)
        Dim str As String = "update TbllogConsent set response_status=@response_status ,response_message= @response_message where LogID=@LogID"

        com = New SqlCommand(str, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@LogID", SqlDbType.BigInt).Value = logid
            .Parameters.Add("@response_message", SqlDbType.VarChar).Value = respone(1).ToString()
            .Parameters.Add("@response_status", SqlDbType.VarChar).Value = respone(0).ToString()
            .ExecuteNonQuery()
        End With


    End Sub
End Class
