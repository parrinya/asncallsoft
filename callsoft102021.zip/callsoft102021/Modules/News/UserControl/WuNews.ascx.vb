﻿
Partial Class Modules_News_Top_WuNews
    Inherits System.Web.UI.UserControl

End Class
