﻿
Partial Class Modules_News_DetailNew_frmDetail
    Inherits System.Web.UI.Page

End Class
