﻿
Partial Class Modules_Sale_CheckApp_frmCaseAppPay
    Inherits System.Web.UI.Page
    Protected Sub BindGvAppProtect(ByVal months As Integer, ByVal years As Integer)


        SqlProtect.SelectParameters.Item("months").DefaultValue = months
        SqlProtect.SelectParameters.Item("years").DefaultValue = years
    End Sub

    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click
        BindGvAppProtect(ddMonth.SelectedValue, ddYear.SelectedValue)
    End Sub

    Protected Sub AddYear()
        Dim i As Integer
        For i = 0 To 9
            ddYear.Items.Add(DateTime.Today.Year - i)

        Next


    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            AddYear()
            ddMonth.SelectedValue = DateTime.Today.Month
           
        End If
    End Sub

    Protected Sub GVAppPayment_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvProtect.RowCommand
        If e.CommandName = "Select" Then
            Dim urlLink As String = "../Application/frmApplication.aspx?"
            urlLink += "Edit=0&Buy=2"
            urlLink += "&&IdCar=" & GvProtect.DataKeys(e.CommandArgument).Item(0)
            urlLink += "&&AppID=" & GvProtect.DataKeys(e.CommandArgument).Item(1)
            ScriptManager.RegisterClientScriptBlock(UpdatePanel5, GetType(UpdatePanel), UpdatePanel5.ClientID, " window.open('" & urlLink & "','Application');", True)

            'Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  window.open('" & urlLink & "','Application');</script>")
        ElseIf e.CommandName = "History" Then
            ScriptManager.RegisterClientScriptBlock(UpdatePanel5, GetType(UpdatePanel), UpdatePanel5.ClientID, "javascript:parent.iframeShow('" & GvProtect.DataKeys(e.CommandArgument).Item(0) & "');", True)
            'Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.iframeShow('" & GVAppPayment.DataKeys(e.CommandArgument).Item(0) & "');</script>")
        End If
    End Sub
End Class
