﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class Modules_Sale_CheckApp_frmPhone
    Inherits System.Web.UI.Page
    Public TelAjax As String = ""
    Dim FunAll As New FuntionAll
    Dim StrQryProvince As New QueryProvince
    Dim com As SqlCommand
    Dim Conn As New SqlConnection(ConfigurationManager.ConnectionStrings("asnbroker").ConnectionString)
    Dim StrQuery As New QueryPhone
    Dim dt As DataTable
    Dim DataAccess As New DataAccess
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Try
            GetSoftPhone()
        Catch ex As Exception
            ScriptManager.RegisterClientScriptBlock(UpdatePanel3, GetType(UpdatePanel), UpdatePanel3.ClientID, "alert('ไม่สามารถโทรออกได้เนื่องจาก : " & ex.Message & "');", True)
        End Try
    End Sub

    Protected Sub GetSoftPhone()
        If checkPhoneNumber() = True Then
            Dim CallUrl As String = ""

            CallUrl += Replace(ConfigurationManager.AppSettings("WebCall"), "@IpAsserisk", Request.Cookies("IpAsterisk").Value) & "to=" & GetPhoneNumber() & "&&from=" & Request.Cookies("Extension").Value & "&&refer1=" & Request.QueryString("IdCar").ToString
            CallUrl += "&refer2=" & Request.Cookies("userID").Value
            TelAjax = CallUrl

        End If

    End Sub

    Protected Function checkPhoneNumber() As Boolean
        dt = New DataTable
        Dim strqry As String
        strqry = "Select * from TblBlackListCALL Where Mobile = '" & GetPhoneNumber() & "'"
        dt = DataAccess.DataRead(strqry)
        If dt.Rows.Count > 0 Then
            ScriptManager.RegisterClientScriptBlock(UpdatePanel3, GetType(UpdatePanel), UpdatePanel3.ClientID, "alert('เบอร์โทรติด Blacklist ไม่สามารถโทรออกได้');", True)
            Return False
        Else
            Return True
        End If
    End Function

    Protected Function GetPhoneNumber() As String
        Select Case ddCall.SelectedValue
            Case 1

                Return frmTel.DataKey.Item(0).ToString
            Case 2

                Return frmTel.DataKey.Item(1).ToString
            Case 3

                Return frmTel.DataKey.Item(2).ToString
            Case 4

                Return frmTel.DataKey.Item(3).ToString
            Case Else
                Return ""
        End Select
    End Function

    Protected Sub ImageButton2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(1)
    End Sub

    Protected Sub ImageButton3_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(2)
    End Sub

    Protected Sub ImageButton4_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(5)
    End Sub

    Protected Sub ImageButton5_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(4)
    End Sub

    Protected Sub ImageButton6_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(3)
    End Sub

    Protected Sub UpdateTblCustomer(ByVal UpdateID As Integer)

        Try
            Dim txtTel As TextBox = FunAll.ObjFindControl("txtTel", frmTel)
            Dim txtTelExt As TextBox = FunAll.ObjFindControl("txtTelExt", frmTel)
            Dim txtOTel As TextBox = FunAll.ObjFindControl("txtOTel", frmTel)
            Dim txtOTelExt As TextBox = FunAll.ObjFindControl("txtOTelExt", frmTel)
            Dim txtMobile As TextBox = FunAll.ObjFindControl("txtMobile", frmTel)
            Dim txtFax As TextBox = FunAll.ObjFindControl("txtFax", frmTel)
            Dim txtOther As TextBox = FunAll.ObjFindControl("txtOther", frmTel)
            Dim txtOtherExt As TextBox = FunAll.ObjFindControl("txtOtherExt", frmTel)

            CheckConnectionState()
            com = New SqlCommand(StrQuery.UpdateTblCustomer(UpdateID), Conn)
            With com
                .Parameters.Clear()
                .Parameters.Add("@Tel", SqlDbType.VarChar).Value = txtTel.Text.Trim
                .Parameters.Add("@TelExt", SqlDbType.VarChar).Value = txtTelExt.Text.Trim
                .Parameters.Add("@OTel", SqlDbType.VarChar).Value = txtOTel.Text.Trim
                .Parameters.Add("@OTelExt", SqlDbType.VarChar).Value = txtOTelExt.Text.Trim
                .Parameters.Add("@Mobile", SqlDbType.VarChar).Value = txtMobile.Text.Trim
                .Parameters.Add("@OthTel1", SqlDbType.VarChar).Value = txtOther.Text.Trim
                .Parameters.Add("@OthTel1Ext", SqlDbType.VarChar).Value = txtOtherExt.Text.Trim
                .Parameters.Add("@Fax", SqlDbType.VarChar).Value = txtFax.Text.Trim
                .Parameters.Add("@CusID", SqlDbType.VarChar).Value = frmTel.DataKey.Item(4)
                .ExecuteNonQuery()

            End With

            frmTel.ChangeMode(FormViewMode.ReadOnly)
            frmTel.DataBind()

            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('บันทึกข้อมูลเรียบร้อย');", True)
        Catch ex As Exception
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้เนื่องจาก : " & ex.Message & "');", True)

        End Try


        'BindLink()
    End Sub

    Public Sub CheckConnectionState()
        If Conn.State = ConnectionState.Open Then
            Conn.Close()
        Else
            Conn.Open()
        End If
    End Sub
End Class
