﻿
Partial Class Modules_Sale_CheckApp_frmCaseWaitToCancel
    Inherits System.Web.UI.Page
    Dim ISODate As New ISODate

    Protected Sub BtnShow_Click(sender As Object, e As System.EventArgs) Handles BtnShow.Click
        
        Sqlselect.SelectParameters.Item("TypeSearch").DefaultValue = 1
        Sqlselect.SelectParameters.Item("date1").DefaultValue = ISODate.SetISODate("en", txtdateWaitTocancels.Text.Trim)
        Sqlselect.SelectParameters.Item("date2").DefaultValue = ISODate.SetISODate("en", txtdateWaitTocancele.Text.Trim)
        GVAppWaitTocancel.DataSource = Sqlselect
        GVAppWaitTocancel.DataBind()
        'lblCase.Text = ""
    End Sub

    Protected Sub Sqlselect_Selected(sender As Object, e As System.Web.UI.WebControls.SqlDataSourceStatusEventArgs) Handles Sqlselect.Selected
        lblCase.Text = e.AffectedRows & " รายการ "
    End Sub

    Protected Sub Button1_Click(sender As Object, e As System.EventArgs) Handles Button1.Click
        Sqlselect.SelectParameters.Item("TypeSearch").DefaultValue = 2
        Sqlselect.SelectParameters.Item("date1").DefaultValue = ISODate.SetISODate("en", txtdateProtects.Text.Trim)
        Sqlselect.SelectParameters.Item("date2").DefaultValue = ISODate.SetISODate("en", txtdateProtecte.Text.Trim)
        GVAppWaitTocancel.DataSource = Sqlselect
        GVAppWaitTocancel.DataBind()
    End Sub
End Class
