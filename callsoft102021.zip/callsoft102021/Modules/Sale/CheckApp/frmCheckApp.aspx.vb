﻿
Partial Class Modules_Sale_CheckApp_frmCheckApp
    Inherits System.Web.UI.Page
    Public CaseWait, CaseDoc, CaseSend, CaseAppPay, CaseProtect, Casewaittocancel, Casecancel As String
    Protected Sub WebImageButton1_Click(ByVal sender As Object, ByVal e As Infragistics.WebUI.WebDataInput.ButtonEventArgs) Handles WebImageButton1.Click
        CaseWait = "frmCaseWait.aspx?SupID=" & ddUser.SelectedValue
    End Sub

    Protected Sub WebImageButton2_Click(ByVal sender As Object, ByVal e As Infragistics.WebUI.WebDataInput.ButtonEventArgs) Handles WebImageButton2.Click
        CaseDoc = "frmCaseDoc.aspx?SupID=" & ddUser.SelectedValue
    End Sub

    Protected Sub WebImageButton3_Click(ByVal sender As Object, ByVal e As Infragistics.WebUI.WebDataInput.ButtonEventArgs) Handles WebImageButton3.Click
        CaseSend = "frmCaseSend.aspx?SupID=" & ddUser.SelectedValue
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

        End If
    End Sub

    Protected Sub ddUser_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddUser.SelectedIndexChanged

        If Request.Cookies("TypeTsr").Value = 3 Then
            CaseAppPay = "frmCaseAppPayRenew.aspx?SupID=" & ddUser.SelectedValue
        Else
            CaseAppPay = "frmCaseAppPay.aspx?SupID=" & ddUser.SelectedValue
        End If
        CaseProtect = "frmCaseProtect.aspx?SupID=" & ddUser.SelectedValue
        Casewaittocancel = "frmCaseWaitToCancel.aspx?SupID=" & ddUser.SelectedValue
        Casecancel = "frmCaseCancel.aspx?SupID=" & ddUser.SelectedValue
    End Sub

    Protected Sub ddUser_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddUser.DataBound

        If Request.Cookies("TypeTsr").Value = 3 Then
            CaseAppPay = "frmCaseAppPayRenew.aspx?SupID=" & ddUser.SelectedValue
        Else
            CaseAppPay = "frmCaseAppPay.aspx?SupID=" & ddUser.SelectedValue
        End If
        CaseProtect = "frmCaseProtect.aspx?SupID=" & ddUser.SelectedValue
        Casewaittocancel = "frmCaseWaitToCancel.aspx?SupID=" & ddUser.SelectedValue
        Casecancel = "frmCaseCancel.aspx?SupID=" & ddUser.SelectedValue
    End Sub
End Class
