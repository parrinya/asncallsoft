﻿
Partial Class Modules_Sale_CheckApp_frmCaseAppPay
    Inherits System.Web.UI.Page
    Dim ISODate As New ISODate
    Protected Sub BindGvAppPay()

        Select Case ddTypeApp.SelectedValue
            Case 1
                SqlAppPay.SelectParameters.Item("date3").DefaultValue = ISODate.SetISODate("en", txtdate3.Text.Trim)
                SqlAppPay.SelectParameters.Item("date4").DefaultValue = ISODate.SetISODate("en", txtdate4.Text.Trim)
                SqlAppPay.SelectParameters.Item("TypeSearch").DefaultValue = 1
                GVAppPayment.DataSource = SqlAppPay
                GVAppPayment.DataBind()
            Case 4
                SqlAppPay2.SelectParameters.Item("date3").DefaultValue = ISODate.SetISODate("en", txtdate3.Text.Trim)
                SqlAppPay2.SelectParameters.Item("date4").DefaultValue = ISODate.SetISODate("en", txtdate4.Text.Trim)
                SqlAppPay2.SelectParameters.Item("TypeSearch").DefaultValue = 1
                GVAppPayment.DataSource = SqlAppPay2
                GVAppPayment.DataBind()

                'Case 2
                '    SqlAppPay2.SelectParameters.Item("date3").DefaultValue = ISODate.SetISODate("en", txtdate3.Text.Trim)
                '    SqlAppPay2.SelectParameters.Item("date4").DefaultValue = ISODate.SetISODate("en", txtdate4.Text.Trim)
                '    SqlAppPay2.SelectParameters.Item("TypeSearch").DefaultValue = 1
                '    GVAppPayment.DataSource = SqlAppPay2
                '    GVAppPayment.DataBind()
                'Case 3
                '    SqlAppPay3.SelectParameters.Item("date3").DefaultValue = ISODate.SetISODate("en", txtdate3.Text.Trim)
                '    SqlAppPay3.SelectParameters.Item("date4").DefaultValue = ISODate.SetISODate("en", txtdate4.Text.Trim)
                '    SqlAppPay3.SelectParameters.Item("TypeSearch").DefaultValue = 1
                '    GVAppPayment.DataSource = SqlAppPay3
                '    GVAppPayment.DataBind()

        End Select

    End Sub
    Protected Sub BindGvAppPayAll()

        Select Case ddTypeApp.SelectedValue
            Case 1
                SqlAppPayAll01.SelectParameters.Item("date3").DefaultValue = ISODate.SetISODate("en", txtdate3.Text.Trim)
                SqlAppPayAll01.SelectParameters.Item("date4").DefaultValue = ISODate.SetISODate("en", txtdate4.Text.Trim)
                SqlAppPayAll01.SelectParameters.Item("TypeSearch").DefaultValue = 1
                SqlAppPayAll01.SelectParameters.Item("SupID").DefaultValue = Request.QueryString("SupID")
                GVAppPayment.DataSource = SqlAppPayAll01
                GVAppPayment.DataBind()
            Case 4
                SqlAppPayAll02.SelectParameters.Item("date3").DefaultValue = ISODate.SetISODate("en", txtdate3.Text.Trim)
                SqlAppPayAll02.SelectParameters.Item("date4").DefaultValue = ISODate.SetISODate("en", txtdate4.Text.Trim)
                SqlAppPayAll02.SelectParameters.Item("TypeSearch").DefaultValue = 1
                SqlAppPayAll02.SelectParameters.Item("SupID").DefaultValue = Request.QueryString("SupID")
                GVAppPayment.DataSource = SqlAppPayAll02
                GVAppPayment.DataBind()



        End Select

    End Sub

    Protected Sub Button10_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button10.Click
        If ddUser.SelectedValue = "-1" Then

            Select Case ddTypeApp.SelectedValue
                Case 1
                    SqlAppPayAll01.SelectParameters.Item("date3").DefaultValue = 0
                    SqlAppPayAll01.SelectParameters.Item("date4").DefaultValue = 0
                    SqlAppPayAll01.SelectParameters.Item("TypeSearch").DefaultValue = 2
                    SqlAppPayAll01.SelectParameters.Item("SupID").DefaultValue = Request.QueryString("SupID")
                    SqlAppPayAll01.SelectParameters.Item("date1").DefaultValue = ISODate.SetISODate("en", txtdate1.Text.Trim)
                    SqlAppPayAll01.SelectParameters.Item("date2").DefaultValue = ISODate.SetISODate("en", txtdate2.Text.Trim)
                    GVAppPayment.DataSource = SqlAppPayAll01
                    GVAppPayment.DataBind()
                Case 4
                    SqlAppPayAll02.SelectParameters.Item("date3").DefaultValue = 0
                    SqlAppPayAll02.SelectParameters.Item("date4").DefaultValue = 0
                    SqlAppPayAll02.SelectParameters.Item("TypeSearch").DefaultValue = 2
                    SqlAppPayAll02.SelectParameters.Item("SupID").DefaultValue = Request.QueryString("SupID")
                    SqlAppPayAll02.SelectParameters.Item("date1").DefaultValue = ISODate.SetISODate("en", txtdate1.Text.Trim)
                    SqlAppPayAll02.SelectParameters.Item("date2").DefaultValue = ISODate.SetISODate("en", txtdate2.Text.Trim)
                    GVAppPayment.DataSource = SqlAppPayAll02
                    GVAppPayment.DataBind()
            End Select

        Else
            Select Case ddTypeApp.SelectedValue
                Case 1
                    SqlAppPay.SelectParameters.Item("date3").DefaultValue = 0
                    SqlAppPay.SelectParameters.Item("date4").DefaultValue = 0
                    SqlAppPay.SelectParameters.Item("TypeSearch").DefaultValue = 2
                    SqlAppPay.SelectParameters.Item("date1").DefaultValue = ISODate.SetISODate("en", txtdate1.Text.Trim)
                    SqlAppPay.SelectParameters.Item("date2").DefaultValue = ISODate.SetISODate("en", txtdate2.Text.Trim)
                    GVAppPayment.DataSource = SqlAppPay
                    GVAppPayment.DataBind()
                Case 4
                    SqlAppPay2.SelectParameters.Item("date3").DefaultValue = 0
                    SqlAppPay2.SelectParameters.Item("date4").DefaultValue = 0
                    SqlAppPay2.SelectParameters.Item("TypeSearch").DefaultValue = 2
                    SqlAppPay2.SelectParameters.Item("date1").DefaultValue = ISODate.SetISODate("en", txtdate1.Text.Trim)
                    SqlAppPay2.SelectParameters.Item("date2").DefaultValue = ISODate.SetISODate("en", txtdate2.Text.Trim)
                    GVAppPayment.DataSource = SqlAppPay2
                    GVAppPayment.DataBind()
            End Select
        End If

        
    End Sub

    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click

        If ddUser.SelectedValue = "-1" Then
            BindGvAppPayAll()
        Else
            BindGvAppPay()
        End If
    End Sub

  

  

    Protected Sub GVAppPayment_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GVAppPayment.RowCommand
        If e.CommandName = "Select" Then
            Dim urlLink As String = "../Application/frmApplication.aspx?"
            urlLink += "Edit=0&Buy=2"
            urlLink += "&&IdCar=" & GVAppPayment.DataKeys(e.CommandArgument).Item(0)
            urlLink += "&&AppID=" & GVAppPayment.DataKeys(e.CommandArgument).Item(1)
            ScriptManager.RegisterClientScriptBlock(UpdatePanel5, GetType(UpdatePanel), UpdatePanel5.ClientID, " window.open('" & urlLink & "','Application');", True)

            'Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  window.open('" & urlLink & "','Application');</script>")
        ElseIf e.CommandName = "History" Then
            ScriptManager.RegisterClientScriptBlock(UpdatePanel5, GetType(UpdatePanel), UpdatePanel5.ClientID, "javascript:parent.iframePending('" & GVAppPayment.DataKeys(e.CommandArgument).Item(1) & "');", True)
            'Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.iframeShow('" & GVAppPayment.DataKeys(e.CommandArgument).Item(0) & "');</script>")
        ElseIf e.CommandName = "Doc" Then
            ScriptManager.RegisterClientScriptBlock(UpdatePanel5, GetType(UpdatePanel), UpdatePanel5.ClientID, "javascript:parent.iframeDoc('" & GVAppPayment.DataKeys(e.CommandArgument).Item(1) & "');", True)
        ElseIf e.CommandName = "Tel" Then
            ScriptManager.RegisterClientScriptBlock(UpdatePanel5, GetType(UpdatePanel), UpdatePanel5.ClientID, "javascript:parent.iframePhone('" & GVAppPayment.DataKeys(e.CommandArgument).Item(0) & "');", True)
        End If
    End Sub

  
    Protected Sub SqlAppPay_Selected(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.SqlDataSourceStatusEventArgs) Handles SqlAppPay.Selected
        lblCase.Text = e.AffectedRows
    End Sub

    Protected Sub SqlAppPay2_Selected(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.SqlDataSourceStatusEventArgs) Handles SqlAppPay2.Selected
        lblCase.Text = e.AffectedRows
    End Sub

    Protected Sub SqlAppPay3_Selected(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.SqlDataSourceStatusEventArgs) Handles SqlAppPay3.Selected
        lblCase.Text = e.AffectedRows
    End Sub
    Protected Sub SqlAppPayAll01_Selected(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.SqlDataSourceStatusEventArgs) Handles SqlAppPayAll01.Selected
        lblCase.Text = e.AffectedRows
    End Sub
    Protected Sub SqlAppPayAll02_Selected(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.SqlDataSourceStatusEventArgs) Handles SqlAppPayAll02.Selected
        lblCase.Text = e.AffectedRows
    End Sub
End Class
