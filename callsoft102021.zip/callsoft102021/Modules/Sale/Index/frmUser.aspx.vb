﻿Imports System.Data
Partial Class Modules_Sale_Index_frmUser
    Inherits System.Web.UI.Page
    Dim FunAll As New FuntionAll
    Dim ChkPassword As New ChkLogin
    Dim proxy As New asnserverbk.WebService
    Dim DataAccess As New DataAccess

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If CheckPassword() Then
            Dim txtPassword1 As TextBox = FunAll.ObjFindControl("txtPassword1", frmUser)
            SqlUser.UpdateParameters("UserPassword").DefaultValue = proxy.EncrytePassword(txtPassword1.Text.Trim)
            SqlUser.UpdateParameters("userID").DefaultValue = frmUser.DataKey.Item(0)
            SqlUser.Update()
            Dim ip As String = Request.ServerVariables("REMOTE_ADDR")
            SqlLogPassword.InsertParameters("IPCom").DefaultValue = ip
            SqlLogPassword.InsertParameters("userID").DefaultValue = frmUser.DataKey.Item(0)
            SqlLogPassword.InsertParameters("UserPassword").DefaultValue = proxy.EncrytePassword(txtPassword1.Text.Trim)
            SqlLogPassword.Insert()
            'Add By Na
            Exitpage()
        End If
    End Sub
    Protected Sub Exitpage()
        If frmUser.DataKey.Item(2) = "0" Then
            Response.Cookies("userID").Expires = DateTime.Now.AddDays(-1)

            Response.Redirect("~/Modules/Sale/Index/frmIndex.aspx")
        Else
            Response.Redirect("~/Modules/Sale/Index/frmHome.aspx")
        End If

    End Sub
    Protected Function CheckPassword() As Boolean
        Dim txtPassword1 As TextBox = FunAll.ObjFindControl("txtPassword1", frmUser)
        Dim dt As New DataTable
        Dim arrerror As New ArrayList
        Dim SreError As String = "กรุณาตรวจสอบความถูกต้อง ดังนี้ \n------------------------------------\n"
        Dim ChkBool As Boolean = True
        arrerror = ChkPassword.CheckFormat(txtPassword1.Text.Trim)
        If arrerror.Count > 0 Then
            ChkBool = False
            For cellCtr = 0 To arrerror.Count - 1
                SreError += arrerror(cellCtr).ToString + "\n"

            Next
        End If
        'Hitory 4
        Dim strqry As New System.Text.StringBuilder()
        'strqry = New System.Text.StringBuilder()
        'strqry.Append(" select  top 4 TblLogPassword.UserPassword  ")
        'strqry.Append(" FROM TblLogPassword")
        'strqry.Append(" where TblLogPassword.userID = " & frmUser.DataKey.Item(0))
        'strqry.Append(" order by CreateDate desc")
        'แก้ไข ตาม Policy Company With 
        strqry.Append(" select UserPassword from tbluser  ")
        strqry.Append(" where userid = " & frmUser.DataKey.Item(0))
        dt = New DataTable
        dt = DataAccess.DataRead(strqry.ToString)
        For cellCtr = 0 To dt.Rows.Count - 1
            If txtPassword1.Text.Trim = proxy.DecrytePassword(dt.Rows(cellCtr).Item("UserPassword").ToString()) Then
                ChkBool = False
                SreError += "- รหัสผ่านซ้ำกับรอบที่ผ่านมา" + "\n"
                Exit For
            End If
        Next
        If ChkBool = False Then
            MsgBox(SreError.ToString)
            Return False
        Else
            Return True
        End If

    End Function


    Protected Sub MsgBox(ByVal strMassage As String)
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('" & strMassage & "');", True)
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        'Response.Redirect("~/Modules/Sale/Index/frmHome.aspx")
        Exitpage()
    End Sub
End Class
