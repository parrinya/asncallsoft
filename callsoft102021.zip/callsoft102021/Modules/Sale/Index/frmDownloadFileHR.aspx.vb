﻿
Partial Class Modules_Sale_Index_frmDownloadFileHR
    Inherits System.Web.UI.Page
    Public download As String = ""
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        download = "http://asnserverbk/itdivision/Modules/FileUpload/frmdownload.aspx?type=HR"
    End Sub
End Class
