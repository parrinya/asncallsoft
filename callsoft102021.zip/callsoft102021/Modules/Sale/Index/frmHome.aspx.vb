﻿
Partial Class Modules_Sale_Index_frmHome
    Inherits System.Web.UI.Page

End Class
