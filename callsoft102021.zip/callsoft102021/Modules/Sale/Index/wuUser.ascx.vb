﻿
Partial Class Modules_Sale_Index_wuUser
    Inherits System.Web.UI.UserControl
 
    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Response.Redirect("~/Modules/Sale/Index/frmUser.aspx")
    End Sub

    Protected Sub frmUser_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmUser.DataBound
        If frmUser.DataItemCount > 0 Then
            If frmUser.DataKey.Item(0) <= 0 Then
                Response.Redirect("~/Modules/Sale/Index/frmUser.aspx")
            End If
        End If
    End Sub

    Protected Sub LinkButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ChkLogin As New ChkLogin
        ChkLogin.UpdateUserOnline(Request.Cookies("userID").Value, "False")
        ChkLogin.UserLogOut(Request.Cookies("userID").Value, Request.ServerVariables("REMOTE_ADDR"))

        Response.Cookies("userID").Expires = DateTime.Now.AddDays(-1)
        Response.Cookies("UserLevel").Expires = DateTime.Now.AddDays(-1)
        Response.Cookies("TypeTsr").Expires = DateTime.Now.AddDays(-1)
        Response.Cookies("Extension").Expires = DateTime.Now.AddDays(-1)
        Response.Cookies("IpAsterisk").Expires = DateTime.Now.AddDays(-1)
        Session.Abandon() '*** Delete All ***'
        Session.Clear() '*** Delete All ***'
        Response.Redirect("~/Modules/Sale/Index/frmIndex.aspx")
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        frmUser.DataBind()
    End Sub
End Class
