﻿Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Partial Class modules_Sale_Report_frmGraph
    Inherits System.Web.UI.Page
    Dim myReport As New ReportDocument
    Dim reportname As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Request.Cookies("UserLevel").Value = 1 Or Request.Cookies("UserLevel").Value = 2 Then
            MyReportLoad()
        End If
        '    
        'End If

    End Sub

  
    Protected Sub MyReportLoad()
        myReport = New ReportDocument

    
        Select Case ddReport.SelectedValue
            Case 1
                reportname = Server.MapPath("rptGraphToday.rpt")
                LoadReportBind()
            Case 2
                reportname = Server.MapPath("rptGraphMonth.rpt")
                LoadReportBind()
            Case 3
                reportname = Server.MapPath("rptGraphIn.rpt")
                LoadReportBind()
            Case 4
                reportname = Server.MapPath("rptGraphCom.rpt")
                LoadReportBind()
            Case 0
                CrystalReportViewer1.ReportSource = Nothing
                CrystalReportViewer1.DataBind()
        End Select

   
      

    End Sub

    Protected Sub LoadReportBind()
        Dim users As String = "sa"
        Dim pass As String = "asn@sr1"

        myReport.Load(reportname)
        myReport.SetDatabaseLogon(users, pass)

        Select Case ddReport.SelectedValue
            Case 3
                'myReport.SetParameterValue("typetsr", Request.Cookies("TypeTsr").Value)
                myReport.SetParameterValue("userID", Request.Cookies("userID").Value)
            Case 4

                If Request.Cookies("UserLevel").Value = "3" Then
                    myReport.SetParameterValue("SupID", Request.Cookies("userID").Value)
                ElseIf Request.Cookies("UserLevel").Value = "5" Then
                    myReport.SetParameterValue("SupID", "(select supid  from tbluser where userid=" & Request.Cookies("userID").Value & ")")
                Else
                    myReport.SetParameterValue("SupID", "0")
                End If

                If Request.Cookies("UserLevel").Value = "2" Then
                    myReport.SetParameterValue("LeadID", Request.Cookies("userID").Value)
                Else
                    myReport.SetParameterValue("LeadID", "0")
                End If
            Case 1

                'myReport.SetParameterValue("typetsr", Request.Cookies("TypeTsr").Value)
            Case 2
                'myReport.SetParameterValue("typetsr", Request.Cookies("TypeTsr").Value)

        End Select
        CrystalReportViewer1.ReportSource = myReport
        CrystalReportViewer1.DataBind()
    End Sub

    Protected Sub ddReport_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddReport.SelectedIndexChanged
        MyReportLoad()
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload

        myReport.Dispose()
        myReport.Close()

    End Sub

    Protected Sub CrystalReportViewer1_Load(sender As Object, e As System.EventArgs) Handles CrystalReportViewer1.Load
        If Request.Cookies("UserLevel").Value = 1 Or Request.Cookies("UserLevel").Value = 2 Then
            CrystalReportViewer1.DisplayToolbar = True
        Else
            CrystalReportViewer1.DisplayToolbar = False
        End If
    End Sub

    Protected Sub CrystalReportViewer1_Navigate(source As Object, e As CrystalDecisions.Web.NavigateEventArgs)
        MyReportLoad()
    End Sub
End Class
