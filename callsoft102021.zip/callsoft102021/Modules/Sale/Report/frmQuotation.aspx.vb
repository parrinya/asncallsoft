﻿Imports System.Drawing
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Data
Partial Class Modules_Sale_Report_frmQuotation
    Inherits System.Web.UI.Page
    Dim myReport As New ReportDocument

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        MyReportLoad()
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        myReport.Dispose()
        myReport.Close()
    End Sub

    Protected Sub MyReportLoad()

        Dim reportname As String
        reportname = Server.MapPath("rptQuotation.rpt")

        Dim users As String = "sa"
        'Dim pass As String = "DTS2009"
        Dim pass As String = "asn@sr1"

        myReport.Load(reportname)
        myReport.SetDatabaseLogon(users, pass)
        CrystalReportViewer1.ReportSource = myReport
        CrystalReportViewer1.SelectionFormula = "{TblSendFax.Runno} = " & Request.QueryString("Runno").ToString
        'CrystalReportViewer1.SelectionFormula = "{TblSendFax.Runno} = 37478"
        CrystalReportViewer1.DataBind()
    End Sub
End Class
