﻿
Partial Class Modules_Sale_Pending_frmReApp
    Inherits System.Web.UI.Page
    Dim FunAll As New FuntionAll
    Public TelAjax As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim mnList As Menu = CType(Master.FindControl("NavigationMenu"), Menu)
        mnList.Visible = False
        If Not IsPostBack Then
            ViewState("StartTime") = DateTime.Now
        End If

    End Sub

   
    Protected Sub Button3_Click1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        SaveFeedBack()
        BackLink()
    End Sub
    Protected Sub SaveFeedBack()
        With SqlFeedback
            .UpdateParameters("commentTsr").DefaultValue = txtComments.Text.Trim
            .Update()
        End With
    End Sub

    Protected Sub BackLink()
        Select Case Request.Cookies("UserLevel").Value
            Case 5
                Response.Redirect("../Phone/frmCase.aspx")
            Case Else
                Response.Redirect("../../Manager/Manage Tsr/frmPending.aspx")
        End Select
    End Sub

    Protected Function GetPhoneNumber() As String
        Select Case ddCall.SelectedValue
            Case 1
                Return frmTel.DataKey.Item(0)
            Case 2
                Return frmTel.DataKey.Item(1)
            Case 3
                Return frmTel.DataKey.Item(2)
            Case 4
                Return frmTel.DataKey.Item(3)
            Case Else
                Return ""
        End Select
    End Function

    Protected Sub GetSoftPhone()
        Dim CallUrl As String = ""

        CallUrl += Replace(ConfigurationManager.AppSettings("WebCall"), "@IpAsserisk", Request.Cookies("IpAsterisk").Value)
        CallUrl += "to=" & GetPhoneNumber() & "&&from=" & frmTel.DataKey.Item(4) & "&&refer1=" & frmCar.DataKey.Item(0)
        TelAjax = CallUrl
    End Sub

    Protected Sub Button9_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button9.Click
        GetSoftPhone()
    End Sub

    Protected Sub Button10_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button10.Click
        TelAjax = GetSoftPhoneUrlEndCall(GetPhoneNumber, frmTel.DataKey.Item(4))
    End Sub
    Protected Function GetSoftPhoneUrlEndCall(ByVal PhoneNumber As String, ByVal Extension As String) As String

        Dim CallUrl As String = ""
        CallUrl += ConfigurationManager.AppSettings("PhoneEndIn") & "exten=" & frmTel.DataKey.Item(4)
        Return CallUrl

    End Function

    Protected Sub Button11_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button11.Click
        BackLink()
    End Sub
End Class
