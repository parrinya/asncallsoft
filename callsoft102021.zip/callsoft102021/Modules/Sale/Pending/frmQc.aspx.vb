﻿Imports System.Data
Imports System.Data.SqlClient


Partial Class Modules_Sale_Pending_frmQc
    Inherits System.Web.UI.Page
    Dim FunAll As New FuntionAll
    Public TelAjax As String = ""
    Dim ISODate As New ISODate
    Public strProtype As String
    Dim dt As New DataTable
    Dim DataAccess As New DataAccess
    Dim dtGetAppPhotos As DataTable
    Dim StrQuery As New QueryPhone
    Dim com As SqlCommand
    Dim Conn As New SqlConnection(ConfigurationManager.ConnectionStrings("asnbroker").ConnectionString)
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim mnList As Menu = CType(Master.FindControl("NavigationMenu"), Menu)
        mnList.Visible = False
        If Not IsPostBack Then
            ViewState("StartTime") = DateTime.Now
        End If

    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnApp.Click
        If frmApp.DataKey.Item(2) = 1 Then
            Dim urlLink As String = "../Application/frmApplication.aspx?"
            urlLink += "Edit=1&Buy=2"
            urlLink += "&&IdCar=" & frmCar.DataKey.Item(0)
            urlLink += "&&AppID=" & frmApp.DataKey.Item(0)
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.open('" & urlLink & "','Application');</script>")
        Else
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>alert('App ถูกยกเลิกไม่สามารถตรวจสอบรายละเอียดได้');</script>")
        End If



    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        Select Case Request.Cookies("UserLevel").Value
            Case 5
                Response.Redirect("../Phone/frmCase.aspx")
            Case Else
                Response.Redirect("../../Manager/Manage Tsr/frmPending.aspx")
        End Select
    End Sub
    Protected Sub UpdateTblcalllisttsr()
        With SqlDataTblCallListTsr
            .Update()
        End With
    End Sub
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If frmCar.DataItemCount > 0 Then
            UpdateTblcalllisttsr()
            UpdateCar()
            UpdateTblQc()
            If ddStatus.SelectedValue = 0 Then
                If frmApp.DataKey.Item(2) = 1 Then
                    UpdateApp()
                End If

                UpdatePendingTsr()
            Else
                UpdatePendingTsr2()
            End If
        Else

            UpdatePendingTsr()
            UpdateTblcalllisttsr()
        End If




        Select Case Request.Cookies("UserLevel").Value
            Case 5
                Response.Redirect("../Phone/frmCase.aspx")
            Case Else
                Response.Redirect("../../Manager/Manage Tsr/frmPending.aspx")
        End Select
    End Sub

    Protected Sub UpdateTblQc()
        With SqlUpdateQc
            .UpdateParameters("idQc").DefaultValue = frmQc.DataKey.Item(0)
            .Update()
        End With
    End Sub

    Protected Sub UpdateApp()
        With SqlQc
            .UpdateParameters("AppID").DefaultValue = Request.QueryString("AppID")
            .Update()
        End With
    End Sub



    Protected Sub UpdateCar()
        Dim txtComments As TextBox = FunAll.ObjFindControl("txtComments", frmQc)
        With SqlCar
            .UpdateParameters("Comments").DefaultValue = txtComments.Text.Trim
            .Update()

        End With


    End Sub

    Protected Sub UpdatePendingTsr()
        With SqlPendingTsr
            .Update()
        End With
    End Sub

    Protected Sub UpdatePendingTsr2()
        With SqlPendingTsr2
            .UpdateParameters("AppointDate").DefaultValue = ISODate.SetISODate("en", txtAppoint.Text.Trim) & " " & txtHour.Text & ":" & txtMin.Text
            .Update()
        End With
        With SqlTblCar1
            .UpdateParameters("AppointDate").DefaultValue = ISODate.SetISODate("en", txtAppoint.Text.Trim) & " " & txtHour.Text & ":" & txtMin.Text
            .Update()
        End With

    End Sub

    Protected Sub Button9_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button9.Click
        GetSoftPhone()
    End Sub

    Protected Function GetPhoneNumber() As String
        Select Case ddCall.SelectedValue
            Case 1
                Return frmTel.DataKey.Item(0).ToString
            Case 2
                Return frmTel.DataKey.Item(1).ToString
            Case 3
                Return frmTel.DataKey.Item(2).ToString
            Case 4
                Return frmTel.DataKey.Item(3).ToString
            Case Else
                Return ""
        End Select
    End Function

    Protected Sub GetSoftPhone()
        Dim CallUrl As String = ""

        CallUrl += Replace(ConfigurationManager.AppSettings("WebCall"), "@IpAsserisk", Request.Cookies("IpAsterisk").Value)
        CallUrl += "to=" & GetPhoneNumber() & "&&from=" & Request.Cookies("Extension").Value & "&&refer1=" & frmCar.DataKey.Item(0)
        CallUrl += "&refer2=" & Request.Cookies("userID").Value
        TelAjax = CallUrl
    End Sub

    Protected Sub frmTel_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmTel.DataBound
        If Request.QueryString("Call").ToString = 1 Then
            GetSoftPhone()
        End If

    End Sub

    Protected Sub Button10_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button10.Click
        TelAjax = GetSoftPhoneUrlEndCall(GetPhoneNumber, frmTel.DataKey.Item(4))
    End Sub

    Protected Function GetSoftPhoneUrlEndCall(ByVal PhoneNumber As String, ByVal Extension As String) As String

        Dim CallUrl As String = ""
        CallUrl += ConfigurationManager.AppSettings("PhoneEndIn") & "exten=" & frmTel.DataKey.Item(4)
        Return CallUrl

    End Function

    Protected Sub Button11_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button11.Click
        frmTel.DataBind()
    End Sub

    Protected Sub LinkButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton2.Click
        strProtype = "../Product/frmProType2.aspx?IdCar=" & frmCar.DataKey.Item(0)
    End Sub

    Protected Sub LinkButton3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton3.Click
        strProtype = "../Product/frmProType3Plus.aspx?IdCar=" & frmCar.DataKey.Item(0)
    End Sub

    Protected Sub LinkButton4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton4.Click
        strProtype = "../Product/frmProType3.aspx?IdCar=" & frmCar.DataKey.Item(0)
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        strProtype = "../Product/frmProType1.aspx?IdCar=" & frmCar.DataKey.Item(0)
    End Sub

    Protected Sub frmApp_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmApp.DataBound
        If frmApp.DataItemCount = 0 Then
            btnApp.Visible = False
        End If
    End Sub

    Public Sub CheckConnectionState()
        If Conn.State = ConnectionState.Open Then
            Conn.Close()
        Else
            Conn.Open()
        End If
    End Sub


    Protected Sub LinkButton6_Click(sender As Object, e As System.EventArgs) Handles LinkButton6.Click
        strProtype = "../Product/frmProType1Plus.aspx?IdCar=" & frmCar.DataKey.Item(0)

    End Sub

    'Protected Sub LinkButton7_Click(sender As Object, e As System.EventArgs) Handles LinkButton7.Click
    '    strProtype = "../Product/frmProType1DD.aspx?IdCar=" & frmCar.DataKey.Item(0)
    'End Sub

    Protected Sub LinkButton8_Click(sender As Object, e As System.EventArgs) Handles LinkButton8.Click
        strProtype = "../Product/frmProType20.aspx?IdCar=" & frmCar.DataKey.Item(0)
    End Sub
End Class
