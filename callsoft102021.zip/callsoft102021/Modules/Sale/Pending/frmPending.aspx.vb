﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class Modules_Sale_Pending_frmPending
    Inherits System.Web.UI.Page
    Public TelAjax As String = ""
    Dim ISODate As New ISODate
    Dim FunAll As New FuntionAll
    Dim DataAccess As New DataAccess
    Private Function ChkDateAppiont15(ByVal DayA As Date) As Boolean
        Dim Add15Day As Date = CDate(DayA).AddDays(7) 'CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy"))).AddDays(2)
        Dim txtCarBuyDate2 As DateTime  'วันคุ้มครอง
        Dim dt9 As New DataTable

        Dim strqry As String = ""
        strqry += " select protectdate from tblapplication where appid=" + Request.QueryString("AppID").ToString()
        dt9 = New DataTable
        dt9 = DataAccess.DataRead(strqry)
        If dt9.Rows.Count > 0 Then
            txtCarBuyDate2 = CDate(dt9.Rows(0).Item("protectdate")).ToString("dd/MM/yyyy")
        End If

        If Add15Day <= txtCarBuyDate2 Then
            Return True
        Else
            Return False

        End If


    End Function
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim mnList As Menu = CType(Master.FindControl("NavigationMenu"), Menu)
        mnList.Visible = False
        If Not IsPostBack Then
            'Dim chkSend As CheckBox = FunAll.ObjFindControl("chkSend", formviewLine)
            'If chkSend.Checked = True Then
            '    chkSend.Visible = False
            'End If
            ViewState("StartTime") = DateTime.Now
            Dim DayToday As Date = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy"))).AddDays(0)
            Dim Day2A As Date = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy"))).AddDays(2)
            Dim Day1A As Date = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy"))).AddDays(1)
            If ChkDateAppiont15(Day2A) Then
                'Dafault(Day() + 2)
                txtAppoint.Text = Day2A.ToString("dd/MM/yyyy")
                D.Text = Day2A.ToString("dd/MM/yyyy")
                H.Text = "0"
                M.Text = "0"
                CHKD.Text = "CHK_F"
                txtHour.Text = H.Text
                txtMin.Text = M.Text
            Else
                'Dafault(Day() + 1)
                txtAppoint.Text = Day1A.ToString("dd/MM/yyyy")
                D.Text = Day1A.ToString("dd/MM/yyyy")
                H.Text = "0"
                M.Text = "0"
                txtHour.Text = H.Text
                txtMin.Text = M.Text
                CHKD.Text = "CHK_T"

                'txtAppoint.Enabled = False
                'txtHour.Enabled = False
                'txtMin.Enabled = False

            End If

        End If

    End Sub


#Region "SoftPhone"
    Protected Sub Button9_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button9.Click
        GetSoftPhone()
    End Sub

    Protected Function GetPhoneNumber() As String
        Select Case ddCall.SelectedValue
            Case 1
                lblTel.Text = frmTel.DataKey.Item(0).ToString
                Return frmTel.DataKey.Item(0).ToString
            Case 2
                lblTel.Text = frmTel.DataKey.Item(1).ToString
                Return frmTel.DataKey.Item(1).ToString
            Case 3
                lblTel.Text = frmTel.DataKey.Item(2).ToString
                Return frmTel.DataKey.Item(2).ToString
            Case 4
                lblTel.Text = frmTel.DataKey.Item(3).ToString
                Return frmTel.DataKey.Item(3).ToString
            Case Else
                Return ""
        End Select
    End Function

    Protected Sub GetSoftPhone()
        Dim CallUrl As String = ""

        CallUrl += Replace(ConfigurationManager.AppSettings("WebCall"), "@IpAsserisk", Request.Cookies("IpAsterisk").Value)
        CallUrl += "to=" & GetPhoneNumber() & "&&from=" & frmCus.DataKey.Item(4) & "&&refer1=" & frmCar.DataKey.Item(0)
        CallUrl += "&refer2=" & Request.Cookies("userID").Value
        TelAjax = CallUrl
    End Sub

    
#End Region

    

    'Check การกรอกข้อมูล
    Protected Function ChkData() As Boolean
        If ddStatus.SelectedValue = 99 Then
            MsgBox("กรุณาเลือกสถานะ")
            Return False
        Else
            If txtAppoint.Text.Trim = "" Or txtMin.Text.Trim = "" Or txtHour.Text.Trim = "" Then
                MsgBox("กรุณากรอกวันและเวลาให้ครบ")
                Return False

            ElseIf txtMin.Text.Trim > 60 Then
                MsgBox("เวลาของคุณผิดพลาด : นาทีต้องไม่เกิน 60")
                Return False
            ElseIf txtHour.Text.Trim > 24 Then
                MsgBox("เวลาของคุณผิดพลาด : ชั่วโมงต้องไม่เกิน 24")
                Return False
            Else
                Return True
            End If
        End If
    End Function
    Protected Function ChkData15() As Boolean
        If CHKD.Text = "CHK_T" Then
            Return True
        Else
            If ChkDateAppiont15(txtAppoint.Text) Then
                Return True
            Else
                'MsgBox("กรุณากรอกวันนัดต้อง<=7 วันคุ้มครอง")
                'Return False
                Return True
            End If

        End If
    End Function

    'Check การกรอกวันที่
    Protected Function CheckAppointDate() As Boolean
        Try
            Dim AppointDate As DateTime = CDate(SortDateAppoint())
            Dim DateNow As DateTime = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy")) & " " & Now.Hour.ToString & ":" & Now.Minute.ToString)

            If AppointDate < DateNow Then
                MsgBox("ไม่สามารถนัดเวลาน้อยกว่าเวลาปัจจุบันได้ : " & DateNow & " < " & AppointDate)
                Return False
            Else
                Return True
            End If

        Catch ex As Exception
            MsgBox("fotmat วันที่ผิดพลาด : จะต้องเป็น วัน/เดือน/ปี")
            Return False
        End Try


    End Function

    'จัดการเรียง วันที่นัด  วว ดด ปปปป  hh:mm
    Protected Function SortDateAppoint() As String
        'Dim AppointDateCV As String = ISODate.SetISODate("th", tbDay.Text.Trim & "/" & ddMonth.SelectedValue & "/" & ddYear.SelectedValue) & " " & tbHour.Text.Trim & ":" & tbMin.Text.Trim

        Dim AppointDateCV As String = ""
        AppointDateCV = ISODate.SetISODate("th", txtAppoint.Text) & " " & txtHour.Text.Trim & ":" & txtMin.Text.Trim

        Return AppointDateCV

    End Function

    'Script MsgBox
    Public Sub MsgBox(ByVal sMsg As String)

        Dim sb As New StringBuilder()
        Dim oFormObject As System.Web.UI.Control
        sMsg = sMsg.Replace("'", "\'")
        sMsg = sMsg.Replace(Chr(34), "\" & Chr(34))
        sMsg = sMsg.Replace(vbCrLf, "\n")
        sMsg = "<script language=javascript>alert(""" & sMsg & """)</script>"

        sb = New StringBuilder()
        sb.Append(sMsg)

        For Each oFormObject In Me.Controls
            If TypeOf oFormObject Is HtmlForm Then
                Exit For
            End If
        Next

        ' Add the javascript after the form object so that the 
        ' message doesn't appear on a blank screen.
        oFormObject.Controls.AddAt(oFormObject.Controls.Count, New LiteralControl(sb.ToString()))
    End Sub

    Protected Sub Button12_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button12.Click
        Dim urlLink As String = "../Application/frmApplication.aspx?"
        urlLink += "Edit=0&Buy=2"
        urlLink += "&&IdCar=" & frmCar.DataKey.Item(0)
        urlLink += "&&AppID=" & Request.QueryString("AppID").ToString
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.open('" & urlLink & "','Application');</script>")
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click

        If ChkData() = True And CheckAppointDate() = True And ChkData15() And chkSelectLINE() Then
            SaveCar()
            SavePending()
            btnSaveTblReAppCredit()
            UpdatePendingTsr()
            UpdateLINEID()
            Select Case Request.Cookies("UserLevel").Value
                Case 5
                    Response.Redirect("../Phone/frmCase.aspx")
                Case Else
                    Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script> window.close();</script>")
            End Select
        Else

        End If
    End Sub
    Protected Sub RBSelectConditionLINE_SelectedIndexChanged1(sender As Object, e As System.EventArgs)
        DefalutLINEID()
    End Sub
    Private Sub DefalutLINEID()
        Dim txtLINEID As TextBox = FunAll.ObjFindControl("txtLINEID", formviewLine)
        Dim RBSelectConditionLINE As RadioButtonList = FunAll.ObjFindControl("RBSelectConditionLINE", formviewLine)

        If RBSelectConditionLINE.SelectedValue = "3" Then
            txtLINEID.Text = ""
        End If
    End Sub
    Protected Sub RBSelectConditionLINE_SelectedIndexChanged(sender As Object, e As System.EventArgs)
        DefalutLINEID()
    End Sub
    Protected Function chkSelectLINE() As Boolean
        Dim txtLINEID As TextBox = FunAll.ObjFindControl("txtLINEID", formviewLine)
        Dim RBSelectConditionLINE As RadioButtonList = FunAll.ObjFindControl("RBSelectConditionLINE", formviewLine)
        Dim chk As Boolean
        If RBSelectConditionLINE.SelectedValue = "1" Or RBSelectConditionLINE.SelectedValue = "2" Or RBSelectConditionLINE.SelectedValue = "3" Then
            If (RBSelectConditionLINE.SelectedValue = "1" Or RBSelectConditionLINE.SelectedValue = "2") And txtLINEID.Text <> "" Then
                chk = True
            ElseIf RBSelectConditionLINE.SelectedValue = "3" Then
                chk = True
            Else
                chk = False
            End If

        Else
            chk = False
        End If
        Return chk
    End Function
    'SqlDataSourceLineID
    Protected Sub UpdateLINEID()
        Dim txtLINEID As TextBox = FunAll.ObjFindControl("txtLINEID", formviewLine)
        Dim RBSelectConditionLINE As RadioButtonList = FunAll.ObjFindControl("RBSelectConditionLINE", formviewLine)
        If RBSelectConditionLINE.SelectedValue = "3" Then
            With SqlDataSourceLineID
                .UpdateParameters("LINEID").DefaultValue = ""
                .UpdateParameters("FlagLINE").DefaultValue = RBSelectConditionLINE.SelectedValue
                .UpdateParameters("CusID").DefaultValue = frmCus.DataKey.Item(0)
                .Update()
            End With
        Else
            With SqlDataSourceLineID
                .UpdateParameters("LINEID").DefaultValue = txtLINEID.Text
                .UpdateParameters("FlagLINE").DefaultValue = RBSelectConditionLINE.SelectedValue
                .UpdateParameters("CusID").DefaultValue = frmCus.DataKey.Item(0)
                .Update()
            End With
        End If
        If formviewLine.DataKey.Item(0).ToString() = "3" And RBSelectConditionLINE.SelectedValue <> "3" And txtLINEID.Text <> "" Then
            With SqlDataSourceLineID0
                .Insert()
            End With
            With SqlDataSourceLineID0
                .UpdateParameters("FlagSendLINE").DefaultValue = 1
                .Update()
            End With
        End If

    End Sub

    Protected Sub SaveCar()
        Dim FlagA = ChkAppointDate()
        With SqlCustomer
            .UpdateParameters("AppointDate").DefaultValue = SortDateAppoint()
            .UpdateParameters("Flag_AppointDate").DefaultValue = FlagA
            .Update()
        End With
    End Sub
    Private Function ChkAppointDate() As Int16
        If txtHour.Text = H.Text And txtMin.Text = M.Text And txtAppoint.Text = D.Text Then
            'ไม่ตั้งใจนัด
            Return "2"
        Else
            'ตั้งใจนัด
            Return "1"
        End If

    End Function

    Protected Sub SavePending()

        With SqlCustomer
            .InsertParameters("StatusTsrPayid").DefaultValue = ddStatus.SelectedValue
            .InsertParameters("Comments").DefaultValue = txtComments.Text.Trim
            .Insert()
        End With
    End Sub

    Protected Sub UpdatePendingTsr()
        With SqlPendingTsr
            .Update()
        End With
        With SqlDataTblCallListTsr
            .Update()
        End With
    End Sub

    Protected Sub btnSaveTblReAppCredit()
        If frmReAppCredit.DataItemCount > 0 Then
            SaveTblReAppCredit()
            InsertTblEditApp()

        End If
    End Sub

    Protected Sub SaveTblReAppCredit()

        Dim txtReAnswer As TextBox = FunAll.ObjFindControl("txtReAnswer", frmReAppCredit)
        Dim chkAppont As CheckBox = FunAll.ObjFindControl("chkAppont", frmReAppCredit)
        Dim txtAppoint As TextBox = FunAll.ObjFindControl("txtAppoint", frmReAppCredit)

        With SqlReAppCredit
            .UpdateParameters("reAnswer").DefaultValue = txtReAnswer.Text.Trim
            If chkAppont.Checked = True Then
                .UpdateParameters("DueDate").DefaultValue = ISODate.SetISODate("th", txtAppoint.Text.Trim)
            Else
                .UpdateParameters("DueDate").DefaultValue = frmReAppCredit.DataKey.Item(1).ToString
            End If

            .UpdateParameters("RecNo").DefaultValue = frmReAppCredit.DataKey.Item(0)
            .Update()
        End With
    End Sub

    Protected Sub InsertTblEditApp()
        Dim txtReAnswer As TextBox = FunAll.ObjFindControl("txtReAnswer", frmReAppCredit)
        Dim chkEditApp As CheckBox = FunAll.ObjFindControl("chkEditApp", frmReAppCredit)
        If chkEditApp.Checked = True Then
            With SqlReAppCredit
                .InsertParameters("Detail").DefaultValue = txtReAnswer.Text.Trim
                .Insert()

            End With
        End If
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Select Case Request.Cookies("UserLevel").Value
            Case 5
                Response.Redirect("../Phone/frmCase.aspx")
            Case Else
                Response.Redirect("../../Manager/Manage Tsr/frmPending.aspx")
        End Select
    End Sub


    'Protected Sub frmReAppCredit_DataBound(sender As Object, e As System.EventArgs) Handles frmReAppCredit.DataBound
    '    'Dafault Day +2 00:00 if 15<protectdate +1 

    '    Dim DayToday As Date = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy"))).AddDays(0)
    '    Dim Day2A As Date = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy"))).AddDays(2)
    '    Dim Day1A As Date = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy"))).AddDays(1)
    '    If ChkDateAppiont15(Day2A) Then
    '        'Dafault(Day() + 2)
    '        txtAppoint.Text = Day2A
    '        D.Text = Day2A.ToString("dd/MM/yyyy")
    '        H.Text = "00"
    '        M.Text = "00"
    '        txtHour.Text = H.Text
    '        txtMin.Text = M.Text
    '    Else
    '        'Dafault(Day() + 1)
    '        txtAppoint.Text = Day1A
    '        D.Text = Day2A.ToString("dd/MM/yyyy")
    '        H.Text = "00"
    '        M.Text = "00"
    '        txtHour.Text = H.Text
    '        txtMin.Text = M.Text

    '    End If
    'End Sub

    'Protected Sub frmCar_DataBound(sender As Object, e As System.EventArgs) Handles frmCar.DataBound
    '    Dim DayToday As Date = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy"))).AddDays(0)
    '    Dim Day2A As Date = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy"))).AddDays(2)
    '    Dim Day1A As Date = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy"))).AddDays(1)
    '    If ChkDateAppiont15(Day2A) Then
    '        'Dafault(Day() + 2)
    '        txtAppoint.Text = Day2A
    '        D.Text = Day2A.ToString("dd/MM/yyyy")
    '        H.Text = "00"
    '        M.Text = "00"
    '        txtHour.Text = H.Text
    '        txtMin.Text = M.Text
    '    Else
    '        'Dafault(Day() + 1)
    '        txtAppoint.Text = Day1A
    '        D.Text = Day2A.ToString("dd/MM/yyyy")
    '        H.Text = "00"
    '        M.Text = "00"
    '        txtHour.Text = H.Text
    '        txtMin.Text = M.Text

    '    End If
    'End Sub
End Class
