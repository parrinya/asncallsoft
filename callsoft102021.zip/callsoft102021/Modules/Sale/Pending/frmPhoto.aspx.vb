﻿
Partial Class Modules_Sale_Pending_frmPhoto
    Inherits System.Web.UI.Page
    Dim FunAll As New FuntionAll
    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs)

        Select Case Request.Cookies("UserLevel").Value
            Case 5
                Response.Redirect("../Phone/frmCase.aspx")
            Case Else
                Response.Redirect("../../Manager/Manage Tsr/frmPending.aspx")
        End Select
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim txtDesAns As TextBox = FunAll.ObjFindControl("txtDesAns", frmPhoto)
        With SqlPhoto2
            .UpdateParameters("DescAns").DefaultValue = txtDesAns.Text.Trim
            .UpdateParameters("RunID").DefaultValue = frmPhoto.DataKey.Item(0)
            .Update()
        End With

        Select Case Request.Cookies("UserLevel").Value
            Case 5
                Response.Redirect("../Phone/frmCase.aspx")
            Case Else
                Response.Redirect("../../Manager/Manage Tsr/frmPending.aspx")
        End Select
    End Sub

End Class
