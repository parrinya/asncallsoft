﻿
Partial Class Modules_Sale_Pending_frmCallCenter
    Inherits System.Web.UI.Page

    Public TelAjax As String = ""
    Dim FunAll As New FuntionAll
    Protected Sub Button9_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button9.Click
        GetSoftPhone()
    End Sub

    Protected Function GetPhoneNumber() As String
        Select Case ddCall.SelectedValue
            Case 1
                Return frmTel.DataKey.Item(0).ToString
            Case 2
                Return frmTel.DataKey.Item(1).ToString
            Case 3
                Return frmTel.DataKey.Item(2).ToString
            Case 4
                Return frmTel.DataKey.Item(3).ToString
            Case Else
                Return ""
        End Select
    End Function

    Protected Sub GetSoftPhone()
        Dim CallUrl As String = ""

        CallUrl += Replace(ConfigurationManager.AppSettings("WebCall"), "@IpAsserisk", Request.Cookies("IpAsterisk").Value)
        CallUrl += "to=" & GetPhoneNumber() & "&&from=" & frmTel.DataKey.Item(4) & "&&refer1=" & frmCar.DataKey.Item(0)
        CallUrl += "&refer2=" & Request.Cookies("userID").Value
        TelAjax = CallUrl
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click

        UpdateTblcalllisttsr()
        SqlApplicatin.Update()
        SavePending()
        If chkAppoint.Checked = True Then
            SqlAppReNew.Update()
        End If
        Select Case Request.Cookies("UserLevel").Value
            Case 5
                Response.Redirect("../Phone/frmCase.aspx")
            Case Else
                Response.Redirect("../../Manager/Manage Tsr/frmPending.aspx")
        End Select
    End Sub
    Protected Sub UpdateTblcalllisttsr()
        With SqlDataTblCallListTsr
            .Update()
        End With
    End Sub
    Protected Sub SavePending()
        For i As Integer = 0 To DataList1.Items.Count - 1
            Dim txtTSRAns As TextBox = FunAll.ObjFindControl("txtTSRAns", DataList1.Items(i))
            Dim ddStatus As DropDownList = FunAll.ObjFindControl("ddStatus", DataList1.Items(i))
            Dim chkStatus As CheckBox = FunAll.ObjFindControl("chkStatus", DataList1.Items(i))
            Dim ddAppStatus As DropDownList = FunAll.ObjFindControl("ddAppStatus", DataList1.Items(i))
            With SqlCallPending
                .UpdateParameters("TSRAns").DefaultValue = txtTSRAns.Text.Trim
                .UpdateParameters("CaseStatus").DefaultValue = ddStatus.SelectedValue
                .UpdateParameters("CallID").DefaultValue = DataList1.DataKeys(i)
                .Update()
            End With

            If chkStatus.Checked = True And ViewState("TblCar") Is Nothing Then
                With SqlCallcenter
                    .InsertParameters("Appid").DefaultValue = Request.QueryString("AppID").ToString
                    .InsertParameters("Comments").DefaultValue = txtTSRAns.Text.Trim
                    .InsertParameters("wTYPE").DefaultValue = ddAppStatus.SelectedValue
                    .InsertParameters("Cusid").DefaultValue = frmCar.DataKey.Item(1)
                    .InsertParameters("IdCar").DefaultValue = frmCar.DataKey.Item(0)
                    .Insert()
                End With

                SaveTblCar()
            End If
        Next

    End Sub

    Protected Sub SaveTblCar()
        With SqlCallcenter
            .UpdateParameters("IdCar").DefaultValue = frmCar.DataKey.Item(0)
            .Update()
        End With

        ViewState("TblCar") = True
    End Sub


    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        Select Case Request.Cookies("UserLevel").Value
            Case 5
                Response.Redirect("../Phone/frmCase.aspx")
            Case Else
                Response.Redirect("../../Manager/Manage Tsr/frmPending.aspx")
        End Select

    End Sub

    Protected Sub Button10_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button10.Click
        TelAjax = GetSoftPhoneUrlEndCall(GetPhoneNumber, frmTel.DataKey.Item(4))
    End Sub

    Protected Function GetSoftPhoneUrlEndCall(ByVal PhoneNumber As String, ByVal Extension As String) As String

        Dim CallUrl As String = ""
        CallUrl += ConfigurationManager.AppSettings("PhoneEndIn") & "exten=" & frmTel.DataKey.Item(4)
        Return CallUrl

    End Function


    Protected Sub frmTel_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmTel.DataBound
        If Request.QueryString("Call").ToString = 1 Then
            GetSoftPhone()
        End If

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim mnList As Menu = CType(Master.FindControl("NavigationMenu"), Menu)
        mnList.Visible = False
        If Not IsPostBack Then
            ViewState("StartTime") = DateTime.Now
        End If

    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim strLink As String = "Edit=0&Buy=3"
        strLink += "&IdCar=" & frmCar.DataKey.Item(0)
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.open('../Application/frmApplication.aspx?" & strLink & "','Application');</script>")

    End Sub
End Class
