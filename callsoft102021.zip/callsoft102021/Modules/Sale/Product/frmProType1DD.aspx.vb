﻿Imports System.Data.SqlClient
Imports System.Data

Partial Class Modules_Sale_Product_frmProType1DD
    Inherits System.Web.UI.Page

    Dim FunAll As New FuntionAll
    Dim StrQryProvince As New QueryProvince
    Dim DataAccess As New DataAccess
    Dim dt As DataTable
    Dim StrQryProValue As New QueryProValue1
    Protected Sub BindCarSeries()
        Dim ddBrand As DropDownList = DirectCast(frmCar.FindControl("ddBrand"), DropDownList)
        Dim ddSeries As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
        Dim ddYear As DropDownList = DirectCast(frmCar.FindControl("ddYear"), DropDownList)
        Dim ddModel As DropDownList = DirectCast(frmCar.FindControl("ddModel"), DropDownList)
        Dim ddCarTypeNew As DropDownList = DirectCast(frmCar.FindControl("ddCarTypeNew"), DropDownList)

        FunAll.ListDropDown(ddSeries, StrQryProvince.SelectCarBrand(ddBrand.SelectedValue), "CarSeries", "CarSeries")
        FunAll.ListDropDown(ddYear, StrQryProvince.SelectCarYear(ddBrand.SelectedValue, ddSeries.SelectedValue), "caryear", "caryear")
        FunAll.ListDropDown(ddModel, StrQryProvince.SelectCarModel(ddBrand.SelectedValue, ddSeries.SelectedValue, ddYear.SelectedValue), "model", "model")
        FunAll.ListDropDown(ddCarTypeNew, StrQryProvince.SelectCarCarType(ddBrand.SelectedValue, ddSeries.SelectedValue, ddYear.SelectedValue, ddModel.SelectedValue), "CarTypeName", "CarTypeID")

    End Sub
    Protected Sub BindCarYear()
        Dim ddBrand As DropDownList = DirectCast(frmCar.FindControl("ddBrand"), DropDownList)
        Dim ddSeries As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
        Dim ddYear As DropDownList = DirectCast(frmCar.FindControl("ddYear"), DropDownList)
        Dim ddModel As DropDownList = DirectCast(frmCar.FindControl("ddModel"), DropDownList)
        Dim ddCarTypeNew As DropDownList = DirectCast(frmCar.FindControl("ddCarTypeNew"), DropDownList)

        FunAll.ListDropDown(ddYear, StrQryProvince.SelectCarYear(ddBrand.SelectedValue, ddSeries.SelectedValue), "caryear", "caryear")
        FunAll.ListDropDown(ddModel, StrQryProvince.SelectCarModel(ddBrand.SelectedValue, ddSeries.SelectedValue, ddYear.SelectedValue), "model", "model")
        FunAll.ListDropDown(ddCarTypeNew, StrQryProvince.SelectCarCarType(ddBrand.SelectedValue, ddSeries.SelectedValue, ddYear.SelectedValue, ddModel.SelectedValue), "CarTypeName", "CarTypeID")


    End Sub

    Protected Sub BindCarModel()
        Dim ddBrand As DropDownList = DirectCast(frmCar.FindControl("ddBrand"), DropDownList)
        Dim ddSeries As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
        Dim ddYear As DropDownList = DirectCast(frmCar.FindControl("ddYear"), DropDownList)
        Dim ddModel As DropDownList = DirectCast(frmCar.FindControl("ddModel"), DropDownList)
        Dim ddCarTypeNew As DropDownList = DirectCast(frmCar.FindControl("ddCarTypeNew"), DropDownList)

        FunAll.ListDropDown(ddModel, StrQryProvince.SelectCarModel(ddBrand.SelectedValue, ddSeries.SelectedValue, ddYear.SelectedValue), "model", "model")
        FunAll.ListDropDown(ddCarTypeNew, StrQryProvince.SelectCarCarType(ddBrand.SelectedValue, ddSeries.SelectedValue, ddYear.SelectedValue, ddModel.SelectedValue), "CarTypeName", "CarTypeID")


    End Sub
    Protected Sub ddBrand_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        BindClearData()
        BindCarSeries()
    End Sub

    Protected Sub ddBrand_DataBound1(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub

    Protected Sub frmCar_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmCar.DataBound
        BindCarSeries()
        If frmCar.DataItemCount > 0 Then
            Dim ddSeries As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
            ddSeries.SelectedValue = frmCar.DataKey.Item(2)
            BindCarYear()

        End If
    End Sub

    Protected Sub ddBrand_DataBound(ByVal sender As Object, ByVal e As System.EventArgs)
        BindCarSeries()
    End Sub

    Protected Sub ddSeries_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        BindClearData()
        BindCarYear()

    End Sub

#Region "Package"
    'ผูกข้อมูล Package 1
    Protected Sub BindInsure1()
        Dim ddCarTypeNew As DropDownList = DirectCast(frmCar.FindControl("ddCarTypeNew"), DropDownList)
        With SqlPackage
            .SelectParameters("ProtypeID").DefaultValue = ddProType.SelectedValue

            .SelectParameters("CarTypeID").DefaultValue = ddCarTypeNew.SelectedValue
            .SelectParameters("FixIn").DefaultValue = ddFixIn.SelectedValue
        End With
        ddPackage.DataBind()
        BindPackageDetail1()
    End Sub

    'ดึงราคารถ
    Protected Function GetCarPrice() As Integer
        Dim ddCarType As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
        Dim ddCarYear As DropDownList = DirectCast(frmCar.FindControl("ddYear"), DropDownList)
        Dim ddCarModel As DropDownList = DirectCast(frmCar.FindControl("ddModel"), DropDownList)
        dt = New DataTable
        dt = DataAccess.DataRead(StrQryProvince.SelectTblCarBrandType1(ddCarType.SelectedValue, ddCarYear.SelectedValue, ddCarModel.SelectedValue))
        If dt.Rows.Count > 0 Then
            txtCarPrice.Text = CDbl(dt.Rows(0).Item("CarPrice")).ToString("##,##")
            txtCarPrice1.Text = CDbl(dt.Rows(0).Item("CarPrice1")).ToString("##,##")
            Return dt.Rows(0).Item("CarPrice")
        Else
            Return 0
        End If

    End Function

    'ดึงกลุ่มรถยนต์
    Protected Function GetCarGroup() As Integer
        Dim ddCarType As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
        Dim ddModel As DropDownList = DirectCast(frmCar.FindControl("ddModel"), DropDownList)
        Dim ddBrand As DropDownList = DirectCast(frmCar.FindControl("ddBrand"), DropDownList)
        Dim ddYear As DropDownList = DirectCast(frmCar.FindControl("ddYear"), DropDownList)
        Dim ddCarTypeNew As DropDownList = DirectCast(frmCar.FindControl("ddCarTypeNew"), DropDownList)

        dt = New DataTable
        dt = DataAccess.DataRead(StrQryProvince.SelectTblCarBrandType(ddCarType.SelectedValue, ddModel.SelectedValue, ddBrand.SelectedValue, ddYear.SelectedValue, ddCarTypeNew.SelectedValue))
        If dt.Rows.Count > 0 Then
            txtCarGroup.Text = dt.Rows(0).Item("CarGroup")
            Return dt.Rows(0).Item("CarGroup")
        Else
            Return 0
        End If

    End Function

    'ดึงประเภทรถยนต์ dropdown
    Protected Sub BindCarType()
        Dim ddCarTypeNew As DropDownList = DirectCast(frmCar.FindControl("ddCarTypeNew"), DropDownList)
        With SqlCarType
            '.SelectParameters("CarTypeID").DefaultValue = GetCarType()
            .SelectParameters("CarTypeID").DefaultValue = ddCarTypeNew.SelectedValue
        End With
        ddCarType.DataBind()
    End Sub

    'ดึงขนาดรถ
    Protected Sub BindCarSize()
        Dim ddCarTypeNew As DropDownList = DirectCast(frmCar.FindControl("ddCarTypeNew"), DropDownList)
        Dim StrCmd As String = "SELECT [CarSizeId], [CarSize] FROM [TblInsur_CarSize]  WHERE CarSizeID  "
        ddCarUse.Enabled = False
        ' Select Case GetCarType()
        Select Case ddCarTypeNew.SelectedValue
            Case "1"
                StrCmd += " in('1','2') "
                ddCarUse.SelectedValue = 1
            Case "2"
                StrCmd += " in('3','4') "
                ddCarUse.SelectedValue = 1
                ddCarUse.Enabled = True
            Case "3"
                StrCmd += " in('5') "
                ddCarUse.SelectedValue = 2
            Case "7"
                StrCmd += " in('3','4') "
                ddCarUse.SelectedValue = 2
                ddCarUse.Enabled = True
            Case "8"
                StrCmd += " in('3','4') "
                ddCarUse.SelectedValue = 1
                'ddCarUse.Enabled = True
            Case "9"
                StrCmd += " in('3','4') "
                ddCarUse.SelectedValue = 3
                'ddCarUse.Enabled = True
            Case Else
                StrCmd += " in('1','2') "
                ddCarUse.SelectedValue = 1
        End Select

        With SqlCarSize
            .SelectCommand = StrCmd
        End With
        ddCarSize.DataBind()
    End Sub

    'คำนวณทุน
    Protected Sub BindProprice()
        'Dim CarPrice As Integer = GetCarPrice()
        'Dim PriceStep As Integer = 10000
        'ddProPrice.Items.Clear()
        'If CarPrice < 1000000 Then
        '    PriceStep = 10000
        'Else
        '    PriceStep = 100000
        'End If

        ''คำนวณราคาปัดเศษ
        'Dim CarPriceM As Integer = CarPrice - PriceStep
        'CarPriceM = CarPriceM + (PriceStep - (CarPriceM Mod PriceStep))

        'Dim i As Integer
        'For i = 0 To 70
        '    If CarPriceM <= 1000000 Then
        '        CarPriceM -= 10000
        '    ElseIf CarPriceM > 1000000 And CarPriceM <= 2000000 Then
        '        CarPriceM -= 10000
        '    ElseIf CarPriceM > 2000000 And CarPriceM <= 4000000 Then
        '        CarPriceM -= 10000
        '    ElseIf CarPriceM > 4000000 And CarPriceM <= 100000000 Then
        '        CarPriceM -= 100000
        '    End If

        '    Dim lsvItem As New ListItem
        '    lsvItem.Text = CarPriceM
        '    ddProPrice.Items.Add(lsvItem)
        'Next
        If txtCarPrice.Text <> "0" And txtCarPrice.Text <> "" Then
            txtProPrice.Text = (CDbl(txtCarPrice.Text) * 85 / 100).ToString("##,##")
        ElseIf txtCarPrice.Text = "" Then
            txtProPrice.Text = "0"
        End If

    End Sub

    'ค้นหาข้อมูลความคุ้มครอง
    Protected Sub BindPackageDetail1()

        With SqlPackageDetail
            .SelectParameters("AppSubmitID").DefaultValue = ddPackage.SelectedValue
            .SelectParameters("IsCappet").DefaultValue = GetCarPet()
        End With
        frmPackage.DataBind()

        GetProPriceToProtect1()
    End Sub

    'Get พรบ.
    Protected Function GetCarPet() As Integer
        If ChkCarPet.Checked = True Then
            Return 1
        Else
            Return 0
        End If
    End Function

    'จำนวนเงินเอาประกัน
    Protected Sub GetProPriceToProtect1()
        If frmPackage.DataItemCount > 0 Then
            Dim lblLostCar1 As Label = FunAll.ObjFindControl("lblLostCar1", frmPackage)
            Dim lblCarFire As Label = FunAll.ObjFindControl("lblCarFire", frmPackage)
            If txtProPrice.Text = "" Then
                txtProPrice.Text = "0"
            End If
            lblLostCar1.Text = CInt(txtProPrice.Text).ToString("##,##")
            lblCarFire.Text = CInt(txtProPrice.Text).ToString("##,##")
            If Request.Cookies("UserLevel").Value = 6 Then  'Recoving
                Dim Button2 As Button = FunAll.ObjFindControl("Button2", frmPackage)
                Button2.Visible = False
            End If
        End If


    End Sub

    'ประเภทรถยนต์
    'Protected Function GetCarType() As Integer
    '    Dim ddCarType As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
    '    Dim ddModel As DropDownList = DirectCast(frmCar.FindControl("ddModel"), DropDownList)
    '    dt = New DataTable
    '    dt = DataAccess.DataRead(StrQryProvince.SelectTblCarBrandType(ddCarType.SelectedValue, ddModel.SelectedValue))
    '    If dt.Rows.Count > 0 Then
    '        Return dt.Rows(0).Item("CarType")
    '    Else
    '        Return 0
    '    End If

    'End Function
    ' ประเภทรถยนต์
    Protected Function GetCarType2() As Integer
        Dim ddCarType As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
        Dim ddModel As DropDownList = DirectCast(frmCar.FindControl("ddModel"), DropDownList)
        Dim ddBrand As DropDownList = DirectCast(frmCar.FindControl("ddBrand"), DropDownList)
        Dim ddYear As DropDownList = DirectCast(frmCar.FindControl("ddYear"), DropDownList)
        Dim ddCarTypeNew As DropDownList = DirectCast(frmCar.FindControl("ddCarTypeNew"), DropDownList)

        dt = New DataTable
        dt = DataAccess.DataRead(StrQryProvince.SelectTblCarBrandType(ddCarType.SelectedValue, ddModel.SelectedValue, ddBrand.SelectedValue, ddYear.SelectedValue, ddCarTypeNew.SelectedValue))
        If dt.Rows.Count > 0 Then
            Return dt.Rows(0).Item("CarTypeID")
        Else
            Return 0
        End If

    End Function

    'ID ยี่ห้อ
    Protected Function GetCarNo() As Integer
        Dim ddCarType As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
        Dim ddModel As DropDownList = DirectCast(frmCar.FindControl("ddModel"), DropDownList)
        Dim ddBrand As DropDownList = DirectCast(frmCar.FindControl("ddBrand"), DropDownList)
        Dim ddYear As DropDownList = DirectCast(frmCar.FindControl("ddYear"), DropDownList)
        Dim ddCarTypeNew As DropDownList = DirectCast(frmCar.FindControl("ddCarTypeNew"), DropDownList)
        dt = New DataTable
        dt = DataAccess.DataRead(StrQryProvince.SelectTblCarBrandType(ddCarType.SelectedValue, ddModel.SelectedValue, ddBrand.SelectedValue, ddYear.SelectedValue, ddCarTypeNew.SelectedValue))
        If dt.Rows.Count > 0 Then
            Return dt.Rows(0).Item("CarNo")
        Else
            Return 0
        End If

    End Function

    Protected Sub ddProType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddProType.SelectedIndexChanged
        BindInsure1()
        BindPackageDetail1()
    End Sub

    Protected Sub ddProType_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddProType.DataBound
        BindInsure1()
        BindPackageDetail1()
    End Sub

    Protected Sub ddFixIn_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddFixIn.SelectedIndexChanged
        BindInsure1()
        BindPackageDetail1()
    End Sub

    Protected Sub ddPackage_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddPackage.SelectedIndexChanged
        BindPackageDetail1()
    End Sub
    Protected Sub ChkCarPet_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ChkCarPet.CheckedChanged
        BindPackageDetail1()
    End Sub

    'Protected Sub ddProPrice_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddProPrice.SelectedIndexChanged
    '    GetProPriceToProtect1()
    'End Sub
    'คำนวนเบี้ยประกัน
    Protected Sub ProValue()
        Dim ddCarTypeNew As DropDownList = DirectCast(frmCar.FindControl("ddCarTypeNew"), DropDownList)
        Dim ar As New ArrayList
        Dim ddCarSeries As DropDownList = FunAll.ObjFindControl("ddSeries", frmCar)
        Dim ddYears As DropDownList = FunAll.ObjFindControl("ddYears", frmCar)
        Dim lblAccLost2 As Label = FunAll.ObjFindControl("lblAccLost2", frmPackage)
        Dim lblAccLost3 As Label = FunAll.ObjFindControl("lblAccLost3", frmPackage)
        Dim lblAccLost4 As Label = FunAll.ObjFindControl("lblAccLost4", frmPackage)

        Dim lblMaintain As Label = FunAll.ObjFindControl("lblMaintain", frmPackage)
        Dim lblInsure As Label = FunAll.ObjFindControl("lblInsure", frmPackage)

        Dim lblProValue As Label = FunAll.ObjFindControl("lblProValue", frmPackage)
        Dim lblProValue2 As Label = FunAll.ObjFindControl("lblProValue2", frmPackage)
        Dim lblTotalValue As Label = FunAll.ObjFindControl("lblTotalValue", frmPackage)
        Dim lblCarpet As Label = FunAll.ObjFindControl("lblCarpet", frmPackage)
        Dim lblMinPreminum As Label = FunAll.ObjFindControl("lblMinPreminum", frmPackage)

        Dim chkMinPreminum As CheckBox = FunAll.ObjFindControl("chkMinPreminum", frmPackage)
        'รุ่นรถ 0
        ar.Add(ddCarSeries.SelectedValue)
        'ยี่ห้อ 1
        ar.Add(ddCarTypeNew.SelectedValue)
        'ขนาดรถ 2
        ar.Add(ddCarSize.SelectedValue)
        'ปีรถ 3
        ar.Add(ddYears.SelectedValue)
        'ลักษณะการใช้รถ 4 
        ar.Add(ddCarUse.SelectedValue)
        'อายุผู้ขับขี่' 5
        ar.Add(ddCarDriver.SelectedValue)
        'ซ่อม 6 
        ar.Add(ddFixIn.SelectedValue)
        'product 7
        ar.Add(ddProType.SelectedValue)
        'package 8
        ar.Add(ddPackage.SelectedValue)
        'ProPrice 9
        ar.Add(txtProPrice.Text)
        'DisCount 10
        ar.Add(ddDisProfile.SelectedValue)
        'DriverValueOfHeal 11
        ar.Add(lblAccLost2.Text)
        'PassengerValueOfHeal 12
        ar.Add(lblAccLost4.Text)
        'Passenger 13
        ar.Add(lblAccLost3.Text)
        'ValueOfHeal  14
        ar.Add(lblMaintain.Text)
        'ValueOfWarrant  15
        ar.Add(lblInsure.Text)
        'รหัสประเภทรถยนต์ 16
        ar.Add(ddCarType.SelectedValue)
        'CarNo17
        ar.Add(GetCarNo)
        'ระบุเบี้ยพื้นฐาน18
        If chkMinPreminum.Checked = True Then
            ar.Add(lblMinPreminum.Text)
        Else
            ar.Add(0)
        End If
        Dim ar2 As New ArrayList
        ar2 = StrQryProValue.ProValue1(ar)
        Dim strPro As Double = ar2(0).ToString
        Dim TotalProValue As Double
        Dim Vat1 As Double = (strPro * 0.004) + 1
        TotalProValue = strPro + Vat1

        Dim Vat2 As Double = TotalProValue * 0.07
        TotalProValue += Vat2
        lblProValue.Text = strPro.ToString("##.##")
        lblProValue2.Text = TotalProValue.ToString("##.##")
        'lblTotalProValue.Text = 
        'lblCarpetWrite()
        lblTotalValue.Text = CDbl(lblProValue2.Text) + CDbl(lblCarpet.Text)
        lblMinPreminum.Text = ar2(1)
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            ProValue()
        Catch ex As Exception

        End Try

    End Sub
#End Region

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs)

        If Request.Cookies("UserLevel").Value <> 6 Then
            If ChkCarBrand() <> "0" And txtProPrice.Text <> "0" And txtProPrice.Text <> "" Then
                SaveTblCar()
                Dim lblProValue As Label = FunAll.ObjFindControl("lblProValue2", frmPackage)
                Dim strLink As String = "TypeID=14&AppsubmitID=" & frmPackage.DataKey.Item(0)
                strLink += "&Edit=1&Buy=1"
                strLink += "&CarPet=" & GetCarPet()
                strLink += "&ProValue=" & lblProValue.Text.Trim
                strLink += "&IdCar=" & Request.QueryString("IdCar").ToString
                strLink += "&ProPrice=" & txtProPrice.Text
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.open('../Application/frmApplication.aspx?" & strLink & "','Application');</script>")
            Else
                MsgBox("ไม่สามารถบันทึกได้ กรุณาเลือก ยี่ห้อ-รุ่น ,จำนวนเงินเอาประกัน ")
            End If
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

        End If
    End Sub

    Protected Sub SaveTblCar()
        Dim ddBrand As DropDownList = DirectCast(frmCar.FindControl("ddBrand"), DropDownList)
        Dim ddSeries As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
        Dim ddCarTypeNew As DropDownList = FunAll.ObjFindControl("ddCarTypeNew", frmCar)
        Dim ddModel As DropDownList = FunAll.ObjFindControl("ddModel", frmCar)

        With SqlCar
            .UpdateParameters("CarBrand").DefaultValue = ddBrand.SelectedValue
            .UpdateParameters("CarSeries").DefaultValue = ddSeries.SelectedValue
            .UpdateParameters("CarType").DefaultValue = GetCarType2()
            .UpdateParameters("CarGroup").DefaultValue = GetCarGroup()
            .UpdateParameters("carBrandNo").DefaultValue = ChkCarBrand()
            .UpdateParameters("carmodel").DefaultValue = ddModel.SelectedValue
            .Update()
        End With
    End Sub
    Protected Function ChkCarBrand() As String
        Dim ddBrand As DropDownList = DirectCast(frmCar.FindControl("ddBrand"), DropDownList)
        Dim ddSeries As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
        Dim ddModel As DropDownList = DirectCast(frmCar.FindControl("ddModel"), DropDownList)
        Dim ddYear As DropDownList = DirectCast(frmCar.FindControl("ddYear"), DropDownList)
        Dim ddCarTypeNew As DropDownList = FunAll.ObjFindControl("ddCarTypeNew", frmCar)

        dt = New DataTable
        dt = DataAccess.DataRead("SELECT top 1 carNO FROM TblCarBrand WHERE carBRAND='" & ddBrand.SelectedValue & "' and carSERIES='" & ddSeries.SelectedValue & "' and Model='" & ddModel.SelectedValue & "' and caryear='" & ddYear.SelectedValue & "' ")
        If dt.Rows.Count > 0 Then
            Return dt.Rows(0).Item("carNO")
        Else
            Return "0"
        End If

    End Function

    Protected Sub ddYear_SelectedIndexChanged(sender As Object, e As System.EventArgs)
        BindClearData()
        BindCarModel()
    End Sub

    Protected Sub BtnCal_Click(sender As Object, e As System.EventArgs)
        BindClearData()
        BindInsure1()
        GetCarPrice()
        GetCarGroup()
        BindCarType()
        BindCarSize()
        BindProprice()
    End Sub
    Protected Sub BindClearData()
        txtCarPrice.Text = ""
        txtCarPrice1.Text = ""
        txtProPrice.Text = ""

        ddCarType.SelectedValue = Nothing
    End Sub

    Protected Sub ddModel_SelectedIndexChanged(sender As Object, e As System.EventArgs)
        BindClearData()
        Dim ddBrand As DropDownList = DirectCast(frmCar.FindControl("ddBrand"), DropDownList)
        Dim ddSeries As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
        Dim ddYear As DropDownList = DirectCast(frmCar.FindControl("ddYear"), DropDownList)
        Dim ddModel As DropDownList = DirectCast(frmCar.FindControl("ddModel"), DropDownList)
        Dim ddCarTypeNew As DropDownList = DirectCast(frmCar.FindControl("ddCarTypeNew"), DropDownList)
        FunAll.ListDropDown(ddCarTypeNew, StrQryProvince.SelectCarCarType(ddBrand.SelectedValue, ddSeries.SelectedValue, ddYear.SelectedValue, ddModel.SelectedValue), "CarTypeName", "CarTypeID")
    End Sub

    Protected Sub txtProPrice_TextChanged(sender As Object, e As System.EventArgs) Handles txtProPrice.TextChanged
        GetProPriceToProtect1()
    End Sub
End Class

