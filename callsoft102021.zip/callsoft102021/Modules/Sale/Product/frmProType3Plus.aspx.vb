﻿Imports System.Data.SqlClient
Imports System.Data
Partial Class Modules_Sale_Product_frmProType2
    Inherits System.Web.UI.Page
    Dim FunAll As New FuntionAll
    Dim StrQryProvince As New QueryProvince
    Dim DataAccess As New DataAccess
    Dim dt As DataTable

#Region "Bind Package"
    Protected Sub ddBrand_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        BindCarSeries()
    End Sub

    Protected Sub ddBrand_DataBound1(ByVal sender As Object, ByVal e As System.EventArgs)
        BindCarSeries()
        If frmCar.DataItemCount > 0 Then
            Dim ddSeries As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
            ddSeries.SelectedValue = frmCar.DataKey.Item(2)
            BindCarYear()
        End If
    End Sub

    Protected Sub ddBrand_DataBound(ByVal sender As Object, ByVal e As System.EventArgs)
        BindCarSeries()
    End Sub

    Protected Sub BindCarSeries()
    
        Dim ddBrand As DropDownList = DirectCast(frmCar.FindControl("ddBrand"), DropDownList)
        Dim ddSeries As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
        Dim ddYear As DropDownList = DirectCast(frmCar.FindControl("ddYear"), DropDownList)
        Dim ddModel As DropDownList = DirectCast(frmCar.FindControl("ddModel"), DropDownList)
        Dim ddCarTypeNew As DropDownList = DirectCast(frmCar.FindControl("ddCarTypeNew"), DropDownList)

        FunAll.ListDropDown(ddSeries, StrQryProvince.SelectCarBrand(ddBrand.SelectedValue), "CarSeries", "CarSeries")
        FunAll.ListDropDown(ddYear, StrQryProvince.SelectCarYear(ddBrand.SelectedValue, ddSeries.SelectedValue), "caryear", "caryear")
        FunAll.ListDropDown(ddModel, StrQryProvince.SelectCarModel(ddBrand.SelectedValue, ddSeries.SelectedValue, ddYear.SelectedValue), "model", "model")
        FunAll.ListDropDown(ddCarTypeNew, StrQryProvince.SelectCarCarType(ddBrand.SelectedValue, ddSeries.SelectedValue, ddYear.SelectedValue, ddModel.SelectedValue), "CarTypeName", "CarTypeID")
        BindPackageClean()

    End Sub

    Protected Sub ddSeries_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        ' BindPackage()
        BindCarYear()
    End Sub
    Protected Sub BindPackageClean()
        With SqlPackage
            .SelectParameters("CarTypeID").DefaultValue = "999"
            .SelectParameters("IsCappet").DefaultValue = GetCarPet()
        End With
        GvPackage.DataBind()
    End Sub
    Protected Sub BindPackage()
        Dim ddCarTypeNew As DropDownList = DirectCast(frmCar.FindControl("ddCarTypeNew"), DropDownList)

        With SqlPackage
            .SelectParameters("CarTypeID").DefaultValue = ddCarTypeNew.SelectedValue
            .SelectParameters("IsCappet").DefaultValue = GetCarPet()
        End With
        GvPackage.DataBind()
    End Sub

    Protected Function GetCarPet() As Integer
        If chkIsCarpet.Checked = True Then
            Return 1
        Else
            Return 0
        End If
    End Function
#End Region


    'ประเภทรถยนต์
    'Protected Function GetCarType() As Integer
    '    Dim ddCarType As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
    '    Dim ddModel As DropDownList = DirectCast(frmCar.FindControl("ddModel"), DropDownList)
    '    dt = New DataTable
    '    dt = DataAccess.DataRead(StrQryProvince.SelectTblCarBrandType(ddCarType.SelectedValue, ddModel.SelectedValue))
    '    If dt.Rows.Count > 0 Then
    '        Return dt.Rows(0).Item("CarType")
    '    Else
    '        Return 0
    '    End If

    'End Function
    Protected Function ChkCarBrand() As String
        Dim ddBrand As DropDownList = DirectCast(frmCar.FindControl("ddBrand"), DropDownList)
        Dim ddSeries As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
        Dim ddModel As DropDownList = DirectCast(frmCar.FindControl("ddModel"), DropDownList)
        Dim ddYear As DropDownList = DirectCast(frmCar.FindControl("ddYear"), DropDownList)
        dt = New DataTable
        dt = DataAccess.DataRead("SELECT top 1 carNO FROM TblCarBrand WHERE carBRAND='" & ddBrand.SelectedValue & "' and carSERIES='" & ddSeries.SelectedValue & "' and Model='" & ddModel.SelectedValue & "' and caryear='" & ddYear.SelectedValue & "' ")
        If dt.Rows.Count > 0 Then
            Return dt.Rows(0).Item("carNO")
        Else
            Return "0"
        End If

    End Function
    Protected Sub GvPackage_DataBound(sender As Object, e As System.EventArgs) Handles GvPackage.DataBound
        If Request.Cookies("UserLevel").Value = 6 Then 'Recoving
            For i As Integer = 0 To GvPackage.Rows.Count - 1
                Dim ImageButton1 As Button = FunAll.ObjFindControl("Button1", GvPackage.Rows(i).Cells(0))
                ImageButton1.Visible = False
            Next
        End If

    End Sub

    Protected Sub GvPackage_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvPackage.RowCommand
        If e.CommandName = "Select" Then
            SqlPackageDetail.SelectParameters("AppsubmitID").DefaultValue = e.CommandArgument
        ElseIf e.CommandName = "Buy" Then
            If ChkCarBrand() <> "0" Then
                Dim strlink As String = "AppsubmitID=" & GvPackage.DataKeys(e.CommandArgument).Item(0)
                strlink += "&Edit=1&Buy=1&TypeID=" & GvPackage.DataKeys(e.CommandArgument).Item(1)
                strlink += "&CarPet=" & GetCarPet()
                strlink += "&IdCar=" & Request.QueryString("IdCar").ToString
                SaveTblCar()
                ScriptManager.RegisterClientScriptBlock(UpdatePanel1, GetType(UpdatePanel), UpdatePanel1.ClientID, "window.open('../Application/frmApplication.aspx?" & strlink & "','Application');", True)
            Else
                MsgBox("ไม่สามารถบันทึกได้ กรุณาเลือก ยี่ห้อ-รุ่น")
            End If
        End If
    End Sub

    Protected Sub chkIsCarpet_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkIsCarpet.CheckedChanged
        BindPackage()
    End Sub

#Region "Save TblCar"

    Protected Sub SaveTblCar()
        Dim ddBrand As DropDownList = DirectCast(frmCar.FindControl("ddBrand"), DropDownList)
        Dim ddSeries As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
        Dim ddYears As DropDownList = FunAll.ObjFindControl("ddYears", frmCar)
        Dim ddCarTypeNew As DropDownList = FunAll.ObjFindControl("ddCarTypeNew", frmCar)
        Dim ddModel As DropDownList = FunAll.ObjFindControl("ddModel", frmCar)

        With SqlCar
            .UpdateParameters("CarBrand").DefaultValue = ddBrand.SelectedValue
            .UpdateParameters("CarSeries").DefaultValue = ddSeries.SelectedValue
            .UpdateParameters("CarType").DefaultValue = GetCarType2()
            .UpdateParameters("CarGroup").DefaultValue = GetCarGroup()
            .UpdateParameters("carBrandNo").DefaultValue = ChkCarBrand()
            .UpdateParameters("carmodel").DefaultValue = ddModel.SelectedValue
            .Update()
        End With
    End Sub

    'ดึงกลุ่มรถยนต์
    Protected Function GetCarGroup() As Integer
        Dim ddCarType As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
        Dim ddModel As DropDownList = DirectCast(frmCar.FindControl("ddModel"), DropDownList)
        Dim ddBrand As DropDownList = DirectCast(frmCar.FindControl("ddBrand"), DropDownList)
        Dim ddYear As DropDownList = DirectCast(frmCar.FindControl("ddYear"), DropDownList)
        Dim ddCarTypeNew As DropDownList = DirectCast(frmCar.FindControl("ddCarTypeNew"), DropDownList)

        dt = New DataTable
        dt = DataAccess.DataRead(StrQryProvince.SelectTblCarBrandType(ddCarType.SelectedValue, ddModel.SelectedValue, ddBrand.SelectedValue, ddYear.SelectedValue, ddCarTypeNew.SelectedValue))
        If dt.Rows.Count > 0 Then
            Return dt.Rows(0).Item("CarGroup")
        Else
            Return 0
        End If

    End Function

    'Protected Function GetCarType2() As Integer
    '    Dim ddCarType As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
    '    Dim ddModel As DropDownList = DirectCast(frmCar.FindControl("ddModel"), DropDownList)
    '    dt = New DataTable
    '    dt = DataAccess.DataRead(StrQryProvince.SelectTblCarBrandType(ddCarType.SelectedValue, ddModel.SelectedValue))
    '    If dt.Rows.Count > 0 Then
    '        Return dt.Rows(0).Item("CarTypeID")
    '    Else
    '        Return 0
    '    End If

    'End Function
    Protected Function GetCarType2() As Integer
        Dim ddCarType As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
        Dim ddModel As DropDownList = DirectCast(frmCar.FindControl("ddModel"), DropDownList)
        Dim ddBrand As DropDownList = DirectCast(frmCar.FindControl("ddBrand"), DropDownList)
        Dim ddYear As DropDownList = DirectCast(frmCar.FindControl("ddYear"), DropDownList)
        Dim ddCarTypeNew As DropDownList = DirectCast(frmCar.FindControl("ddCarTypeNew"), DropDownList)

        dt = New DataTable
        dt = DataAccess.DataRead(StrQryProvince.SelectTblCarBrandType(ddCarType.SelectedValue, ddModel.SelectedValue, ddBrand.SelectedValue, ddYear.SelectedValue, ddCarTypeNew.SelectedValue))
        If dt.Rows.Count > 0 Then
            Return dt.Rows(0).Item("CarTypeID")
        Else
            Return 0
        End If

    End Function
#End Region
    Protected Sub ddYear_SelectedIndexChanged(sender As Object, e As System.EventArgs)

        BindCarModel()
    End Sub

    Protected Sub BtnCal_Click(sender As Object, e As System.EventArgs)
        BindPackage()
    End Sub
    Protected Sub BindCarModel()
        Dim ddBrand As DropDownList = DirectCast(frmCar.FindControl("ddBrand"), DropDownList)
        Dim ddSeries As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
        Dim ddYear As DropDownList = DirectCast(frmCar.FindControl("ddYear"), DropDownList)
        Dim ddModel As DropDownList = DirectCast(frmCar.FindControl("ddModel"), DropDownList)
        Dim ddCarTypeNew As DropDownList = DirectCast(frmCar.FindControl("ddCarTypeNew"), DropDownList)

        FunAll.ListDropDown(ddModel, StrQryProvince.SelectCarModel(ddBrand.SelectedValue, ddSeries.SelectedValue, ddYear.SelectedValue), "model", "model")
        FunAll.ListDropDown(ddCarTypeNew, StrQryProvince.SelectCarCarType(ddBrand.SelectedValue, ddSeries.SelectedValue, ddYear.SelectedValue, ddModel.SelectedValue), "CarTypeName", "CarTypeID")

        BindPackageClean()

    End Sub
    Protected Sub BindCarYear()
        Dim ddBrand As DropDownList = DirectCast(frmCar.FindControl("ddBrand"), DropDownList)
        Dim ddSeries As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
        Dim ddYear As DropDownList = DirectCast(frmCar.FindControl("ddYear"), DropDownList)
        Dim ddModel As DropDownList = DirectCast(frmCar.FindControl("ddModel"), DropDownList)
        Dim ddCarTypeNew As DropDownList = DirectCast(frmCar.FindControl("ddCarTypeNew"), DropDownList)

        FunAll.ListDropDown(ddYear, StrQryProvince.SelectCarYear(ddBrand.SelectedValue, ddSeries.SelectedValue), "caryear", "caryear")
        FunAll.ListDropDown(ddModel, StrQryProvince.SelectCarModel(ddBrand.SelectedValue, ddSeries.SelectedValue, ddYear.SelectedValue), "model", "model")
        FunAll.ListDropDown(ddCarTypeNew, StrQryProvince.SelectCarCarType(ddBrand.SelectedValue, ddSeries.SelectedValue, ddYear.SelectedValue, ddModel.SelectedValue), "CarTypeName", "CarTypeID")

        BindPackageClean()

    End Sub
    Protected Sub ddModel_SelectedIndexChanged(sender As Object, e As System.EventArgs)
        BindPackageClean()
        Dim ddBrand As DropDownList = DirectCast(frmCar.FindControl("ddBrand"), DropDownList)
        Dim ddSeries As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
        Dim ddYear As DropDownList = DirectCast(frmCar.FindControl("ddYear"), DropDownList)
        Dim ddModel As DropDownList = DirectCast(frmCar.FindControl("ddModel"), DropDownList)
        Dim ddCarTypeNew As DropDownList = DirectCast(frmCar.FindControl("ddCarTypeNew"), DropDownList)
        FunAll.ListDropDown(ddCarTypeNew, StrQryProvince.SelectCarCarType(ddBrand.SelectedValue, ddSeries.SelectedValue, ddYear.SelectedValue, ddModel.SelectedValue), "CarTypeName", "CarTypeID")
    End Sub
End Class
