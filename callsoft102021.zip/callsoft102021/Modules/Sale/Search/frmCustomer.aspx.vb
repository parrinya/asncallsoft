﻿
Partial Class Modules_Sale_Search_frmCustomer
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Request.Cookies("TypeTsr").Value = 3 Then ' ปีต่อ จะเห็นข้อมูลปีต่อ
            FormViewDetailRenew.Visible = True
        Else
            FormViewDetailRenew.Visible = False
        End If
    End Sub
End Class
