﻿
Partial Class Modules_Sale_Search_frmSearch
    Inherits System.Web.UI.Page
    Public strLink As String
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click

        If txtSearch.Text <> "" Then
            Dim ss As String = ""
            Dim chk As Boolean = False
            If ddCondition.SelectedValue = "0" And IsNumeric(txtSearch.Text) Then
                'APPID
                ss = " and a7.appid='" & txtSearch.Text.Trim & "'"
                chk = True
            ElseIf ddCondition.SelectedValue = "1" Then
                'ทะเบียน
                chk = True
                ss = " and a2.CarID like '%" & txtSearch.Text.Trim & "%'"
            ElseIf ddCondition.SelectedValue = "2" Then
                'ชื่อ-สกุล
                chk = True
                ss = " and a1.FNameTH + ' ' + a1.LNameTH like '%" & txtSearch.Text.Trim & "%'"
            End If
            If chk = True Then
                SqlCustomer.SelectCommand += ss + GetQuery()
                GvCase.DataBind()
            Else
                SqlCustomer.SelectCommand = ""
                GvCase.DataBind()
            End If
        End If
    End Sub
    Protected Function GetQuery() As String
        Dim str As String = ""
        If Request.Cookies("UserLevel").Value = 2 Then
            'PL จะเห็นเฉพราะ เด็กของตัวเอง
            str = " and (a2.AssignTo in (select userID from tbluser where LeaderID=" & Request.Cookies("UserID").Value
            str += " )) "
        ElseIf Request.Cookies("UserLevel").Value = 3 Then
            'sup จะเห็นเฉพราะ เด็กของตัวเอง
            str = " and (a2.AssignTo in (select userID from tbluser where SupID=" & Request.Cookies("UserID").Value
            str += " )) "
        ElseIf Request.Cookies("UserLevel").Value = 1 Then
            str = ""
        Else
            ' จะเห็นเฉพาะของตัวเอง
            str = " and a2.AssignTo =" & Request.Cookies("UserID").Value

        End If
        Return str
    End Function
    Protected Sub GvCase_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvCase.RowCommand
        If e.CommandName = "Select" Then
            strLink = "frmCustomer.aspx?idCar=" & GvCase.DataKeys(e.CommandArgument).Item(1)
        ElseIf e.CommandName = "Tel" Then
            strLink = "../CheckApp/frmPhone.aspx?IdCar=" & e.CommandArgument
        ElseIf e.CommandName = "UpdateCase" Then
            With SqlCustomer
                .InsertParameters("CarID").DefaultValue = e.CommandArgument
                .InsertParameters("userID").DefaultValue = Request.Cookies("userID").Value
                .InsertParameters("HostAccess").DefaultValue = Request.ServerVariables("REMOTE_ADDR")
                .Insert()

            End With

            With SqlCustomer
                .UpdateParameters("IdCar").DefaultValue = e.CommandArgument
                .Update()
            End With

            MsgBox("ดำเนินการเรียบร้อย")
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            SqlCustomer.SelectCommand = ""
            GvCase.DataBind()
        End If
    End Sub

    Protected Sub MsgBox(ByVal strMassage As String)
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('" & strMassage & "');", True)
    End Sub
 
    Protected Sub GvCase_DataBound(sender As Object, e As System.EventArgs) Handles GvCase.DataBound
        If GvCase.Rows.Count > 0 Then
            If Request.Cookies("TypeTsr").Value <> 3 Then
                GvCase.Columns(2).Visible = False
            End If
        End If
    End Sub
End Class
