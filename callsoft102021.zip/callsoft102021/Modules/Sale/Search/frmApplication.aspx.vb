﻿
Partial Class Modules_Sale_Search_frmApplication
    Inherits System.Web.UI.Page
    Dim StrQuery As New QueryProvince
    Dim FunAll As New FuntionAll

    Protected Sub GvHistory_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvHistory.RowCommand
        If e.CommandName = "Select" Then

        
            With SqlEditApp
                .SelectParameters("AppID").DefaultValue = GvHistory.DataKeys(e.CommandArgument).Item(0)
            End With
            GvEditApp.DataBind()
            'Tab ตอบกลับภายใน
            With SqlHispFeedback
                .SelectParameters("AppID").DefaultValue = GvHistory.DataKeys(e.CommandArgument).Item(0)
            End With
            GVHispFeedback.DataBind()
            If GVHispFeedback.Rows.Count > 0 Then
                Label5.Text = "ประวัติตอบกลับภายใน :: <FONT Color='blue'>พบข้อมูลประวัติตอบกลับภายในจำนวน " & GVHispFeedback.Rows.Count & " แถว</FONT>"
            Else
                Label5.Text = "ประวัติตอบกลับภายใน :: <FONT Color='red'>ไม่พบข้อมูลประวัติตอบกลับภายใน</FONT>"
            End If
         
            'Tab CallCenter
            If GVCallCenter.Rows.Count > 0 Then
                Label2.Text = "ประวัติศูนย์ลูกค้าสัมพันธ์ :: <FONT Color='blue'>พบข้อมูลประวัติศูนย์ลูกค้าสัมพันธ์จำนวน " & GVCallCenter.Rows.Count & " แถว</FONT>"
            Else
                Label2.Text = "ประวัติศูนย์ลูกค้าสัมพันธ์ :: <FONT Color='red'>ไม่พบข้อมูลประวัติศูนย์ลูกค้าสัมพันธ์</FONT>"
            End If
            'Tab ประวัติส่งเอกสาร
            With SqlHispDoc
                .SelectParameters("AppID").DefaultValue = GvHistory.DataKeys(e.CommandArgument).Item(0)
            End With
            GVDoc.DataBind()
            If GVDoc.Rows.Count > 0 Then
                Label12.Text = "ประวัติส่งเอกสาร :: <FONT Color='blue'>พบข้อมูลประวัติส่งเอกสาร " & GVDoc.Rows.Count & " แถว</FONT>"
            Else
                Label12.Text = "ประวัติส่งเอกสาร :: <FONT Color='red'>ไม่พบข้อมูลประวัติส่งเอกสาร</FONT>"
            End If


        End If

    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            If GvHistory.SelectedValue IsNot Nothing Then
                If ChkWaitToCancel() = True Then
                    SaveTblWaitToCancel()
                    SaveTblCustomer()
                    GvHistory.DataBind()

                    With SqlEditApp
                        .SelectParameters("AppID").DefaultValue = ""
                    End With

                    GvEditApp.DataBind()
                End If
            Else
                MsgBox("กรุณาเลือก App ที่ต้องการแจ้งแก้ไข")
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Protected Function ChkWaitToCancel() As Boolean
       
        If (GvHistory.DataKeys(GvHistory.SelectedIndex).Item(1) = 3 Or GvHistory.DataKeys(GvHistory.SelectedIndex).Item(1) = 4) And GvHistory.DataKeys(GvHistory.SelectedIndex).Item(4) = 1 Then
            If ddAppStatus.SelectedValue = 0 Or ddAppStatus.SelectedValue = 2 Then
                If GvHistory.DataKeys(GvHistory.SelectedIndex).Item(2) = False Then
                    MsgBox("Appที่เลือกไม่มี พรบ.")
                    Return False
                Else
                    Return True
                End If
            Else
                Return True
            End If
        Else
            MsgBox("สถานะลูกค้าต้องเป็น Success หรือ Wait และต้องเป็น App ที่ยังใช้งาน เท่านั้น")
            Return False

        End If



    End Function

    Protected Sub SaveTblCustomer()
        SqlApplication.Update()
    End Sub

    Protected Sub SaveTblWaitToCancel()
        With SqlApplication
            .InsertParameters("Appid").DefaultValue = GvHistory.DataKeys(GvHistory.SelectedIndex).Item(0)
            .InsertParameters("Comments").DefaultValue = txtComments.Text.Trim
            .InsertParameters("wTYPE").DefaultValue = ddAppStatus.SelectedValue
            .InsertParameters("Cusid").DefaultValue = GvHistory.DataKeys(GvHistory.SelectedIndex).Item(3)
            .Insert()
        End With
    End Sub

    'Script MsgBox
    Public Sub MsgBox(ByVal sMsg As String)

        Dim sb As New StringBuilder()
        Dim oFormObject As System.Web.UI.Control
        sMsg = sMsg.Replace("'", "\'")
        sMsg = sMsg.Replace(Chr(34), "\" & Chr(34))
        sMsg = sMsg.Replace(vbCrLf, "\n")
        sMsg = "<script language=javascript>alert(""" & sMsg & """)</script>"

        sb = New StringBuilder()
        sb.Append(sMsg)

        For Each oFormObject In Me.Controls
            If TypeOf oFormObject Is HtmlForm Then
                Exit For
            End If
        Next

        ' Add the javascript after the form object so that the 
        ' message doesn't appear on a blank screen.
        oFormObject.Controls.AddAt(oFormObject.Controls.Count, New LiteralControl(sb.ToString()))
    End Sub

    Protected Sub ddMainEdit_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddMainEdit.SelectedIndexChanged
        SubMainBind()
        If ddMainEdit.SelectedValue = "7" Then
            ddDivision.SelectedValue = "4"
            ddDivision.Enabled = False
        Else
            ddDivision.Enabled = True
        End If

    End Sub

    Protected Sub SubMainBind()
        FunAll.ListDropDown(ddSubEdit, StrQuery.SelectTblSubMainEdit(ddMainEdit.SelectedValue), "SubMainEditData", "SubMainEditDataId")
    End Sub

    Protected Sub ddMainEdit_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddMainEdit.DataBound
        SubMainBind()
       
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            If GvHistory.SelectedValue IsNot Nothing Then
                SaveTblEditApp()
              
                With SqlEditApp
                    .SelectParameters("AppID").DefaultValue = ""
                End With

                GvEditApp.DataBind()
                Dim ddMain As Integer = ddMainEdit.SelectedValue
                Dim ddSub As Integer = ddSubEdit.SelectedValue
                If ddMainEdit.SelectedValue = "7" And GvHistory.DataKeys(GvHistory.SelectedIndex).Item(0).ToString() <> "" Then
                    'Insert TblLogSendLinePending
                    With SqlDataSourceLineID
                        .InsertParameters("AppID").DefaultValue = GvHistory.DataKeys(GvHistory.SelectedIndex).Item(0)
                        .InsertParameters("MainTitle").DefaultValue = ddMain
                        .InsertParameters("SubTitle").DefaultValue = ddSub
                        .InsertParameters("Comment").DefaultValue = txtEditComment.Text.Trim
                        .Insert()
                    End With
                End If
            Else
                MsgBox("กรุณาเลือก App ที่ต้องการแจ้งแก้ไข")
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Protected Sub SaveTblEditApp()
        With SqlEditApp
            .InsertParameters("Appid").DefaultValue = GvHistory.DataKeys(GvHistory.SelectedIndex).Item(0)
            .InsertParameters("Detail").DefaultValue = txtEditComment.Text.Trim
            .InsertParameters("MainEditDataId").DefaultValue = ddMainEdit.SelectedValue
            .InsertParameters("SubMainEditDataId").DefaultValue = ddSubEdit.SelectedValue
            .InsertParameters("DivisionId").DefaultValue = ddDivision.SelectedValue
            .Insert()
        End With
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

  
End Class
