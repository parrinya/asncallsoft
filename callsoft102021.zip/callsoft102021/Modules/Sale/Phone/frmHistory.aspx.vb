﻿
Partial Class Modules_Sale_Phone_frmHistory
    Inherits System.Web.UI.Page

End Class
