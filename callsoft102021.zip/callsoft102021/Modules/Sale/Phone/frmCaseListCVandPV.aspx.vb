﻿
Partial Class Modules_Sale_Phone_frmCaseListCVandPV
    Inherits System.Web.UI.Page
    Dim ISODate As New ISODate
    Protected Sub btnFind_Click(sender As Object, e As System.EventArgs) Handles btnFind.Click

        If txtdate1.Text <> "" And txtdate2.Text <> "" Then
            SqlsendCVPV.SelectCommand += " and CONVERT(VarChar,tblapplication.SuccessDate,111) between '" & ISODate.SetISODate("en", txtdate1.Text.Trim) & "'and '" & ISODate.SetISODate("en", txtdate2.Text.Trim) & "' order by TblLogSendCVandPV.CreateDate desc "
            GvCaseCVPV.DataSource = SqlsendCVPV
            GvCaseCVPV.DataBind()
        End If

    End Sub
End Class
