﻿
Partial Class Modules_Sale_Case_frmPhoto
    Inherits System.Web.UI.Page

    Protected Sub GvPhoto_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GVAppWait.RowCommand
        If e.CommandName = "Selects" Then
            Dim strLink As String = "?userID=" & Request.Cookies("userID").Value
            strLink += "&AppID=" & GVAppWait.DataKeys(e.CommandArgument).Item(2)
            strLink += "&IdCar=" & GVAppWait.DataKeys(e.CommandArgument).Item(0)
            strLink += "&RunNo=0&Call=2"
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.change_parent_url('../Pending/frmQc.aspx" & strLink & "');</script>")
        End If
    End Sub


End Class
