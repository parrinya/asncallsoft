﻿Imports System.IO.Ports
Imports System.Net
Imports System.IO
Imports System.Data
Imports System.Data.SqlClient
Imports System.Security.Cryptography.X509Certificates
Partial Class modules_Sale_Phone_SoftPhone
    Inherits System.Web.UI.Page
    Dim dt As DataTable
    Public strPhoneCall As String = ""
    Dim DataAccess As New DataAccess
    Dim StrQuery As New QueryPhone
    Dim Conn As New SqlConnection(ConfigurationManager.ConnectionStrings("asnbroker").ConnectionString)
    Dim com As SqlCommand
    Dim ISODate As New ISODate
    Protected Sub Timer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        'ReadPort()
        CheckCall()
    End Sub

    Protected Sub CheckCall()
        If ReadPort() = False Then

            CheckCloaseWindow()
        End If
    End Sub

    Protected Function ReadPort() As Boolean

        Dim URL As String = Replace(ConfigurationManager.AppSettings("ReadCall"), "@IpAsserisk", Request.Cookies("IpAsterisk").Value)

        Dim request1 As HttpWebRequest = WebRequest.Create(URL)
        request1.Proxy = Nothing
        request1.Credentials = CredentialCache.DefaultCredentials
        ServicePointManager.ServerCertificateValidationCallback = New System.Net.Security.RemoteCertificateValidationCallback(AddressOf ValidateServerCertificate)
        Dim response2 As HttpWebResponse = request1.GetResponse()
        Dim reader As StreamReader = New StreamReader(response2.GetResponseStream())
        Dim str As String = reader.ReadToEnd()
        If InStr(str, "SIP Busy : 0") Then
            Return True
        Else
            If InStr(str, Request.Cookies("Extension").Value & " Busy") Then
                ViewState("CTimer") = 10
                Label2.Text = "คุณกำลังใช้สาย : "
                Label1.Text = ""
                Return True
            Else
                RTrim(False)
            End If

        End If
       

        reader.Close()




    End Function

    Protected Sub CheckCloaseWindow()

        If Label1.Text.Trim = "" Then

            ViewState("CTimer") = 10
            Label2.Text = "สายได้ถูกวาง หน้านี้จะปิดใน : "
            Label1.Text = 10
        ElseIf Label1.Text.Trim > 0 Then
            ViewState("CTimer") -= 1
            Label1.Text = ViewState("CTimer")
        ElseIf Label1.Text.Trim = 0 Then
            CheckConnectionState()
            InsertTblCall()
            Label1.Text = -1
        End If
    End Sub

    Public Shared Function ValidateServerCertificate(ByVal sender As Object, ByVal certificate As X509Certificate, ByVal chain As X509Chain, ByVal sslPolicyErrors As Security.SslPolicyErrors) As Boolean
        Return True
    End Function

    Public Sub CheckConnectionState()
        If Conn.State = ConnectionState.Open Then
            Conn.Close()
        Else
            Conn.Open()
        End If
    End Sub

    Protected Sub updateTblCustomer()
       
    End Sub

    'Insert TblCall History
    Protected Sub InsertTblCall()
        SqlIncomplete.InsertParameters("IdCar").DefaultValue = Request.QueryString("IdCar").ToString
        SqlIncomplete.Insert()

        Try
            If Request.QueryString("CallID").ToString = "" Then
                SqlCar.Update()
            End If
        Catch ex As Exception

        End Try


        ScriptManager.RegisterClientScriptBlock(UpdatePanel1, GetType(UpdatePanel), UpdatePanel1.ClientID, "javascript:parent.change_parent_url('frmCase.aspx');", True)
    End Sub

End Class
