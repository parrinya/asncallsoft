﻿
Partial Class Modules_Sale_Phone_frmCaseCall4Recoving
    Inherits System.Web.UI.Page
    Dim FunAll As New FuntionAll
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("chkCall") IsNot Nothing Then
                chkCall.Checked = Session("chkCall")
            End If
        End If
    End Sub
    Protected Sub GvCase_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles GvCase.DataBound
        For i As Integer = 1 To GvCase.Rows.Count - 1
            Dim ImageButton4 As Button = FunAll.ObjFindControl("Button4", GvCase.Rows(i).Cells(0))
            ImageButton4.Visible = False
        Next
    End Sub
    Protected Sub GvCase_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvCase.RowCommand
        If e.CommandName = "Select" Then

        ElseIf e.CommandName = "Phone" Then

            Dim strLink As String = "?IdCar=" & GvCase.DataKeys(e.CommandArgument).Item(0)
            strLink += "&&RunNo=" & GvCase.DataKeys(e.CommandArgument).Item(5)
            strLink += "&Call=1"
            If GvCase.DataKeys(e.CommandArgument).Item(3).ToString = "0" Then
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.change_parent_url('frmPhoneRecoving.aspx" & strLink & "');</script>")
               
            End If
        End If
    End Sub
    Protected Sub chkCall_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkCall.CheckedChanged
        Session("chkCall") = chkCall.Checked
        'If chkCall.Checked = True Then
        '    SqlCall.Insert()
        'ElseIf chkCall.Checked = False Then
        '    SqlCall.Update()
        'End If
    End Sub
    Protected Sub Timer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If lblSec.Text > 0 And chkCall.Checked = False Then
            lblSec.Text -= 1
        Else
            If GvCase.Rows.Count > 0 And chkCall.Checked = False Then
                LinkGv()
            End If
        End If
    End Sub
    Protected Sub LinkGv()
        Dim strLink As String = "?IdCar=" & GvCase.DataKeys(0).Item(0)
        strLink += "&&RunNo=" & GvCase.DataKeys(0).Item(5)
        strLink += "&Call=1"
        If GvCase.DataKeys(0).Item(3).ToString = "0" Then
            ScriptManager.RegisterClientScriptBlock(UpdatePanel1, GetType(UpdatePanel), UpdatePanel1.ClientID, "javascript:parent.change_parent_url('frmPhoneRecoving.aspx" & strLink & "');", True)
          
       End If
    End Sub
End Class
