﻿
Partial Class Modules_Sale_Case_frmCallCenter
    Inherits System.Web.UI.Page

    Protected Sub GvHistory_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvHistory.RowCommand
        If e.CommandName = "Select" Then
            Dim strLink As String = "?userID=" & Request.Cookies("userID").Value & "&&IdCar=" & GvHistory.DataKeys(e.CommandArgument).Item(1)
            strLink += "&CusID=" & GvHistory.DataKeys(e.CommandArgument).Item(0)
            strLink += "&&AppID=" & GvHistory.DataKeys(e.CommandArgument).Item(2)
            strLink += "&&RunNo=0"
            strLink += "&Call=2"
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.change_parent_url('../Pending/frmPending.aspx" & strLink & "');</script>")
        End If
    End Sub
End Class
