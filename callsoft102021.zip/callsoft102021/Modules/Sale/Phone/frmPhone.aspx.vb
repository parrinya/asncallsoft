﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Globalization


Partial Class Modules_Sale_Phone_frmPhone
    Inherits System.Web.UI.Page
    Dim FunAll As New FuntionAll
    Dim StrQryProvince As New QueryProvince
    Public strsrc As String
    Public TelAjax As String = ""
    Dim ISODate As New ISODate
    Dim StrQuery As New QueryPhone
    Dim com As SqlCommand
    Dim Conn As New SqlConnection(ConfigurationManager.ConnectionStrings("asnbroker").ConnectionString)
    Public strProtype As String
    Dim dt As New DataTable
    Dim DataAccess As New DataAccess
    Dim dtGetAppPhotos As DataTable
    Public strRecoving As String
	Private strappid As String = ""

    'Private Property RBSelectConditionLINE As Object

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim mnList As Menu = CType(Master.FindControl("NavigationMenu"), Menu)
        mnList.Visible = False
        If Not IsPostBack Then
            ViewState("StartTime") = DateTime.Now
            If Request.Cookies("TypeTsr").Value = 6 Then
                frmRecruit.Visible = True
            Else
                frmRecruit.Visible = False
            End If
        End If
        ' 
        If Request.Cookies("TypeTsr").Value = 3 Then 'sale ปีต่อ จะเห็นข้อมูลปีต่อ
            FormViewDetailRenew.Visible = True
        Else
            FormViewDetailRenew.Visible = False
        End If
        'การมองเห็น Recoving
        Select Case Request.Cookies("TypeTsr").Value
            Case 3
                strRecoving = "frmHistoryRecoving.aspx?IdCar=" & Request.QueryString("IdCar")
            Case Else
                strRecoving = ""
        End Select
    End Sub

#Region "Address"
    Protected Sub frmAddr_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmAddr.DataBound
        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)

        FunAll.ListDropDown(ddDist, StrQryProvince.TblZipCodeBindDist(ddProvince.SelectedValue), "Dist", "Dist")
        'Dim str As String = frmAddr.DataKey.Item(0)
        FunAll.ListDropDown(ddSubDist, StrQryProvince.TblZipCodeBindSubDist(frmAddr.DataKey.Item(0).ToString.Trim, ddProvince.SelectedValue), "SubDist", "SubDist")

        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(frmAddr.DataKey.Item(1).ToString.Trim, ddProvince.SelectedValue, frmAddr.DataKey.Item(0).ToString.Trim), "ZipCode", "ZipCode")

        If ddDist.Items.Count > 0 Then
            ddDist.SelectedValue = frmAddr.DataKey.Item(0).ToString.Trim

        End If

        If ddSubDist.Items.Count > 0 Then
            ddSubDist.SelectedValue = frmAddr.DataKey.Item(1).ToString.Trim

        End If

        If ddZipCode.Items.Count > 0 Then
            ddZipCode.SelectedValue = frmAddr.DataKey.Item(2).ToString.Trim

        End If
    End Sub

    Protected Sub ddProvince_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)

        FunAll.ListDropDown(ddDist, StrQryProvince.TblZipCodeBindDist(ddProvince.SelectedValue), "Dist", "Dist")
        FunAll.ListDropDown(ddSubDist, StrQryProvince.TblZipCodeBindSubDist(ddDist.SelectedValue, ddProvince.SelectedValue), "SubDist", "SubDist")
        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(ddSubDist.SelectedValue, ddProvince.SelectedValue, ddDist.SelectedValue), "ZipCode", "ZipCode")


    End Sub

    Protected Sub ddDist_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)
        FunAll.ListDropDown(ddSubDist, StrQryProvince.TblZipCodeBindSubDist(ddDist.SelectedValue, ddProvince.SelectedValue), "SubDist", "SubDist")
        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(ddSubDist.SelectedValue, ddProvince.SelectedValue, ddDist.SelectedValue), "ZipCode", "ZipCode")

    End Sub

    Protected Sub ddSubDist_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)

        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(ddSubDist.SelectedValue, ddProvince.SelectedValue, ddDist.SelectedValue), "ZipCode", "ZipCode")

    End Sub
#End Region

#Region "Tel Call"
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Try
           UpdateTblUser()
            GetSoftPhone()

        Catch ex As Exception
            ScriptManager.RegisterClientScriptBlock(UpdatePanel1, GetType(UpdatePanel), UpdatePanel1.ClientID, "alert('ไม่สามารถโทรออกได้เนื่องจาก : " & ex.Message & "');", True)
        End Try

    End Sub
    Protected Sub UpdateTblUser()
        'update Tbluser TsrTel=เบอร์ลูกค้าที่โทรออก GetPhoneNumber(),TsrFlagCall=0 where Userid=Request.Cookies("userID").Value
        Dim strq As String = "Update tbluser set TsrFlagCall=0 ,TsrTel='" & GetPhoneNumber() & "' where userid=" & Request.Cookies("userID").Value
        CheckConnectionState()
        com = New SqlCommand(strq, Conn)
        com.ExecuteNonQuery()
    End Sub
    Protected Function checkPhoneNumber() As Boolean
        dt = New DataTable
        Dim strqry As String
        strqry = "Select * from TblBlackListCALL Where Mobile = '" & GetPhoneNumber() & "'"
        dt = DataAccess.DataRead(strqry)
        If dt.Rows.Count > 0 Then
            ScriptManager.RegisterClientScriptBlock(UpdatePanel1, GetType(UpdatePanel), UpdatePanel1.ClientID, "alert('เบอร์โทรติด Blacklist ไม่สามารถโทรออกได้');", True)
            Return False
        Else
            Return True
        End If
    End Function


    Protected Function GetPhoneNumber() As String
        Select Case ddCall.SelectedValue
            Case 1

                Return frmTel.DataKey.Item(0).ToString
            Case 2

                Return frmTel.DataKey.Item(1).ToString
            Case 3

                Return frmTel.DataKey.Item(2).ToString
            Case 4

                Return frmTel.DataKey.Item(3).ToString
            Case 5

                Return frmTel.DataKey.Item(4).ToString
            Case Else
                Return ""
        End Select
    End Function

    Protected Sub GetSoftPhone()
        If checkPhoneNumber() = True Then
            Dim CallUrl As String = ""

            CallUrl += Replace(ConfigurationManager.AppSettings("WebCall"), "@IpAsserisk", Request.Cookies("IpAsterisk").Value) & "to=" & GetPhoneNumber() & "&&from=" & Request.Cookies("Extension").Value & "&&refer1=" & Request.QueryString("IdCar").ToString
            CallUrl += "&refer2=" & Request.Cookies("userID").Value
            TelAjax = CallUrl
            LinkSoftPhone()
		With SqlDataSourceLineID
               	 .InsertParameters("Tel_Path").DefaultValue = CallUrl
               	 .Insert()
            	End With


        End If
    End Sub

    Protected Sub LinkSoftPhone()
        If Request.QueryString("Call").ToString = 1 And Request.Cookies("Extension").Value <> "0000" And Request.Cookies("Extension").Value <> "" And Request.Cookies("TypeTsr").Value <> 3 And Request.Cookies("TypeTsr").Value <> 6  Then
            strsrc = "SoftPhone.aspx?" & Request.ServerVariables("QUERY_STRING").ToString() & "&CallID=" & GetPhoneNumber()
        Else
            strsrc = ""
        End If
    End Sub


    Protected Sub frmTel_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmTel.DataBound
        If Not IsPostBack Then
            If Request.QueryString("Call").ToString = 1 And Request.Cookies("Extension").Value <> "0000" And Request.Cookies("Extension").Value <> "" And Request.Cookies("TypeTsr").Value <> 3 And Request.Cookies("TypeTsr").Value <> 6  Then
                UpdateTblUser()
                GetSoftPhone()
            End If



        End If
    End Sub
    Private Sub Appiont_Date()
        Date_S_E_Calendar()
        Dim DayToday As Date = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy"))).AddDays(0)
        If Request.Cookies("TypeTsr").Value <> 3 And Request.Cookies("TypeTsr").Value <> 6 Then
            If ddStatus.SelectedValue = 6 Then 'Follow Default Add 2 Day 
                Dim Day2A As Date = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy"))).AddDays(2)
                If ChkDateAppiont(Day2A) Then
                    txtAppoint.Text = Day2A.ToString("dd/MM/yyyy")
                    D.Text = Day2A.ToString("dd/MM/yyyy")
                    H.Text = "00"
                    M.Text = "00"
                    txtHour.Text = H.Text
                    txtMin.Text = M.Text
                Else
                    Dim Day1A As Date = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy"))).AddDays(1)
                    If ChkDateAppiont(Day1A) Then
                        txtAppoint.Text = Day1A.ToString("dd/MM/yyyy")
                        D.Text = Day1A.ToString("dd/MM/yyyy")
                        H.Text = "00"
                        M.Text = "00"
                        txtHour.Text = H.Text
                        txtMin.Text = M.Text

                    Else
                        txtAppoint.Text = DayToday.ToString("dd/MM/yyyy")
                        D.Text = DayToday.ToString("dd/MM/yyyy")
                        H.Text = Now.Hour.ToString
                        M.Text = Now.Minute.ToString
                        txtHour.Text = H.Text
                        txtMin.Text = M.Text
                    End If

                End If
            ElseIf ddStatus.SelectedValue = 7 Or ddStatus.SelectedValue = 8 Then 'CallBack ตามทุกวัน Default ทุก4 H
                txtAppoint.Text = DayToday.ToString("dd/MM/yyyy")
                D.Text = DayToday.ToString("dd/MM/yyyy")
                H.Text = (Now.AddHours(4)).ToString("HH")
                M.Text = Now.Minute.ToString
                txtHour.Text = H.Text
                txtMin.Text = M.Text
            End If
        End If
    End Sub
    Protected Sub ddStatus_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddStatus.SelectedIndexChanged
        ShowAppoint()
        Appiont_Date()
        LinkSoftPhone()
    End Sub

#End Region

    Private Function ChkDateAppiont(ByVal DayA As Date) As Boolean
        'Dim Add30Day As Date = CDate(DayA).AddDays(30)
        Dim txtCarBuyDate2 As DateTime = frmCar.DataKey.Item(4)

        If DayA <= txtCarBuyDate2 Then
            Return True
        Else
            Return False
        End If
    End Function
    'Show เวลานัด
    Protected Sub ShowAppoint()
        If ddStatus.SelectedValue = 5 Or ddStatus.SelectedValue = 9 Or ddStatus.SelectedValue = 12 Or ddStatus.SelectedValue = 11 Or ddStatus.SelectedValue = 7 Or ddStatus.SelectedValue = 27 Then
            If Request.Cookies("TypeTsr").Value = 3 And ddStatus.SelectedValue = 9 Then
                Panel1.Visible = True
            Else
                Panel1.Visible = False
            End If
        Else
            Panel1.Visible = True
        End If
    End Sub

    Protected Sub ddStatus_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddStatus.DataBound
        ShowAppoint()
    End Sub


#Region "Save Tblcustomer TblCar"

    'Address
    Protected Sub WebImageButton1_Click3(sender As Object, e As System.EventArgs)
        Try
            SaveTblCustomerAddr()

            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('บันทึกข้อมูลเรียบร้อย');", True)

        Catch ex As Exception
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้เนื่องจาก : " & ex.Message & "');", True)
        End Try
    End Sub

    Protected Sub SaveTblCustomerAddr()
        Dim txtAddr As TextBox = FunAll.ObjFindControl("txtAddr", frmAddr)
        Dim txtMoo As TextBox = FunAll.ObjFindControl("txtMoo", frmAddr)
        Dim txtViilege As TextBox = FunAll.ObjFindControl("txtViilege", frmAddr)
        Dim txtRoad As TextBox = FunAll.ObjFindControl("txtRoad", frmAddr)
        Dim txtSoi As TextBox = FunAll.ObjFindControl("txtSoi", frmAddr)

        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)

        With SqlCustomer
            .UpdateParameters("Address").DefaultValue = txtAddr.Text.Trim
            .UpdateParameters("Villege").DefaultValue = txtViilege.Text.Trim
            .UpdateParameters("Moo").DefaultValue = txtMoo.Text.Trim
            .UpdateParameters("Soi").DefaultValue = txtSoi.Text.Trim
            .UpdateParameters("Road").DefaultValue = txtRoad.Text.Trim
            .UpdateParameters("Dist").DefaultValue = ddDist.SelectedValue
            .UpdateParameters("Province").DefaultValue = ddProvince.SelectedValue
            .UpdateParameters("Zip").DefaultValue = ddZipCode.SelectedValue
            .UpdateParameters("SubDist").DefaultValue = ddSubDist.SelectedValue
            .UpdateParameters("CusID").DefaultValue = frmCus.DataKey.Item(0)
            .Update()
        End With
    End Sub


    Protected Sub WebImageButton1_Click(sender As Object, e As System.EventArgs)
        Try
            Dim txtCarBuyDate As TextBox = FunAll.ObjFindControl("txtCarBuyDate", frmCar)
            With SqlApp
                .UpdateParameters("CarBuyDate").DefaultValue = ISODate.SetISODate("en", txtCarBuyDate.Text.Trim)
                .Update()
            End With
            frmCar.DataBind()
            Appiont_Date()
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('บันทึกข้อมูลเรียบร้อย');", True)
        Catch ex As Exception
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้เนื่องจาก : " & ex.Message & "');", True)

        End Try


    End Sub

#End Region

    Protected Sub ImageButton2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        Dim NumberPhone As String = selectTelephone(1)
        'บ้าน
        If NumberPhone <> "" Then
            If chkTelephone(NumberPhone) Then
                UpdateTblCustomer(1)
            Else
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถแก้ไขเบอร์เดิมได้ ');", True)
            End If
        Else
            UpdateTblCustomer(1)
        End If
    End Sub

    Protected Sub ImageButton3_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        ' ที่ทำงาน
        Dim NumberPhone As String = selectTelephone(2)
        If NumberPhone <> "" Then
            If chkTelephone(NumberPhone) Then
                UpdateTblCustomer(2)
            Else
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถแก้ไขเบอร์เดิมได้ ');", True)
            End If
        Else
            UpdateTblCustomer(2)
        End If
    End Sub

    Protected Sub ImageButton4_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        'มือถือ
        Dim NumberPhone As String = selectTelephone(5)
        If NumberPhone <> "" Then
            If chkTelephone(NumberPhone) Then
                UpdateTblCustomer(5)
            Else
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถแก้ไขเบอร์เดิมได้ ');", True)
            End If
        Else
            UpdateTblCustomer(5)
        End If
    End Sub

    Protected Sub ImageButton5_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        'อื่นๆ1
        Dim NumberPhone As String = selectTelephone(4)
        If NumberPhone <> "" Then
            If chkTelephone(NumberPhone) Then
                UpdateTblCustomer(4)
            Else
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถแก้ไขเบอร์เดิมได้ ');", True)
            End If
        Else
            UpdateTblCustomer(4)
        End If
    End Sub

    Protected Sub ImageButton6_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(3)
    End Sub

    Protected Sub ImageButton7_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(7)
    End Sub

    Protected Sub ImageButton8_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs)
        'อื่นๆ2
        Dim NumberPhone As String = selectTelephone(8)
        If NumberPhone <> "" Then
            If chkTelephone(NumberPhone) Then
                UpdateTblCustomer(8)
            Else
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถแก้ไขเบอร์เดิมได้ ');", True)
            End If
        Else
            UpdateTblCustomer(8)
        End If
    End Sub

    Protected Sub UpdateTblCustomer(ByVal UpdateID As Integer)

        Try
            Dim txtTel As TextBox = FunAll.ObjFindControl("txtTel", frmTel)
            Dim txtTelExt As TextBox = FunAll.ObjFindControl("txtTelExt", frmTel)
            Dim txtOTel As TextBox = FunAll.ObjFindControl("txtOTel", frmTel)
            Dim txtOTelExt As TextBox = FunAll.ObjFindControl("txtOTelExt", frmTel)
            Dim txtMobile As TextBox = FunAll.ObjFindControl("txtMobile", frmTel)
            Dim txtFax As TextBox = FunAll.ObjFindControl("txtFax", frmTel)
            Dim txtOther As TextBox = FunAll.ObjFindControl("txtOther", frmTel)
            Dim txtOtherExt As TextBox = FunAll.ObjFindControl("txtOtherExt", frmTel)
            Dim txtEmail As TextBox = FunAll.ObjFindControl("txtEmail", frmTel)
            Dim txtOther3 As TextBox = FunAll.ObjFindControl("txtOther3", frmTel)
            Dim txtOtherExt3 As TextBox = FunAll.ObjFindControl("txtOtherExt3", frmTel)
            CheckConnectionState()
            com = New SqlCommand(StrQuery.UpdateTblCustomer(UpdateID), Conn)
            With com
                .Parameters.Clear()
                .Parameters.Add("@Tel", SqlDbType.VarChar).Value = txtTel.Text.Trim
                .Parameters.Add("@TelExt", SqlDbType.VarChar).Value = txtTelExt.Text.Trim
                .Parameters.Add("@OTel", SqlDbType.VarChar).Value = txtOTel.Text.Trim
                .Parameters.Add("@OTelExt", SqlDbType.VarChar).Value = txtOTelExt.Text.Trim
                .Parameters.Add("@Mobile", SqlDbType.VarChar).Value = txtMobile.Text.Trim
                .Parameters.Add("@OthTel1", SqlDbType.VarChar).Value = txtOther.Text.Trim
                .Parameters.Add("@OthTel1Ext", SqlDbType.VarChar).Value = txtOtherExt.Text.Trim
                .Parameters.Add("@OthTel2", SqlDbType.VarChar).Value = txtOther3.Text.Trim
                .Parameters.Add("@OthTel2Ext", SqlDbType.VarChar).Value = txtOtherExt3.Text.Trim
                .Parameters.Add("@Fax", SqlDbType.VarChar).Value = txtFax.Text.Trim
                .Parameters.Add("@Email", SqlDbType.VarChar).Value = txtEmail.Text.Trim
                .Parameters.Add("@CusID", SqlDbType.VarChar).Value = frmCus.DataKey.Item(0)
                .ExecuteNonQuery()

            End With

            frmTel.ChangeMode(FormViewMode.ReadOnly)
            frmTel.DataBind()

            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('บันทึกข้อมูลเรียบร้อย');", True)
        Catch ex As Exception
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้เนื่องจาก : " & ex.Message & "');", True)

        End Try


        'BindLink()
    End Sub

    Public Sub CheckConnectionState()
        If Conn.State = ConnectionState.Open Then
            Conn.Close()
        Else
            Conn.Open()
        End If
    End Sub


    Protected Sub LinkButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton2.Click
        strProtype = "../Product/frmProType2.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    End Sub

    Protected Sub LinkButton3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton3.Click
        strProtype = "../Product/frmProType3Plus.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    End Sub

    Protected Sub LinkButton4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton4.Click
        strProtype = "../Product/frmProType3.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        strProtype = "../Product/frmProType1.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    End Sub

    Protected Sub LinkButton5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton5.Click
        'strProtype = "../Product/frmProType1.aspx?IdCar=" & frmCar.DataKey.Item(0)
        strProtype = "../Product/frmSendFax.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    End Sub
    'Protected Sub LinkButton6_Click(sender As Object, e As System.EventArgs) Handles LinkButton6.Click
    '    strProtype = "../Product/frmProType1.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    'End Sub

    Protected Sub WebImageButton3_Click(sender As Object, e As System.EventArgs) Handles WebImageButton3.Click
        frmAddr.DataBind()
        frmApp.DataBind()
        frmTel.DataBind()
        frmCar.DataBind()

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim strLink As String = "Edit=1&Buy=2"
        strLink += "&IdCar=" & frmCar.DataKey.Item(0)
        strLink += "&AppID=" & frmApp.DataKey.Item(0)
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.open('../Application/frmApplication.aspx?" & strLink & "','Application');</script>")
    End Sub



#Region "Save Status"
    Protected Sub WebImageButton1_Click2(sender As Object, e As System.EventArgs) Handles WebImageButton1.Click

        'If Request.Cookies("TypeTsr").Value <> 3 And Request.Cookies("TypeTsr").Value <> 6 Then
        '    Dim ss As Date = ISODate.SetISODate("th", txtAppoint.Text)
        '    Dim DayAppoint As Date = CDate(ISODate.SetISODate("th", ss.ToString("dd/MM/yyyy")))
        '    If ddStatus.SelectedValue = 6 Then
        '        If ChkDateAppiont30(DayAppoint) = False Then
        '            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้ เนื่องจากวันคุ้มครองน้อยกว่า 30 วัน');", True)
        '            Exit Sub
        '        End If
        '    End If
        'End If



        If ChkData() = True And CheckAppointDate() = True And chkSelectLINE() = True Then
            If chk90() = True And chkFollow2D() = True Then

                frmApp.DataBind()
                CheckConnectionState()
                If ChkRider() = True Then

                    'สำหรับลงสถานะ Success
                    If ddStatus.SelectedValue = 3 Or ddStatus.SelectedValue = 4 Then
                        UpdateApplication()
                    End If
                    InsertTblRecruit()
                    btnSaveCus()
                    SqlStatus.Update()
                    UpdateLINEID()

                    'สำหรับ DataMining
                    'If ddStatus.SelectedValue = 3 Then
                    '    InsertBaseDataMinning_bk()
                    '    UpdateBaseDataMinning_bk()
                    'End If

                    'Update 
                    SqlDataTblCallListTsr.Update()

                    Select Case Request.Cookies("UserLevel").Value
                        Case 5
                            Response.Redirect("frmCase.aspx")
                        Case 12
                            Response.Redirect("frmCase.aspx")

                        Case Else
                            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.close();</script>")
                    End Select
                End If
            Else
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้ เนื่องจากวันคุ้มครองน้อยกว่า 20 วัน ไม่สามารถเลือกสถานะ Follow/CallBack ได้');", True)
            End If
        Else
            If chkSelectLINE() = False Then
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('กรุณาเลือกข้อมูล LIND');", True)
            End If
        End If
        'Catch ex As Exception
        '    MsgBox(ex.Message)
        'End Try

        DaiNgernPoll()

    End Sub
    Protected Function chkSelectLINE() As Boolean
        Dim txtLINEID As TextBox = FunAll.ObjFindControl("txtLINEID", formviewLine)
        Dim RBSelectConditionLINE As RadioButtonList = FunAll.ObjFindControl("RBSelectConditionLINE", formviewLine)
        Dim chk As Boolean
        If RBSelectConditionLINE.SelectedValue = "1" Or RBSelectConditionLINE.SelectedValue = "2" Or RBSelectConditionLINE.SelectedValue = "3" Then
            If (RBSelectConditionLINE.SelectedValue = "1" Or RBSelectConditionLINE.SelectedValue = "2") And txtLINEID.Text <> "" Then
                chk = True
            ElseIf RBSelectConditionLINE.SelectedValue = "3" Then
                chk = True
            Else
                chk = False
            End If

        Else
            chk = False
        End If
        Return chk
    End Function

    'Protected Sub InsertBaseDataMinning_bk()
    '    With SqlDataMining
    '        .InsertParameters("FNameTH").DefaultValue = frmCus.DataKey.Item(7)
    '        .InsertParameters("LNameTH").DefaultValue = frmCus.DataKey.Item(8)
    '        .Insert()
    '    End With
    'End Sub
    Protected Function chk90() As Boolean
        Dim chk As Boolean
        Conn.Open()
        If (ddStatus.SelectedValue = 6 Or ddStatus.SelectedValue = 8) And (Request.Cookies("TypeTsr").Value = 1) Then
            Dim strqrychk As String = ""
            strqrychk += " SELECT case when year(carbuydate) <YEAR(GETDATE()) then datediff(day,getdate(),DATEADD(year,datediff(YEAR,CarBuyDate,GETDATE()),CarBuyDate)) else datediff(day,GETDATE(),carbuydate) end as cday FROM TblCar  where IdCar=" & frmCar.DataKey.Item(0)
            Dim Command As SqlCommand
            Dim DataReader As SqlDataReader
            Dim cday As Integer = 0
            Command = New SqlCommand(strqrychk, Conn)
            DataReader = Command.ExecuteReader()
            If DataReader.HasRows Then
                While DataReader.Read
                    If IsDBNull(DataReader("cday")) = False Then
                        cday = DataReader("cday")
                    End If
                End While
            End If
            DataReader.Close()
            If cday > 20 Then
                chk = True
            Else
                chk = False
            End If
        Else
            chk = True
        End If
        If chk = False And Request.Cookies("TypeTsr").Value <> 3 Then
            chk = True
        End If

        Conn.Close()
        Return chk
    End Function
    Protected Function chkFollow2D() As Boolean
        Dim chk As Boolean
        'Follow and typetsr=1
        If (Request.Cookies("TypeTsr").Value = 1) And (ddStatus.SelectedValue = 6) Then

            Dim AppointDate As DateTime = CDate(SortDateAppoint())
            Dim DateNow As DateTime = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy")) & " " & Now.Hour.ToString & ":" & Now.Minute.ToString)
            Dim nday As Integer
            nday = DateDiff(DateInterval.Day, CDate(DateNow), CDate(AppointDate))

            If nday > 7 Then
                chk = False
                MsgBox("ไม่สามารถนัดเวลาดังกล่าวได้เนื่องจากสถานะ Follow ระยะห่างในการนัดได้สูงสุด 7 วัน , ซึ่งขณะนี้ห่าง  " & nday & " วัน ")
            Else
                chk = True
            End If

        Else
            chk = True
        End If
        Return chk

    End Function

    'Protected Sub UpdateBaseDataMinning_bk()
    '    'Tel2,OTel2,Mobile2,OthTel2,OthTel3,TelExt,OTelExt,OthTel1,OthTel1Ext,OthTel3Ext
    '    With SqlDataMining
    '        .UpdateParameters("Tel").DefaultValue = frmTel.DataKey.Item(0).ToString
    '        .UpdateParameters("TelExt").DefaultValue = frmTel.DataKey.Item(5).ToString
    '        .UpdateParameters("OTel").DefaultValue = frmTel.DataKey.Item(1).ToString
    '        .UpdateParameters("OTelExt").DefaultValue = frmTel.DataKey.Item(6).ToString
    '        .UpdateParameters("Mobile").DefaultValue = frmTel.DataKey.Item(2).ToString
    '        .UpdateParameters("OthTel1").DefaultValue = frmTel.DataKey.Item(7).ToString
    '        .UpdateParameters("OthTel2").DefaultValue = frmTel.DataKey.Item(4).ToString
    '        .UpdateParameters("creditCARD").DefaultValue = frmApp.DataKey.Item(5).ToString
    '        .UpdateParameters("ACQ_FNAME").DefaultValue = frmCus.DataKey.Item(7)
    '        .UpdateParameters("ACQ_LNAME").DefaultValue = frmCus.DataKey.Item(8)
    '        .Update()
    '    End With
    'End Sub


    ''คำนวณ Status ของ Customer
    Protected Sub btnSaveCus()
        Dim CntStatusDB As Integer = frmCus.DataKey.Item(2)
        Dim CurStatusDB As String = frmCus.DataKey.Item(1)
        Dim StatusCur As String = ddStatus.SelectedValue


        If StatusCur = CurStatusDB Then

            If StatusCur = "8" And CntStatusDB >= 10 And Request.Cookies("TypeTsr").Value <> 6 And Request.Cookies("TypeTsr").Value <> 3 Then 'CallBack = 7 to AbanDon ยกเว้น webasn ปีต่อ
                UpdateStatus("13", "0")
            ElseIf StatusCur = "8" And CntStatusDB >= 10 And Request.Cookies("TypeTsr").Value = 6 Then 'CallBack = 10 to AbanDon TypeTsr 6 (WebAsn)
                UpdateStatus("13", "0")
            ElseIf StatusCur = "6" And CntStatusDB >= 10 And Request.Cookies("TypeTsr").Value <> 6 And Request.Cookies("TypeTsr").Value <> 3 Then 'Follow Unlimit to Three Plus
                'UpdateStatus("15", "0")
                UpdateStatus(StatusCur, (CntStatusDB + 1).ToString)
            ElseIf StatusCur = "7" And CntStatusDB >= 3 And Request.Cookies("TypeTsr").Value <> 3 Then 'NoContact = 7 to Unreach ยกเว้นปีต่อ
                UpdateStatus("14", "0")
            Else
                UpdateStatus(StatusCur, (CntStatusDB + 1).ToString)
            End If

        Else
            UpdateStatus(StatusCur, "0")
        End If

    End Sub
    Private Function ChkAppointDate() As Int16
        If txtHour.Text = H.Text And txtMin.Text = M.Text And txtAppoint.Text = D.Text Then
            'ไม่ตั้งใจนัด
            Return "2"
        Else
            'ตั้งใจนัด
            Return "1"
        End If

    End Function

    'Update Status Customer
    Protected Sub UpdateStatus(ByVal CurStatus As String, ByVal CntStatus As String)

        Dim flagAppoint As Int16 = ChkAppointDate()
        com = New SqlCommand(StrQuery.UpdateCus, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@CurStatus", SqlDbType.Int).Value = CurStatus
            .Parameters.Add("@CntStatus", SqlDbType.Int).Value = CntStatus
            .Parameters.Add("@Comments", SqlDbType.VarChar).Value = DirectCast(frmComments.FindControl("txtComments"), TextBox).Text.Trim
            .Parameters.Add("@AppointDate", SqlDbType.DateTime).Value = SortDateAppoint()
            .Parameters.Add("@IsAppoint", SqlDbType.Bit).Value = 1
            .Parameters.Add("@UpdateID", SqlDbType.Int).Value = Request.Cookies("userID").Value
            .Parameters.Add("@IDCar", SqlDbType.Int).Value = Request.QueryString("IdCar").ToString
            .Parameters.Add("@RefNo", SqlDbType.VarChar).Value = GetRefNo()
            .Parameters.Add("@Flag_AppointDate", SqlDbType.Int).Value = flagAppoint
            .CommandTimeout = 50
            .ExecuteNonQuery()

        End With

        SaveTblCall(CurStatus, CntStatus)
    End Sub

    'Insert TblCall
    Protected Sub SaveTblCall(ByVal CurStatus As String, ByVal Cntstatus As String)
        Dim txtComments As TextBox = DirectCast(frmComments.FindControl("txtComments"), TextBox)

        'Try

        com = New SqlCommand(StrQuery.SaveTblCall(), Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@CarID", SqlDbType.Int).Value = frmCus.DataKey.Item(3)
            .Parameters.Add("@IsOutbound", SqlDbType.Int).Value = 1
            .Parameters.Add("@CallOrder", SqlDbType.Int).Value = 0
            .Parameters.Add("@SubStatusID", SqlDbType.Int).Value = ddSubStatus.SelectedValue
            .Parameters.Add("@CntSubStatus", SqlDbType.Int).Value = Cntstatus
            .Parameters.Add("@CallDetail", SqlDbType.VarChar).Value = txtComments.Text.Trim
            .Parameters.Add("@StartTime", SqlDbType.DateTime).Value = ViewState("StartTime")
            .Parameters.Add("@CreateID", SqlDbType.Int).Value = Request.Cookies("userID").Value
            .Parameters.Add("@UpdateID", SqlDbType.Int).Value = Request.Cookies("userID").Value
            .Parameters.Add("@StatusID", SqlDbType.Int).Value = CurStatus
            .Parameters.Add("@telNUMBER", SqlDbType.VarChar).Value = GetPhoneNumber()
            .Parameters.Add("@IsNew", SqlDbType.VarChar).Value = frmCus.DataKey.Item(6)
            .Parameters.Add("@perCloseApp", SqlDbType.VarChar).Value = ddPercent.SelectedValue
            .CommandTimeout = 50
            .ExecuteNonQuery()
        End With

        'Catch ex As Exception
        '    MsgBox(ex.ToString)
        'End Try
    End Sub

    'Update Application
    Protected Sub UpdateApplication()
        com = New SqlCommand(StrQuery.UpdateApp, Conn)
        Dim userqc As String = GetUserQc()
        With com
            .Parameters.Clear()
            .Parameters.Add("@userIDQc", SqlDbType.VarChar).Value = userqc
            .Parameters.Add("@AppIP", SqlDbType.NVarChar).Value = "\\" & Request.ServerVariables("REMOTE_ADDR") & "\Recorder"
            .Parameters.Add("@userID", SqlDbType.NVarChar).Value = Request.Cookies("userID").Value
            .Parameters.Add("@TypeTsr", SqlDbType.NVarChar).Value = Request.Cookies("TypeTsr").Value
            .Parameters.Add("@AppID", SqlDbType.VarChar).Value = frmApp.DataKey.Item(0)
            .ExecuteNonQuery()
        End With

        'ลบลำดับ

        If userqc <> "684" Then
            Dim strqrychk As String = ""
            strqrychk += " select autoid,useridqc from tbl_LogAssignSaleQc where useridqc=" & userqc
            Dim dt1 As New DataTable
            dt1 = DataAccess.DataRead(strqrychk)

            If dt1.Rows.Count > 0 Then
                strqrychk = " DELETE FROM tbl_LogAssignSaleQc WHERE useridqc=@userID "
                com = New SqlCommand(strqrychk, Conn)
                With com
                    .Parameters.Clear()
                    .Parameters.Add("@userID", SqlDbType.VarChar).Value = userqc
                    .ExecuteNonQuery()
                End With
            End If
            strqrychk = " INSERT INTO tbl_LogAssignSaleQc (useridqc) VALUES ( @userID )"
            com = New SqlCommand(strqrychk, Conn)
            With com
                .Parameters.Clear()
                .Parameters.Add("@userID", SqlDbType.VarChar).Value = userqc
                .ExecuteNonQuery()
            End With
        End If
        'จบ


    End Sub
    'SqlDataSourceLineID
    Protected Sub UpdateLINEID()
        Dim txtLINEID As TextBox = FunAll.ObjFindControl("txtLINEID", formviewLine)
        Dim RBSelectConditionLINE As RadioButtonList = FunAll.ObjFindControl("RBSelectConditionLINE", formviewLine)
        If RBSelectConditionLINE.SelectedValue = "3" Then
            With SqlDataSourceLineID
                .UpdateParameters("LINEID").DefaultValue = ""
                .UpdateParameters("FlagLINE").DefaultValue = RBSelectConditionLINE.SelectedValue
                .UpdateParameters("CusID").DefaultValue = frmCus.DataKey.Item(0)
                .Update()
            End With
        Else
            With SqlDataSourceLineID
                .UpdateParameters("LINEID").DefaultValue = txtLINEID.Text
                .UpdateParameters("FlagLINE").DefaultValue = RBSelectConditionLINE.SelectedValue
                .UpdateParameters("CusID").DefaultValue = frmCus.DataKey.Item(0)
                .Update()
            End With
        End If

    End Sub

    'TblRecruit
    Protected Sub InsertTblRecruit()
        If frmRecruit.DataItemCount = 0 And Request.Cookies("TypeTsr").Value = 6 Then
            Dim ddStatus As DropDownList = FunAll.ObjFindControl("ddStatus", frmRecruit)
            Dim txtComments As TextBox = FunAll.ObjFindControl("txtComments", frmRecruit)
            If ddStatus.SelectedValue > 0 Then
                With SqlRecruit
                    .InsertParameters("StatusID").DefaultValue = ddStatus.SelectedValue
                    .InsertParameters("ReDesc").DefaultValue = txtComments.Text.Trim
                    .Insert()
                End With
            End If

        End If

    End Sub

    'Check การกรอกข้อมูล
    Protected Function ChkData() As Boolean

        frmTel.DataBind()
        If frmTel.DataKey.Item(0).ToString = "" And frmTel.DataKey.Item(1).ToString = "" And frmTel.DataKey.Item(2).ToString = "" And frmTel.DataKey.Item(3).ToString = "" And frmTel.DataKey.Item(4).ToString = "" Then
            MsgBox("กรุณากรอกเบอร์ลูกค้าอย่างน้อย 1 เบอร์ในระบบ")
            Return False

        End If

        If ddStatus.SelectedValue = 6 And ddPercent.SelectedValue = 0 Then
            MsgBox("กรุณาใส่ Percent (%) การปิดApp")
            Return False
        End If

        If ddStatus.SelectedValue = 99 Then
            MsgBox("กรุณาเลือกสถานะ")
            Return False
        ElseIf ddStatus.SelectedValue <> 3 And ddStatus.SelectedValue <> 4 And ddStatus.SelectedValue <> 5 And ddStatus.SelectedValue <> 27 And ddStatus.SelectedValue <> 9 And ddStatus.SelectedValue <> 12 And ddStatus.SelectedValue <> 11 And ddStatus.SelectedValue <> 7 Then

            If txtMin.Text.Trim = "" Or txtHour.Text.Trim = "" Then
                MsgBox("กรุณากรอกวันและเวลาให้ครบ")
                Return False

            ElseIf txtMin.Text.Trim > 60 Then
                MsgBox("เวลาของคุณผิดพลาด : นาทีต้องไม่เกิน 60")
                Return False
            ElseIf txtHour.Text.Trim > 24 Then
                MsgBox("เวลาของคุณผิดพลาด : ชั่วโมงต้องไม่เกิน 24")
                Return False
            Else
                Return True
            End If
        ElseIf ddStatus.SelectedValue = 3 Or ddStatus.SelectedValue = 4 Or ddStatus.SelectedValue = 25 Or ddStatus.SelectedValue = 26 Then

            If txtMin.Text.Trim = "" Or txtHour.Text.Trim = "" Then
                MsgBox("กรุณาระบุวันที่")
                Return False
            ElseIf txtMin.Text.Trim > 59 Or txtHour.Text > 24 Then
                MsgBox("กรุณาระบุเวลาผิดพลาด")
                Return False
            End If

            frmApp.DataBind()
            If frmApp.DataItemCount = 0 Then
                MsgBox("ไม่สามารถบันทึกได้เนื่องจากยังไม่มี App")
                Return False
            Else
                If frmApp.DataKey.Item(6).ToString = "" And frmApp.DataKey.Item(8) = "True" Then
                    MsgBox("กรุณาระบุเลขบัตรประชาชน ประกันสมัครใจ")
                    Return False
                End If

                If frmApp.DataKey.Item(7).ToString = "" And frmApp.DataKey.Item(9) = "True" Then
                    MsgBox("กรุณาระบุเลขบัตรประชาชน พรบ.")
                    Return False
                End If

                If checkAppPay() = False Then
                    MsgBox("ไม่มีข้อมูลงวดชำระเงิน")
                    Return False
                End If


                Return True

            End If
        Else
            Return True
        End If
    End Function

    Protected Function checkAppPay() As Boolean
        SqlAppPay.SelectParameters("appid").DefaultValue = frmApp.DataKey.Item(0)
        Dim dvSql As DataView = DirectCast(SqlAppPay.Select(DataSourceSelectArguments.Empty), DataView)
        If dvSql.Count > 0 Then

            Return True
        Else
            Return False
        End If
    End Function

    'Check การกรอกวันที่
    Protected Function CheckAppointDate() As Boolean
        Try

            If ddStatus.SelectedValue <> 5 And ddStatus.SelectedValue <> 27 And ddStatus.SelectedValue <> 9 And ddStatus.SelectedValue <> 12 And ddStatus.SelectedValue <> 11 Or ddStatus.SelectedValue <> 7 Then
                Dim AppointDate As DateTime = CDate(SortDateAppoint())
                Dim DateNow As DateTime = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy")) & " " & Now.Hour.ToString & ":" & Now.Minute.ToString)

                If AppointDate < DateNow Then
                    MsgBox("ไม่สามารถนัดเวลาน้อยกว่าเวลาปัจจุบันได้ : " & DateNow & " < " & AppointDate)
                    Return False

                Else
                    Return True
                End If
            Else
                Return True
            End If
        Catch ex As Exception
            MsgBox("fotmat วันที่ผิดพลาด : จะต้องเป็น วัน/เดือน/ปี")
            Return False
        End Try


    End Function

    'จัดการเรียง วันที่นัด  วว ดด ปปปป  hh:mm
    Protected Function SortDateAppoint() As String
        'Dim AppointDateCV As String = ISODate.SetISODate("th", tbDay.Text.Trim & "/" & ddMonth.SelectedValue & "/" & ddYear.SelectedValue) & " " & tbHour.Text.Trim & ":" & tbMin.Text.Trim

        Dim AppointDateCV As String = ""
        If ddStatus.SelectedValue <> 5 And ddStatus.SelectedValue <> 27 And ddStatus.SelectedValue <> 9 And ddStatus.SelectedValue <> 12 And ddStatus.SelectedValue <> 11 And ddStatus.SelectedValue <> 7 Then
            Dim strdate As DateTime = ISODate.SetISODate("th", txtAppoint.Text)
            AppointDateCV = ISODate.SetISODate("th", strdate.ToString("dd/MM/yyyy")) & " " & txtHour.Text.Trim & ":" & txtMin.Text.Trim
        ElseIf ddStatus.SelectedValue = 7 Then
            Dim date1 As DateTime
            If Date.Now.DayOfWeek = DayOfWeek.Friday And DateTime.Now.Hour >= 14 Then
                date1 = DateTime.Now.AddDays(2)
            Else
                date1 = DateTime.Now.AddHours(4)
            End If
            AppointDateCV = ISODate.SetISODate("th", date1.ToString("dd/MM/yyyy")) & " " & date1.Hour & ":" & date1.Minute
        Else
            AppointDateCV = ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy")) & " " & DateTime.Now.Hour & ":" & DateTime.Now.Minute
        End If


        Return AppointDateCV

    End Function

    'Script MsgBox
    Public Sub MsgBox(ByVal sMsg As String)

        Dim sb As New StringBuilder()
        Dim oFormObject As System.Web.UI.Control
        sMsg = sMsg.Replace("'", "\'")
        sMsg = sMsg.Replace(Chr(34), "\" & Chr(34))
        sMsg = sMsg.Replace(vbCrLf, "\n")
        sMsg = "<script language=javascript>alert(""" & sMsg & """)</script>"

        sb = New StringBuilder()
        sb.Append(sMsg)

        For Each oFormObject In Me.Controls
            If TypeOf oFormObject Is HtmlForm Then
                Exit For
            End If
        Next

        ' Add the javascript after the form object so that the 
        ' message doesn't appear on a blank screen.
        oFormObject.Controls.AddAt(oFormObject.Controls.Count, New LiteralControl(sb.ToString()))
    End Sub

    'gen RefNo
    Protected Function GetRefNo() As String
        If frmCus.DataKey.Item(5).ToString.Length <> 13 Then
            Return FunAll.GetRefCar(frmCus.DataKey.Item(3))
        Else
            Return frmCus.DataKey.Item(5)
        End If
    End Function

    'GetQc
    Protected Function GetUserQc() As String
        dt = New DataTable
        dt = DataAccess.DataRead(StrQuery.SelectUserQc(GetTblAppPay))
        If dt.Rows.Count > 0 Then
            Dim str As String = dt.Rows(0).Item("useridqc").ToString
            Return dt.Rows(0).Item("useridqc")
        Else
            dt = New DataTable
            dt = DataAccess.DataRead(StrQuery.SelectUserQc("5"))
            If dt.Rows.Count > 0 Then
                Return dt.Rows(0).Item("useridqc")
            Else
                Return "3293"  'Nusataqc
            End If


        End If
    End Function

    Protected Function GetTblAppPay() As String
        dt = New DataTable
        dt = DataAccess.DataRead(StrQuery.SelectTblTypetsr(frmApp.DataKey.Item(0)))
        Dim strAppPay As String = ""
        If dt.Rows.Count > 0 Then
            If dt.Rows(0).Item("TypeTsr") = 3 Then
                strAppPay = "1" 'renew
            Else
                strAppPay = "2" 'out
            End If
        Else
            MsgBox("ไม่พบข้อมูล")
        End If


        Return strAppPay
    End Function

#Region "TakePhoto"
    'CheckProTypeID
    Protected Function ChkProType(ByVal ProID As String) As Boolean

        dt = New DataTable
        dt = DataAccess.DataRead(StrQuery.SelectTblProduct(ProID))
        If dt.Rows.Count > 0 And frmApp.DataKey.Item(2) = 1 Then
            If dt.Rows(0).Item("StatusPhoto") = True Then
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If

    End Function

    Protected Function ChkRider() As Boolean
        If ddStatus.SelectedValue = 4 Or ddStatus.SelectedValue = 3 Then
            If ChkProType(frmApp.DataKey.Item(1)) = True And frmApp.DataKey.Item(2) = 1 And TakePhotoOldApp() = True Then
                Return ChkTblAppointTakePhoto(frmCar.DataKey.Item(0), frmApp.DataKey.Item(0))
            Else
                Return True
            End If
        Else
            Return True
        End If
    End Function

    'Check App Photo สำหรับ ปีต่ออายุ
    Protected Function TakePhotoOldApp() As Boolean
        If Request.Cookies("TypeTsr").Value = 3 Or Request.Cookies("TypeTsr").Value = 11 Then
            Dim strqry As String = "select * from  TmpApp_CustRenew a1 Where IdCar =  " & frmCar.DataKey.Item(0)
            strqry += "  and a1.AppStatus = 1 and a1.FlagNewApp = 0"
            strqry += "  order by a1.CreateDate DESC "
            dt = New DataTable
            dt = DataAccess.DataRead(strqry)
            If dt.Rows.Count > 0 Then
                If dt.Rows(0).Item("ProductID") = frmApp.DataKey.Item(1) Then
                    'กรณีต่ออายุ และบริษัทประกันเดิมไม่ต้องให้ ASN ถ่ายรูป
                    Return False
                Else
                    Return True
                End If
            Else
                Return True
            End If
        Else
            Return True

        End If
    End Function

    'Check TblAppointTakePhoto
    Protected Function ChkTblAppointTakePhoto(ByVal IdCar As Integer, ByVal AppID As Integer) As Boolean
        Dim dtChk As New DataTable
        dtChk = GetTblAppointPhotos(IdCar)
        If dtChk.Rows.Count > 0 Then
            If dtChk.Rows(0).Item("Flag") <> 0 Then
                SqlRecruitStatus.DeleteParameters("appID").DefaultValue = AppID
                SqlRecruitStatus.Delete()
                InsertTblTakePhoto(dtChk, AppID)
                Return True
            Else
                Return True
            End If

        Else
            MsgBox("ไม่สามารถบันทึกได้ ไม่มีข้อมูลถ่ายรูปรถ")
            Return False
        End If
    End Function

    'ค้นหา TblAppointTakephoto
    Protected Function GetTblAppointPhotos(ByVal IdCar As String) As DataTable
        dtGetAppPhotos = New DataTable
        dtGetAppPhotos = DataAccess.DataRead(StrQuery.BindTblAppointTakephoto(IdCar))
        Return dtGetAppPhotos
    End Function

    Protected Sub InsertTblTakePhoto(ByVal dtPhoto As DataTable, ByVal AppID As Integer)
        com = New SqlCommand(StrQuery.InsertTblTakePhoto, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@CusID", SqlDbType.VarChar).Value = frmCus.DataKey.Item(0)
            .Parameters.Add("@idCAR", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("IdCar")
            .Parameters.Add("@appID", SqlDbType.VarChar).Value = AppID
            .Parameters.Add("@phID", SqlDbType.VarChar).Value = 2
            .Parameters.Add("@tID", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("tID")
            .Parameters.Add("@createID", SqlDbType.VarChar).Value = Request.Cookies("userID").Value
            .Parameters.Add("@appointDATE", SqlDbType.DateTime).Value = ISODate.SetISODate("th", CDate(dtPhoto.Rows(0).Item("appointDATE")).ToString("dd/MM/yyyy"))
            .Parameters.Add("@appointCOMMENT", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("Name")
            .Parameters.Add("@provinceDEST", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("Province")
            .Parameters.Add("@mainDEST", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("Dist")
            .Parameters.Add("@Destination", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("SubDist")
            .ExecuteNonQuery()
        End With


        com = New SqlCommand(StrQuery.UpdateAppTakePhoto, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@AppID", SqlDbType.VarChar).Value = AppID
            .ExecuteNonQuery()
        End With
    End Sub

#End Region
#End Region

    Protected Sub WebImageButton2_Click(ByVal sender As Object, e As System.EventArgs) Handles WebImageButton2.Click
        Select Case Request.Cookies("UserLevel").Value
            Case 5
                Response.Redirect("frmCase.aspx")
            Case 12
                Response.Redirect("frmCase.aspx")
            Case Else
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.close();</script>")
        End Select

    End Sub

    Protected Sub frmComments_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmComments.DataBound
        Dim txtComments As TextBox = FunAll.ObjFindControl("txtComments", frmComments)
        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)
        Dim strAddr As String = ""
        If ddDist.Items.Count = 0 Then

            strAddr += "|" & frmAddr.DataKey.Item(0).ToString.Trim
        End If

        If ddSubDist.Items.Count = 0 Then

            strAddr += "|" & frmAddr.DataKey.Item(1).ToString.Trim
        End If

        If ddZipCode.Items.Count = 0 Then

            strAddr += "|" & frmAddr.DataKey.Item(2).ToString.Trim
        End If

        If InStr(txtComments.Text.Trim, strAddr) Then
            txtComments.Text = Replace(txtComments.Text, strAddr, strAddr)
        Else
            txtComments.Text += strAddr
        End If
    End Sub

    Protected Sub WebImageButton4_Click(sender As Object, e As System.EventArgs) Handles WebImageButton4.Click
        Dim strlink As String = ""
        strlink = Request.QueryString("IdCar").ToString
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script> window.open ('http://10.17.1.230/tm4/" & strlink & "');</script>")
        'Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script> window.open ('file:///D:/" & strlink & "');</script>")
    End Sub

    Protected Sub WebImageButton5_Click(sender As Object, e As System.EventArgs) Handles WebImageButton5.Click
        Dim strLink As String = "Edit=0&Buy=3"
        strLink += "&IdCar=" & frmCar.DataKey.Item(5)
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.open('../Application/frmApplication.aspx?" & strLink & "','Application');</script>")
    End Sub


    Protected Sub ddSubStatus_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddSubStatus.SelectedIndexChanged
        'LinkSoftPhone()
    End Sub



    'Protected Sub Button3_Click(sender As Object, e As System.EventArgs) Handles Button3.Click
    '    With SqlDataMining
    '        .SelectParameters("FNameTH").DefaultValue = frmCus.DataKey.Item(7)
    '        .SelectParameters("LNameTH").DefaultValue = frmCus.DataKey.Item(8)
    '        .SelectParameters("BRAND_D").DefaultValue = frmCar.DataKey.Item(1)
    '    End With
    '    GvDataMind.Visible = True
    '    GvDataMind.DataBind()
    'End Sub

    Protected Sub frmCar_DataBound(sender As Object, e As System.EventArgs) Handles frmCar.DataBound
        If frmCar.DataItemCount > 0 Then
            SqlStatus.SelectParameters("StatusID").DefaultValue = frmCar.DataKey.Item(2)
        End If
    End Sub
    Protected Sub btnScript_Click(sender As Object, e As System.EventArgs) Handles btnScript.Click
        '1.ค้นหา APP
        Dim dtAppID As New System.Data.DataTable
        Dim dv As DataView = DirectCast(SqlAppConfirm.Select(DataSourceSelectArguments.Empty), DataView)
        dtAppID = dv.ToTable()
        If dtAppID.Rows.Count > 0 Then
            strappid = dtAppID.Rows(0)("AppID").ToString()
            '2.
            SetScript(strappid)
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "sett", "sett();", True)
        Else
            SetScript(0)
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "sett", "sett();", True)
            'Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ค้นหา APP ไม่พบกรุณาตรวจสอบ');", True)
        End If

    End Sub
    Protected Sub Date_S_E_Calendar()

        If Request.Cookies("TypeTsr").Value <> 3 And Request.Cookies("TypeTsr").Value <> 6 Then
            Dim DProtect As DateTime = frmCar.DataKey.Item(4)
            Dim DStatr As DateTime = DateTime.Now
            Dim DEnd As DateTime = DateTime.Now
            If ddStatus.SelectedValue = 6 Then
                '
                If DStatr.AddDays(6) <= DProtect Then
                    DEnd = DEnd.AddDays(7)
                Else
                    Dim DiffDate As Integer = DateDiff(DateInterval.Day, DStatr.AddDays(7), DProtect)
                    If DiffDate > 0 Then
                        DEnd = DEnd.AddDays(DiffDate)

                    Else

                        DEnd = DEnd.AddDays(7 + DiffDate - 1)

                    End If
                End If
                txtAppoint_CalendarExtender.StartDate = DStatr
                txtAppoint_CalendarExtender.EndDate = DEnd
            Else
                txtAppoint_CalendarExtender.StartDate = DStatr
                txtAppoint_CalendarExtender.EndDate = DStatr.AddDays(180)
            End If
        End If
    End Sub
    Protected Sub SetScript(ByVal strappid As String)

        Dim query = New System.Text.StringBuilder()
        query.Append(" select a.AppID,a.Idcar,d.InitTH+' '+c.FNameTH+' '+c.LNameTH as cusname,b.CarID, ")
        query.Append(" b.CarBrand,")
        query.Append(" b.CarSeries,")
        query.Append(" isnull(b.CarSize,'') as CarSize")
        query.Append(" ,e.ProTypeName,a7.TypeName,")
        query.Append(" case a.IsCarpet when 1 then a.CarPet else 0 end as Carpet,")
        query.Append(" case a.IsCarpet when 1 then CONVERT(VARCHAR,a.ProtectDateCarpet,103) else 'ไม่ระบุ'  end as ProtectDateCarpet,")
        query.Append(" case a.IsCarpet when 1 then 'โดยเริ่มคุ้มครองวันที่(พรบ.)' else ''  end as lblProtectDateCarpet,")
        query.Append(" case a.IsCarpet when 1 then 'รวม พรบ.' else 'ไม่รวม พรบ.'  end as lblCarpet,")
        query.Append(" CAST(a.ProValue as money)+ CAST(a.CarPet as money) as ProValue,")
        query.Append(" case a.IsProvalue when 1 then CONVERT(VARCHAR,a.ProtectDate,103) else 'ไม่ระบุ' end as ProtectDate,")
        query.Append(" case a.IsProvalue when 1 then CAST(a.Car_Fire as money) else 0 end as Car_Fire,")
        query.Append(" case b.CarFixIn when '1' then 'ซ่อมอู่'  else 'ซ่อมห้าง' end as IsFixIn ,")
        query.Append(" (select count(*) from tblapppay where appid=a.AppID) as CPay,")
        query.Append(" case b.CarDriverNo when 0  then 'ไม่เป็นแบบระบุชื่อผู้ขับขี่'  else 'เป็นแบบระบุชื่อผู้ขับขี่' end as lblCarDriverNo ,")
        query.Append(" case b.CarDriverNo when 0  then ''  else CAST(b.CarDriverNo as varchar) end as CarDriverNo , ")
        query.Append(" case b.CarDriverNo when 0  then ''  else 'ท่าน(กรณีทำประกันประเภทระบุชื่อผู้ขับขี่)' end as lbl ,")
        query.Append(" case f.IsPayDate when 1 then CONVERT(VARCHAR, f.PayDate,103) else 'ไม่ระบุ' end as PayDate ")
        query.Append(" from tblapplication a  ")
        query.Append(" inner join tblcar b on a.Idcar=b.idcar ")
        query.Append(" inner join tblcustomer c on b.CusID=c.cusid ")
        query.Append(" inner join TblCustomerInit d on d.InitID=c.InitID")
        query.Append(" Inner Join Tbl_ProductType a6 on a.ProductID = a6.ProTypeID")
        query.Append(" Inner Join Tbl_Type a7 on a.Typeprovalue = a7.TypeID")
        query.Append(" Left  Join Tbl_ProductType e on  e.ProTypeID=a.ProDuctID")
        query.Append(" Left  Join TblAppCard f on a.AppID=f.AppID")
        query.Append(" where a.AppID =" & strappid)


        Dim da As SqlDataAdapter = New SqlDataAdapter(query.ToString, Conn)
        Dim table As DataTable = New DataTable
        da.Fill(table)
        If table.Rows.Count > 0 Then
            HFAppID.Value = table.Rows(0)("AppID").ToString
            txtCarID.Text = table.Rows(0)("CarID").ToString
            txtCarBrand.Text = table.Rows(0)("CarBrand").ToString
            txtCarSeries.Text = table.Rows(0)("CarSeries").ToString
            txtCarSize.Text = table.Rows(0)("CarSize").ToString
            txtProTypeName.Text = table.Rows(0)("ProTypeName").ToString
            txtTypeName.Text = table.Rows(0)("TypeName").ToString
            txtProtectDate.Text = table.Rows(0)("ProtectDate").ToString
            lblProtectDateCarprt.Text = table.Rows(0)("lblProtectDateCarpet").ToString
            txtProtectDateCarprt.Text = table.Rows(0)("ProtectDateCarpet").ToString
            lblCarDriverNo.Text = table.Rows(0)("lblCarDriverNo").ToString
            txtCarDriverNo.Text = table.Rows(0)("CarDriverNo").ToString
            Label13.Text = table.Rows(0)("lbl").ToString
            lblCarpet.Text = table.Rows(0)("lblCarpet").ToString
            txtCar_Fire.Text = String.Format(CultureInfo.InvariantCulture, "{0:0,0.00}", table.Rows(0)("Car_Fire"))
            txtIsFixIn.Text = table.Rows(0)("IsFixIn").ToString
            txtProValue.Text = String.Format(CultureInfo.InvariantCulture, "{0:0,0.00}", table.Rows(0)("ProValue"))
            txtPayDate.Text = table.Rows(0)("PayDate").ToString
            SqlAppPayDGVPay.SelectParameters("Appid").DefaultValue = strappid
            DGVPay.DataSource = SqlAppPayDGVPay
            DGVPay.DataBind()

            frmAddrConfirm.DataSource = SqlCustomerConfirm
            frmAddrConfirm.DataBind()

            DGVAppCard.DataSource = SqlAppCard2Confirm
            DGVAppCard.DataBind()

            frmCusNameConfirm.DataSource = SqlCustomerConfirm
            frmCusNameConfirm.DataBind()

        Else

            query = New System.Text.StringBuilder()
            query.Append(" select b.Idcar,b.CarID, ")
            query.Append(" b.CarBrand,")
            query.Append(" b.CarSeries,")
            query.Append(" isnull(b.CarSize,'') as CarSize")
            query.Append(" From  tblcar b ")
            query.Append(" inner join tblcustomer c on b.CusID=c.cusid ")
            query.Append(" where b.Idcar =" & Request.QueryString("IdCar").ToString())
            Dim da1 As SqlDataAdapter = New SqlDataAdapter(query.ToString, Conn)
            Dim table1 As DataTable = New DataTable
            da1.Fill(table1)
            HFAppID.Value = "0"
            ' HFidCar.Value = table1.Rows(0)("Idcar").ToString
            '3.
            txtCarID.Text = table1.Rows(0)("CarID").ToString
            txtCarBrand.Text = table1.Rows(0)("CarBrand").ToString
            txtCarSeries.Text = table1.Rows(0)("CarSeries").ToString
            txtCarSize.Text = table1.Rows(0)("CarSize").ToString
            '4.
            txtProTypeName.Text = ""
            txtTypeName.Text = ""
            '5.
            txtProtectDate.Text = ""
            lblProtectDateCarprt.Text = ""
            txtProtectDateCarprt.Text = ""
            lblCarDriverNo.Text = "การระบุผู้ขับขี่"
            txtCarDriverNo.Text = ""
            Label13.Text = ""
            lblCarpet.Text = ""
            txtCar_Fire.Text = ""
            txtIsFixIn.Text = ""
            txtProValue.Text = ""
            txtPayDate.Text = ""

            'DGVPay.DataSource = SqlAppPayDGVPay
            'DGVPay.DataBind()
            frmAddrConfirm.DataSource = SqlCustomerConfirm
            frmAddrConfirm.DataBind()
            DGVAppCard.DataSource = SqlAppCard2Confirm
            DGVAppCard.DataBind()
            frmCusNameConfirm.DataSource = SqlCustomerConfirm
            frmCusNameConfirm.DataBind()
        End If

    End Sub

    Public Sub DaiNgernPoll()
        Dim IsDaiNgern As Int32
        Dim strSQL As String
        Dim dtReader As SqlDataReader
        Conn.Open()
        strSQL = "SELECT * FROM tblDaiNgern_poll where IdCar =" + Convert.ToString(frmCar.DataKey.Item(0))
        com = New SqlCommand(strSQL, Conn)
        dtReader = com.ExecuteReader()

        If dtReader.HasRows Then

            Try
                If RdPollDaiNgern.SelectedValue = 1 Then
                    IsDaiNgern = 1
                ElseIf RdPollDaiNgern.SelectedValue = 2 Then
                    IsDaiNgern = 0
                Else
                    Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('เลือกคำตอบความสนใจโปรเจค-ได้เงิน-ด้วยค่ะ');", True)
                End If
            Catch ex As Exception
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้เนื่องจาก : " & ex.Message & "');", True)
            End Try

            With pollDaiNgern
                .UpdateParameters("IsDaiNgern").DefaultValue = IsDaiNgern
                .Update()
            End With
        Else

            Try

                If RdPollDaiNgern.SelectedValue = 1 Then
                    IsDaiNgern = 1
                ElseIf RdPollDaiNgern.SelectedValue = 2 Then
                    IsDaiNgern = 0
                Else
                    Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('เลือกคำตอบความสนใจโปรเจค-ได้เงิน-ด้วยค่ะ');", True)
                End If

                With pollDaiNgern
                    .InsertParameters("IsDaiNgern").DefaultValue = IsDaiNgern
                    .InsertParameters("IdCar").DefaultValue = IsDaiNgern
                    .Insert()
                End With

            Catch ex As Exception
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้เนื่องจาก : " & ex.Message & "');", True)
            End Try


            dtReader.Close()
            dtReader = Nothing
            Conn.Close()
            Conn = Nothing
        End If
    End Sub
    Protected Function selectTelephone(ByVal ID As Integer) As String
        Dim chk As Boolean
        Conn.Open()

        Dim strqrychk As String = ""
        strqrychk += "  SELECT isnull(a1.Tel,'') as Tel , isnull(a1.OTel,'') as OTel ,isnull(a1.Mobile,'') as Mobile ,isnull(a1.OthTel1,'') as OthTel1 ,isnull(a1.OthTel2,'') as OthTel2 FROM TblCustomer a1 Inner Join TblCar a2 on a1.CusID = a2.CusID Where   a2.IdCar = " & frmCar.DataKey.Item(0)



        Dim Command As SqlCommand
        Dim DataReader As SqlDataReader
        Dim Tel As String = ""
        Dim OTel As String = ""
        Dim Mobile As String = ""
        Dim OthTel1 As String = ""
        Dim OthTel2 As String = ""

        Command = New SqlCommand(strqrychk, Conn)
        DataReader = Command.ExecuteReader()
        If DataReader.HasRows Then
            While DataReader.Read

                Tel = DataReader("Tel")
                OTel = DataReader("OTel")
                Mobile = DataReader("Mobile")
                OthTel1 = DataReader("OthTel1")
                OthTel2 = DataReader("OthTel2")

            End While
        End If
        DataReader.Close()
        Conn.Close()
        If ID = 1 Then
            Return Tel
        ElseIf ID = 2 Then
            Return OTel
        ElseIf ID = 5 Then
            Return Mobile
        ElseIf ID = 4 Then
            Return OthTel1
        ElseIf ID = 8 Then
            Return OthTel2
        End If
    End Function

    Protected Function chkTelephone(ByVal phoneno As String) As Boolean
        Dim chk As Boolean
        Conn.Open()

        Dim strqrychk As String = ""
        strqrychk += "select count(*) as ncount from TblCallControl where  cctbillsec>0 and cctcallerid='" & phoneno & "'"
        Dim Command As SqlCommand
        Dim DataReader As SqlDataReader
        Dim ncount As Integer = 0
        Command = New SqlCommand(strqrychk, Conn)
        DataReader = Command.ExecuteReader()
        If DataReader.HasRows Then
            While DataReader.Read
                If IsDBNull(DataReader("ncount")) = False Then
                    ncount = DataReader("ncount")
                End If
            End While
        End If
        DataReader.Close()
        If ncount > 0 Then
            chk = False
        Else
            chk = True
        End If

        Conn.Close()
        Return chk
    End Function

    Protected Sub RBSelectConditionLINE_SelectedIndexChanged(sender As Object, e As System.EventArgs)
        DefalutLINEID()
    End Sub

    Protected Sub RBSelectConditionLINE_SelectedIndexChanged1(sender As Object, e As System.EventArgs)
        DefalutLINEID()
    End Sub
    Private Sub DefalutLINEID()
        Dim txtLINEID As TextBox = FunAll.ObjFindControl("txtLINEID", formviewLine)
        Dim RBSelectConditionLINE As RadioButtonList = FunAll.ObjFindControl("RBSelectConditionLINE", formviewLine)

        If RBSelectConditionLINE.SelectedValue = "3" Then
            txtLINEID.Text = ""
        End If
    End Sub


    Protected Sub LinkButton99_Click(sender As Object, e As System.EventArgs) Handles LinkButton99.Click
        strProtype = "../Product/frmProType1Plus.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    End Sub
    'Protected Sub LinkButton6_Click(sender As Object, e As System.EventArgs) Handles LinkButton6.Click
    '    strProtype = "../Product/frmProType1DD.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    'End Sub

    Protected Sub LinkButton7_Click(sender As Object, e As System.EventArgs) Handles LinkButton7.Click
        strProtype = "../Product/frmProType20.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    End Sub
End Class
