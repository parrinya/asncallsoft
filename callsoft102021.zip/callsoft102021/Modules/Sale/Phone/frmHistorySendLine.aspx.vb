﻿
Partial Class Modules_Sale_Phone_frmHistorySendLine
    Inherits System.Web.UI.Page

End Class
