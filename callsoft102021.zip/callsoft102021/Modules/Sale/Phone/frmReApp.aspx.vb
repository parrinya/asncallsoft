﻿
Partial Class Modules_Sale_Case_frmReApp
    Inherits System.Web.UI.Page

   

    

   
     
    Protected Sub GvFeedBack_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvFeedBack.RowCommand
        If e.CommandName = "Select" Then
            Dim strLink As String = "?userID=" & Request.Cookies("userID").Value & "&&RunFNo=" & GvFeedBack.DataKeys(e.CommandArgument).Item(0)
            strLink += "&&AppID=" & GvFeedBack.DataKeys(e.CommandArgument).Item(1)
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.change_parent_url('../Pending/frmReApp.aspx" & strLink & "');</script>")
        End If
    End Sub
End Class
