﻿Imports Microsoft.VisualBasic

Public Class QureyCredit
    Public Function InsertAppCard() As String
        Dim strqry As String = ""
        strqry += "INSERT INTO TblAppCard"
        strqry += " (Appid, CardRun, CardNo1, CardNo2, CardExp, Cardname, PayTypeId, Cardid, Bankid, PayDate, IsPayDate, Createid, Createdate, Updatedate, Updateid, Tel1, Mobile)"
        strqry += " VALUES        (@Appid,@CardRun,@CardNo1,@CardNo2,@CardExp,@Cardname,1,@Cardid,@Bankid,@PayDate,@IsPayDate,@Createid,GetDate(),GetDate(),@Updateid,@Tel1,@Mobile)"
        Return strqry
    End Function

    Public Function UpdateAppCard() As String
        Dim strqry As String = ""
        strqry += " UPDATE TblAppCard "
        strqry += " SET CardNo1 = @CardNo1"
        strqry += " , CardNo2 = @CardNo2"
        strqry += " , CardExp = @CardExp"
        strqry += " , Cardname = @Cardname"
        strqry += " , PayTypeId = 1"
        strqry += " , Cardid = @Cardid"
        strqry += " , Bankid = @Bankid"
        strqry += " , PayDate = @PayDate"
        strqry += " , IsPayDate = @IsPayDate"
        strqry += " , Updatedate = GETDATE()"
        strqry += " , Updateid = @Updateid"
        strqry += " , Tel1 = @Tel1"
        strqry += " , Mobile = @Mobile "
        strqry += " WHERE (AppCardId = @AppCardID)"
        Return strqry

    End Function
End Class
