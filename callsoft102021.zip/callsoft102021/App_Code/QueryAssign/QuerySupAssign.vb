﻿Imports Microsoft.VisualBasic

Public Class QuerySupAssign

#Region "Select"
    Public Function SelectCountSourceGroup(ByVal GroupID As String, ByVal userID As String) As String
        Dim strqry As String = ""
        strqry += " SELECT a2.IdCar FROM [TblSourceGroup] a1 "
        strqry += " Inner Join TblCar a2 on a1.GroupID = a2.GroupID"
        strqry += " Where a2.CurStatus in (0,1) and a1.GroupID = " & GroupID & " and AssignTo = " & userID

        Return strqry
    End Function

    Public Function TblBindGroupSourceAssign(ByVal strCmd As String) As String
        Dim strqry As String
        strqry = "(Select 'All' as GroupName,0 as GroupID) union (SELECT    Distinct a2.GroupName,a2.GroupID "
        strqry += " FROM         TblCar a1 INNER JOIN "
        strqry += " TblSourceGroup a2 ON a1.GroupID = a2.GroupID"
        strqry += " INNER JOIN TblUser a3 on a1.AssignTo = a3.userID"
        strqry += " where "
        strqry += " a2.GroupStatus = 1   " & strCmd & ") "
        strqry += " Order by a2.GroupID "
        Return strqry
    End Function

    Public Function TblCustomer(ByVal FnameTH As String, ByVal LNameTH As String) As String
        Dim strqry As String
        strqry = "Select a1.* from TblCustomer a1"
        strqry += " Where FNameTH = '" & FnameTH & "' And LNameTH = '" & LNameTH & "'"
        Return strqry
    End Function

    Public Function TblCustomerCar(ByVal CarID As String) As String
        Dim strqry As String
        strqry = "Select * from TblCustomer a1"
        strqry += " Inner Join TblCar a2 on a1.CusID = a2.CusID"
        strqry += " Where a2.CarID = '" & CarID & "' "
        Return strqry
    End Function
#End Region

#Region "Update Assign"
    Public Function GVCusSourceTranfer(ByVal strCmd As String) As String
        Dim strqry As String
        strqry = "SELECT IdCar " & _
                " FROM TblCar " & _
                "WHERE " & strCmd
        Return strqry
    End Function

    Public Function GVCusSourceTranfer3(ByVal strCmd As String) As String
        Dim strqry As String
        strqry = "SELECT IdCar " & _
                " FROM TblCar a1 Inner Join TblUser a2 on a1.AssignTo = a2.userID " & _
                "WHERE " & strCmd
        Return strqry
    End Function

    Public Function UpdateCustomerAssign() As String
        Dim strqry As String
        strqry = "Update TblCar" & _
                " Set AssignTo = @AssignTo , AssCreateID=@AssCreateID,AssCreateDate=GetDate(),AssUpdateDate=GetDate(),CurStatus='1',CntStatus='0' " & _
                " Where IdCar=@IdCar  "
        Return strqry
    End Function

    Public Function UpdateCustomerAssign2() As String
        Dim strqry As String
        strqry = "Update TblCar" & _
                " Set AssignTo = @AssignTo ,AssUpdateDate=GetDate() " & _
                " Where IdCar=@IdCar  "
        Return strqry
    End Function
#End Region


End Class
