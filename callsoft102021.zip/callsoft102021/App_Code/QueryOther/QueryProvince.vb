﻿Imports Microsoft.VisualBasic

Public Class QueryProvince

    Public Function TblZipCodeBindDist(ByVal strProvinceID As String) As String
        Dim strsqy As String
        strsqy = "(SELECT distinct [Dist] FROM [TblZipcode]" & _
                 " Where Province = '" & strProvinceID & "') "

        Return strsqy
    End Function
    Public Function TblZipCodeBindSubDist(ByVal strDist As String, ByVal strProvinceID As String) As String
        Dim strsqy As String
        strsqy = "( SELECT distinct [SubDist] FROM [TblZipcode]" & _
                 " Where Dist= '" & strDist & "' and Province = '" & strProvinceID & "' )  "

        Return strsqy
    End Function

    Public Function TblZipCOdeBindZipCode(ByVal strSubDist As String, ByVal strProvince As String, ByVal strDist As String) As String

        Dim strqry As String
        strqry = "(SELECT distinct [ZipCode] FROM [TblZipcode]" & _
                 " Where SubDist= '" & strSubDist & "' AND Province='" & strProvince & "' and Dist ='" & strDist & "')  "

        Return strqry
    End Function

    'อาชีพ
    Public Function TblSubOccBind(ByVal OccID As String) As String

        Dim strqry As String
        strqry = "(Select 0 as OccSubID ,'[ไม่ระบุ]' as OccSubDescription) union (SELECT [OccSubID],[OccSubDescription] FROM [TblOccSub]" & _
                 " Where OccMainID = '" & OccID & "' )"

        Return strqry
    End Function

    'รถยนต์
    Public Function SelectCarBrand(ByVal strCarBrand As String) As String

        Dim strqry As String
        strqry = "(SELECT distinct [CarSeries]  FROM [TblCarBrand]" & _
                 " Where flag=2 and CarBrand= '" & strCarBrand & "' and carStatus = 1)  "
        Return strqry

    End Function

    Public Function SelectTblCarBrandType(ByVal strCarSERIES As String, ByVal model As String, ByVal strCarBrand As String, ByVal strCarYear As String, ByVal strCarType As String) As String
        Dim strqry As String

        'strqry = "SELECT a1.carSERIES,a1.CarType,a1.CarNo,a1.CarPrice,a1.CarGroup,CarTypeID,a2.CodeType "
        'strqry += " FROM [TblCarBrand] a1 "
        'strqry += " Inner Join Tbl_CarType a2 on a1.CarType = a2.CarNo"
        'strqry += " Where a1.carSERIES = '" & CarNo & "' and  a1.model='" & CarModel & "'"
        'Return strqry

        strqry = "SELECT  a1.carSERIES,a1.CarType,a1.CarNo,a1.CarPrice,a1.CarGroup,CarTypeID,a2.CodeType FROM [TblCarBrand] a1 Inner Join Tbl_CarType a2 on a1.CarType = a2.CarNo " & _
                 " Where a1.flag=2 and a1.CarBrand= '" & strCarBrand & "' and a1.carSERIES = '" & strCarSERIES & "' and a1.model = '" & model & "' and a1.CarType='" & strCarType & "'  and a1.caryear = '" & strCarYear & "' and a1.carStatus = 1  "
        Return strqry
    End Function

    Public Function SelectTblCarBrandTypeApp(ByVal CarNo As String, ByVal model As String) As String
        Dim strqry As String

        strqry = "SELECT a1.carSERIES,a1.CarType,a1.CarNo,a1.CarPrice,a1.CarGroup,CarTypeID,a2.CodeType "
        strqry += " FROM [TblCarBrand] a1 "
        strqry += " Inner Join Tbl_CarType a2 on a1.CarType = a2.CarNo"
        strqry += " Where a1.carSERIES = '" & CarNo & "' and  a1.model='" & model & "'"
        Return strqry


    End Function
    Public Function SelectTblCarBrandType1(ByVal CarNo As String, ByVal CarYear As String, ByVal CarModel As String) As String
        Dim strqry As String

        strqry = "SELECT a1.carSERIES,a1.CarType,a1.CarNo,a1.CarPrice,a1.CarGroup,CarTypeID,a2.CodeType,a1.price1 as CarPrice1 "
        strqry += " FROM [TblCarBrand] a1 "
        strqry += " Inner Join Tbl_CarType a2 on a1.CarType = a2.CarNo"
        strqry += " Where  a1.flag=2 and a1.carSERIES = '" & CarNo & "'"
        strqry += " and  a1.caryear = '" & CarYear & "'"
        strqry += " and  a1.model = '" & CarModel & "'"
        Return strqry

    End Function

    Public Function SelectCarYear(ByVal strCarBrand As String, ByVal strCarSERIES As String) As String

        Dim strqry As String
        strqry = "(SELECT distinct [caryear]  FROM [TblCarBrand]" & _
                 " Where flag=2 and CarBrand= '" & strCarBrand & "' and carSERIES = '" & strCarSERIES & "' and carStatus = 1)  "
        Return strqry

    End Function
    Public Function SelectCarModel(ByVal strCarBrand As String, ByVal strCarSERIES As String, ByVal strCarYear As String) As String

        Dim strqry As String
        strqry = "(SELECT distinct [model]  FROM [TblCarBrand]" & _
                 " Where flag=2 and CarBrand= '" & strCarBrand & "' and carSERIES = '" & strCarSERIES & "' and caryear = '" & strCarYear & "' and carStatus = 1)  "
        Return strqry

    End Function
    'SelectCarCarType
    Public Function SelectCarCarType(ByVal strCarBrand As String, ByVal strCarSERIES As String, ByVal strCarYear As String, ByVal model As String) As String

        Dim strqry As String
        strqry = "(SELECT distinct TblCarBrand.CarType as CarTypeID,TblInsur_CarType.Cartype   as CarTypeName FROM TblCarBrand inner join TblInsur_CarType on TblCarBrand.CarType=TblInsur_CarType.CarTypeID" & _
                 " Where TblCarBrand.flag=2 and TblCarBrand.CarBrand= '" & strCarBrand & "' and TblCarBrand.carSERIES = '" & strCarSERIES & "' and TblCarBrand.model = '" & model & "'  and TblCarBrand.caryear = '" & strCarYear & "' and TblCarBrand.carStatus = 1)  "
        Return strqry
  
    End Function

    Public Function SelectTblAreaDist(ByVal Province As String) As String
        Dim strqry As String
        strqry = "SELECT distinct [Dist] FROM [TblRiderArea]"
        strqry += " Where AreaStatus = 1 and Province = '" & Province & "'"
        strqry += " Order by Dist"
        Return strqry
    End Function

    Public Function SelectTblAreaSubDist(ByVal Dist As String, ByVal Province As String) As String
        Dim strqry As String
        strqry = "SELECT distinct [SubDist] FROM [TblRiderArea]"
        strqry += " Where AreaStatus = 1 and Province = '" & Province & "' and Dist = '" & Dist & "'"
        strqry += " Order by SubDist"
        Return strqry
    End Function

    Public Function SelectTblAreaRider(ByVal SubDist As String, ByVal Dist As String, ByVal Province As String) As String
        Dim strqry As String
        strqry = " SELECT distinct a2.tid,a2.tFNAME + ' ' + a2.tLNAME + '(' + a2.tNNAME + ')' as RiderName FROM [TblRiderArea] a1"
        strqry += " inner join TblRiderPhoto a2 on a1.tid = a2.tid"
        strqry += " Where a1.AreaStatus = 1 and a1.Province = '" & Province & "' and a1.Dist = '" & Dist & "' and a1.SubDist = '" & SubDist & "' "
        strqry += " Order by RiderName "
        Return strqry
    End Function

    Public Function SelectTblAreaRider2(ByVal SubDist As String, ByVal Dist As String, ByVal Province As String) As String
        Dim strqry As String
        strqry = "  SELECT distinct a2.tid,a2.tFNAME + ' ' + a2.tLNAME + '(' + a2.tNNAME + ')' as RiderName FROM [TblRiderArea] a1"
        strqry += " inner join TblRiderPhoto a2 on a1.tid = a2.tid"
        strqry += " Where a1.AreaStatus = 1 and a1.Province = '" & Province & "' and a1.Dist = '" & Dist & "' and a1.SubDist = '" & SubDist & "' "
        strqry += " Order by RiderName "
        Return strqry
    End Function


    Public Function SelectTblSubMainEdit(ByVal MainID As String) As String
        Dim strqry As String = ""
        strqry += "SELECT [SubMainEditDataId], [SubMainEditData] FROM [TblSubMainEditApp]"
        strqry += " Where MainEditDataID = " & MainID
        Return strqry
    End Function
End Class
