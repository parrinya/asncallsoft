﻿Imports Microsoft.VisualBasic

Public Class QueryNews
    Public Function TblNews() As String
        Dim strqry As String
        strqry = "Select * from TblNews order by datenew desc "
        Return strqry
    End Function
End Class
