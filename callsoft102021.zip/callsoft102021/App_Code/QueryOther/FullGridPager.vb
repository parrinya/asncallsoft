﻿Imports Microsoft.VisualBasic
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls

Namespace dpant
    Public Class FullGridPager
        Private Const DEFAULT_MAX_VISIBLE As Integer = 0
        Private Const DEFAULT_COUNTER_TEXT As String = "Test"
        Private Const DEFAULT_TOTAL_TEXT As String = "Test2"

        Protected maxVisiblePageNumbers As Integer
        Protected firstPageNumber As Integer
        Protected lastPageNumber As Integer
        Protected pageCounterText As String
        Protected pageCounterTotalText As String
        Protected theGrid As GridView
        Protected theGridViewRow As GridViewRow

        Public Sub New(ByVal TheGrid__1 As GridView)
            ' Default Constructor		
            maxVisiblePageNumbers = DEFAULT_MAX_VISIBLE
            pageCounterText = DEFAULT_COUNTER_TEXT
            pageCounterTotalText = DEFAULT_TOTAL_TEXT
            theGrid = TheGrid__1
        End Sub

        Public Sub New(ByVal TheGrid__1 As GridView, ByVal MaxVisible As Integer, ByVal CounterText As String, ByVal TotalText As String)
            ' Parameterized constructor
            maxVisiblePageNumbers = MaxVisible
            pageCounterText = CounterText
            pageCounterTotalText = TotalText
            theGrid = TheGrid__1
        End Sub

        Public Property MaxVisiblePageNumbers1() As Integer
            Get
                Return maxVisiblePageNumbers
            End Get
            Set(ByVal value As Integer)
                maxVisiblePageNumbers = value
            End Set
        End Property

        Public Property PageCounterText1() As String
            Get
                Return pageCounterText
            End Get
            Set(ByVal value As String)
                pageCounterText = value
            End Set
        End Property

        Public Property PageCounterTotalText1() As String
            Get
                Return pageCounterTotalText
            End Get
            Set(ByVal value As String)
                pageCounterTotalText = value
            End Set
        End Property

        Public ReadOnly Property TheGrid1() As GridView
            Get
                Return theGrid
            End Get
        End Property

        Public Sub CreateCustomPager(ByVal PagerRow As GridViewRow)
            ' Create custom pager inside the Grid's pagerTemplate.
            ' An html table is used to format the custom pager.

            ' No data to display.
            If PagerRow Is Nothing Then
                Return
            End If

            theGridViewRow = PagerRow

            Dim pagerInnerTable As HtmlTable = DirectCast(PagerRow.Cells(0).FindControl("pagerInnerTable"), HtmlTable)
            If pagerInnerTable IsNot Nothing Then
                ' default dynamic cell position. 
                ' (after the pageCount, the "First" and the "Previous" cells).            
                Dim insertCellPosition As Integer = 2
                If theGrid.PageIndex = 0 Then
                    ' The first page is currently displayed.
                    ' Hide First and Previous page navigation.
                    pagerInnerTable.Rows(0).Cells(1).Visible = False
                    pagerInnerTable.Rows(0).Cells(2).Visible = False
                    ' Change the default dynamic cell to 1.
                    insertCellPosition = 0
                End If

                CalcFirstPageNumber()
                CalcLastPageNumber()

                CreatePageNumbers(pagerInnerTable, insertCellPosition)

                Dim lastCellPosition As Integer = pagerInnerTable.Rows(0).Cells.Count - 1
                If theGrid.PageIndex = theGrid.PageCount - 1 Then
                    ' The last page is currently displayed.
                    ' Hide Next and Last page navigation.                
                    pagerInnerTable.Rows(0).Cells(lastCellPosition - 1).Visible = False
                    pagerInnerTable.Rows(0).Cells(lastCellPosition).Visible = False
                End If

                UpdatePageCounter(pagerInnerTable)
            End If
        End Sub

        Private Sub CreatePageNumbers(ByVal pagerInnerTable As HtmlTable, ByVal insertCellPosition As Integer)
            Dim i As Integer = firstPageNumber, pos As Integer = 1
            While i <= lastPageNumber
                ' Create a new table cell for every data page number.
                Dim tableCell As New HtmlTableCell()
                If theGrid.PageIndex = i - 1 Then
                    tableCell.Attributes.Add("class", "pageCurrentNumber")
                Else
                    tableCell.Attributes.Add("class", "pagePrevNextNumber")
                End If

                ' Create a new LinkButton for every data page number.
                Dim lnkPage As New LinkButton()
                lnkPage.ID = "Page" & i.ToString()
                lnkPage.Text = i.ToString()
                lnkPage.CommandName = "Page"
                lnkPage.CommandArgument = i.ToString()
                lnkPage.CssClass = "pagerLink"

                ' Place link inside the table cell; Add the cell to the table row.                
                tableCell.Controls.Add(lnkPage)
                pagerInnerTable.Rows(0).Cells.Insert(insertCellPosition + pos, tableCell)
                i += 1
                pos += 1
            End While
        End Sub

        Private Sub CalcFirstPageNumber()
            ' Calculate the first, visible page number of the pager.             
            firstPageNumber = 1
            If maxVisiblePageNumbers = DEFAULT_MAX_VISIBLE Then
                maxVisiblePageNumbers = theGrid.PageCount
            End If

            If theGrid.PageCount > maxVisiblePageNumbers Then
                ' Seperate page numbers in groups if necessary.
                If (theGrid.PageIndex + 1) > maxVisiblePageNumbers Then
                    ' Calculate the group to display.
                    ' Example: 
                    '      GridView1.PageCount = 12
                    '      maxVisiblePageNumbers = 4
                    '      GridView1.PageIndex+1 = 7
                    '      --> pageGroup = 2       (Page numbers: 5, 6, 7, 8)
                    Dim pageGroup As Decimal = Math.Ceiling(CDec(theGrid.PageIndex + 1) / maxVisiblePageNumbers)
                    ' Calculate the first page number for the group to display.
                    ' Example :
                    '      if pageGroup = 1 (Page numbers: 1,2,3,4) --> firstPageNumber = 1
                    '      if pageGroup = 2 (Page numbers: 5,6,7,8) --> firstPageNumber = 5
                    '      if pageGroup = 3 (Page numbers: 9,10,11,12) --> firstPageNumber = 9                        
                    firstPageNumber = CInt(Math.Truncate(1 + (maxVisiblePageNumbers * (pageGroup - 1))))
                End If
            End If
        End Sub

        Private Sub CalcLastPageNumber()
            ' Calculate the last, visible page number of the pager.
            lastPageNumber = theGrid.PageCount
            If maxVisiblePageNumbers = DEFAULT_MAX_VISIBLE Then
                maxVisiblePageNumbers = theGrid.PageCount
            End If

            If theGrid.PageCount > maxVisiblePageNumbers Then
                lastPageNumber = firstPageNumber + (maxVisiblePageNumbers - 1)
                If theGrid.PageCount < lastPageNumber Then
                    lastPageNumber = theGrid.PageCount
                End If
            End If
        End Sub

        Private Sub UpdatePageCounter(ByVal pagerInnerTable As HtmlTable)
            ' Display current page number and total number of pages.        
            Dim pageCounter As Label = DirectCast(pagerInnerTable.Rows(0).Cells(0).FindControl("lblPageCounter"), Label)
            pageCounter.Text = " " & pageCounterText & " " & (theGrid.PageIndex + 1).ToString() & " " & pageCounterTotalText & " " & theGrid.PageCount.ToString() & " "
        End Sub

        Public Sub PageGroups(ByVal PagerRow As GridViewRow)
            ' Display page groups in pager if GridView.PageCount is greater than the maxVisiblePageNumbers.

            ' No data to display.
            If PagerRow Is Nothing Then
                Return
            End If

            theGridViewRow = PagerRow

            Dim pagerOuterTable As HtmlTable = DirectCast(PagerRow.Cells(0).FindControl("pagerOuterTable"), HtmlTable)

            If maxVisiblePageNumbers = DEFAULT_MAX_VISIBLE Then
                maxVisiblePageNumbers = theGrid.PageCount
            End If

            Dim maxPageGroups As Integer = CInt(Math.Ceiling(CDec(theGrid.PageCount) / maxVisiblePageNumbers))
            If theGrid.PageCount > maxVisiblePageNumbers Then
                Dim lastCellPosition As Integer = pagerOuterTable.Rows(0).Cells.Count - 1
                Dim pageGroup As Decimal = Math.Ceiling(CDec(theGrid.PageIndex + 1) / maxVisiblePageNumbers)

                Dim ddlPageGroups As DropDownList = DirectCast(pagerOuterTable.Rows(0).Cells(lastCellPosition).FindControl("ddlPageGroups"), DropDownList)
                For pg As Integer = 1 To maxPageGroups
                    Dim groupFirstPageNumber As Integer = CInt(1 + (maxVisiblePageNumbers * (pg - 1)))
                    Dim groupLastPageNumber As Integer = groupFirstPageNumber + (maxVisiblePageNumbers - 1)
                    If theGrid.PageCount < groupLastPageNumber Then
                        groupLastPageNumber = theGrid.PageCount
                    End If
                    Dim group As String = [String].Format("{0} ... {1}", groupFirstPageNumber.ToString(), groupLastPageNumber.ToString())
                    Dim groupItem As New ListItem(group, groupFirstPageNumber.ToString())
                    If pageGroup = pg Then
                        groupItem.Selected = True
                    End If
                    ddlPageGroups.Items.Add(groupItem)
                Next
                ' Make the dropdownlist visible.
                pagerOuterTable.Rows(0).Cells(lastCellPosition).Visible = True
            End If
        End Sub

        Public Sub PageGroupChanged(ByVal PagerRow As GridViewRow)
            ' Change the page group.        
            If PagerRow IsNot Nothing Then
                Dim pagerOuterTable As HtmlTable = DirectCast(PagerRow.Cells(0).FindControl("pagerOuterTable"), HtmlTable)
                Dim lastCellPosition As Integer = pagerOuterTable.Rows(0).Cells.Count - 1
                Dim ddlPageGroups As DropDownList = DirectCast(pagerOuterTable.Rows(0).Cells(lastCellPosition).FindControl("ddlPageGroups"), DropDownList)
                Me.theGrid.PageIndex = Int32.Parse(ddlPageGroups.SelectedValue) - 1
            End If
        End Sub

    End Class
End Namespace

