﻿Imports Microsoft.VisualBasic

Public Class QueryChkLab
    Public Function chk_TblRewardTsr(ByVal userid As String, ByVal rewarddate As DateTime, ByVal typestatus As String) As String
        Dim strqry As String = ""
        strqry += " Select [Runno] from [TblRewardTsr]"
        strqry += " WHERE [Userid]= '" & userid & "'  and "
        strqry += " month(RewardDate) = month(convert(datetime, '" & rewarddate & "', 103)) and "
        strqry += " year(RewardDate)+543  = year(convert(datetime, '" & rewarddate & "', 103)) and "
        strqry += " Typereword  = '" & typestatus & "' "

        Return strqry
    End Function
End Class
