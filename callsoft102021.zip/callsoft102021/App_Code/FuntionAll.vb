﻿Imports Microsoft.VisualBasic
Imports System.Data
Public Class FuntionAll
    Dim dt As DataTable
    Dim DataAccess As New DataAccess
    'Get ค่าจาก Control
    Public Function ObjFindControl(ByVal ObjName As String, ByVal ObjFormView As Object) As Object
        Return DirectCast(ObjFormView.FindControl(ObjName), Object)
    End Function

    'ผูกค่ากลับ DropDown
    Public Sub ListDropDown(ByVal Oj As Object, ByVal QueryString As String, ByVal TextField As String, ByVal ValueField As String)
        Dim dt As New DataTable
        Dim da As New DataAccess
        dt = da.DataRead(QueryString)
        Oj.DataSource = dt
        Oj.DataTextField = TextField
        Oj.DataValueField = ValueField
        Oj.DataBind()
    End Sub

    'ผูกค่ากลับ DropDown
    Public Sub ListDropDownTM4(ByVal Oj As Object, ByVal QueryString As String, ByVal TextField As String, ByVal ValueField As String)
        Dim dt As New DataTable
        Dim da As New DataAccess
        dt = da.DataRead(QueryString)
        Oj.DataSource = dt
        Oj.DataTextField = TextField
        Oj.DataValueField = ValueField
        Oj.DataBind()
    End Sub

    'GetRefCar
    Public Function GetRefCar(ByVal IdCar As String) As String
        Dim d1, d2, d3, d4, d5, d6, dsum, dsel, dbPrime As Double
        Dim refNo As String
        Dim x, ranX As Integer
rEsTaRt:
        ranX = Int(Rnd() * 98) + 1
        dbPrime = CDbl(100001) + CDbl(ranX) + Int(Rnd() * IdCar)
        x = 1
linxx:
        If x = 5 Then dbPrime = CDbl(100001) + CDbl(Int(Rnd() * 98) + 1) * Int(Rnd() * 450000) : x = 1
        dbPrime = dbPrime - 1
        d1 = Left(dbPrime, 1)
        d2 = Mid(dbPrime, 2, 1)
        d3 = Mid(dbPrime, 3, 1)
        d4 = Mid(dbPrime, 4, 1)
        d5 = Mid(dbPrime, 5, 1)
        d6 = Right(dbPrime, 1)
        dsum = (d1 * d6) + (d2 * d3) + (d3 * d2) + (d4 * d5) + (d6 * d1)
        dsel = Right(dsum, 1)


        If CInt(Date.Today.Year + 543) > 2300 Then
            refNo = Right((Date.Today.Year + 543) - 543, 2) & Date.Today.ToString("MM") & dbPrime & dsel
        Else
            refNo = Date.Today.ToString("yyMM") & dbPrime & dsel
        End If

        refNo = Mid(refNo, 1, 11)
        refNo = GetDigit(refNo)

        If GetRefNo(refNo).Rows.Count > 0 Then
            x += 1
            GoTo linxx
        Else
            Return refNo
        End If

    End Function

    Protected Function GetRefNo(ByVal refNo As String) As DataTable
        Dim strqry As String = "Select * from TblCar Where RefNo = '" & refNo & "'"
        dt = New DataTable
        dt = DataAccess.DataRead(strqry)
        Return dt
    End Function

    Protected Function GetDigit(ByVal RefNo As String) As String
        Dim CompTax, custREF As String
        Dim sumDigit1, sumDigit2, sumDigit3 As Long
        Dim X, Y, Z As Integer

        CompTax = "3031815285"
        sumDigit1 = 0
        sumDigit2 = 0
        sumDigit3 = 0
        Y = 0
        Z = 0
        custREF = RefNo
        sumDigit1 = (5 * 3) + (8 * 0) + (3 * 3) + (5 * 1) + (8 * 8) + (3 * 1) + (5 * 5) + (8 * 2) + (3 * 8) + (5 * 5)

        For X = 1 To Len(custREF)
            Y = Y + 1
            Select Case Y
                Case 1 : Z = Mid(custREF, X, 1) : sumDigit2 = sumDigit2 + (Z * 8)
                Case 2 : Z = Mid(custREF, X, 1) : sumDigit2 = sumDigit2 + (Z * 3)
                Case 3 : Z = Mid(custREF, X, 1) : sumDigit2 = sumDigit2 + (Z * 5)
            End Select
            If Y = 3 Then Y = 0
        Next

        sumDigit3 = ((sumDigit1 + sumDigit2) * 7) Mod 100
        'MsgBox Len(Trim(sumDIGIT3))
        If Len(Trim(sumDigit3)) = 1 Then
            Return custREF & "0" & sumDigit3
        Else
            Return custREF & sumDigit3
        End If
    End Function

End Class
