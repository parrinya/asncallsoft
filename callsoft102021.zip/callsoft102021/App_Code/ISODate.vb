﻿Imports Microsoft.VisualBasic

Public Class ISODate

    Public Sub ISODate()

    End Sub

    Public Function SetISODate(ByVal cultrue As String, ByVal myDate As String) As String

        If myDate = "" Then
            Return SetISODate(cultrue, DateTime.Today.ToString("dd/MM/yyyy"))
        End If

        Dim result As String
        Dim tmp As String() = myDate.Split(New Char() {"/"c})
        Dim tmpY As Integer = 0
        'if (Convert.ToInt32(tmp[0]) < 10)
        '{
        ' tmp[0] = 0 + tmp[0];
        '}
        'if (Convert.ToInt32(tmp[1]) < 10)
        '{
        ' tmp[1] = 0 + tmp[1];
        '}
        tmpY = Convert.ToInt32(tmp(2))
        result = ((tmpY.ToString() & "/") + tmp(1) & "/") + tmp(0)

        Dim YearEn As Integer = Convert.ToInt32(DateTime.Now.Year)
        If cultrue = "th" Then
            If tmpY <= 2300 AndAlso tmpY >= 1900 Then
                tmpY = tmpY + 543
            End If
            result = ((tmpY.ToString() & "/") + tmp(1) & "/") + tmp(0)
        ElseIf cultrue = "en" Then
            If tmpY >= 2300 Then
                tmpY = tmpY - 543
            End If
            result = ((tmpY & "/") + tmp(1) & "/") + tmp(0)
        End If

        Return result
    End Function

    Public Function SetISODateAddYear(ByVal cultrue As String, ByVal myDate As String, ByVal Years As Integer) As String

        If myDate = "" Then
            Return ""
        End If

        Dim result As String
        Dim tmp As String() = myDate.Split(New Char() {"/"c})
        Dim tmpY As Integer = 0
        'if (Convert.ToInt32(tmp[0]) < 10)
        '{
        ' tmp[0] = 0 + tmp[0];
        '}
        'if (Convert.ToInt32(tmp[1]) < 10)
        '{
        ' tmp[1] = 0 + tmp[1];
        '}
        tmpY = Convert.ToInt32(tmp(2)) + Years
        result = ((tmpY.ToString() & "/") + tmp(1) & "/") + tmp(0)

        Dim YearEn As Integer = Convert.ToInt32(DateTime.Now.Year)
   
        If cultrue = "th" Then
            If tmpY <= 2300 AndAlso tmpY >= 1900 Then
                tmpY = tmpY + 543
            End If
            result = ((tmpY.ToString() & "/") + tmp(1) & "/") + tmp(0)
        ElseIf cultrue = "en" Then
            If tmpY >= 2300 Then
                tmpY = tmpY - 543
            End If
            result = ((tmpY & "/") + tmp(1) & "/") + tmp(0)
        End If

        Return result
    End Function
End Class
