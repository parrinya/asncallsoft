﻿Imports Microsoft.VisualBasic
Imports System.Data.SqlClient
Imports System.Data
Imports System.Text.RegularExpressions

Public Class ChkLogin
    Dim DataAccess As New DataAccess
    Public Function ChkTimeLogin() As Boolean
        If DateTime.Now.ToString("HH:mm") >= "08:00" And DateTime.Now.ToString("HH:mm") <= "21:30" And DateTime.Now.DayOfWeek <> DayOfWeek.Sunday Then
            Return True
        Else
            Return False
        End If
    End Function
    Public Sub UserLogOut(ByVal userID As String, ByVal IPLogin As String)
        Dim Conn As SqlConnection
        Dim com As SqlCommand
        Dim strConn = ConfigurationManager.ConnectionStrings("asnbroker").ConnectionString
        Conn = New SqlConnection()
        With Conn
            If .State = ConnectionState.Open Then .Close()
            .ConnectionString = strConn
            .Open()
        End With
        Dim strqry As String = "INSERT INTO TblLoginUser (UserID,IPLogin,TypeIO) VALUES (@UserID,@IPLogin,@TypeIO) "
        com = New SqlCommand(strqry, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@IPLogin", SqlDbType.VarChar).Value = IPLogin
            .Parameters.Add("@UserID", SqlDbType.VarChar).Value = userID
            .Parameters.Add("@TypeIO", SqlDbType.Char).Value = "O"
            .ExecuteNonQuery()
        End With
    End Sub
    Public Sub UpdateUserOnline(ByVal userID As String, ByVal IsLogon As String)
        Dim Conn As SqlConnection
        Dim com As SqlCommand
        Dim strConn = ConfigurationManager.ConnectionStrings("asnbroker").ConnectionString
        Conn = New SqlConnection()
        With Conn
            If .State = ConnectionState.Open Then .Close()
            .ConnectionString = strConn
            .Open()
        End With

        Dim strqry As String = "Update TblUser set IsLogon = @IsLogon ,LastAccess =GetDate() Where UserID = @UserID"
        com = New SqlCommand(strqry, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@IsLogon", SqlDbType.VarChar).Value = IsLogon
            .Parameters.Add("@userID", SqlDbType.VarChar).Value = userID
            .ExecuteNonQuery()
        End With

       

    End Sub
    Public Sub UpdateipUser(ByVal userID As String, ByVal IpUser As String)
        Dim Conn As SqlConnection
        Dim com As SqlCommand
        Dim strConn = ConfigurationManager.ConnectionStrings("asnbroker").ConnectionString
        Conn = New SqlConnection()
        With Conn
            If .State = ConnectionState.Open Then .Close()
            .ConnectionString = strConn
            .Open()
        End With

        Dim strqry As String = "Update TblUser set ipTSR = @ipTSR  Where UserID = @UserID"
        com = New SqlCommand(strqry, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@ipTSR", SqlDbType.VarChar).Value = IpUser
            .Parameters.Add("@userID", SqlDbType.VarChar).Value = userID
            .ExecuteNonQuery()
        End With

    End Sub


    Public Sub UpdateUserOnlineTime(ByVal userID As String)
        Dim Conn As SqlConnection
        Dim com As SqlCommand
        Dim strConn = ConfigurationManager.ConnectionStrings("asnbroker").ConnectionString
        Conn = New SqlConnection()
        With Conn
            If .State = ConnectionState.Open Then .Close()
            .ConnectionString = strConn
            .Open()
        End With

        Dim strqry As String = "Update TblUser set LastAccess = GetDate() Where UserID = @UserID"
        com = New SqlCommand(strqry, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@userID", SqlDbType.VarChar).Value = userID
            .ExecuteNonQuery()
        End With

    End Sub

    Public Function ChkTimeAccess(ByVal userID As String) As Boolean
        Dim strqry As String = ""
        strqry += " select "
        strqry += " datediff( minute,lastaccess,getdate()) as lastLogonDate"
        strqry += " , case when datediff( minute,lastaccess,getdate()) > 30 then 'False' else 'True' end as lastLogon"
        strqry += " from tbluser"
        strqry += " where userID = " & userID

        Dim dt As New DataTable
        dt = DataAccess.DataRead(strqry)
        Return dt.Rows(0).Item("lastLogon")
    End Function
    'Log เมื่อ Log in ระบบไม่ถูกต้องเกินที่กำหนด
    Public Sub UpdateUserCancel(ByVal userID As String)
        Dim Conn As SqlConnection
        Dim com As SqlCommand
        Dim strConn = ConfigurationManager.ConnectionStrings("asnbroker").ConnectionString
        Conn = New SqlConnection()
        With Conn
            If .State = ConnectionState.Open Then .Close()
            .ConnectionString = strConn
            .Open()
        End With

        Dim strqry As String = "Update TblUser set userstatus = 2  Where UserID = @UserID and userstatus =1"
        com = New SqlCommand(strqry, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@UserID", SqlDbType.VarChar).Value = userID
            .ExecuteNonQuery()
        End With
    End Sub
    Public Sub InsertTblLog_LoginFailure(ByVal userID As String, ByVal ip As String)
        Dim Conn As SqlConnection
        Dim com As SqlCommand
        Dim strConn = ConfigurationManager.ConnectionStrings("asnbroker").ConnectionString
        Conn = New SqlConnection()
        With Conn
            If .State = ConnectionState.Open Then .Close()
            .ConnectionString = strConn
            .Open()
        End With

        Dim strqry As String = "INSERT INTO TblLog_LoginFailure (userID,Iplogin,Cratedate) VALUES(@UserID,@IP,getdate())"

        com = New SqlCommand(strqry, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@UserID", SqlDbType.VarChar).Value = userID
            .Parameters.Add("@IP", SqlDbType.VarChar).Value = ip
            .ExecuteNonQuery()
        End With
    End Sub
    Public Function CheckFormat(ByVal txtPassword As String) As ArrayList
        Dim strRegularPattern As String = "^(?=.*[a-zA-Z])(?=.*\d)(?=.*[!@#\$%\^&\*\(\)])[A-Za-z\d!@#\$%\^&\*\(\)]{6,16}"
        Dim ArrStr As New ArrayList
        If Regex.IsMatch(txtPassword, strRegularPattern) = False Then
             ArrStr.Add("- รหัสผ่านต้องประกอบตัวอักษร ตัวเลข ตัวอักขระพิเศษ(ได้แก้ !,@,#,%,^,&,*,(,))")
        End If
        If txtPassword.Trim.Length < 6 Or txtPassword.Trim.Length > 16 Then
            ArrStr.Add("- รหัสผ่านต้องมีความยาวไม่น้อยกว่า 6 ตัวอักษร")
        End If
        Return ArrStr
    End Function
    ''add by na 20150331 Edit 20171221
    'Public Function CheckFormat(ByVal txtPassword As String) As Boolean
    '    'Dim strRegularPattern As String = "(?!^[0-9]*$)(?!^[a-zA-Z]*$)^([a-zA-Z0-9]{6,8})$"
    '    Dim strRegularPattern As String = "^(?=.*[a-zA-Z])(?=.*\d)(?=.*[!@#\$%\^&\*\(\)])[A-Za-z\d!@#\$%\^&\*\(\)]{6,16}"
    '    If Regex.IsMatch(txtPassword, strRegularPattern) Then
    '        Return True
    '    Else
    '        Return False
    '    End If
    'End Function
    'Public Function CheckPassword(ByVal txtPassword As String) As Boolean
    '    If txtPassword.Length < 6 Or txtPassword.Length > 16 Then
    '        Return False
    '    Else
    '        Return True
    '    End If
    'End Function
    ''End add by na 20150331 Edit 20171221
End Class
