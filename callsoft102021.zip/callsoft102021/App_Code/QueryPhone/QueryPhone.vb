﻿Imports Microsoft.VisualBasic

Public Class QueryPhone
    'สำหรับดึงหมายเหตุการโทร
    Public Function BindTblSubStatus(ByVal StatusID As String) As String
        Dim strqry As String = ""

        strqry = "(Select a1.SubStatusID,a1.SubStatusName from TblSubStatus a1 Where a1.ValidSubStatus = 1 And a1.StatusID = " & StatusID
        strqry += " )"
        Return strqry
    End Function

    'สำหรับดึง AppPhotosมาตรวจสอบ
    Public Function BindTblAppointTakephoto(ByVal IdCar As String) As String
        Dim strqry As String = ""

        strqry = "Select Top 1  * from TblAppointTakePhoto where IdCar = " & IdCar
        Return strqry
    End Function

#Region "Update"

    Public Function UpdateTblCustomer(ByVal UpdateID As Integer) As String
        Dim strqry As String = ""

        strqry = "UPDATE       TblCustomer"
        strqry += " SET "
        If UpdateID = 1 Then
            strqry += "  Tel = @Tel"
            strqry += " , TelExt = @TelExt"
        ElseIf UpdateID = 2 Then
            strqry += "  OTel = @OTel"
            strqry += " , OTelExt = @OTelExt"
        ElseIf UpdateID = 4 Then
            strqry += "  OthTel1 = @OthTel1"
            strqry += " ,  OthTel1Ext = @OthTel1Ext"
        ElseIf UpdateID = 3 Then
            strqry += "  Fax = @Fax"
        ElseIf UpdateID = 5 Then
            strqry += "  Mobile = @Mobile"
        ElseIf UpdateID = 6 Then
            strqry += "  FNameTH = @FNameTH"
            strqry += " , LNameTH = @LNameTH"
        ElseIf UpdateID = 7 Then
            strqry += "  Email = @Email"
        ElseIf UpdateID = 8 Then
            strqry += "  OthTel2 = @OthTel2"
            strqry += " ,OthTel2Ext=@OthTel2Ext"
        End If

        strqry += " Where CusID = @CusID"
        Return strqry
    End Function


    Public Function UpdateCus() As String
        Dim strqry As String
        strqry = "UPDATE    TblCar"
        strqry += "  SET      AppointDate = @AppointDate"
        strqry += " , CurStatus = @CurStatus"
        strqry += " , CntStatus = @CntStatus"
        strqry += " , Comments = @Comments"
        strqry += " ,UpdateDate = GetDate()"
        strqry += " ,UpdateID=@UpdateID "
        strqry += " ,IsAppoint = @IsAppoint "
        strqry += " ,RefNo=@RefNo"
        strqry += " ,CallDate=Getdate()"
        strqry += " ,IsNew=case CurStatus when 1 then 1 else 0 end"
        strqry += " ,Flag_AppointDate=@Flag_AppointDate"
        strqry += " WHERE IDCar=@IDCar"

        Return strqry
    End Function

    Public Function UpdateApp() As String
        Dim strqry As String
        strqry = "UPDATE    TblApplication"
        strqry += "  SET      SuccessDate = GetDate(),StatusQc=0,userIDQc=@userIDQc,AppIP=@AppIP,CreateID=@userID,typetsr=@TypeTsr "
        strqry += " Where AppID=@AppID"

        Return strqry
    End Function

    Public Function UpdateAppTakePhoto() As String
        Dim strqry As String
        strqry = "UPDATE    TblApplication"
        strqry += "  SET      TakePhoto = 1 Where AppID=@AppID"

        Return strqry
    End Function


#End Region

#Region "Insert"
    Public Function SaveTblCall() As String
        Dim strqry As String
        strqry = "INSERT INTO TblCall" & _
                " (CarID, IsOutbound, CallOrder, SubStatusID, CntSubStatus, CallDetail, StartTime, EndTime, CreateID, CreateDate, UpdateID, UpdateDate, StatusID, IsNew,telNUMBER,perCloseApp) " & _
                "  VALUES     (@CarID,@IsOutbound,@CallOrder,@SubStatusID,@CntSubStatus,@CallDetail,@StartTime,GetDate(),@CreateID,GetDate(),@UpdateID,GetDate(),@StatusID,@IsNew,@telNUMBER,@perCloseApp)"

        Return strqry


    End Function
    Public Function InsertTblTakePhoto() As String
        Dim strqry As String
        strqry = "INSERT INTO TblTakePhoto   (CusID, idCAR, appID, phID, tID, createID, createDATE, appointDATE, appointCOMMENT, provinceDEST, mainDEST, Destination)"
        strqry += " VALUES        (@CusID,@idCAR,@appID,@phID,@tID,@createID, GETDATE(),@appointDATE,@appointCOMMENT,@provinceDEST,@mainDEST,@Destination)"
        Return strqry
    End Function
#End Region

#Region "Case.aspx"
    Public Function SelectBindAppointDate(ByVal date1 As String, ByVal date2 As String) As String
        Dim strqry As String = ""
        strqry += " select a1.FNameTH "
        strqry += " ,a1.LNameTH"
        strqry += " ,a3.StatusName"
        strqry += " ,a2.CarID"
        strqry += " ,a2.IdCar"
        strqry += " ,a1.CusID"
        strqry += " ,'ShowHistory(' + Convert(VarChar,a2.IdCar) + ')' as ShowHistory"
        strqry += " , DateDiff(day,GetDate(), case "
        strqry += " when datediff(year,a2.carbuydate,getdate()) <= 0 then a2.carbuydate "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 1 then dateadd(year,1,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 2 then dateadd(year,2,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 3 then dateadd(year,3,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 4 then dateadd(year,4,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 5 then dateadd(year,5,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 6 then dateadd(year,6,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 7 then dateadd(year,7,a2.carbuydate)"
        strqry += " when datediff(year,a2.carbuydate,getdate()) > 7 then dateadd(year,8,a2.carbuydate)"
        strqry += " end ) as ExpProtect"
        strqry += " , case "
        strqry += " when datediff(year,a2.carbuydate,getdate()) <= 0 then a2.carbuydate "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 1 then dateadd(year,1,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 2 then dateadd(year,2,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 3 then dateadd(year,3,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 4 then dateadd(year,4,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 5 then dateadd(year,5,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 6 then dateadd(year,6,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 7 then dateadd(year,7,a2.carbuydate)"
        strqry += " when datediff(year,a2.carbuydate,getdate()) > 7 then dateadd(year,8,a2.carbuydate)"
        strqry += " end  as ProtectDate"
        strqry += " ,a3.SortID"
        strqry += " ,a3.StatusID"
        strqry += " ,case when Datediff(day,GetDate(),a2.AppointDate) = 0 and a2.AppointDate < GetDate() then 1 when a3.StatusID = 1 then 1 else 0 end as GetStatus"
        strqry += " ,case a3.StatusID when 1 then null else a2.AppointDate end as AppointDate"
        strqry += " ,case a3.StatusID when 1 then null else a2.UpdateDate end as UpdateDate"
        strqry += " ,case a3.StatusID when 1 then null else a2.Comments end as Comments"
        strqry += " ,case a3.StatusID when 1 then 1 else 0 end as IsNew"
        strqry += " from TblCustomer a1"
        strqry += " Inner Join TblCar a2 on a1.CusID = a2.CusID"
        strqry += " Inner Join TblStatus a3 on a2.CurStatus = a3.StatusID"
        strqry += " where a2.AssignTo = @userID"
        strqry += " and (a2.CurStatus in (6,7,8,25,26))  "
        strqry += " and  Convert(VarChar(10),a2.AppointDate,111) between '" & date1 & "' and '" & date2 & "'"
        Return strqry
    End Function

    Public Function SelectBindAppointDateAll() As String
        Dim strqry As String = ""
        strqry += " select a1.FNameTH "
        strqry += " ,a1.LNameTH"
        strqry += " ,a3.StatusName"
        strqry += " ,a2.CarID"
        strqry += " ,a2.IdCar"
        strqry += " ,a1.CusID"
        strqry += " ,'ShowHistory(' + Convert(VarChar,a2.IdCar) + ')' as ShowHistory"
        strqry += " , DateDiff(day,GetDate(), case "
        strqry += " when datediff(year,a2.carbuydate,getdate()) <= 0 then a2.carbuydate "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 1 then dateadd(year,1,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 2 then dateadd(year,2,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 3 then dateadd(year,3,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 4 then dateadd(year,4,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 5 then dateadd(year,5,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 6 then dateadd(year,6,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 7 then dateadd(year,7,a2.carbuydate)"
        strqry += " when datediff(year,a2.carbuydate,getdate()) > 7 then dateadd(year,8,a2.carbuydate)"
        strqry += " end ) as ExpProtect"
        strqry += " , case "
        strqry += " when datediff(year,a2.carbuydate,getdate()) <= 0 then a2.carbuydate "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 1 then dateadd(year,1,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 2 then dateadd(year,2,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 3 then dateadd(year,3,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 4 then dateadd(year,4,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 5 then dateadd(year,5,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 6 then dateadd(year,6,a2.carbuydate) "
        strqry += " when datediff(year,a2.carbuydate,getdate()) = 7 then dateadd(year,7,a2.carbuydate)"
        strqry += " when datediff(year,a2.carbuydate,getdate()) > 7 then dateadd(year,8,a2.carbuydate)"
        strqry += " end  as ProtectDate"
        strqry += " ,a3.SortID"
        strqry += " ,a3.StatusID"
        strqry += " ,case when Datediff(day,GetDate(),a2.AppointDate) = 0 and a2.AppointDate < GetDate() then 1 when a3.StatusID = 1 then 1 else 0 end as GetStatus"
        strqry += " ,case a3.StatusID when 1 then null else a2.AppointDate end as AppointDate"
        strqry += " ,case a3.StatusID when 1 then null else a2.UpdateDate end as UpdateDate"
        strqry += " ,case a3.StatusID when 1 then null else a2.Comments end as Comments"
        strqry += " ,case a3.StatusID when 1 then 1 else 0 end as IsNew"
        strqry += " from TblCustomer a1"
        strqry += " Inner Join TblCar a2 on a1.CusID = a2.CusID"
        strqry += " Inner Join TblStatus a3 on a2.CurStatus = a3.StatusID"
        strqry += " where a2.AssignTo = @userID"
        strqry += " and (a2.CurStatus in (6,7,8,25,26))  "
        strqry += " and a2.AppointDate <= GetDate()"
        Return strqry
    End Function
#End Region
    Public Function SelectUserQc(ByVal strUserGroup As String) As String
        Dim strqry As String = ""
        strqry += "  select  a.useridqc as useridqc from tbl_LogAssignSaleQc a "
        strqry += "  left join tbluser b on a.useridqc = b.userid  where b.userlevelid = 8 "
        strqry += "  And b.UserStatus = 1 and b.IsLogon = 1 "
        strqry += "  and b.usergroup = " & strUserGroup
        strqry += "  order by a.createDate asc "
        Return strqry
    End Function

    Public Function SelectTblApppay(ByVal AppID As String) As String
        Dim strqry As String = ""
        strqry += " Select a1.TypePay,a1.AppID from TblAppPay a1 Where a1.PayID=1 and a1.AppID =" & AppID
        Return strqry
    End Function
    Public Function SelectTblTypetsr(ByVal AppID As String) As String
        Dim strqry As String = ""
        strqry += " Select a3.TypeTsr as TypeTsr "
        strqry += " from tblapplication  a1 "
        strqry += " inner join TblCar a2 on a2.Idcar=a1.IdCar"
        strqry += " Inner Join TblUser a3 on a3.UserID=a2.AssignTo"
        strqry += " Where a1.AppID =" & AppID
        Return strqry
    End Function


    Public Function SelectTblProduct(ByVal ProID As String) As String
        Dim strqry As String = ""
        strqry += " SELECT StatusPhoto  from Tbl_ProductType"
        strqry += " where ProTypeID = " & ProID

        Return strqry
    End Function
    Public Function UpdateTblCustomer() As String
        Dim strqry As String = ""

        strqry = "UPDATE       TblCustomer"
        strqry += " SET "

        strqry += "   Tel = @Tel"
        strqry += " , TelExt = @TelExt"
        strqry += " , OTel = @OTel"
        strqry += " , OTelExt = @OTelExt"
        strqry += " , OthTel1 = @OthTel1"
        strqry += " , OthTel1Ext = @OthTel1Ext"
        strqry += " , Fax = @Fax"
        strqry += " , Mobile = @Mobile"
        strqry += " , Email = @Email"
        strqry += " , OthTel2 = @OthTel2"
        strqry += " , OthTel2Ext=@OthTel2Ext"


        strqry += " Where CusID = @CusID"
        Return strqry
    End Function
End Class
