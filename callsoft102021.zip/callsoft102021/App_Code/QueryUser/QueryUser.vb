﻿Imports Microsoft.VisualBasic

Public Class QueryUser

    Public Function LoginUser(ByVal username As String, ByVal password As String) As String
        Dim strqry As String
        strqry = "SELECT a1.* " & _
                    "FROM TblUser a1 " & _
                      "Left join TblUser a2 on a1.LeaderID = a2.UserID " & _
                      "Left join TblUser a3 on a1.SupID = a3.UserID " & _
                      "WHERE a1.userstatus=1 and a1.UserName = '" & username & "' "

        '" AND a1.UserPassword = '" & password & "' " & _
        Return strqry
    End Function

    Public Function UpdateTblUserLogin(ByVal statuslogin As String, ByVal userid As String) As String
        Dim strqry As String
        strqry = " Update tbluser "
        strqry += " set loginSTATUS= " & statuslogin
        strqry += " where userID=" & userid
        Return strqry
    End Function

    Public Function InsertTblUserLogIP() As String
        Dim strqry As String
        strqry = "INSERT INTO TblUserLogHome (userID, ComIP, ComName, ComMacAddr, ComLoginDate)"
        strqry += " VALUES        (@userID,@ComIP,@ComName,@ComMacAddr, GETDATE())"
        Return strqry
    End Function

    Public Function InsertTblUserLogIn() As String
        Dim strqry As String
        strqry = "INSERT INTO TblLoginUser (UserID,IPLogin,TypeIO)"
        strqry += " VALUES  (@UserID,@IPLogin,@TypeIO)"
        Return strqry
    End Function

    Public Function InsertTblUserLogIn2() As String
        Dim strqry As String
        strqry = "INSERT INTO TblLogUserLogin (UserID,ip)"
        strqry += " VALUES  (@UserID,@IPLogin)"
        Return strqry
    End Function

    Public Function SelectTblUserLogIn(ByVal userID As String) As String
        Dim strqry As String
        strqry = "Select top 1 * from TblLoginUser"
        strqry += " Where Convert(VarChar,LoginDate,112) =  Convert(VarChar,GetDate(),112) and userID = " & userID
        Return strqry
    End Function

#Region "Update/Insert TblUser"
    Public Function UpdateTsr() As String
        Dim strqry As String = ""
        strqry += " UPDATE       TblUser"
        strqry += " SET                UserName = @UserName"
        strqry += " , UserPassword = @UserPassword"
        strqry += " , FName = @FName"
        strqry += " , LName = @LName"
        strqry += " , NName = @NName"
        strqry += " , UserLevelID = @UserLevelID"
        strqry += " ,  SupID = @SupID"
        strqry += " , UserStatus = @UserStatus"
        strqry += " , UpdateID = @UpdateID"
        strqry += " , UpdateDate = GETDATE()"
        strqry += " , Extension = @Extension"
        strqry += " , TargetSale=@TargetSale"
        strqry += " , WorkingDay=@WorkingDay"
        strqry += " Where UserID = @UserID"

        Return strqry
    End Function

    Public Function UpdateExtention() As String
        Dim strqry As String = ""
        strqry += " UPDATE TblExtentionHomeAgent"
        strqry += " Set UserID=@UserID"
        strqry += " "
        strqry += " Where ExtenNo = @ExtenNo"

        Return strqry
    End Function

    Public Function InsertTblError(ByVal Modulew As String, ByVal Error_Date As DateTime, ByVal Error_In As String, ByVal Error_Message As String, ByVal CreateID As String) As String
        Dim strqry As String
        strqry = "INSERT INTO TblLogError (Module,Error_Date,Error_In,Error_Message,CreateID)"
        strqry += " VALUES  ('" + Modulew + "',getDate(),'" + Error_In + "','" + Error_Message + "','" + CreateID + "')"
        Return strqry
    End Function

    Public Function InsertTsr() As String
        Dim strqry As String = ""
        strqry += " INSERT INTO TblUser  (UserName, UserPassword, FName, LName, NName, UserLevelID, LeaderID, SupID, UserStatus, CreateID, CreateDate, UpdateID, UpdateDate, TypeTsr, Extension,IsLogon,TargetSale,WorkingDay)"
        strqry += " VALUES        (@UserName,@UserPassword,@FName,@LName,@NName,@UserLevelID,0,@SupID,@UserStatus,@UpdateID, GETDATE(),@UpdateID, GETDATE(),    4,@Extension,0,@TargetSale,@WorkingDay)"

        Return strqry
    End Function
#End Region


End Class
