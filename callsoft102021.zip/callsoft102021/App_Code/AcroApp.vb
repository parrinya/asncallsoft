﻿Imports Microsoft.VisualBasic

Namespace Acrobat
    Public Class AcroApp

        Sub Open(p1 As Object)
            Throw New NotImplementedException
        End Sub

        Function OpenAVDoc(p1 As String) As AcroApp
            Throw New NotImplementedException
        End Function

        Sub Hide()
            Throw New NotImplementedException
        End Sub

        Function GetJSObject() As Object
            Throw New NotImplementedException
        End Function

        Sub Close()
            Throw New NotImplementedException
        End Sub

        Sub CloseAllDocs()
            Throw New NotImplementedException
        End Sub

    End Class
End Namespace
