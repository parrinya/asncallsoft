﻿Imports Microsoft.VisualBasic

Public Class QueryApplication
    Public Function UpdateTblcar() As String
        Dim strqry As String = ""
        strqry += " UPDATE       TblCar"
        strqry += " SET                CarDriverNo = @CarDriverNo"
        strqry += " , CarDriver1 = @CarDriver1"
        strqry += " , CarDriverLname1 = @CarDriverLname1"
        strqry += " , CarDriverBorn1 = @CarDriverBorn1"
        strqry += " , CarDriver2 = @CarDriver2"
        strqry += " , CarDriverLname2 = @CarDriverLname2"
        strqry += " , CarDriverBorn2 = @CarDriverBorn2"
        strqry += " , DBornNO1 = @DBornNO1"
        strqry += " , DBornDate1 = @DBornDate1"
        strqry += " , DBornAddr1 = @DBornAddr1"
        strqry += " , DBornNO2 = @DBornNO2"
        strqry += " , DBornDate2 = @DBornDate2"
        strqry += " , DBornAddr2 = @DBornAddr2"
        strqry += " , CarID = Replace(case @CarID1 when 'ป้ายแดง' then 'ป้ายแดง' else Replace(@CarID,'-','')+@CarID1 end,' ','')"
        strqry += " , CarNo = @CarNo"
        strqry += " , CarBoxNo = @CarBoxNo"
        strqry += " , CarSize = @CarSize"
        strqry += " , IDCard1 = @IDCard1"
        strqry += " , IDCard2 = @IDCard2"
        strqry += " , CarFixIn = @CarFixIn"
        strqry += " , CarBuyDate = @ProtectDate"
        strqry += " , CarYear=@CarYear"

        strqry += " , CarColorID=@CarColorID"
        strqry += " WHERE        (IdCar = @IdCar) "
        Return strqry
    End Function

    Public Function InsertTblApplication() As String
        Dim strqry As String = ""
        strqry += " INSERT INTO TblApplication"
        strqry += "  (Idcar, cusid, ProDuctID, ProDuctIDCarpet, IsProtect, ProtectDate, ExpProtectDate, ProPrice, IsProvalue, ProValue, Typeprovalue, IsCarpet, CarPet, "
        strqry += " YearPay, Lost_Life1, Lost_Life2, Lost_Prop1, Lost_Prop2, Lost_Car1, Lost_Car2, Car_Fire, Acc_Lost1, Acc_Lost2, Acc_Lost3, Acc_Lost4, Maintain, Insure, "
        strqry += "  Old_Insu, Old_PolicyNO, Apprela, CarpetValue, Carpetvat, ProtectDateCarpet, ExpProtectDateCarpet,CreateID,DiscountProfile,UpdateID,CreateDate,UpdateDate,Comments,AppComment,PkgID"
        strqry += " ,Doc1,Doc2,Doc3,Doc5,Doc5Comment,DisCountType,chkDeviceAdd,detDeviceAdd,PriceDeviceAdd,SendDoc,protectChk,FlagSendLINE1,flagsend,Premium,flagDiscCamera)"

        strqry += " VALUES  (@Idcar,@cusid,@ProDuctID,@ProDuctIDCarpet,@IsProtect,@ProtectDate,@ExpProtectDate,@ProPrice,@IsProvalue,@ProValue,@Typeprovalue"
        strqry += " ,@IsCarpet,@CarPet,@YearPay,@Lost_Life1,@Lost_Life2,@Lost_Prop1,@Lost_Prop2,@Lost_Car1,@Lost_Car2,@Car_Fire,@Acc_Lost1,@Acc_Lost2,@Acc_Lost3,@Acc_Lost4,@Maintain,@Insure"
        strqry += " ,@Old_Insu,@Old_PolicyNO,@Apprela,@CarpetValue,@Carpetvat,@ProtectDateCarpet,@ExpProtectDateCarpet,@userID,@DiscountProfile,@userID,GetDate(),GetDate(),@Comments,@AppComment,@PkgID"
        strqry += " ,@Doc1,@Doc2,@Doc3,@Doc5,@Doc5Comment,@DisCountType,@chkDeviceAdd,@detDeviceAdd,@PriceDeviceAdd,@SendDoc,@protectChk,@FlagSendLINE,@flagsend,@Premium,@flagDiscCamera)"

        Return strqry
    End Function

    Public Function UpdateTblApplication() As String
        Dim strqry As String = ""
        strqry += " UPDATE       TblApplication"
        strqry += " SET                Idcar = @Idcar"
        strqry += " , cusid = @cusid"
        strqry += " , ProDuctID = @ProDuctID"
        strqry += " , ProDuctIDCarpet = @ProDuctIDCarpet"
        strqry += " , IsProtect = @IsProtect"
        strqry += " , ProtectDate = @ProtectDate"
        strqry += " , ExpProtectDate = @ExpProtectDate"
        strqry += " , ProPrice = @ProPrice"
        strqry += " , IsProvalue = @IsProvalue"
        strqry += " , ProValue = @ProValue"
        strqry += " , Typeprovalue = @Typeprovalue"
        strqry += " , IsCarpet = @IsCarpet"
        strqry += " , CarPet = @CarPet"
        strqry += " , YearPay = @YearPay"
        strqry += " , Lost_Life1 = @Lost_Life1"
        strqry += " , Lost_Life2 = @Lost_Life2"
        strqry += " , Lost_Prop1 = @Lost_Prop1"
        strqry += " , Lost_Prop2 = @Lost_Prop2"
        strqry += " , Lost_Car1 = @Lost_Car1"
        strqry += " , Lost_Car2 = @Lost_Car2"
        strqry += " , Car_Fire = @Car_Fire"
        strqry += " , Acc_Lost1 = @Acc_Lost1"
        strqry += " , Acc_Lost2 = @Acc_Lost2"
        strqry += " , Acc_Lost3 = @Acc_Lost3"
        strqry += " , Acc_Lost4 = @Acc_Lost4"
        strqry += " , Maintain = @Maintain"
        strqry += " , Insure = @Insure"
        strqry += " , Old_Insu = @Old_Insu"
        strqry += " , Old_PolicyNO = @Old_PolicyNO"
        strqry += " , Apprela = @Apprela"
        strqry += " , CarpetValue = @CarpetValue"
        strqry += " , Carpetvat = @Carpetvat"
        strqry += " , ProtectDateCarpet = @ProtectDateCarpet"
        strqry += " , ExpProtectDateCarpet = @ExpProtectDateCarpet"
        strqry += " , DiscountProfile = @DiscountProfile"
        strqry += " , UpdateID = @userID"
        strqry += " , UpdateDate = GetDate()"
        strqry += " , AppComment = @AppComment"
        strqry += " , Comments = @Comments"
        strqry += " , PkgID = @PkgID"
        strqry += " , Doc1=@Doc1"
        strqry += " , Doc2=@Doc2"
        strqry += " , Doc3=@Doc3"
        strqry += " , Doc5=@Doc5"
        strqry += " , protectChk=@protectChk"
        strqry += " , Doc5Comment=@Doc5Comment"
        strqry += " , DisCountType=@DisCountType"
        strqry += " , chkDeviceAdd=@chkDeviceAdd"
        strqry += " , detDeviceAdd=@detDeviceAdd"
        strqry += " , PriceDeviceAdd=@PriceDeviceAdd"
        strqry += " , SendDoc=@SendDoc"
        strqry += " , FlagSendLINE1=@FlagSendLINE"
        strqry += " , flagsend=@flagsend"
        strqry += " , Premium=@Premium"
        strqry += " , flagDiscCamera=@flagDiscCamera"
        strqry += " Where AppID = @AppID"
        Return strqry
    End Function

    Public Function UpdateCustomer() As String
        Dim strqry As String = ""
        strqry += " UPDATE       TblCustomer"
        strqry += " SET InitID = @InitID"
        strqry += " , FNameTH = @FNameTH"
        strqry += " , LNameTH = @LNameTH"
        strqry += " , Address = @Address"
        strqry += " , SAddress = @SAddress"
        strqry += " , Villege = @Villege"
        strqry += " , Svillege = @Svillege"
        strqry += " , Moo = @Moo"
        strqry += " , SMoo = @SMoo"
        strqry += " , Soi = @Soi"
        strqry += " , SSoi = @SSoi"
        strqry += " , Road = @Road"
        strqry += " , SRoad = @SRoad"
        strqry += " , SubDist = @SubDist"
        strqry += " , SSubDist = @SSubDist"
        strqry += " , Dist = @Dist"
        strqry += " , SDist = @SDist"
        strqry += " , Province = @Province"
        strqry += " , SProvince = @SProvince"
        strqry += " , Zip = @Zip"
        strqry += " , SZip = @SZip"
        strqry += " , sameAddr = @sameAddr"
        strqry += " , UpdateDate = GetDate() "
        strqry += " , UpdateID = @userID"
        strqry += " , SName=@SName"
        strqry += " , IDCard=@IDCard"
        strqry += " , IDCard_Carpet=@IDCard_Carpet"
        strqry += " , BirthDate=@BirthDate"

	strqry += " , IsMale=@IsMale"
        strqry += " , OccID=@OccID"
        strqry += " , Age=@Age"

        strqry += " Where CusID=@CusID"
        Return strqry
    End Function

    Public Function InsertTblAppointTakePhoto() As String
        Dim strqry As String = ""
        strqry += " INSERT INTO TblAppointTakePhoto (Cusid, IdCar, AppointDate, AppointTime, Name, Tel, Province, Dist, SubDist, tid, Flag, createdate)"
        strqry += " VALUES        (@Cusid,@IdCar,@AppointDate,@AppointTime,@Name,@Tel,@Province,@Dist,@SubDist,@tid,@Flag, GETDATE())"
        Return strqry
    End Function

    Public Function UpdateTblAppointTakePhoto() As String
        Dim strqry As String = ""
        strqry += " Update TblAppointTakePhoto "
        strqry += " SET Cusid = @Cusid"
        strqry += " , IdCar = @IdCar"
        strqry += " , AppointDate = @AppointDate"
        strqry += " , AppointTime = @AppointTime"
        strqry += " , Name = @Name"
        strqry += " , Tel = @Tel"
        strqry += " , Province = @Province"
        strqry += " , Dist = @Dist"
        strqry += " ,SubDist = @SubDist"
        strqry += " , tid = @tid"
        strqry += " , Flag = @Flag"
        strqry += " , createdate = GETDATE()"
        strqry += " Where RunID =@RunID"
        Return strqry
    End Function

    Public Function SelectTblApplication(ByVal IdCar As String) As String
        Dim strqry As String = ""
        strqry += " SELECT a1.* "
        strqry += "  ,case when a4.FName  is null then '' else a4.FName end   as AppRelaTH    "
        strqry += " ,case when a5.ProTypeName is null then '[ไม่ระบุ]' else a5.ProTypeName end as OldInsureTH           "
        strqry += " FROM TblApplication a1"
        strqry += " Inner Join TblCar a2 on a1.IdCar = a2.IdCar"
        strqry += " Inner Join TblCustomer a3 on a3.CusID = a2.CusID"
        strqry += " Left Join TblFinance  a4 on a1.AppRela = a4.FName"
        strqry += " Left Join Tbl_ProductType a5 on a1.Old_Insu = a5.ProTypeName"
        strqry += " where a2.IdCar = " & IdCar & " and a1.AppStatus = 1 and a1.FlagNewApp = 0 "

        Return strqry
    End Function

    Public Function SelectTblProduct(ByVal ProID As String) As String
        Dim strqry As String = ""
        strqry += " SELECT StatusPhoto  from Tbl_ProductType"
        strqry += " where ProTypeID = " & ProID

        Return strqry
    End Function
    Public Function SelectTblApplicationPa(ByVal IdCar As String) As String
        Dim strqry As String = ""


        strqry += " select TblApplicationPA.* "
        strqry += " from TblApplicationPA"
        strqry += " Inner join TblApplication On TblApplication.AppId=TblApplicationPA.AppID"
        strqry += " Inner Join Tblcar on TblApplication.Idcar=Tblcar.Idcar"
        strqry += "  where Tblcar.Idcar =  " & IdCar & " "
        Return strqry
    End Function
End Class
