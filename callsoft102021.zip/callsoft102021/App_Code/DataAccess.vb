﻿Imports Microsoft.VisualBasic

Imports System
Imports System.Data
Imports System.Configuration
Imports System.Linq
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.HtmlControls
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Xml.Linq
Imports System.Data.SqlClient


Public Class DataAccess
    'Public Shared strConn As String = ConfigurationManager.AppSettings.Get("Finansa")
    Public Shared strConn As String = ConfigurationManager.ConnectionStrings("asnbroker").ConnectionString



    'Public Shared strConn As String = "Data Source=ASN2006DB2;Initial Catalog=Finansa;User ID=sa;Password= a2network@sr2"
    Dim Conn As New SqlConnection(strConn)

    '  Dim Cmd As New SqlCommand()
    Dim DT As New DataTable()

  
    Public Sub DataAccess()
        Dim Conn As New SqlConnection(strConn)
        Dim Cmd As New SqlCommand()
        Dim DT As New DataTable()
    End Sub

    Public Property ConnectionString() As String
        Get
            Return strConn
        End Get
        Set(ByVal value As String)
            strConn = value
        End Set
    End Property

    Public Sub CheckConnectionState()
        If Conn.State = ConnectionState.Open Then
            Conn.Close()
        Else
            Conn.Open()
        End If
    End Sub

    Public Function DataRead(ByVal strqry As String) As DataTable
        CheckConnectionState()
        Try
            Dim cmd As New SqlCommand(strqry, Conn)
            cmd.Parameters.Clear()
            cmd.CommandTimeout = 500
            Dim DR As SqlDataReader = cmd.ExecuteReader()
            DT = New DataTable()
            DT.Load(DR)
            DR.Close()
            Conn.Close()
            Return DT
        Catch se As SqlException
            Throw New ApplicationException(se.Message)
        End Try
    End Function

    Public Sub DataWrite(ByVal strqry As String)

        Dim cmd As New SqlCommand(strqry, Conn)
        CheckConnectionState()
        cmd.Parameters.Clear()
        cmd.ExecuteNonQuery()
        Conn.Close()
    End Sub
End Class