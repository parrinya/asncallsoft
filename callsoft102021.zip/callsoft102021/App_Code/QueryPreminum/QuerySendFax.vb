﻿Imports Microsoft.VisualBasic

Public Class QuerySendFax
    Public Function InsertSendFax() As String
        Dim strqry As String = ""
        strqry += " INSERT INTO TblSendFax"
        strqry += " (Createid, FNameth, FaxNo, Pay, Carid, CarBrand, CarSeries, Carsize, ProType, Fixin, Tsrname, Caryear, Pro1_Name, Pro1_Lost_Life1, Pro1_Lost_Life2, "
        strqry += " Pro1_Lost_Life3, Pro1_Lost_Car1, Pro1_Lost_Car2, Pro1_Acc_Lost1, Pro1_Acc_Lost2, Pro1_Acc_Lost3, Pro1_Provalue, Pro1_Prov_Carpet, Pro1_Age1, Pro1_Age2, "
        strqry += " Pro1_Age3, Pro1_Age4, Pro1_Dvalue, Fix1, Per1, Pro2_Name, Pro2_Lost_Life1, Pro2_Lost_Life2, Pro2_Lost_Life3, Pro2_Lost_Car1, Pro2_Lost_Car2, "
        strqry += " Pro2_Acc_Lost1, Pro2_Acc_Lost2, Pro2_Provalue, Pro2_Prov_Carpet, Pro2_Age1, Pro2_Age2, Pro2_Age3, Pro2_Age4, Pro2_Acc_Lost3, Pro2_Dvalue, Fix2, Per2, "
        strqry += " Pro3_Name, Pro3_Lost_Life1, Pro3_Lost_Life2, Pro3_Lost_Life3, Pro3_Lost_Car1, Pro3_Lost_Car2, Pro3_Acc_Lost1, Pro3_Acc_Lost2, Pro3_Provalue, "
        strqry += " Pro3_Prov_Carpet, Pro3_Age1, Pro3_Age2, Pro3_Age3, Pro3_Age4, Pro3_Acc_Lost3, Pro3_Dvalue, Fix3, Per3, Pro4_Name, Pro4_Lost_Life1, Pro4_Lost_Life2, "
        strqry += " Pro4_Lost_Life3, Pro4_Lost_Car1, Pro4_Lost_Car2, Pro4_Acc_Lost1, Pro4_Acc_Lost2, Pro4_Provalue, Pro4_Prov_Carpet, Pro4_Age1, Pro4_Age2, Pro4_Age3, "
        strqry += " Pro4_Age4, Pro4_Acc_Lost3, Pro4_Dvalue, Fix4, Per4, Status, Type,Email,TypeSend)"

        strqry += " VALUES (@userID,@FNameth,@FaxNo,@Pay,@Carid,@CarBrand,@CarSeries,@Carsize,@ProType,@Fixin,@Tsrname,@Caryear,@Pro1_Name,@Pro1_Lost_Life1,@Pro1_Lost_Life2"
        strqry += " ,@Pro1_Lost_Life3,@Pro1_Lost_Car1,@Pro1_Lost_Car2,@Pro1_Acc_Lost1,@Pro1_Acc_Lost2,@Pro1_Acc_Lost3,@Pro1_Provalue,@Pro1_Prov_Carpet,@Pro1_Age1,@Pro1_Age2"
        strqry += " ,@Pro1_Age3,@Pro1_Age4,@Pro1_Dvalue,@Fix1,@Per1,@Pro2_Name,@Pro2_Lost_Life1,@Pro2_Lost_Life2,@Pro2_Lost_Life3,@Pro2_Lost_Car1,@Pro2_Lost_Car2"
        strqry += " ,@Pro2_Acc_Lost1,@Pro2_Acc_Lost2,@Pro2_Provalue,@Pro2_Prov_Carpet,@Pro2_Age1,@Pro2_Age2,@Pro2_Age3,@Pro2_Age4,@Pro2_Acc_Lost3,@Pro2_Dvalue,@Fix2,@Per2"
        strqry += " ,@Pro3_Name,@Pro3_Lost_Life1,@Pro3_Lost_Life2,@Pro3_Lost_Life3,@Pro3_Lost_Car1,@Pro3_Lost_Car2,@Pro3_Acc_Lost1,@Pro3_Acc_Lost2,@Pro3_Provalue"
        strqry += " ,@Pro3_Prov_Carpet,@Pro3_Age1,@Pro3_Age2,@Pro3_Age3,@Pro3_Age4,@Pro3_Acc_Lost3,@Pro3_Dvalue,@Fix3,@Per3,@Pro4_Name,@Pro4_Lost_Life1,@Pro4_Lost_Life2"
        strqry += " ,@Pro4_Lost_Life3,@Pro4_Lost_Car1,@Pro4_Lost_Car2,@Pro4_Acc_Lost1,@Pro4_Acc_Lost2,@Pro4_Provalue,@Pro4_Prov_Carpet,@Pro4_Age1,@Pro4_Age2,@Pro4_Age3"
        strqry += " ,@Pro4_Age4,@Pro4_Acc_Lost3,@Pro4_Dvalue,@Fix4,@Per4,case @TypeSend when '0' then '0' when '1' then '2' else '0' end, 1,@Email,@TypeSend)"
        Return strqry

    End Function
End Class
