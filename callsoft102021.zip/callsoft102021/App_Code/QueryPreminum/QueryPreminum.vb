﻿Imports Microsoft.VisualBasic

Public Class QueryPreminum

    Public Function SelectTblSeries(ByVal CarBrand As String) As String
        Dim strqry As String
        strqry = "(Select '[ไม่ระบุ]' as CarSeries, 0 as CarType, 0 as CarNo ) "
        strqry += " union (SELECT [carSERIES],CarType,CarNo FROM [TblCarBrand] Where CarBrand = '" & CarBrand & "')"
        Return strqry

    End Function

    Public Function SelectTblPackage(ByVal ProTypeID As String) As String
        Dim strqry As String
        strqry = "SELECT [Detail], [AppsubmitId] FROM [TblAppSubmit] Where ProTypeID = " & ProTypeID
        Return strqry


    End Function

    Public Function SelectTblCarSize(ByVal StrCmd As String) As String
        Dim strqry As String
        strqry = "SELECT [CarSizeId], [CarSize] FROM [TblInsur_CarSize] " & StrCmd
        Return strqry

    End Function

    Public Function SelectTblCarUse(ByVal StrCmd As String) As String
        Dim strqry As String
        strqry = "SELECT [CarUseId], [CarUse] FROM [TblInsur_CarUse] " & StrCmd
        Return strqry

    End Function

    Public Function SelectTblCarBrand(ByVal CarNo As String) As String
        Dim strqry As String

        strqry = "SELECT [carSERIES],CarType,CarNo,CarPrice,CarGroup FROM [TblCarBrand] Where carSERIES = '" & CarNo & "'"
        Return strqry

    End Function

    Public Function SelectTblCarType(ByVal CarType As String) As String
        Dim strqry As String

        strqry = "SELECT Code,CarType from TblInsur_CarType Where CarTypeID = '" & CarType & "'"
        Return strqry

    End Function

#Region "ชั้น 1"
    Public Function SelectInsurePreminum1(ByVal StrProTypeID As String, ByVal StrCarType As String, ByVal FixIn As String) As String
        Dim strqry As String
        strqry = "SELECT a1.Detail ,a1.AppSubmitID from TblAppSubmit a1 "
        strqry += " Where a1.ProtypeID = " & StrProTypeID & " and a1.CarTypeID = " & StrCarType & " and a1.TypeID in(1) and a1.FixIn in(" & FixIn & ")"
        Return strqry

    End Function

    Public Function SelectInsurePreminum2(ByVal StrProTypeID As String, ByVal StrCarType As String, ByVal FixIn As String, ByVal CarGroup As String, ByVal CarYearID As String, ByVal CarSizeID As String, ByVal CarDriverID As String) As String
        Dim strqry As String
        strqry = "(select '[ไม่ระบุ]' as Detail , 0 as AppSubmitID ) union (SELECT Distinct a1.Detail ,a1.AppSubmitID from TblAppSubmit a1 "
        strqry += " Inner Join TblFixProValue a2 on a1.AppSubmitID = a2.AppSubmitID "
        strqry += " Where a2.ProductID = " & StrProTypeID & " and a2.CarTypeID = " & StrCarType & " and a2.FixIn in(" & FixIn & ")"
        strqry += " and a2.CarGroup = " & CarGroup & " and a2.CarYearID = " & CarYearID & " and a2.CarSizeID = " & CarSizeID & " "
        strqry += " and a2.CarDriverID = " & CarDriverID
        strqry += "  )"
        Return strqry

    End Function

    Public Function SelectProValue(ByVal StrProTypeID As String, ByVal StrCarType As String, ByVal FixIn As String, ByVal CarGroup As String, ByVal CarYearID As String, ByVal CarSizeID As String, ByVal CarDriverID As String, ByVal ProPrice As String) As String
        Dim strqry As String
        strqry = "select * from  TblFixProValue a2"
        strqry += " Where a2.ProductID = " & StrProTypeID & " and a2.CarTypeID = " & StrCarType & " and a2.FixIn in(" & FixIn & ")"
        strqry += " and a2.CarGroup = " & CarGroup & " and a2.CarYearID = " & CarYearID & " and a2.CarSizeID = " & CarSizeID & " "
        strqry += " and a2.CarDriverID = " & CarDriverID
        strqry += " and a2.ProPrice = '" & ProPrice & "'"
        Return strqry

    End Function

    Public Function SelectTblPackage1(ByVal AppSubmitID As String) As String
        Dim strqry As String
        strqry = "SELECT a1.*,a3.ProTypeID,a2.Detail as PackageName,a2.CarTypeID"
        strqry += " ,a4.PetValue"
        strqry += " ,a4.PetVat"
        strqry += " ,a4.Sumpet"
        strqry += " ,a4.CodeType"
        strqry += " ,a2.TypeID"
        strqry += " ,Convert(decimal,a1.Detail11) as Driver1"
        strqry += " ,Convert(decimal,a1.Detail12) as Driver2"
        strqry += " FROM [TblAppSubmitDetail]  a1"
        strqry += " Inner Join TblAppSubmit a2 on a1.AppSubmitID = a2.AppSubmitID"
        strqry += " Inner Join Tbl_ProductType a3 on a1.ProTypeID = a3.ProTypeID"
        strqry += " Inner Join Tbl_CarType a4 on a2.CarTypeID = a4.CarTypeID"
        strqry += " Where a1.AppSubmitID = " & AppSubmitID

        Return strqry

    End Function
#End Region

#Region "ชั้น3,5"
    Public Function SelectInsurePreminum3(ByVal StrTypeID As String, ByVal StrCarType As String) As String
        Dim strqry As String
        strqry = "SELECT a1.ProTypeID,a2.ProTypeName,a1.AppSubmitID,a1.CarTypeID From TblAppSubmit a1 Inner Join Tbl_ProductType a2 on a1.ProTypeID  = a2.ProTypeID"
        strqry += " Inner Join TblAppSubmitTypeTsr a3 on a1.AppSubmitID = a3.AppSubmitID"
        strqry += " WHERE a3.TypeTsr = 4 and  a1.TypeID in(" & StrTypeID & ") and a1.Status  = 1 and a1.CarTypeID =  " & StrCarType
        Return strqry

    End Function

    Public Function SelectInsurePreminum3Detail(ByVal StrSubID As String) As String
        Dim strqry As String
        strqry = "SELECT a1.*,a2.Detail from TblAppSubmitDetail a1 Inner Join TblAppSubmit a2 on a1.AppSubmitID = a2.AppSubmitID Where a1.AppSubmitID = " & StrSubID

        Return strqry

    End Function

#End Region

#Region "Update"
    Public Function UpdateTblCar() As String
        Dim strqry As String

        strqry = "UPDATE       TblCar "
        strqry += " SET                UpdateID = @UpdateID"
        strqry += " , UpdateDate = GetDate() "
        strqry += " , CarDriverNo = @CarDriverNo"
        strqry += " , CarDriver1 = @CarDriver1"
        strqry += " , CarDriverLname1 = @CarDriverLname1"
        strqry += " , CarDriverBorn1 = @CarDriverBorn1"
        strqry += " , CarDriver2 = @CarDriver2"
        strqry += " , CarDriverLname2 = @CarDriverLname2"
        strqry += " ,CarDriverBorn2 = @CarDriverBorn2"
        strqry += " , DBornNO1 = @DBornNO1"
        strqry += " , DBornDate1 = @DBornDate1"
        strqry += " , DBornAddr1 = @DBornAddr1"
        strqry += " , DBornNO2 = @DBornNO2"
        strqry += " , DBornDate2 = @DBornDate2"
        strqry += " ,    DBornAddr2 = @DBornAddr2"
        strqry += " , IdCard1 = @IdCard1"
        strqry += " , TypeCard1 = @TypeCard1"
        strqry += " , IdCard2 = @IdCard2"
        strqry += " , TypeCard2 = @TypeCard2"
        strqry += " , CarID = @CarID"
        strqry += " , CarFixIn = @CarFixIn"
        strqry += " , CarSize = @CarSize"
        strqry += " , CarNo = @CarNo"
        strqry += " , CarBoxNo = @CarBoxNo"
        strqry += " , CarType = @CarType"
        strqry += " , CarYear = @CarYear"
        strqry += " , CarBrand = @CarBrand"
        strqry += " ,  CarSeries = @CarSeries"
        strqry += " , CarGroup = @CarGroup"
        strqry += " Where IDCar=@IDCar"
        Return strqry

    End Function
#End Region
End Class
