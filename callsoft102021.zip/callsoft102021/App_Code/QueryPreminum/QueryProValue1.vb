﻿Imports Microsoft.VisualBasic
Imports System.Data
Public Class QueryProValue1
    Dim DataAccess As New DataAccess
    Dim dt, dtGetData As DataTable
    Dim StrCarGroup, StrCarGroupPercent, CarSizePercent, CarYearPercent, CarUsePercent, CarDriverPercent, StrCarType As Double
    Dim MinValue, MinPremium, Value1_1, Value1_2, Value2_1, Value2_2, Value2_3, Value2_4, Value2_5, Value2_6, Value3_1 As Double
    Dim CarLost1, CarLost2, CarLost3, Detail4, Detail5, Detail6, Percent As Double
    Dim CarLostValue1, CarLostValue2, CarLostValue3 As Double
    Dim DisCountX, Value11, Value12, Value1, Value2, Value3 As Double
    Dim ProValue As Double
    Public Function ProValue1(ByVal ArPro As ArrayList) As ArrayList
        Dim strPro As String = ""
        'กลุ่มรถ
        dtGetData = New DataTable
        dtGetData = ReadData(SelectCarGroup(ArPro(0)))
        StrCarGroup = GetDataDt(dtGetData, "CarGroup")

        '% กลุ่ม
        dtGetData = New DataTable
        dtGetData = ReadData(SelectCarGroupPercent(StrCarGroup))
        StrCarGroupPercent = GetDataDt(dtGetData, "CarGroupPercent")
        StrCarGroupPercent = StrCarGroupPercent / 100

        '%ขนาดรถ
        dtGetData = New DataTable
        dtGetData = ReadData(SelectCarSizePercent(ArPro(2), ArPro(1)))
        CarSizePercent = GetDataDt(dtGetData, "CarSizePercent")
        CarSizePercent = CarSizePercent / 100

        '%ปีรถ
        dtGetData = New DataTable
        dtGetData = ReadData(SelectCarYearPercent(CalYear(ArPro(3)), ArPro(1)))
        CarYearPercent = GetDataDt(dtGetData, "CarYearPercent")
        CarYearPercent = CarYearPercent / 100

        '%การใช้รถ
        dtGetData = New DataTable
        dtGetData = ReadData(SelectCarUsePercent(ArPro(4), ArPro(1)))
        CarUsePercent = GetDataDt(dtGetData, "CarUsePercent")
        CarUsePercent = CarUsePercent / 100

        '%การขับ
        dtGetData = New DataTable
        dtGetData = ReadData(SelectCarDriverPercent(ArPro(5), ArPro(1)))
        CarDriverPercent = GetDataDt(dtGetData, "CarDriverPercent")
        CarDriverPercent = CarDriverPercent / 100

        'สำหรับเบี้ย LMG และ ราคารถ >=1 package = 9
        If ArPro(7) = 13 And ArPro(9) >= 1 And (ArPro(8) = 9 Or ArPro(8) = 790) Then

            MinPremium = CalMinPreminumLMG2(CalYear(ArPro(3)), StrCarGroup, ArPro(16), ArPro(6), ArPro(2), ArPro(9), ArPro(17), ArPro(8))
            'dtGetData = New DataTable
            'dtGetData = ReadData(SelectPreminum(StrCarGroup, ArPro(1), ArPro(6), ArPro(7)))
            'MinValue = GetDataDt(dtGetData, "MinValue")


            If ArPro(16) = 110 And StrCarGroup <> 5 Then
                Value3_1 = 0.2142
                Value1_1 = 0.5
                Value1_2 = 0.5
                Value2_1 = 10
                Value2_2 = 10
                Value2_3 = 10
                Value2_4 = 10
                Value2_5 = 10
                Value2_6 = 10
            ElseIf ArPro(16) = 110 And StrCarGroup = 5 Then
                Value3_1 = 0.2142
                Value1_1 = 0.5
                Value1_2 = 0.5
                Value2_1 = 10
                Value2_2 = 10
                Value2_3 = 10
                Value2_4 = 10
                Value2_5 = 10
                Value2_6 = 10
                'MinValue = 18000
            ElseIf ArPro(16) = 210 Then
                Value3_1 = 0.382
                Value1_1 = 1
                Value1_2 = 1
                Value2_1 = 2
                Value2_2 = 2
                Value2_3 = 2
                Value2_4 = 2
                Value2_5 = 2
                Value2_6 = 2
            ElseIf ArPro(16) = 320 Then
                Value3_1 = 0.127
                Value1_1 = 0.5
                Value1_2 = 0.5
                Value2_1 = 1
                Value2_2 = 1
                Value2_3 = 1
                Value2_4 = 1
                Value2_5 = 1
                Value2_6 = 1
            End If
            


        ElseIf ArPro(7) = 13 And ArPro(9) >= 1 Then
            MinPremium = CalMinPreminumLMG(CalYear(ArPro(3)), StrCarGroup, ArPro(16), ArPro(6), ArPro(2), ArPro(9), ArPro(17), ArPro(8))
            dtGetData = New DataTable
            dtGetData = ReadData(SelectPreminum(StrCarGroup, ArPro(1), ArPro(6), ArPro(7)))
            MinValue = GetDataDt(dtGetData, "MinValue")

            Value1_1 = GetDataDt(dtGetData, "Value1_1")
            Value1_2 = GetDataDt(dtGetData, "Value1_2")
            Value2_1 = GetDataDt(dtGetData, "Value2_1")
            Value2_2 = GetDataDt(dtGetData, "Value2_2")
            Value2_3 = GetDataDt(dtGetData, "Value2_3")
            Value2_4 = GetDataDt(dtGetData, "Value2_4")
            Value2_5 = GetDataDt(dtGetData, "Value2_5")
            Value2_6 = GetDataDt(dtGetData, "Value2_6")
            Value3_1 = GetDataDt(dtGetData, "Value3_1")
        ElseIf ArPro(7) = 18 Then
            dtGetData = New DataTable
            dtGetData = ReadData(SelectPreminum(StrCarGroup, ArPro(1), ArPro(6), ArPro(7)))
            MinValue = GetDataDt(dtGetData, "MinValue")

            MinPremium = GetDataDt(dtGetData, "MinPremium")

            Value1_1 = GetDataDt(dtGetData, "Value1_1")
            Value1_2 = GetDataDt(dtGetData, "Value1_2")
            Value2_1 = GetDataDt(dtGetData, "Value2_1")
            Value2_2 = GetDataDt(dtGetData, "Value2_2")
            Value2_3 = GetDataDt(dtGetData, "Value2_3")
            Value2_4 = GetDataDt(dtGetData, "Value2_4")
            Value2_5 = GetDataDt(dtGetData, "Value2_5")
            Value2_6 = GetDataDt(dtGetData, "Value2_6")
            Value3_1 = GetDataDt(dtGetData, "Value3_1")

        Else

            dtGetData = New DataTable
            dtGetData = ReadData(SelectPreminum(StrCarGroup, ArPro(1), ArPro(6), ArPro(7)))
            MinValue = GetDataDt(dtGetData, "MinValue")
            MinPremium = GetDataDt(dtGetData, "MinPremium")
            Value1_1 = GetDataDt(dtGetData, "Value1_1")
            Value1_2 = GetDataDt(dtGetData, "Value1_2")
            Value2_1 = GetDataDt(dtGetData, "Value2_1")
            Value2_2 = GetDataDt(dtGetData, "Value2_2")
            Value2_3 = GetDataDt(dtGetData, "Value2_3")
            Value2_4 = GetDataDt(dtGetData, "Value2_4")
            Value2_5 = GetDataDt(dtGetData, "Value2_5")
            Value2_6 = GetDataDt(dtGetData, "Value2_6")
            Value3_1 = GetDataDt(dtGetData, "Value3_1")
        End If


        dtGetData = New DataTable
        dtGetData = ReadData(SelectSubmitAppDetail(ArPro(8), ArPro(7)))
        CarLost2 = CalCarLost2(GetDataDt(dtGetData, "Detail1"))
        CarLost3 = CalCarLost3(GetDataDt(dtGetData, "Detail2"))
        CarLost1 = CalCarLost1(GetDataDt(dtGetData, "Detail3"))
        Detail4 = GetDataDt(dtGetData, "Detail4")
        Detail5 = GetDataDt(dtGetData, "Detail5")
        Detail6 = GetDataDt(dtGetData, "Detail6")

        dtGetData = New DataTable
        dtGetData = ReadData(SelectProPricePercent(ArPro(9), ArPro(1)))
        Percent = GetDataDt(dtGetData, "Percent")
        Percent = Percent / 100

        dtGetData = New DataTable
        dtGetData = ReadData(SelectCarLostValue1(CarLost1, ArPro(1)))
        CarLostValue1 = GetDataDt(dtGetData, "CarLostValue1")

        dtGetData = New DataTable
        dtGetData = ReadData(SelectCarLostValue2(CarLost2, ArPro(1)))
        CarLostValue2 = GetDataDt(dtGetData, "CarLostValue2")

        dtGetData = New DataTable
        dtGetData = ReadData(SelectCarLostValue3(CarLost3, ArPro(1)))
        CarLostValue3 = GetDataDt(dtGetData, "CarLostValue3")


        If ArPro(10) > 0 Then
            DisCountX = ArPro(10) / 100
        Else
            DisCountX = 0
        End If


        Value1 = CalValue1(Value1_1, Value1_2, ArPro(13), ArPro(11), ArPro(12))
        Value2 = CalValue2(ArPro(14), ArPro(13))
        'Value2 = 70
        Value3 = CalValue3(ArPro(15))

SetCalProValue:
        If ArPro(18) <> 0 Then
            MinPremium = ArPro(18)
        End If
        ProValue = CalProValue()

        If DisCountX > 0 Then
            Dim DisCountValue As Double
            DisCountValue = ProValue * DisCountX
            ProValue -= DisCountValue
        End If

        If ArPro(18) = 0 And ArPro(7) = 18 Then
            If ProValue <= MinValue Then
                MinPremium += 100
                GoTo SetCalProValue
            End If
        ElseIf ArPro(7) = 13 And ProValue < MinValue And MinValue > 0 And ArPro(8) <> 9 Then
            ProValue = MinValue
        ElseIf ArPro(7) = 13 And ProValue < MinValue And MinValue > 0 And ArPro(8) = 9 Then
            ProValue = MinValue
        End If

        Dim ar As New ArrayList
        ar.Add(ProValue.ToString("##.##"))
        ar.Add(MinPremium)
        Return ar
    End Function

    Protected Function GetDataDt(ByVal dt1 As DataTable, ByVal nameField As String) As String
        If dt1.Rows.Count > 0 Then
            Return dt.Rows(0).Item(nameField)
        Else
            Return "0"
        End If
    End Function

    Protected Function ReadData(ByVal strqry As String) As DataTable
        dt = New DataTable
        dt = DataAccess.DataRead(strqry)
        Return dt
    End Function

    Protected Function CalMinPreminum(ByVal years As Integer, ByVal CarGroup As Integer, ByVal CarCode As String, ByVal CarFixIn As Integer, ByVal Package As Integer, ByVal ProPrice As Integer) As Integer
        Dim MinPre As Integer = 0



        If CarFixIn = 1 Then 'ซ่อมอู่

            If CarGroup <> 5 And CarCode = 110 Then 'รถไม่ใช้กลุ่ม 5 และเป็นประเภทเก่ง
                If ProPrice >= 550000 And years > 5 Then
                    MinPremium = 8065
                ElseIf ProPrice >= 600000 And years = 4 Then
                    MinPremium = 8065
                ElseIf ProPrice >= 650000 And years = 3 Then
                    MinPremium = 8065
                ElseIf ProPrice >= 700000 And years = 2 Then
                    MinPremium = 8065
                Else
                    MinPremium = 8490
                End If

            ElseIf CarGroup = 5 And CarCode = 110 Then 'รถใช้กลุ่ม 5 และเป็นประเภทเก่ง
                MinPremium = 9710
            ElseIf CarCode = 210 Then 'รถใช้กลุ่ม 5 และเป็นประเภท 210
                If ProPrice >= 350000 And years > 5 Then
                    MinPremium = 12734
                ElseIf ProPrice >= 400000 And years = 4 Then
                    MinPremium = 12734
                ElseIf ProPrice >= 450000 And years = 3 Then
                    MinPremium = 12734
                ElseIf ProPrice >= 500000 And years = 2 Then
                    MinPremium = 12734
                Else
                    MinPremium = 13205
                End If


            ElseIf CarCode = 320 Then 'รถใช้กลุ่ม 5 และเป็นประเภท 320
                If ProPrice >= 350000 And years > 5 Then
                    MinPremium = 13795
                ElseIf ProPrice >= 400000 And years = 4 Then
                    MinPremium = 13795
                ElseIf ProPrice >= 450000 And years = 3 Then
                    MinPremium = 13795
                ElseIf ProPrice >= 500000 And years = 2 Then
                    MinPremium = 13795
                Else
                    MinPremium = 14326
                End If

            End If


        ElseIf CarFixIn = 0 Then 'ซ่อมห้าง

            If CarGroup <> 5 And CarCode = 110 Then

                If ProPrice >= 550000 And years > 5 Then
                    MinPremium = 9356
                ElseIf ProPrice >= 600000 And years = 4 Then
                    MinPremium = 9356
                ElseIf ProPrice >= 650000 And years = 3 Then
                    MinPremium = 9356
                ElseIf ProPrice >= 700000 And years = 2 Then
                    MinPremium = 9356
                Else
                    MinPremium = 9849
                End If


            ElseIf CarGroup = 5 And CarCode = 110 Then
                MinPremium = 11264
            ElseIf CarCode = 210 Then
                If ProPrice >= 350000 And years > 5 Then
                    MinPremium = 14772
                ElseIf ProPrice >= 400000 And years = 4 Then
                    MinPremium = 14772
                ElseIf ProPrice >= 450000 And years = 3 Then
                    MinPremium = 14772
                ElseIf ProPrice >= 500000 And years = 2 Then
                    MinPremium = 14772
                Else
                    MinPremium = 15318
                End If

            ElseIf CarCode = 320 Then

                If ProPrice >= 350000 And years > 5 Then
                    MinPremium = 16003
                ElseIf ProPrice >= 400000 And years = 4 Then
                    MinPremium = 16003
                ElseIf ProPrice >= 450000 And years = 3 Then
                    MinPremium = 16003
                ElseIf ProPrice >= 500000 And years = 2 Then
                    MinPremium = 16003
                Else
                    MinPremium = 16619
                End If

            End If
        End If



        Return MinPremium
    End Function

    'เบี้ยพื้นฐานสำหรับสินทรัพย์
    Protected Function CalMinPreminum2(ByVal years As Integer, ByVal CarGroup As Integer, ByVal CarCode As String, ByVal CarFixIn As Integer, ByVal CarSize As Integer, ByVal ProPrice As Integer) As Integer
        Dim MinPremiumReturn As Integer = 0
        If CarFixIn = 1 Then 'ซ่อมอู่

            If years >= 2 And years <= 7 And CarCode = 110 And CarSize = 1 Then 'อายุลด 2-7 รถเก๋ง ไม่เกิน 2000cc
                If CarGroup <> 2 Then 'กลุ่มรถไม่ใช้ 2
                    Return 7600
                Else 'กลุ่มรถ อื่นๆ
                    Return 8500
                End If
            ElseIf years >= 8 And years <= 10 And CarCode = 110 And CarSize = 1 Then 'อายุลด 8-10 รถเก๋ง ไม่เกิน 2000cc
                If CarGroup <> 2 Then 'กลุ่มรถไม่ใช้ 2
                    Return 7800
                Else 'กลุ่มรถ อื่นๆ
                    Return 8500
                End If

            ElseIf years >= 2 And years <= 10 And CarCode = 110 And CarSize = 2 Then 'อายุลด 2-10 รถเก๋ง เกิน 2000cc
                If CarGroup <> 2 Then 'กลุ่มรถไม่ใช้ 2
                    Return 7800
                Else 'กลุ่มรถ อื่นๆ
                    Return 8500
                End If

            Else
                Return 0
            End If

        ElseIf CarFixIn = 0 Then 'ซ่อมห้าง
            If years >= 2 And years <= 3 And CarCode = 110 And CarSize = 1 Then 'อายุลด 2-7 รถเก๋ง ไม่เกิน 2000cc
                If CarGroup = 2 Then 'กลุ่มรถ
                    Return 9000
                ElseIf CarGroup = 3 Then
                    Return 7800
                ElseIf CarGroup = 4 Or CarGroup = 3 Then
                    Return 8000
                End If
            ElseIf years >= 2 And years <= 3 And CarCode = 110 And CarSize = 2 Then
                If CarGroup = 2 Then
                    Return 9000
                ElseIf CarGroup = 3 Then
                    Return 7800
                ElseIf CarGroup = 4 Then
                    Return 8000
                End If
            Else
                Return 0
            End If
        End If


        Return MinPremiumReturn
    End Function

    'เบี้ยพื้นฐานสำหรับLMG
    Protected Function CalMinPreminumLMG(ByVal years As Integer, ByVal CarGroup As Integer, ByVal CarCode As String, ByVal CarFixIn As Integer, ByVal CarSize As Integer, ByVal ProPrice As Integer, ByVal CarNo As String, ByVal ProPackage As String) As Integer
        Dim MinPremiumReturn As Integer = 0
        Dim dtCarPackage As New DataTable
        dtCarPackage = ReadData("Select * from tblcarbrandpackage where productid = 13 and BrandID=" & CarNo)
        If CarFixIn = 1 Then 'ซ่อมอู่
            'เทียบ กลุ่มรถ

            If CarGroup < 5 And CarCode = 110 Then
                If years = 1 Then
                    MinPremiumReturn = 8915
                ElseIf years = 2 And ProPrice >= 700000 Then
                    MinPremiumReturn = 8915
                ElseIf years = 3 And ProPrice >= 650000 Then
                    MinPremiumReturn = 8915
                ElseIf years = 4 And ProPrice >= 600000 Then
                    MinPremiumReturn = 8915
                ElseIf years = 5 And ProPrice >= 550000 Then
                    MinPremiumReturn = 8915
                ElseIf years = 2 And ProPrice < 700000 Then
                    MinPremiumReturn = 9274
                ElseIf years = 3 And ProPrice < 650000 Then
                    MinPremiumReturn = 9274
                ElseIf years = 4 And ProPrice < 600000 Then
                    MinPremiumReturn = 9274
                ElseIf years = 5 And ProPrice < 550000 Then
                    MinPremiumReturn = 9274
                ElseIf years > 5 Then
                    MinPremiumReturn = 9274
                End If

            ElseIf CarGroup = 5 And CarCode = 110 Then
                If years = 2 Then
                    MinPremiumReturn = 8836
                Else
                    MinPremiumReturn = 9710
                End If

            ElseIf CarCode = 210 Then
                MinPremiumReturn = 13371
            ElseIf CarCode = 320 Then
                MinPremiumReturn = 14486
            End If


            'If CarGroup < 5 And ProPrice < 800000 And years <= 9 And CarCode = 110 Then
            '    MinPremiumReturn = 8915
            'ElseIf CarGroup < 5 And ProPrice >= 800000 And years <= 9 And CarCode = 110 Then
            '    MinPremiumReturn = 8065
            'ElseIf CarGroup = 5 And years <= 9 And CarCode = 110 Then
            '    MinPremiumReturn = 9710
            'ElseIf CarCode = 210 Then
            '    MinPremiumReturn = 14559
            'ElseIf CarCode = 320 Then
            '    MinPremiumReturn = 17595
            'End If



            'เทียบยี่ห้อรถ
            'CHEVROLET Civic Mazda
            If dtCarPackage.Rows.Count > 0 Then
                If years = 1 Then
                    MinPremiumReturn = 9339
                ElseIf years = 2 And ProPrice >= 700000 Then
                    MinPremiumReturn = 9339
                ElseIf years = 3 And ProPrice >= 650000 Then
                    MinPremiumReturn = 9339
                ElseIf years = 4 And ProPrice >= 600000 Then
                    MinPremiumReturn = 9339
                ElseIf years = 5 And ProPrice >= 550000 Then
                    MinPremiumReturn = 9339
                ElseIf years = 2 And ProPrice < 700000 Then
                    MinPremiumReturn = 10202
                ElseIf years = 3 And ProPrice < 650000 Then
                    MinPremiumReturn = 10202
                ElseIf years = 4 And ProPrice < 600000 Then
                    MinPremiumReturn = 10202
                ElseIf years = 5 And ProPrice < 550000 Then
                    MinPremiumReturn = 10202
                ElseIf years > 5 Then
                    MinPremiumReturn = 10202
                End If
                'If ProPrice < 800000 Then
                '    MinPremiumReturn = 9339
                'ElseIf ProPrice >= 800000 Then
                '    MinPremiumReturn = 8872
                'End If


            End If

        ElseIf CarFixIn = 0 Then 'ซ่อมห้าง

            If CarGroup < 5 And CarCode = 110 Then
                MinPremiumReturn = 9849
            ElseIf CarGroup = 5 And CarCode = 110 Then
                If years = 2 Then
                    MinPremiumReturn = 10251
                Else
                    MinPremiumReturn = 11264
                End If
            ElseIf CarCode = 210 Then
                MinPremiumReturn = 14181
            ElseIf CarCode = 320 Then
                MinPremiumReturn = 15363
            End If

            'เทียบ กลุ่มรถ
            'If CarGroup < 5 And ProPrice < 800000 And years <= 9 And CarCode = 110 Then
            '    MinPremiumReturn = 9849
            'ElseIf CarGroup < 5 And ProPrice >= 800000 And years <= 9 And CarCode = 110 Then
            '    MinPremiumReturn = 9356
            'ElseIf CarGroup = 5 And years <= 9 And CarCode = 110 Then
            '    MinPremiumReturn = 11264
            'ElseIf CarCode = 210 Then
            '    MinPremiumReturn = 15318
            'ElseIf CarCode = 320 Then
            '    MinPremiumReturn = 16619
            'End If


            'เทียบยี่ห้อรถ
            'CHEVROLET Civic Mazda
            If dtCarPackage.Rows.Count > 0 Then
                If years = 1 Then
                    MinPremiumReturn = 10834
                ElseIf years = 2 And ProPrice >= 700000 Then
                    MinPremiumReturn = 10834
                ElseIf years = 3 And ProPrice >= 650000 Then
                    MinPremiumReturn = 10834
                ElseIf years = 4 And ProPrice >= 600000 Then
                    MinPremiumReturn = 10834
                ElseIf years = 5 And ProPrice >= 550000 Then
                    MinPremiumReturn = 10834
                ElseIf years = 2 And ProPrice < 700000 Then
                    MinPremiumReturn = 11651
                ElseIf years = 3 And ProPrice < 650000 Then
                    MinPremiumReturn = 11651
                ElseIf years = 4 And ProPrice < 600000 Then
                    MinPremiumReturn = 11651
                ElseIf years = 5 And ProPrice < 550000 Then
                    MinPremiumReturn = 11651
                ElseIf years > 5 Then
                    MinPremiumReturn = 11651
                End If
                'If ProPrice < 800000 Then
                '    MinPremiumReturn = 10834
                'ElseIf ProPrice >= 800000 Then
                '    MinPremiumReturn = 10293
                'End If


            End If




        End If


        Return MinPremiumReturn
    End Function

    'เบี้ยพื้นฐานสำหรับLMG พิเศษ
    Protected Function CalMinPreminumLMG2(ByVal years As Integer, ByVal CarGroup As Integer, ByVal CarCode As String, ByVal CarFixIn As Integer, ByVal CarSize As Integer, ByVal ProPrice As Integer, ByVal CarNo As String, ByVal ProPackage As String) As Integer
        Dim MinPremiumReturn As Integer = 0
        Dim dtCarPackage As New DataTable
        dtCarPackage = ReadData("Select * from tblcarbrandpackage where productid = 13 and BrandID=" & CarNo)

        If CarGroup < 5 And CarCode = 110 Then

            MinPremiumReturn = 9849
            If CarGroup = 3 Or CarGroup = 4 Then
                MinValue = 16000
            ElseIf CarGroup = 1 Or CarGroup = 2 Then
                MinValue = 32500

            End If

        ElseIf CarGroup = 5 And CarCode = 110 Then
            If years = 2 Then
                MinPremiumReturn = 10251
                MinValue = 18000
            Else
                MinPremiumReturn = 11264
                MinValue = 18000
            End If

        ElseIf CarCode = 210 Then
            MinPremiumReturn = 14181
            MinValue = 16000
        ElseIf CarCode = 320 Then
            MinPremiumReturn = 15363
            MinValue = 16000
        End If




        'เทียบยี่ห้อรถ
        'CHEVROLET Civic Mazda
        If dtCarPackage.Rows.Count > 0 Then
            If years = 1 Then
                MinPremiumReturn = 10834
            ElseIf years = 2 And ProPrice >= 700000 Then
                MinPremiumReturn = 10834
            ElseIf years = 3 And ProPrice >= 650000 Then
                MinPremiumReturn = 10834
            ElseIf years = 4 And ProPrice >= 600000 Then
                MinPremiumReturn = 10834
            ElseIf years = 5 And ProPrice >= 550000 Then
                MinPremiumReturn = 10834
            ElseIf years = 2 And ProPrice < 700000 Then
                MinPremiumReturn = 11651
            ElseIf years = 3 And ProPrice < 650000 Then
                MinPremiumReturn = 11651
            ElseIf years = 4 And ProPrice < 600000 Then
                MinPremiumReturn = 11651
            ElseIf years = 5 And ProPrice < 550000 Then
                MinPremiumReturn = 11651
            ElseIf years > 5 Then
                MinPremiumReturn = 11651
            End If

        End If
        Return MinPremiumReturn
    End Function


    Protected Function CalYear(ByVal Year1 As Integer) As Double

        Year1 = (CDbl(DateTime.Today.Year) - Year1) + 1

        If Year1 > 11 Then
            Year1 = 11
        End If

        Return Year1
    End Function

    Protected Function CalValue1(ByVal CalValue_1 As Double, ByVal CalValue_2 As Double, ByVal Passenger As Integer, ByVal DriverValueOfHeal As Double, ByVal PassengerValueOfHeal As Double) As Double
        Value11 = ((DriverValueOfHeal * Value1_1) * (1 / 1000))
        Value12 = ((PassengerValueOfHeal * Value1_2) * (Passenger / 1000))
        Return Value11 + Value12
    End Function

    Protected Function CalValue2(ByVal ValueOfHeal As Double, ByVal Passenger As Integer) As Double
        If ValueOfHeal <= 50000 Then
            Return Value2_1 * (Passenger + 1)
        ElseIf ValueOfHeal <= 100000 AndAlso ValueOfHeal > 50000 Then
            Return Value2_2 * (Passenger + 1)
        ElseIf ValueOfHeal <= 200000 AndAlso ValueOfHeal > 100000 Then
            Return Value2_3 * (Passenger + 1)
        ElseIf ValueOfHeal <= 300000 AndAlso ValueOfHeal > 200000 Then
            Return Value2_4 * (Passenger + 1)
        ElseIf ValueOfHeal <= 400000 AndAlso ValueOfHeal > 300000 Then
            Return Value2_5 * (Passenger + 1)
        ElseIf ValueOfHeal <= 500000 AndAlso ValueOfHeal > 400000 Then
            Return Value2_6 * (Passenger + 1)
        End If

    End Function

    Protected Function CalProValue() As Double
        Dim SumInsure As Double
        SumInsure = (MinPremium * CarUsePercent)
        SumInsure = (SumInsure * CarSizePercent)
        SumInsure = (SumInsure * CarDriverPercent)
        SumInsure = (SumInsure * CarYearPercent)
        SumInsure = (SumInsure * Percent)
        SumInsure = (SumInsure * StrCarGroupPercent)
        SumInsure = (SumInsure * CarLostValue3)
        SumInsure = (SumInsure * CarLostValue2)
        SumInsure = (SumInsure * CarLostValue1)
        SumInsure = (SumInsure + Value1)
        SumInsure = (SumInsure + Value2)
        SumInsure = (SumInsure + Value3)

        Return SumInsure
    End Function

    Protected Function CalValue3(ByVal ValueOfWarrant As Double) As Double
        Return (ValueOfWarrant * Value3_1) / 100
    End Function


#Region "CarLost"
    Protected Function CalCarLost1(ByVal ClCarLost1 As Integer) As Integer
        If ClCarLost1 <= 200000 Then
            ClCarLost1 = 200000
        ElseIf ClCarLost1 <= 400000 AndAlso ClCarLost1 > 200000 Then
            ClCarLost1 = 400000
        ElseIf ClCarLost1 <= 600000 AndAlso ClCarLost1 > 400000 Then
            ClCarLost1 = 600000
        ElseIf ClCarLost1 <= 800000 AndAlso ClCarLost1 > 600000 Then
            ClCarLost1 = 800000
        ElseIf ClCarLost1 <= 1000000 AndAlso ClCarLost1 > 800000 Then
            ClCarLost1 = 1000000
        ElseIf ClCarLost1 <= 1500000 AndAlso ClCarLost1 > 1000000 Then
            ClCarLost1 = 1500000
        ElseIf ClCarLost1 <= 2000000 AndAlso ClCarLost1 > 1500000 Then
            ClCarLost1 = 2000000
        ElseIf ClCarLost1 <= 2500000 AndAlso ClCarLost1 > 2000000 Then
            ClCarLost1 = 2500000
        ElseIf ClCarLost1 <= 3000000 AndAlso ClCarLost1 > 2500000 Then
            ClCarLost1 = 3000000
        ElseIf ClCarLost1 <= 3500000 AndAlso ClCarLost1 > 3000000 Then
            ClCarLost1 = 3500000
        ElseIf ClCarLost1 <= 4000000 AndAlso ClCarLost1 > 3500000 Then
            ClCarLost1 = 4000000
        ElseIf ClCarLost1 <= 4500000 AndAlso ClCarLost1 > 4000000 Then
            ClCarLost1 = 4500000
        ElseIf ClCarLost1 <= 5000000 AndAlso ClCarLost1 > 4500000 Then
            ClCarLost1 = 5000000
        ElseIf ClCarLost1 <= 5500000 AndAlso ClCarLost1 > 5000000 Then
            ClCarLost1 = 5500000
        ElseIf ClCarLost1 <= 6000000 AndAlso ClCarLost1 > 5500000 Then
            ClCarLost1 = 6000000
        ElseIf ClCarLost1 <= 6500000 AndAlso ClCarLost1 > 6000000 Then
            ClCarLost1 = 6500000
        ElseIf ClCarLost1 <= 7000000 AndAlso ClCarLost1 > 6500000 Then
            ClCarLost1 = 7000000
        ElseIf ClCarLost1 <= 7500000 AndAlso ClCarLost1 > 7000000 Then
            ClCarLost1 = 7500000
        ElseIf ClCarLost1 <= 8000000 AndAlso ClCarLost1 > 7500000 Then
            ClCarLost1 = 8000000
        ElseIf ClCarLost1 <= 8500000 AndAlso ClCarLost1 > 8000000 Then
            ClCarLost1 = 8500000
        ElseIf ClCarLost1 <= 9000000 AndAlso ClCarLost1 > 8500000 Then
            ClCarLost1 = 9000000
        ElseIf ClCarLost1 <= 9500000 AndAlso ClCarLost1 > 9000000 Then
            ClCarLost1 = 9500000
        ElseIf ClCarLost1 <= 10000000 AndAlso ClCarLost1 > 9500000 Then
            ClCarLost1 = 10000000
        End If

        Return ClCarLost1

    End Function

    Protected Function CalCarLost2(ByVal ClCarLost2 As Integer) As Integer
        If ClCarLost2 <= 100000 Then
            ClCarLost2 = 100000
        ElseIf ClCarLost2 <= 150000 AndAlso ClCarLost2 > 100000 Then
            ClCarLost2 = 150000
        ElseIf ClCarLost2 <= 200000 AndAlso ClCarLost2 > 150000 Then
            ClCarLost2 = 200000
        ElseIf ClCarLost2 <= 250000 AndAlso ClCarLost2 > 200000 Then
            ClCarLost2 = 250000
        ElseIf ClCarLost2 <= 300000 AndAlso ClCarLost2 > 250000 Then
            ClCarLost2 = 300000
        ElseIf ClCarLost2 <= 400000 AndAlso ClCarLost2 > 300000 Then
            ClCarLost2 = 400000
        ElseIf ClCarLost2 <= 500000 AndAlso ClCarLost2 > 400000 Then
            ClCarLost2 = 500000
        ElseIf ClCarLost2 <= 750000 AndAlso ClCarLost2 > 500000 Then
            ClCarLost2 = 750000
        ElseIf ClCarLost2 <= 1000000 AndAlso ClCarLost2 > 750000 Then
            ClCarLost2 = 1000000
        ElseIf ClCarLost2 <= 1250000 AndAlso ClCarLost2 > 1000000 Then
            ClCarLost2 = 1250000
        ElseIf ClCarLost2 <= 1500000 AndAlso ClCarLost2 > 1250000 Then
            ClCarLost2 = 1500000
        ElseIf ClCarLost2 <= 2000000 AndAlso ClCarLost2 > 1500000 Then
            ClCarLost2 = 2000000
        End If

        Return ClCarLost2

    End Function

    Protected Function CalCarLost3(ByVal ClCarLost3 As Integer) As Integer

        If ClCarLost3 <= 1000000 Then
            ClCarLost3 = 1000000
        ElseIf ClCarLost3 <= 2000000 AndAlso ClCarLost3 > 1000000 Then
            ClCarLost3 = 2000000
        End If


        Return ClCarLost3

    End Function
#End Region

#Region "Query"
    Protected Function SelectCarGroup(ByVal CarSeries As String) As String
        Dim strqry As String = ""
        strqry += "Select * from TblCarBrand Where CarSeries = '" & CarSeries & "'"
        Return strqry
    End Function

    Protected Function SelectCarGroupPercent(ByVal CarGroup As String) As String
        Dim strqry As String = ""
        strqry += " select * from TblInsur_CarGroupPercent"
        strqry += " Where InsurTypeID = 1"
        strqry += " And CarGroupID = " & CarGroup
        Return strqry
    End Function

    Protected Function SelectCarSizePercent(ByVal CarSize As String, ByVal CarType As String) As String
        Dim strqry As String = ""
        strqry += " select a2.CarSizePercent from TblInsur_CarSize a1"
        strqry += " inner join TblInsur_CarSizePercent a2  on a1.carsizeid = a2.carsizeid"
        strqry += " where a2.InsurTypeID = 1"
        strqry += " and a2.CarSizeID = " & CarSize
        strqry += "  and a2.CarTypeID = " & CarType
        Return strqry
    End Function

    Protected Function SelectCarYearPercent(ByVal Years As Integer, ByVal CarType As String) As String
        Dim strqry As String = ""

        strqry += " select a2.CarYearPercent from TblInsur_CarYear  a1"
        strqry += " inner join TblInsur_CarYearPercent a2  on a1.CarYearID = a2.CarYearID "
        strqry += " Where a2.CarTypeID = " & CarType
        strqry += "  And a2.InsurTypeID = 1"
        strqry += "  And a2.CarYearID = " & Years
        Return strqry
    End Function

    Protected Function SelectCarUsePercent(ByVal CarUseID As Integer, ByVal CarType As String) As String

        Dim strqry As String = ""
        strqry += " select a2.CarUsePercent from TblInsur_CarUse  a1"
        strqry += " inner join TblInsur_CarUsePercent a2  on a1.CarUseID = a2.CarUseID"
        strqry += " Where a2.CarTypeID = " & CarType
        strqry += "  And a2.InsurTypeID = 1"
        strqry += "  And a2.CarUseID  = " & CarUseID
        Return strqry
    End Function

    Protected Function SelectCarDriverPercent(ByVal CarDriverID As Integer, ByVal CarType As String) As String

        If CarType >= 3 Then
            CarType = 2
        End If

        Dim strqry As String = ""
        strqry += " select  a2.CarDriverPercent from TblInsur_CarDriver   a1"
        strqry += " inner join TblInsur_CarDriverPercent  a2  on a1.CarDriverID = a2.CarDriverID "
        strqry += " Where a2.CarTypeID = " & CarType
        strqry += "  And a2.InsurTypeID = 1"
        strqry += "  And a2.CarDriverID   = " & CarDriverID
        Return strqry
    End Function

    Protected Function SelectPreminum(ByVal GroupCar As Integer, ByVal CarType As String, ByVal FixIn As Integer, ByVal ProTypeID As Integer) As String

        Dim strqry As String = ""
        strqry += " select  * from TblInsur_Premium"
        strqry += " Where ProTypeID = " & ProTypeID
        strqry += " and CarTypeID = " & CarType
        strqry += " And InsurTypeID = 1"
        strqry += "  And FixIn =" & FixIn
        strqry += "  And GroupCar" & GroupCar & "=1"
        strqry += "  And Status = 1 Order by VersionID DESC "
        Return strqry
    End Function

    Protected Function SelectSubmitAppDetail(ByVal AppSubmitID As Integer, ByVal ProTypeID As Integer) As String

        Dim strqry As String = ""
        strqry += " select  * from TblAppSubmitDetail"
        strqry += " Where ProTypeID = " & ProTypeID
        strqry += " And AppSubmitID  = " & AppSubmitID

        Return strqry
    End Function

    Protected Function SelectProPricePercent(ByVal ProPrice As Integer, ByVal CarTypeID As Integer) As String

        Dim strqry As String = ""
        strqry += " select  * from tblInsur_proprice"
        strqry += " Where CarTypeID  = " & CarTypeID
        strqry += " And InsurTypeID   = 1"
        strqry += " And ProPrice    = " & ProPrice
        Return strqry
    End Function

    Protected Function SelectCarLostValue1(ByVal CarLost1 As Integer, ByVal CarTypeID As Integer) As String

        Dim strqry As String = ""
        strqry += " select  * from TblInsur_CarLostValue"
        strqry += " Where CarTypeID  = " & CarTypeID
        strqry += " And InsurTypeID   = 1"
        strqry += " And CarLost1     = " & CarLost1
        Return strqry
    End Function

    Protected Function SelectCarLostValue2(ByVal CarLost2 As Integer, ByVal CarTypeID As Integer) As String

        Dim strqry As String = ""
        strqry += " select  * from TblInsur_CarLostValue"
        strqry += " Where CarTypeID  = " & CarTypeID
        strqry += " And InsurTypeID   = 1"
        strqry += " And CarLost2     = " & CarLost2
        Return strqry
    End Function

    Protected Function SelectCarLostValue3(ByVal CarLost3 As Integer, ByVal CarTypeID As Integer) As String

        Dim strqry As String = ""
        strqry += " select  * from TblInsur_CarLostValue"
        strqry += " Where CarTypeID  = " & CarTypeID
        strqry += " And InsurTypeID   = 1"
        strqry += " And CarLost3     = '" & CarLost3 & "'"
        Return strqry
    End Function
#End Region
End Class
