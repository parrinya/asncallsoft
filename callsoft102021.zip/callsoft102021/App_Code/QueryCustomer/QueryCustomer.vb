﻿Imports Microsoft.VisualBasic

Public Class QueryCustomer
    Public Function InsertCustomer() As String
        Dim strqry As String = ""
        strqry += " INSERT INTO TblCustomer(InitID, FNameTH, LNameTH, SAddress, Svillege, SMoo, SSoi, SRoad, SSubDist, SDist, SProvince, SZip,Address, villege, Moo, Soi, Road, SubDist, Dist, Province, Zip, Tel, TelExt, OTel, OTelExt, Mobile, CreateDate,Username,Password,StatusSMS,Email)"
        strqry += " VALUES        (@InitID,@FNameTH,@LNameTH,@SAddress,@Svillege,@SMoo,@SSoi,@SRoad,@SSubDist,@SDist,@SProvince,@SZip,@Address,@villege,@Moo,@Soi,@Road,@SubDist,@Dist,@Province,@Zip,@Tel,@TelExt,@OTel,@OTelExt,@Mobile, GETDATE(),@Username,@Password,@StatusSMS,@Email)"
        Return strqry

    End Function

    Public Function UpdateCustomer() As String
        Dim strqry As String = ""
        strqry += " UPDATE       TblCustomer"
        strqry += " SET                InitID = @InitID"
        strqry += " , FNameTH = @FNameTH"
        strqry += " , LNameTH = @LNameTH"
        strqry += " , SAddress = @SAddress"
        strqry += " , Svillege = @Svillege"
        strqry += " , SMoo = @SMoo"
        strqry += " , SSoi = @SSoi"
        strqry += " , SRoad = @SRoad"
        strqry += " , SSubDist = @SSubDist"
        strqry += " , SDist = @SDist"
        strqry += " , SProvince = @SProvince"
        strqry += " , SZip = @SZip"
        strqry += " , Tel = @Tel"
        strqry += " , TelExt = @TelExt"
        strqry += " , OTel = @OTel"
        strqry += " ,  OTelExt = @OTelExt"
        strqry += " , Mobile = @Mobile"
        strqry += " , CreateDate = GETDATE()"
        strqry += " , Password = @Password"
        strqry += " , StatusSMS = @StatusSMS"
        strqry += " , Email=@Email"

        strqry += " WHERE        (CusID = @CusID)"

        Return strqry

    End Function

    Public Function InsertTblCar() As String
        Dim strqry As String = ""
        strqry += " INSERT INTO TblCar(CusID, CarID, CarSize, CarBuyDate, CarNo, CarBoxNo, CarYear, CarType, CarBrand, CarSeries, Cargroup)"
        strqry += " VALUES        (@CusID,@CarID,@CarSize,@CarBuyDate,@CarNo,@CarBoxNo,@CarYear,@CarType,@CarBrand,@CarSeries,@Cargroup)"
        Return strqry

    End Function

    Public Function UpdateTblCar() As String
        Dim strqry As String = ""
        strqry += " UPDATE       TblCar"
        strqry += " SET                CusID = @CusID"
        strqry += " , CarID = @CarID"
        strqry += " , CarSize = @CarSize"
        strqry += " , CarBuyDate = @CarBuyDate"
        strqry += " , CarNo = @CarNo"
        strqry += " , CarBoxNo = @CarBoxNo"
        strqry += " , CarYear = @CarYear"
        strqry += " , CarType = @CarType"
        strqry += " , CarBrand = @CarBrand"
        strqry += " , CarSeries = @CarSeries"
        strqry += " , Cargroup = @Cargroup"
        strqry += " WHERE        (IdCar = @IdCar)"

        Return strqry

    End Function

    Public Function SelectTblCustomerName(ByVal FNameTH As String, ByVal LNameTH As String) As String
        Dim strqry As String = ""
        strqry += " Select * from TblCustomer "
        strqry += " Where FnameTH = '" & FNameTH & "'"
        strqry += " And LNameTH = '" & LNameTH & "'"
        Return strqry

    End Function

    Public Function SelectTblCustomerUser(ByVal Username As String) As String
        Dim strqry As String = ""
        strqry += " Select * from TblCustomer "
        strqry += " Where Username = '" & Username & "'"

        Return strqry

    End Function

    Public Function SelectTblCar(ByVal CarID As String) As String
        Dim strqry As String = ""
        strqry += " Select * from TblCar "
        strqry += " Where CarID = '" & CarID & "'"

        Return strqry

    End Function
End Class
