﻿Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Partial Class Modules_Manager_Report_frmWebASNReport
    Inherits System.Web.UI.Page
    Dim ISODate As New ISODate

    Protected Sub btnExport_Click(sender As Object, e As System.EventArgs) Handles btnExport.Click
        If txtdate1.Text <> "" And txtdate2.Text <> "" Then

            Dim reportname As String
            Dim myReport As New ReportDocument
            Dim users As String = "sa"
            Dim pass As String = "asn@sr1"
            Dim DispDate As String = " ข้อมูลระหว่าง วันที่ " + Format(CDate(txtdate1.Text), "dd-MM-yyyy").ToString() + " ถึง " + Format(CDate(txtdate2.Text), "dd-MM-yyyy").ToString()
            DispDate += " : TSR = " + ddsale.SelectedItem.Text
            reportname = Server.MapPath("rptWebASNReport.rpt")
            Response.Buffer = False
            Response.ClearContent()
            Response.ClearHeaders()
            myReport.Load(reportname)
            myReport.SetDatabaseLogon(users, pass)
            myReport.SetParameterValue("datestr", DispDate)
            myReport.SetParameterValue("userid", ddsale.SelectedValue)

            myReport.SetParameterValue("date01", ISODate.SetISODate("en", txtdate1.Text.Trim))
            myReport.SetParameterValue("date02", ISODate.SetISODate("en", txtdate2.Text.Trim))

            If ddExport.SelectedValue = "0" Then
                myReport.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, True, "asn")
            Else
                myReport.ExportToHttpResponse(ExportFormatType.Excel, Response, True, "asn")
            End If

        End If
    End Sub
End Class
