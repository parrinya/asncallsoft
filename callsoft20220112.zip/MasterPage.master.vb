﻿
Partial Class MasterPage_Page_MasterPage
    Inherits System.Web.UI.MasterPage


    Private Const AntiXsrfTokenKey As String = "__AntiXsrfToken"
    Private Const AntiXsrfUserNameKey As String = "__AntiXsrfUserName"
    Private _antiXsrfTokenValue As String

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As EventArgs)
        Dim requestCookie = Request.Cookies(AntiXsrfTokenKey)
        Dim requestCookieGuidValue As Guid

        If requestCookie IsNot Nothing AndAlso Guid.TryParse(requestCookie.Value, requestCookieGuidValue) Then
            _antiXsrfTokenValue = requestCookie.Value
            Page.ViewStateUserKey = _antiXsrfTokenValue
        Else
            _antiXsrfTokenValue = Guid.NewGuid().ToString("N")
            Page.ViewStateUserKey = _antiXsrfTokenValue
            Dim responseCookie = New HttpCookie(AntiXsrfTokenKey) With {
                .HttpOnly = True,
                .Value = _antiXsrfTokenValue
            }

            If FormsAuthentication.RequireSSL AndAlso Request.IsSecureConnection Then
                responseCookie.Secure = True
            End If

            Response.Cookies.[Set](responseCookie)
        End If

        AddHandler Page.PreLoad, AddressOf master_Page_PreLoad
    End Sub

    Protected Sub master_Page_PreLoad(ByVal sender As Object, ByVal e As EventArgs)
        If Not IsPostBack Then
            ViewState(AntiXsrfTokenKey) = Page.ViewStateUserKey
            ViewState(AntiXsrfUserNameKey) = If(Context.User.Identity.Name, String.Empty)
        Else
            'if ((string)ViewState[AntiXsrfTokenKey] != _antiXsrfTokenValue
            '           || (string)ViewState[AntiXsrfUserNameKey] != (Session.SessionID ?? string.Empty))
            '       {

            '           Response.Redirect("/Error", false);
            '       }
            If CStr(ViewState(AntiXsrfTokenKey)) <> _antiXsrfTokenValue OrElse CStr(ViewState(AntiXsrfUserNameKey)) <> (If(Context.User.Identity.Name, String.Empty)) Then
                Dim a As String = CStr(ViewState(AntiXsrfTokenKey))
                Dim b As String = _antiXsrfTokenValue
                Dim c As String = CStr(ViewState(AntiXsrfUserNameKey))
                Dim d As String = (If(Context.User.Identity.Name, String.Empty))

                Throw New InvalidOperationException("Validation of Anti-XSRF token failed.")
            End If
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Request.Cookies("userID") Is Nothing And Not IsPostBack Then
            Dim str1 As String = Me.Request.FilePath
            Dim str2 As String = "/TM4-V2/Modules/Sale/Index/frmIndex.aspx"
            'Dim str2 As String = "/Tm4_v2/Modules/Sale/Index/frmIndex.aspx"
            If str1 <> str2 Then
                Response.Redirect("~/Modules/Sale/Index/frmIndex.aspx")
            End If
            NavigationMenu.Visible = False
        Else
            btnEnableMenu()
        End If

    End Sub

    Protected Sub btnEnableMenu()
        If Request.Cookies("UserLevel") IsNot Nothing Then

            Select Case Request.Cookies("UserLevel").Value
                Case 5
                    NavigationMenu.Items.RemoveAt(2)
                    NavigationMenu.Items.RemoveAt(2)
                    NavigationMenu.Items.RemoveAt(4)
                    'NavigationMenu.Items(3).ChildItems.RemoveAt(3)
                    NavigationMenu.Items(3).ChildItems.RemoveAt(2)
                    NavigationMenu.Items(3).ChildItems.RemoveAt(2)
                    NavigationMenu.Items(4).ChildItems.RemoveAt(0)
                    'NavigationMenu.Items.RemoveAt(4)
                Case 6
                    'Recoving  Add By na
                    NavigationMenu.Items.RemoveAt(2)
                    NavigationMenu.Items.RemoveAt(2)
                    NavigationMenu.Items.RemoveAt(4)
                    NavigationMenu.Items(3).ChildItems.RemoveAt(2)
                    NavigationMenu.Items(3).ChildItems.RemoveAt(2)
                    NavigationMenu.Items(4).ChildItems.RemoveAt(0)
                    NavigationMenu.Items.RemoveAt(2) 'ลบ งานหลังการขาย
                Case 12
                    NavigationMenu.Items.RemoveAt(2)
                    NavigationMenu.Items.RemoveAt(2)
                    NavigationMenu.Items.RemoveAt(4)
                    NavigationMenu.Items(3).ChildItems.RemoveAt(2)
                    NavigationMenu.Items(3).ChildItems.RemoveAt(2)
                    NavigationMenu.Items(4).ChildItems.RemoveAt(0)
                Case 2

                    NavigationMenu.Items.RemoveAt(1)
                    If Request.Cookies("TypeTsr").Value <> 3 Then
                        NavigationMenu.Items(1).ChildItems.RemoveAt(6)
                        NavigationMenu.Items(1).ChildItems.RemoveAt(6)
                        NavigationMenu.Items(2).ChildItems.RemoveAt(8)
                        NavigationMenu.Items(2).ChildItems.RemoveAt(8)
                        NavigationMenu.Items(2).ChildItems.RemoveAt(8)
                        NavigationMenu.Items(2).ChildItems.RemoveAt(8)
                    End If
                    '
                    NavigationMenu.Items(1).ChildItems(4).ChildItems.RemoveAt(9)
                    'NavigationMenu.Items(1).ChildItems(4).ChildItems.RemoveAt(8)
                    'NavigationMenu.Items(1).ChildItems(4).ChildItems.RemoveAt(10)
                    NavigationMenu.Items(2).ChildItems.RemoveAt(6)

                    NavigationMenu.Items(4).ChildItems.RemoveAt(2)

                Case 1
                    NavigationMenu.Items.RemoveAt(1)
                    If Request.Cookies("TypeTsr").Value <> 3 Then
                        NavigationMenu.Items(1).ChildItems.RemoveAt(6)
                        NavigationMenu.Items(1).ChildItems.RemoveAt(6)
                        NavigationMenu.Items(2).ChildItems.RemoveAt(8)
                        NavigationMenu.Items(2).ChildItems.RemoveAt(8)
                        NavigationMenu.Items(2).ChildItems.RemoveAt(8)
                        NavigationMenu.Items(2).ChildItems.RemoveAt(8)
                    End If
                    '
                    NavigationMenu.Items(1).ChildItems(4).ChildItems.RemoveAt(9)
                    'NavigationMenu.Items(1).ChildItems(4).ChildItems.RemoveAt(8)

                    NavigationMenu.Items(4).ChildItems.RemoveAt(2)
                Case 3
                    NavigationMenu.Items.RemoveAt(1)
                    If Request.Cookies("TypeTsr").Value <> 3 Then
                        NavigationMenu.Items(1).ChildItems(4).ChildItems.RemoveAt(6)
                        NavigationMenu.Items(1).ChildItems(4).ChildItems.RemoveAt(8)
                        NavigationMenu.Items(1).ChildItems(4).ChildItems.RemoveAt(8)
                        'NavigationMenu.Items(1).ChildItems(4).ChildItems.RemoveAt(9)
                        NavigationMenu.Items(1).ChildItems(4).ChildItems.RemoveAt(7) 'ใบอนุมัติส่วนลด
                        NavigationMenu.Items(1).ChildItems(4).ChildItems.RemoveAt(9) 'web asnreport
                        NavigationMenu.Items(1).ChildItems.RemoveAt(6)
                        NavigationMenu.Items(1).ChildItems.RemoveAt(6)
                        NavigationMenu.Items(1).ChildItems.RemoveAt(7)
                        NavigationMenu.Items(1).ChildItems.RemoveAt(7)
                        NavigationMenu.Items(2).ChildItems.RemoveAt(8)
                        NavigationMenu.Items(2).ChildItems.RemoveAt(8)
                        NavigationMenu.Items(2).ChildItems.RemoveAt(8)
                        NavigationMenu.Items(2).ChildItems.RemoveAt(8)

                    Else
                        NavigationMenu.Items(1).ChildItems.RemoveAt(9)
                        NavigationMenu.Items(1).ChildItems.RemoveAt(9)
                        NavigationMenu.Items(1).ChildItems(4).ChildItems.RemoveAt(10) 'web asn report
                        NavigationMenu.Items(1).ChildItems(4).ChildItems.RemoveAt(8)  'ใบอนุมัติส่วนลด
                        'NavigationMenu.Items(1).ChildItems(4).ChildItems.RemoveAt(10)
                    End If
                    NavigationMenu.Items(2).ChildItems.RemoveAt(5)
                    'NavigationMenu.Items(1).ChildItems(4).ChildItems.RemoveAt(7)

                    NavigationMenu.Items(4).ChildItems.RemoveAt(2)
                Case Else
                    NavigationMenu.Items.RemoveAt(1)
                    If Request.Cookies("TypeTsr").Value <> 3 Then
                        NavigationMenu.Items(1).ChildItems.RemoveAt(6)
                        NavigationMenu.Items(1).ChildItems.RemoveAt(6)
                        NavigationMenu.Items(1).ChildItems.RemoveAt(8)
                        NavigationMenu.Items(2).ChildItems.RemoveAt(8)
                        NavigationMenu.Items(2).ChildItems.RemoveAt(8)
                        NavigationMenu.Items(2).ChildItems.RemoveAt(8)
                        NavigationMenu.Items(2).ChildItems.RemoveAt(8)
                        NavigationMenu.Items(6).ChildItems.RemoveAt(0)
                    Else
                        NavigationMenu.Items(1).ChildItems.RemoveAt(10)
                        NavigationMenu.Items(6).ChildItems.RemoveAt(0)
                    End If
                    NavigationMenu.Items(1).ChildItems(4).ChildItems.RemoveAt(9) 'Retention 
                    NavigationMenu.Items(1).ChildItems(4).ChildItems.RemoveAt(9) 'web asn report
                    NavigationMenu.Items(1).ChildItems(4).ChildItems.RemoveAt(8) 'ใบอนุมัติส่วนลด
                    NavigationMenu.Items(1).ChildItems(4).ChildItems.RemoveAt(9) 'Sale Report Source
                    NavigationMenu.Items(4).ChildItems.RemoveAt(2)
            End Select
      
        End If
    End Sub
End Class

