﻿Imports System.Data
Imports System.Text

Partial Class Modules_Sale_Phone_frmCaseDownload
    Inherits System.Web.UI.Page
    Dim ISODate As New ISODate
    Protected Sub btnFind_Click(sender As Object, e As System.EventArgs) Handles btnFind.Click
        If txtdate1.Text <> "" And txtdate2.Text <> "" Then
            SqlCustomer.SelectCommand = GetQuery()
            GvData.DataSource = SqlCustomer
            GvData.DataBind()
        End If
    End Sub
    Protected Function GetQuery() As String
        Dim sb As New StringBuilder()
        sb = New StringBuilder()
        sb.Append(" select a1.AppID,a4.ProTypeName,a2.carid,a3.FNameTH+' '+ a3.LNameTH as 'Namecus',a1.Statusqc")        ' 
        sb.Append(" ,convert(varchar,a6.createdate,103)+' '+convert(varchar,a6.createdate,108) as QCSuccessDate")
        sb.Append(" from tblapplication a1 ")
        sb.Append(" inner join tblcar a2 on a1.idcar=a2.idcar")
        sb.Append(" inner join tblcustomer a3 on a1.cusid=a3.cusid")
        sb.Append(" inner join Tbl_ProductType a4 on a1.ProDuctID=a4.ProTypeID")
        sb.Append(" inner join tbluser a5 on a5.userid=a2.AssignTo")
        sb.Append(" inner join tblqc a6 on a6.appid=a1.appid and a6.statusqc='1'")
        sb.Append(" where a1.AppStatus=1")
        sb.Append(" and convert(date,a6.createdate,111) between '" + ISODate.SetISODate("en", txtdate1.Text) + "' and '" + ISODate.SetISODate("en", txtdate2.Text) + "'")
        sb.Append(" and a2.AssignTo =" + Request.Cookies("userID").Value)
        sb.Append(" order by a6.createdate")

        Return sb.ToString()
    End Function

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Request.Cookies("userID") Is Nothing Then
            Response.Redirect("~/Modules/Sale/Index/frmIndex.aspx")
        End If
    End Sub

    Protected Sub GvData_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvData.RowCommand
        If e.CommandName = "cv" Then
            '692867_Payment.jpg
            '692867_ใบคำขอเอาประกัน.jpg
            Dim strFileName1 As String = "D:\Line\" & GvData.DataKeys(e.CommandArgument).Item(0) & "\" & GvData.DataKeys(e.CommandArgument).Item(0) & "_ใบคำขอเอาประกัน.jpg"

            If ShowPdf(strFileName1, "Covernote_" + GvData.DataKeys(e.CommandArgument).Item(0).ToString()) = False Then
                strFileName1 = "D:\Line\" & GvData.DataKeys(e.CommandArgument).Item(0) & "\" & GvData.DataKeys(e.CommandArgument).Item(0) & "_ใบคำขอเอาประกัน_Reprint.jpg"
                ShowPdf(strFileName1, "Covernote2_" + GvData.DataKeys(e.CommandArgument).Item(0).ToString())
            End If
           
        ElseIf e.CommandName = "pv" Then
            Dim strFileName1 As String = "D:\Line\" & GvData.DataKeys(e.CommandArgument).Item(0) & "\" & GvData.DataKeys(e.CommandArgument).Item(0) & "_Payment.jpg"
            If ShowPdf(strFileName1, "Payment_" + GvData.DataKeys(e.CommandArgument).Item(0).ToString()) = False Then
                strFileName1 = "D:\Line\" & GvData.DataKeys(e.CommandArgument).Item(0) & "\" & GvData.DataKeys(e.CommandArgument).Item(0) & "_Payment_Reprint.jpg"
                ShowPdf(strFileName1, "Payment2_" + GvData.DataKeys(e.CommandArgument).Item(0).ToString())
            End If
        End If
    End Sub
    Protected Function ShowPdf(ByVal strFileName As String, ByVal str As String) As Boolean
        Dim c As Boolean = False
        Try
            Response.ClearContent()
            Response.ClearHeaders()
            Response.AddHeader("Content-Disposition", "inline;filename=" + str + ".jpg")
            Response.ContentType = "application/JPEG"
            Response.WriteFile(strFileName)
            Response.Flush()
            Response.Clear()
            c = True
        Catch ex As Exception

        End Try
        Return c
    End Function
End Class
