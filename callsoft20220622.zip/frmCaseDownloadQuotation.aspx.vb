﻿Imports CrystalDecisions.Shared
Imports CrystalDecisions.CrystalReports.Engine
Partial Class Modules_Sale_Phone_frmCaseDownloadQuotation
    Inherits System.Web.UI.Page
    Dim ISODate As New ISODate
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Request.Cookies("userID") Is Nothing Then
            Response.Redirect("~/Modules/Sale/Index/frmIndex.aspx")
        End If
    End Sub
    Protected Sub MsgBox(ByVal strMassage As String)
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('" & strMassage & "');", True)
    End Sub
    Private Sub btnclick()
        If txtdate1.Text <> "" And txtdate2.Text <> "" Then
            SqlSendFax2.SelectCommand = GetQuery()
            GvData.DataSource = SqlSendFax2
            GvData.DataBind()
        Else
            MsgBox("วันที่ที่ต้องค้นหา ")
        End If
    End Sub
    Protected Sub btnFind_Click(sender As Object, e As System.EventArgs) Handles btnFind.Click
       btnclick()
    End Sub
    Protected Function GetQuery() As String
        Dim sb As New StringBuilder()
        sb = New StringBuilder()
        sb.Append(" SELECT a1.faxid,a1.idcar,a1.FaxNo,a1.CarBrand,a1.CarSeries,a1.CarID,convert(varchar,a1.CreateDate,103)+' '+convert(varchar,a1.CreateDate,108) as CreateDate ")        ' 
        sb.Append(" ,case  a1.SendStatus when '0' then 'รอส่ง' when '2' then 'รอตรวจสอบ' when '1' then 'ส่งเรียบร้อย' else '' end as StatusSend")
        sb.Append(" ,case  a1.SendStatus when '0' then 'color:Red' when '2' then 'color:Gray' when '1' then 'color:Green' else '' end as ColorSend")
        sb.Append(" ,case  a1.TypeSend when '0' then 'ส่งFax' when '2' then 'LINE Official' else 'Email' end as TypeSendName  ")
        sb.Append(" ,isnull(a1.FNameTH,'-') + ' ' + isnull(a1.LNameTH,'-') as CusName")
        sb.Append(" from TblSendFax2   a1     ")
        sb.Append(" Where a1.CreateID= " + Request.Cookies("userID").Value)
        sb.Append(" and Convert(VarChar,a1.CreateDate,111) between '" + ISODate.SetISODate("en", txtdate1.Text) + "' and '" + ISODate.SetISODate("en", txtdate2.Text) + "'")
        sb.Append(" order by a1.createdate")

        Return sb.ToString()
    End Function
    Protected Sub GenReport(FaxID As String)

        Dim reportWord As New ReportDocument  ' Report Name 
        Dim reportname As String
        reportname = Server.MapPath("~/Modules/Sale/Report/rptQuotation2.rpt")

        Dim users As String = "sa"
        Dim pass As String = "asn@sr1"

        reportWord.Load(reportname)
        reportWord.SetDatabaseLogon(users, pass)
        reportWord.SetParameterValue("FaxID", FaxID)

        Dim CrExportOptions As ExportOptions
        Dim CrDiskFileDestinationOptions As New DiskFileDestinationOptions()
        Dim CrFormatTypeOptions As New PdfRtfWordFormatOptions()
        CrDiskFileDestinationOptions.DiskFileName = Server.MapPath("~/Tmp/Fax/Pdf/" & FaxID & ".pdf")
        CrExportOptions = reportWord.ExportOptions
        With CrExportOptions
            .ExportDestinationType = ExportDestinationType.DiskFile
            .ExportFormatType = ExportFormatType.PortableDocFormat
            .DestinationOptions = CrDiskFileDestinationOptions
            .FormatOptions = CrFormatTypeOptions
        End With
        reportWord.Export()
        reportWord.Close()
        reportWord.Dispose()

        Dim urlLink As String = "../../../Tmp/Fax/Pdf/" & FaxID & ".pdf"
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.open('" & urlLink & "','Fax');</script>")

    End Sub

    Protected Sub GvData_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvData.RowCommand
        If e.CommandName = "select" Then
            SqlSendFax2.UpdateParameters("FaxID").DefaultValue = e.CommandArgument
            SqlSendFax2.Update()
            Dim s As String = e.CommandArgument
            GenReport(s)
            btnclick()
        End If
    End Sub
   
End Class
