﻿
Partial Class Modules_Manager_Manage_Case_frmSendPVCVEtc
    Inherits System.Web.UI.Page
    Dim DataAccess As New DataAccess
    Dim ISODate As New ISODate
    Dim FunAll As New FuntionAll
	
    Protected Function GetQuery() As String
        Dim str As String = ""

        Dim date1 As String = ISODate.SetISODate("en", txtdate1.Text.Trim)
        Dim date2 As String = ISODate.SetISODate("en", txtdate2.Text.Trim)
       
        If ddTypedate.SelectedValue = "1" Then
            '1 วันที่คุ้มครอง
            str += " and  Convert(VarChar,TblApplication.ProtectDate,111) between '" + date1 + "' and '" + date2 + "'"

        ElseIf ddTypedate.SelectedValue = "0" Then
            str += " and  Convert(VarChar,TblApplication.SuccessDate,111) between '" + date1 + "' and '" + date2 + "'"

        ElseIf ddTypedate.SelectedValue = "2" Then
            str += " and  Convert(VarChar,tblapplication.QcSuccessDate,111) between '" + date1 + "' and '" + date2 + "'"

        ElseIf ddTypedate.SelectedValue = "3" Then
            str += " and TblLogsendlineoff.createid <>134 and Convert(VarChar,TblLogsendlineoff.createdate,111) between '" + date1 + "' and '" + date2 + "'"

        End If

        If Request.Cookies("UserLevel").Value = "1" Then
            If ddFromUser.SelectedValue = "0" Then
                str += "   and o.UserID in (select userid from tbluser   where UserStatus=1  and TypeTsr=3  and UserLevelID =3 and userid <> 5672)"
            Else
                str += "   and o.UserID =  " + ddFromUser.SelectedValue
            End If
        ElseIf Request.Cookies("UserLevel").Value = "2" Then
            If ddFromUser.SelectedValue = "0" Then
                str += "   and o.UserID in (select userid from tbluser   where UserStatus=1  and TypeTsr=3  and UserLevelID =3 and userid <> 5672 and LeaderID=" + Request.Cookies("userID").Value + ")"
            Else
                str += "   and o.UserID =  " + ddFromUser.SelectedValue
            End If
        ElseIf Request.Cookies("UserLevel").Value = "3" Then
            str += "   and o.UserID =  " + ddFromUser.SelectedValue
        End If


        If ddTypedate.SelectedValue = "1" Then
            str += "  order by tblapplication.ProtectDate    "
        ElseIf ddTypedate.SelectedValue = "0" Then
            str += "  order by tblapplication.SuccessDate    "
        ElseIf ddTypedate.SelectedValue = "2" Then
            str += "  order by tblapppay.AppointDate    "
        ElseIf ddTypedate.SelectedValue = "3" Then
            str += "  order by TblLogsendlineoff.createdate    "
        End If

        Return str
    End Function
	
    Sub GetShow()
        Sqlcondition.SelectCommand += GetQuery()
        GvUser.DataSource = Sqlcondition
        GvUser.DataBind()
        ChkSelectUser()
    End Sub
    Protected Sub ChkSelectUser()
        lblRecord.Text = GvUser.Rows.Count.ToString() + " รายการ"
    End Sub
    Protected Sub btn_ShowList_Click(sender As Object, e As System.EventArgs) Handles btn_ShowList.Click
        If txtdate1.Text.Trim <> "" And txtdate2.Text.Trim <> "" Then
            GetShow()
        End If
    End Sub
    Protected Sub GvUser_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvUser.RowCommand
        If e.CommandName = "OK" Then
            With Sqlcondition
                .UpdateParameters("appid").DefaultValue = GvUser.DataKeys(e.CommandArgument).Item(0)
                .Update()
            End With
            GetShow()
        ElseIf e.CommandName = "CV" Then
            '692867_Payment.jpg
            '692867_ใบคำขอเอาประกัน.jpg
            Dim strFileName As String = "D:\Line\" & GvUser.DataKeys(e.CommandArgument).Item(0) & "\" & GvUser.DataKeys(e.CommandArgument).Item(0) & "_ใบคำขอเอาประกัน.jpg"
            ShowPdf(strFileName)

        ElseIf e.CommandName = "PV" Then
            '692867_Payment.jpg
            '692867_ใบคำขอเอาประกัน.jpg
            Dim strFileName As String = "D:\Line\" & GvUser.DataKeys(e.CommandArgument).Item(0) & "\" & GvUser.DataKeys(e.CommandArgument).Item(0) & "_Payment.jpg"
            ShowPdf(strFileName)
        ElseIf e.CommandName = "Up" Then
            Dim ass As String = GvUser.DataKeys(e.CommandArgument).Item(2)
            With Sqlflaglineofficial
                .UpdateParameters("CusID").DefaultValue = GvUser.DataKeys(e.CommandArgument).Item(2)
                .UpdateParameters("flaglineofficial").DefaultValue = 1
                .Update()
            End With
            GetShow()
        End If
    End Sub

    Public Sub ShowPdf(ByVal strFileName As String)
        Response.ClearContent()
        Response.ClearHeaders()
        Response.AddHeader("Content-Disposition", "inline;filename=" + strFileName)
        Response.ContentType = "application/JPEG"
        Response.WriteFile(strFileName)
        Response.Flush()
        Response.Clear()
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
       
    End Sub

    Protected Sub btnHistory_Click(sender As Object, e As System.EventArgs) Handles btnHistory.Click
       Dim str As String = ""

        If Request.Cookies("UserLevel").Value = 1 Then
            str = " where 1=1   "
        ElseIf Request.Cookies("UserLevel").Value = 2 Then
            str = " where TblLogsendlineoff.sendid in (select userid from tbluser  where TypeTsr=3 and UserLevelID=3 and userid<> 5672   and LeaderID=" & Request.Cookies("userID").Value & " )   "
        Else
            str = " where TblLogsendlineoff.sendid =" & Request.Cookies("UserId").Value
        End If


        If Datesend.Checked And txtd1h.Text.Trim <> "" And txtd2h.Text.Trim <> "" Then
            Dim date1 As String = ISODate.SetISODate("en", txtd1h.Text.Trim)
            Dim date2 As String = ISODate.SetISODate("en", txtd2h.Text.Trim)
            str += "   and  Convert(VarChar,TblLogsendlineoff.senddate,111) between '" + date1 + "' and '" + date2 + "'"

        ElseIf carid.Checked And txtcarid.Text.Trim <> "" Then
            str += "   and tblcar.carid like '%" + txtcarid.Text.Trim + "%' "
        End If
        str += " order by TblLogsendlineoff.senddate"
		
        SqlDataHistory.SelectCommand += str
        GvSendLine.DataSource = SqlDataHistory
        GvSendLine.DataBind()
    End Sub

    Protected Sub GvUser_DataBound(sender As Object, e As System.EventArgs) Handles GvUser.DataBound
        For i As Integer = 0 To GvUser.Rows.Count - 1
            Dim ImageButton4 As Button = FunAll.ObjFindControl("btnud", GvUser.Rows(i).Cells(6))

            If GvUser.DataKeys(i).Item(1) = "0" Then
                GvUser.Rows(i).Cells(6).BackColor = Drawing.Color.Red
                ImageButton4.BackColor = Drawing.Color.Red
            ElseIf GvUser.DataKeys(i).Item(1) = "1" Then
                GvUser.Rows(i).Cells(6).BackColor = Drawing.Color.Green
                ImageButton4.Visible = False
            End If
        Next
    End Sub
End Class
