﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Globalization


Partial Class Modules_Sale_Phone_frmPhone
    Inherits System.Web.UI.Page
    Dim FunAll As New FuntionAll
    Dim StrQryProvince As New QueryProvince
    Public strsrc As String
    Public TelAjax As String = ""
    Dim ISODate As New ISODate
    Dim StrQuery As New QueryPhone
    Dim com As SqlCommand
    Dim Conn As New SqlConnection(ConfigurationManager.ConnectionStrings("asnbroker").ConnectionString)
    Public strProtype As String
    Dim dt As New DataTable
    Dim DataAccess As New DataAccess
    Dim dtGetAppPhotos As DataTable
    Public strRecoving As String
	Private strappid As String = ""

    'Private Property RBSelectConditionLINE As Object

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim mnList As Menu = CType(Master.FindControl("NavigationMenu"), Menu)
        mnList.Visible = False
        If Not IsPostBack Then
            ViewState("StartTime") = DateTime.Now
            If Request.Cookies("TypeTsr").Value = 6 Then
                frmRecruit.Visible = True
            Else
                frmRecruit.Visible = False
            End If
        End If
        ' 
        If Request.Cookies("TypeTsr").Value = 3 Then 'sale ปีต่อ จะเห็นข้อมูลปีต่อ
            FormViewDetailRenew.Visible = True
        Else
            FormViewDetailRenew.Visible = False
        End If
        'การมองเห็น Recoving
        Select Case Request.Cookies("TypeTsr").Value
            Case 3
                strRecoving = "frmHistoryRecoving.aspx?IdCar=" & Request.QueryString("IdCar")
            Case Else
                strRecoving = ""
        End Select
    End Sub

#Region "Address"
    Protected Sub frmAddr_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmAddr.DataBound
        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)

        FunAll.ListDropDown(ddDist, StrQryProvince.TblZipCodeBindDist(ddProvince.SelectedValue), "Dist", "Dist")
        'Dim str As String = frmAddr.DataKey.Item(0)
        FunAll.ListDropDown(ddSubDist, StrQryProvince.TblZipCodeBindSubDist(frmAddr.DataKey.Item(0).ToString.Trim, ddProvince.SelectedValue), "SubDist", "SubDist")

        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(frmAddr.DataKey.Item(1).ToString.Trim, ddProvince.SelectedValue, frmAddr.DataKey.Item(0).ToString.Trim), "ZipCode", "ZipCode")

        If ddDist.Items.Count > 0 Then
            ddDist.SelectedValue = frmAddr.DataKey.Item(0).ToString.Trim

        End If

        If ddSubDist.Items.Count > 0 Then
            ddSubDist.SelectedValue = frmAddr.DataKey.Item(1).ToString.Trim

        End If

        If ddZipCode.Items.Count > 0 Then
            ddZipCode.SelectedValue = frmAddr.DataKey.Item(2).ToString.Trim

        End If
    End Sub

    Protected Sub ddProvince_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)

        FunAll.ListDropDown(ddDist, StrQryProvince.TblZipCodeBindDist(ddProvince.SelectedValue), "Dist", "Dist")
        FunAll.ListDropDown(ddSubDist, StrQryProvince.TblZipCodeBindSubDist(ddDist.SelectedValue, ddProvince.SelectedValue), "SubDist", "SubDist")
        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(ddSubDist.SelectedValue, ddProvince.SelectedValue, ddDist.SelectedValue), "ZipCode", "ZipCode")


    End Sub

    Protected Sub ddDist_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)
        FunAll.ListDropDown(ddSubDist, StrQryProvince.TblZipCodeBindSubDist(ddDist.SelectedValue, ddProvince.SelectedValue), "SubDist", "SubDist")
        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(ddSubDist.SelectedValue, ddProvince.SelectedValue, ddDist.SelectedValue), "ZipCode", "ZipCode")

    End Sub

    Protected Sub ddSubDist_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)

        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(ddSubDist.SelectedValue, ddProvince.SelectedValue, ddDist.SelectedValue), "ZipCode", "ZipCode")

    End Sub
#End Region

#Region "Tel Call"
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Try
           UpdateTblUser()
            GetSoftPhone()

        Catch ex As Exception
            ScriptManager.RegisterClientScriptBlock(UpdatePanel1, GetType(UpdatePanel), UpdatePanel1.ClientID, "alert('ไม่สามารถโทรออกได้เนื่องจาก : " & ex.Message & "');", True)
        End Try

    End Sub
    Protected Sub UpdateTblUser()
        'update Tbluser TsrTel=เบอร์ลูกค้าที่โทรออก GetPhoneNumber(),TsrFlagCall=0 where Userid=Request.Cookies("userID").Value
        Dim strq As String = "Update tbluser set TsrFlagCall=0 ,TsrTel='" & GetPhoneNumber() & "' where userid=" & Request.Cookies("userID").Value
        CheckConnectionState()
        com = New SqlCommand(strq, Conn)
        com.ExecuteNonQuery()
    End Sub
    Protected Function checkPhoneNumber() As Boolean
        'dt = New DataTable
        'Dim strqry As String
        'strqry = "Select * from TblBlackListCALL Where Mobile = '" & GetPhoneNumber() & "'"
        'dt = DataAccess.DataRead(strqry)
        'If dt.Rows.Count > 0 Then
        '    ScriptManager.RegisterClientScriptBlock(UpdatePanel1, GetType(UpdatePanel), UpdatePanel1.ClientID, "alert('เบอร์โทรติด Blacklist ไม่สามารถโทรออกได้');", True)
        '    Return False
        'Else
        '    Return True
        'End If
		
		Dim chk As Int16 = 0
        Dim mess As String = ""
        chk = processblacklist(mess)
		If chk = 0 Then
            Return True
        Else
            'ScriptManager.RegisterClientScriptBlock(UpdatePanel1, GetType(UpdatePanel), UpdatePanel1.ClientID, "alert('" & mess & "');", True)
			lblPhone.Text = "Blacklist"
            ImageButton1.Visible = False
            btntryit.Visible = False
			Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('" & mess & "');", True)
			Return False
               
		End If
		
    End Function
	Protected Function Msgblacklistphone(ByVal dt As DataTable) As String




        Return "\r\n" & "ชื่อ :" & dt.Rows(0).Item("FNameTH").ToString() & " สกุล :" & dt.Rows(0).Item("LNameTH").ToString() & "\r\n" &
      " บัตร :" & dt.Rows(0).Item("CardID").ToString() & "\r\n" &
      " เบอร์โทร :" & dt.Rows(0).Item("tel").ToString() & "\r\n" &
      " หมายเหตู :" & dt.Rows(0).Item("Comments").ToString() & "\r\n" &
       " โดย :" & dt.Rows(0).Item("emp").ToString() & " เมื่อ :" & dt.Rows(0).Item("CreateDate").ToString()

    End Function
	
	Protected Function processblacklist(ByRef mess As String) As Int16
        Dim txtFNameTH As String = frmCus.DataKey.Item(7)
        Dim txtLNameTH As String = frmCus.DataKey.Item(8)
        Dim txtphone As String = GetPhoneNumber()
        Dim txtcardid As String = frmCus.DataKey.Item(9)

        Dim chkkk As Int16 = 0
        Dim dt As New DataTable
        Dim callbk As New callblacklist
        dt = callbk.chkblacklist(1, txtFNameTH, txtLNameTH)
        If dt.Rows.Count > 0 Then
            mess = "ชื่อ-สกุล ดังกล่าว เป็นเคสBlacklist :: " & Msgblacklistphone(dt)
            chkkk = 1
        Else
            dt = New DataTable
            If txtphone <> "" Then
                dt = callbk.chkblacklist(2, txtphone, "")
            End If

            If dt.Rows.Count > 0 Then
                chkkk = 2
                mess = "เบอร์ ดังกล่าว เป็นเคสBlacklist :: " & Msgblacklistphone(dt)
           Else
                dt = New DataTable
                If txtcardid <> "" Then
                    dt = callbk.chkblacklist(5, txtcardid, "")
                End If

                If dt.Rows.Count > 0 Then
                    chkkk = 5
                    mess = "เลขบัตรปปช. ดังกล่าว เป็นเคสBlacklist :: " & Msgblacklistphone(dt)
                Else
                    chkkk = 0
                End If
            End If
        End If
	

        Return chkkk
    End Function


    Protected Function GetPhoneNumber() As String
        Select Case ddCall.SelectedValue
            Case 1

                Return frmTel.DataKey.Item(0).ToString
            Case 2

                Return frmTel.DataKey.Item(1).ToString
            Case 3

                Return frmTel.DataKey.Item(2).ToString
            Case 4

                Return frmTel.DataKey.Item(3).ToString
            Case 5

                Return frmTel.DataKey.Item(4).ToString
            Case Else
                Return ""
        End Select
    End Function

    Protected Sub GetSoftPhone()
        If checkPhoneNumber() = True Then
			Dim str As String = ""
            str = check_conent()
            If str = "consent" Then
				Dim CallUrl As String = ""

				CallUrl += Replace(ConfigurationManager.AppSettings("WebCall"), "@IpAsserisk", Request.Cookies("IpAsterisk").Value) & "to=" & GetPhoneNumber() & "&&from=" & Request.Cookies("Extension").Value & "&&refer1=" & Request.QueryString("IdCar").ToString
				CallUrl += "&refer2=" & Request.Cookies("userID").Value
				TelAjax = CallUrl
				LinkSoftPhone()
				With SqlDataSourceLineID
               	 .InsertParameters("Tel_Path").DefaultValue = CallUrl
               	 .Insert()
				End With
			End If
			
            If str = "" Then
                lblPhone.Text = ""
                ImageButton1.Visible = False
                btntryit.Visible = False
            Else
                ToShow(str)
            End If
		Else
            lblPhone.Text = "Blacklist"
            ImageButton1.Visible = False
            btntryit.Visible = False		
			
        End If
		
    End Sub

    Protected Sub LinkSoftPhone()
        If Request.QueryString("Call").ToString = 1 And Request.Cookies("Extension").Value <> "0000" And Request.Cookies("Extension").Value <> "" And Request.Cookies("TypeTsr").Value <> 3 And Request.Cookies("TypeTsr").Value <> 6  Then
            strsrc = "SoftPhone.aspx?" & Request.ServerVariables("QUERY_STRING").ToString() & "&CallID=" & GetPhoneNumber()
        Else
            strsrc = ""
        End If
    End Sub


    Protected Sub frmTel_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmTel.DataBound
        If Not IsPostBack Then
            If Request.QueryString("Call").ToString = 1 And Request.Cookies("Extension").Value <> "0000" And Request.Cookies("Extension").Value <> "" And Request.Cookies("TypeTsr").Value <> 3 And Request.Cookies("TypeTsr").Value <> 6  Then
                UpdateTblUser()
                GetSoftPhone()
            End If



        End If
    End Sub
    Private Sub Appiont_Date()
        Date_S_E_Calendar()
        Dim DayToday As Date = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy"))).AddDays(0)
        If Request.Cookies("TypeTsr").Value <> 3 And Request.Cookies("TypeTsr").Value <> 6 Then
            If ddStatus.SelectedValue = 6 Then 'Follow Default Add 2 Day 
                Dim Day2A As Date = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy"))).AddDays(2)
                If ChkDateAppiont(Day2A) Then
                    txtAppoint.Text = Day2A.ToString("dd/MM/yyyy")
                    D.Text = Day2A.ToString("dd/MM/yyyy")
                    H.Text = "00"
                    M.Text = "00"
                    txtHour.Text = H.Text
                    txtMin.Text = M.Text
                Else
                    Dim Day1A As Date = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy"))).AddDays(1)
                    If ChkDateAppiont(Day1A) Then
                        txtAppoint.Text = Day1A.ToString("dd/MM/yyyy")
                        D.Text = Day1A.ToString("dd/MM/yyyy")
                        H.Text = "00"
                        M.Text = "00"
                        txtHour.Text = H.Text
                        txtMin.Text = M.Text

                    Else
                        txtAppoint.Text = DayToday.ToString("dd/MM/yyyy")
                        D.Text = DayToday.ToString("dd/MM/yyyy")
                        H.Text = Now.Hour.ToString
                        M.Text = Now.Minute.ToString
                        txtHour.Text = H.Text
                        txtMin.Text = M.Text
                    End If

                End If
            ElseIf ddStatus.SelectedValue = 7 Or ddStatus.SelectedValue = 8 Then 'CallBack ตามทุกวัน Default ทุก4 H
                txtAppoint.Text = DayToday.ToString("dd/MM/yyyy")
                D.Text = DayToday.ToString("dd/MM/yyyy")
                H.Text = (Now.AddHours(4)).ToString("HH")
                M.Text = Now.Minute.ToString
                txtHour.Text = H.Text
                txtMin.Text = M.Text
            End If
        End If
    End Sub
    Protected Sub ddStatus_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddStatus.SelectedIndexChanged
        ShowAppoint()
        Appiont_Date()
       ' LinkSoftPhone()
    End Sub

#End Region

    Private Function ChkDateAppiont(ByVal DayA As Date) As Boolean
        'Dim Add30Day As Date = CDate(DayA).AddDays(30)
        Dim txtCarBuyDate2 As DateTime = frmCar.DataKey.Item(4)

        If DayA <= txtCarBuyDate2 Then
            Return True
        Else
            Return False
        End If
    End Function
    'Show เวลานัด
    Protected Sub ShowAppoint()
        If ddStatus.SelectedValue = 5 Or ddStatus.SelectedValue = 9 Or ddStatus.SelectedValue = 41 Or ddStatus.SelectedValue = 12 Or ddStatus.SelectedValue = 11 Or ddStatus.SelectedValue = 7 Or ddStatus.SelectedValue = 27 Then
            If Request.Cookies("TypeTsr").Value = 3 And ddStatus.SelectedValue = 9 Then
                Panel1.Visible = True
            Else
                Panel1.Visible = False
            End If
        Else
            Panel1.Visible = True
        End If
    End Sub

    Protected Sub ddStatus_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddStatus.DataBound
        ShowAppoint()
    End Sub


#Region "Save Tblcustomer TblCar"

    'Address
    Protected Sub WebImageButton1_Click3(sender As Object, e As System.EventArgs)
        Try
            SaveTblCustomerAddr()

            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('บันทึกข้อมูลเรียบร้อย');", True)

        Catch ex As Exception
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้เนื่องจาก : " & ex.Message & "');", True)
        End Try
    End Sub

    Protected Sub SaveTblCustomerAddr()
        Dim txtAddr As TextBox = FunAll.ObjFindControl("txtAddr", frmAddr)
        Dim txtMoo As TextBox = FunAll.ObjFindControl("txtMoo", frmAddr)
        Dim txtViilege As TextBox = FunAll.ObjFindControl("txtViilege", frmAddr)
        Dim txtRoad As TextBox = FunAll.ObjFindControl("txtRoad", frmAddr)
        Dim txtSoi As TextBox = FunAll.ObjFindControl("txtSoi", frmAddr)

        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)

        With SqlCustomer
            .UpdateParameters("Address").DefaultValue = txtAddr.Text.Trim
            .UpdateParameters("Villege").DefaultValue = txtViilege.Text.Trim
            .UpdateParameters("Moo").DefaultValue = txtMoo.Text.Trim
            .UpdateParameters("Soi").DefaultValue = txtSoi.Text.Trim
            .UpdateParameters("Road").DefaultValue = txtRoad.Text.Trim
            .UpdateParameters("Dist").DefaultValue = ddDist.SelectedValue
            .UpdateParameters("Province").DefaultValue = ddProvince.SelectedValue
            .UpdateParameters("Zip").DefaultValue = ddZipCode.SelectedValue
            .UpdateParameters("SubDist").DefaultValue = ddSubDist.SelectedValue
            .UpdateParameters("CusID").DefaultValue = frmCus.DataKey.Item(0)
            .Update()
        End With
		
		 'log Customer
        Dim data02 As New data_customer
        data02.address = txtAddr.Text.Trim
        data02.villege = txtViilege.Text.Trim
        data02.moo = txtMoo.Text.Trim
        data02.soi = txtSoi.Text.Trim
        data02.dist = ddDist.SelectedValue
        data02.province = ddProvince.SelectedValue
        data02.zip = ddZipCode.SelectedValue
        data02.subdist = ddSubDist.SelectedValue
        data02.createid = Request.Cookies("userID").Value
        data02.cusid = frmCus.DataKey.Item(0)
        data02.comment = "TM4-V2_Modules_Sale_Phone_frmPhone.aspx.vb"
        Dim callcar As New callAPI_log
        callcar.log_customer(data02)
    End Sub


    Protected Sub WebImageButton1_Click(sender As Object, e As System.EventArgs)
        Try
            Dim txtCarBuyDate As TextBox = FunAll.ObjFindControl("txtCarBuyDate", frmCar)
            With SqlApp
                .UpdateParameters("CarBuyDate").DefaultValue = ISODate.SetISODate("en", txtCarBuyDate.Text.Trim)
                .Update()
            End With
            frmCar.DataBind()
            Appiont_Date()
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('บันทึกข้อมูลเรียบร้อย');", True)
        Catch ex As Exception
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้เนื่องจาก : " & ex.Message & "');", True)

        End Try


    End Sub

#End Region

    Protected Sub ImageButton2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        Dim NumberPhone As String = selectTelephone(1)
        'บ้าน
        If NumberPhone <> "" Then
            If chkTelephone(NumberPhone) Then
                UpdateTblCustomer(1)
            Else
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถแก้ไขเบอร์เดิมได้ ');", True)
            End If
        Else
            UpdateTblCustomer(1)
        End If
    End Sub

    Protected Sub ImageButton3_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        ' ที่ทำงาน
        Dim NumberPhone As String = selectTelephone(2)
        If NumberPhone <> "" Then
            If chkTelephone(NumberPhone) Then
                UpdateTblCustomer(2)
            Else
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถแก้ไขเบอร์เดิมได้ ');", True)
            End If
        Else
            UpdateTblCustomer(2)
        End If
    End Sub

    Protected Sub ImageButton4_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        'มือถือ
        Dim NumberPhone As String = selectTelephone(5)
        If NumberPhone <> "" Then
            If chkTelephone(NumberPhone) Then
                UpdateTblCustomer(5)
            Else
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถแก้ไขเบอร์เดิมได้ ');", True)
            End If
        Else
            UpdateTblCustomer(5)
        End If
    End Sub

    Protected Sub ImageButton5_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        'อื่นๆ1
        Dim NumberPhone As String = selectTelephone(4)
        If NumberPhone <> "" Then
            If chkTelephone(NumberPhone) Then
                UpdateTblCustomer(4)
            Else
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถแก้ไขเบอร์เดิมได้ ');", True)
            End If
        Else
            UpdateTblCustomer(4)
        End If
    End Sub

    Protected Sub ImageButton6_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(3)
    End Sub

    Protected Sub ImageButton7_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(7)
    End Sub

    Protected Sub ImageButton8_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs)
        'อื่นๆ2
        Dim NumberPhone As String = selectTelephone(8)
        If NumberPhone <> "" Then
            If chkTelephone(NumberPhone) Then
                UpdateTblCustomer(8)
            Else
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถแก้ไขเบอร์เดิมได้ ');", True)
            End If
        Else
            UpdateTblCustomer(8)
        End If
    End Sub

    Protected Sub UpdateTblCustomer(ByVal UpdateID As Integer)

        Try
            Dim txtTel As TextBox = FunAll.ObjFindControl("txtTel", frmTel)
            Dim txtTelExt As TextBox = FunAll.ObjFindControl("txtTelExt", frmTel)
            Dim txtOTel As TextBox = FunAll.ObjFindControl("txtOTel", frmTel)
            Dim txtOTelExt As TextBox = FunAll.ObjFindControl("txtOTelExt", frmTel)
            Dim txtMobile As TextBox = FunAll.ObjFindControl("txtMobile", frmTel)
            Dim txtFax As TextBox = FunAll.ObjFindControl("txtFax", frmTel)
            Dim txtOther As TextBox = FunAll.ObjFindControl("txtOther", frmTel)
            Dim txtOtherExt As TextBox = FunAll.ObjFindControl("txtOtherExt", frmTel)
            Dim txtEmail As TextBox = FunAll.ObjFindControl("txtEmail", frmTel)
            Dim txtOther3 As TextBox = FunAll.ObjFindControl("txtOther3", frmTel)
            Dim txtOtherExt3 As TextBox = FunAll.ObjFindControl("txtOtherExt3", frmTel)
            CheckConnectionState()
            com = New SqlCommand(StrQuery.UpdateTblCustomer(UpdateID), Conn)
            With com
                .Parameters.Clear()
                .Parameters.Add("@Tel", SqlDbType.VarChar).Value = txtTel.Text.Trim
                .Parameters.Add("@TelExt", SqlDbType.VarChar).Value = txtTelExt.Text.Trim
                .Parameters.Add("@OTel", SqlDbType.VarChar).Value = txtOTel.Text.Trim
                .Parameters.Add("@OTelExt", SqlDbType.VarChar).Value = txtOTelExt.Text.Trim
                .Parameters.Add("@Mobile", SqlDbType.VarChar).Value = txtMobile.Text.Trim
                .Parameters.Add("@OthTel1", SqlDbType.VarChar).Value = txtOther.Text.Trim
                .Parameters.Add("@OthTel1Ext", SqlDbType.VarChar).Value = txtOtherExt.Text.Trim
                .Parameters.Add("@OthTel2", SqlDbType.VarChar).Value = txtOther3.Text.Trim
                .Parameters.Add("@OthTel2Ext", SqlDbType.VarChar).Value = txtOtherExt3.Text.Trim
                .Parameters.Add("@Fax", SqlDbType.VarChar).Value = txtFax.Text.Trim
                .Parameters.Add("@Email", SqlDbType.VarChar).Value = txtEmail.Text.Trim
                .Parameters.Add("@CusID", SqlDbType.VarChar).Value = frmCus.DataKey.Item(0)
                .ExecuteNonQuery()

            End With
			
			'log Customer
            If UpdateID = 1 Or UpdateID = 2 Or UpdateID = 5 Then
                Dim str As String = ""
                Dim data02 As New data_customer
                If UpdateID = 1 Then
                    str = "บ้าน"
                    data02.tel = txtTel.Text.Trim
                ElseIf UpdateID = 2 Then
                    str = "ทำงาน"
                    data02.otel = txtOTel.Text.Trim
                ElseIf UpdateID = 5 Then
                    str = "มือถือ"
                    data02.mobile = txtMobile.Text.Trim
                End If
                data02.createid = Request.Cookies("userID").Value
                data02.cusid = frmCus.DataKey.Item(0)
                data02.comment = "TM4-V2_Modules_Sale_Phone_frmPhone.aspx.vb|" & str
                Dim callcar As New callAPI_log
                callcar.log_customer(data02)
            End If


            frmTel.ChangeMode(FormViewMode.ReadOnly)
            frmTel.DataBind()

            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('บันทึกข้อมูลเรียบร้อย');", True)
        Catch ex As Exception
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้เนื่องจาก : " & ex.Message & "');", True)

        End Try


        'BindLink()
    End Sub

    Public Sub CheckConnectionState()
        If Conn.State = ConnectionState.Open Then
            Conn.Close()
        Else
            Conn.Open()
        End If
    End Sub


    Protected Sub LinkButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton2.Click
        strProtype = "../Product/frmProType2.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    End Sub

    Protected Sub LinkButton3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton3.Click
        strProtype = "../Product/frmProType3Plus.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    End Sub

    Protected Sub LinkButton4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton4.Click
        strProtype = "../Product/frmProType3.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        strProtype = "../Product/frmProType1.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    End Sub

    Protected Sub LinkButton5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton5.Click
        'strProtype = "../Product/frmProType1.aspx?IdCar=" & frmCar.DataKey.Item(0)
        strProtype = "../Product/frmSendFax.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    End Sub
    'Protected Sub LinkButton6_Click(sender As Object, e As System.EventArgs) Handles LinkButton6.Click
    '    strProtype = "../Product/frmProType1.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    'End Sub

    Protected Sub WebImageButton3_Click(sender As Object, e As System.EventArgs) Handles WebImageButton3.Click
        frmAddr.DataBind()
        frmApp.DataBind()
        frmTel.DataBind()
        frmCar.DataBind()

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim strLink As String = "Edit=1&Buy=2"
        strLink += "&IdCar=" & frmCar.DataKey.Item(0)
        strLink += "&AppID=" & frmApp.DataKey.Item(0)
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.open('../Application/frmApplication.aspx?" & strLink & "','Application');</script>")
    End Sub



#Region "Save Status"
    Protected Sub WebImageButton1_Click2(sender As Object, e As System.EventArgs) Handles WebImageButton1.Click

        'If Request.Cookies("TypeTsr").Value <> 3 And Request.Cookies("TypeTsr").Value <> 6 Then
        '    Dim ss As Date = ISODate.SetISODate("th", txtAppoint.Text)
        '    Dim DayAppoint As Date = CDate(ISODate.SetISODate("th", ss.ToString("dd/MM/yyyy")))
        '    If ddStatus.SelectedValue = 6 Then
        '        If ChkDateAppiont30(DayAppoint) = False Then
        '            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้ เนื่องจากวันคุ้มครองน้อยกว่า 30 วัน');", True)
        '            Exit Sub
        '        End If
        '    End If
        'End If



        If ChkData() = True And CheckAppointDate() = True And chkSelectLINE() = True Then
            If chk90() = True And chkFollow2D() = True Then

                frmApp.DataBind()
                CheckConnectionState()
                If ChkRider() = True Then

                    'สำหรับลงสถานะ Success
                    If ddStatus.SelectedValue = 3 Or ddStatus.SelectedValue = 4 Then
                        UpdateApplication()
                    End If
                    InsertTblRecruit()
                    btnSaveCus()
                    SqlStatus.Update()
                    UpdateLINEID()

                    'สำหรับ DataMining
                    'If ddStatus.SelectedValue = 3 Then
                    '    InsertBaseDataMinning_bk()
                    '    UpdateBaseDataMinning_bk()
                    'End If

                    'Update 
                    SqlDataTblCallListTsr.Update()

                    Select Case Request.Cookies("UserLevel").Value
                        Case 5
                            Response.Redirect("frmCase.aspx")
                        Case 12
                            Response.Redirect("frmCase.aspx")

                        Case Else
                            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.close();</script>")
                    End Select
                End If
            Else
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้ เนื่องจากวันคุ้มครองน้อยกว่า 20 วัน ไม่สามารถเลือกสถานะ Follow/CallBack ได้');", True)
            End If
        Else
            If chkSelectLINE() = False Then
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('กรุณาเลือกข้อมูล LIND');", True)
            End If
        End If
        'Catch ex As Exception
        '    MsgBox(ex.Message)
        'End Try

        DaiNgernPoll()

    End Sub
    Protected Function chkSelectLINE() As Boolean
        Dim txtLINEID As TextBox = FunAll.ObjFindControl("txtLINEID", formviewLine)
        Dim RBSelectConditionLINE As RadioButtonList = FunAll.ObjFindControl("RBSelectConditionLINE", formviewLine)
        Dim chk As Boolean
        If RBSelectConditionLINE.SelectedValue = "1" Or RBSelectConditionLINE.SelectedValue = "2" Or RBSelectConditionLINE.SelectedValue = "3" Then
            If (RBSelectConditionLINE.SelectedValue = "1" Or RBSelectConditionLINE.SelectedValue = "2") And txtLINEID.Text <> "" Then
                chk = True
            ElseIf RBSelectConditionLINE.SelectedValue = "3" Then
                chk = True
            Else
                chk = False
            End If

        Else
            chk = False
        End If
        Return chk
    End Function

    'Protected Sub InsertBaseDataMinning_bk()
    '    With SqlDataMining
    '        .InsertParameters("FNameTH").DefaultValue = frmCus.DataKey.Item(7)
    '        .InsertParameters("LNameTH").DefaultValue = frmCus.DataKey.Item(8)
    '        .Insert()
    '    End With
    'End Sub
    Protected Function chk90() As Boolean
        Dim chk As Boolean
        Conn.Open()
        If (ddStatus.SelectedValue = 6 Or ddStatus.SelectedValue = 8) And (Request.Cookies("TypeTsr").Value = 1) Then
            Dim strqrychk As String = ""
            strqrychk += " SELECT case when year(carbuydate) <YEAR(GETDATE()) then datediff(day,getdate(),DATEADD(year,datediff(YEAR,CarBuyDate,GETDATE()),CarBuyDate)) else datediff(day,GETDATE(),carbuydate) end as cday FROM TblCar  where IdCar=" & frmCar.DataKey.Item(0)
            Dim Command As SqlCommand
            Dim DataReader As SqlDataReader
            Dim cday As Integer = 0
            Command = New SqlCommand(strqrychk, Conn)
            DataReader = Command.ExecuteReader()
            If DataReader.HasRows Then
                While DataReader.Read
                    If IsDBNull(DataReader("cday")) = False Then
                        cday = DataReader("cday")
                    End If
                End While
            End If
            DataReader.Close()
            If cday > 20 Then
                chk = True
            Else
                chk = False
            End If
        Else
            chk = True
        End If
        If chk = False And Request.Cookies("TypeTsr").Value <> 3 Then
            chk = True
        End If

        Conn.Close()
        Return chk
    End Function
    Protected Function chkFollow2D() As Boolean
        Dim chk As Boolean
        'Follow and typetsr=1
        If (Request.Cookies("TypeTsr").Value = 1) And (ddStatus.SelectedValue = 6) Then

            Dim AppointDate As DateTime = CDate(SortDateAppoint())
            Dim DateNow As DateTime = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy")) & " " & Now.Hour.ToString & ":" & Now.Minute.ToString)
            Dim nday As Integer
            nday = DateDiff(DateInterval.Day, CDate(DateNow), CDate(AppointDate))

            If nday > 7 Then
                chk = False
                MsgBox("ไม่สามารถนัดเวลาดังกล่าวได้เนื่องจากสถานะ Follow ระยะห่างในการนัดได้สูงสุด 7 วัน , ซึ่งขณะนี้ห่าง  " & nday & " วัน ")
            Else
                chk = True
            End If

        Else
            chk = True
        End If
        Return chk

    End Function

    'Protected Sub UpdateBaseDataMinning_bk()
    '    'Tel2,OTel2,Mobile2,OthTel2,OthTel3,TelExt,OTelExt,OthTel1,OthTel1Ext,OthTel3Ext
    '    With SqlDataMining
    '        .UpdateParameters("Tel").DefaultValue = frmTel.DataKey.Item(0).ToString
    '        .UpdateParameters("TelExt").DefaultValue = frmTel.DataKey.Item(5).ToString
    '        .UpdateParameters("OTel").DefaultValue = frmTel.DataKey.Item(1).ToString
    '        .UpdateParameters("OTelExt").DefaultValue = frmTel.DataKey.Item(6).ToString
    '        .UpdateParameters("Mobile").DefaultValue = frmTel.DataKey.Item(2).ToString
    '        .UpdateParameters("OthTel1").DefaultValue = frmTel.DataKey.Item(7).ToString
    '        .UpdateParameters("OthTel2").DefaultValue = frmTel.DataKey.Item(4).ToString
    '        .UpdateParameters("creditCARD").DefaultValue = frmApp.DataKey.Item(5).ToString
    '        .UpdateParameters("ACQ_FNAME").DefaultValue = frmCus.DataKey.Item(7)
    '        .UpdateParameters("ACQ_LNAME").DefaultValue = frmCus.DataKey.Item(8)
    '        .Update()
    '    End With
    'End Sub


    ''คำนวณ Status ของ Customer
    Protected Sub btnSaveCus()
        Dim CntStatusDB As Integer = frmCus.DataKey.Item(2)
        Dim CurStatusDB As String = frmCus.DataKey.Item(1)
        Dim StatusCur As String = ddStatus.SelectedValue


        If StatusCur = CurStatusDB Then

            If StatusCur = "8" And CntStatusDB >= 10 And Request.Cookies("TypeTsr").Value <> 6 And Request.Cookies("TypeTsr").Value <> 3 Then 'CallBack = 7 to AbanDon ยกเว้น webasn ปีต่อ
                UpdateStatus("13", "0")
            ElseIf StatusCur = "8" And CntStatusDB >= 10 And Request.Cookies("TypeTsr").Value = 6 Then 'CallBack = 10 to AbanDon TypeTsr 6 (WebAsn)
                UpdateStatus("13", "0")
            ElseIf StatusCur = "6" And CntStatusDB >= 10 And Request.Cookies("TypeTsr").Value <> 6 And Request.Cookies("TypeTsr").Value <> 3 Then 'Follow Unlimit to Three Plus
                'UpdateStatus("15", "0")
                UpdateStatus(StatusCur, (CntStatusDB + 1).ToString)
            ElseIf StatusCur = "7" And CntStatusDB >= 3 And Request.Cookies("TypeTsr").Value <> 3 Then 'NoContact = 7 to Unreach ยกเว้นปีต่อ
                UpdateStatus("14", "0")
            Else
                UpdateStatus(StatusCur, (CntStatusDB + 1).ToString)
            End If

        Else
            UpdateStatus(StatusCur, "0")
        End If

    End Sub
    Private Function ChkAppointDate() As Int16
        If txtHour.Text = H.Text And txtMin.Text = M.Text And txtAppoint.Text = D.Text Then
            'ไม่ตั้งใจนัด
            Return "2"
        Else
            'ตั้งใจนัด
            Return "1"
        End If

    End Function

    'Update Status Customer
    Protected Sub UpdateStatus(ByVal CurStatus As String, ByVal CntStatus As String)

        Dim flagAppoint As Int16 = ChkAppointDate()
        com = New SqlCommand(StrQuery.UpdateCus, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@CurStatus", SqlDbType.Int).Value = CurStatus
            .Parameters.Add("@CntStatus", SqlDbType.Int).Value = CntStatus
            .Parameters.Add("@Comments", SqlDbType.VarChar).Value = DirectCast(frmComments.FindControl("txtComments"), TextBox).Text.Trim
            .Parameters.Add("@AppointDate", SqlDbType.DateTime).Value = SortDateAppoint()
            .Parameters.Add("@IsAppoint", SqlDbType.Bit).Value = 1
            .Parameters.Add("@UpdateID", SqlDbType.Int).Value = Request.Cookies("userID").Value
            .Parameters.Add("@IDCar", SqlDbType.Int).Value = Request.QueryString("IdCar").ToString
            .Parameters.Add("@RefNo", SqlDbType.VarChar).Value = GetRefNo()
            .Parameters.Add("@Flag_AppointDate", SqlDbType.Int).Value = flagAppoint
            .CommandTimeout = 50
            .ExecuteNonQuery()

        End With

        SaveTblCall(CurStatus, CntStatus)
    End Sub

    'Insert TblCall
    Protected Sub SaveTblCall(ByVal CurStatus As String, ByVal Cntstatus As String)
        Dim txtComments As TextBox = DirectCast(frmComments.FindControl("txtComments"), TextBox)

        'Try

        com = New SqlCommand(StrQuery.SaveTblCall(), Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@CarID", SqlDbType.Int).Value = frmCus.DataKey.Item(3)
            .Parameters.Add("@IsOutbound", SqlDbType.Int).Value = 1
            .Parameters.Add("@CallOrder", SqlDbType.Int).Value = 0
            .Parameters.Add("@SubStatusID", SqlDbType.Int).Value = ddSubStatus.SelectedValue
            .Parameters.Add("@CntSubStatus", SqlDbType.Int).Value = Cntstatus
            .Parameters.Add("@CallDetail", SqlDbType.VarChar).Value = txtComments.Text.Trim
            .Parameters.Add("@StartTime", SqlDbType.DateTime).Value = ViewState("StartTime")
            .Parameters.Add("@CreateID", SqlDbType.Int).Value = Request.Cookies("userID").Value
            .Parameters.Add("@UpdateID", SqlDbType.Int).Value = Request.Cookies("userID").Value
            .Parameters.Add("@StatusID", SqlDbType.Int).Value = CurStatus
            .Parameters.Add("@telNUMBER", SqlDbType.VarChar).Value = GetPhoneNumber()
            .Parameters.Add("@IsNew", SqlDbType.VarChar).Value = frmCus.DataKey.Item(6)
            .Parameters.Add("@perCloseApp", SqlDbType.VarChar).Value = ddPercent.SelectedValue
            .CommandTimeout = 50
            .ExecuteNonQuery()
        End With

        'Catch ex As Exception
        '    MsgBox(ex.ToString)
        'End Try
    End Sub

    'Update Application
    Protected Sub UpdateApplication()
        com = New SqlCommand(StrQuery.UpdateApp, Conn)
        Dim userqc As String = GetUserQc()
        With com
            .Parameters.Clear()
            .Parameters.Add("@userIDQc", SqlDbType.VarChar).Value = userqc
            .Parameters.Add("@AppIP", SqlDbType.NVarChar).Value = "\\" & Request.ServerVariables("REMOTE_ADDR") & "\Recorder"
            .Parameters.Add("@userID", SqlDbType.NVarChar).Value = Request.Cookies("userID").Value
            .Parameters.Add("@TypeTsr", SqlDbType.NVarChar).Value = Request.Cookies("TypeTsr").Value
            .Parameters.Add("@AppID", SqlDbType.VarChar).Value = frmApp.DataKey.Item(0)
            .ExecuteNonQuery()
        End With

        'ลบลำดับ

        If userqc <> "684" Then
            Dim strqrychk As String = ""
            strqrychk += " select autoid,useridqc from tbl_LogAssignSaleQc where useridqc=" & userqc
            Dim dt1 As New DataTable
            dt1 = DataAccess.DataRead(strqrychk)

            If dt1.Rows.Count > 0 Then
                strqrychk = " DELETE FROM tbl_LogAssignSaleQc WHERE useridqc=@userID "
                com = New SqlCommand(strqrychk, Conn)
                With com
                    .Parameters.Clear()
                    .Parameters.Add("@userID", SqlDbType.VarChar).Value = userqc
                    .ExecuteNonQuery()
                End With
            End If
            strqrychk = " INSERT INTO tbl_LogAssignSaleQc (useridqc) VALUES ( @userID )"
            com = New SqlCommand(strqrychk, Conn)
            With com
                .Parameters.Clear()
                .Parameters.Add("@userID", SqlDbType.VarChar).Value = userqc
                .ExecuteNonQuery()
            End With
        End If
        'จบ


    End Sub
    'SqlDataSourceLineID
    Protected Sub UpdateLINEID()
        Dim txtLINEID As TextBox = FunAll.ObjFindControl("txtLINEID", formviewLine)
        Dim RBSelectConditionLINE As RadioButtonList = FunAll.ObjFindControl("RBSelectConditionLINE", formviewLine)
        If RBSelectConditionLINE.SelectedValue = "3" Then
            With SqlDataSourceLineID
                .UpdateParameters("LINEID").DefaultValue = ""
                .UpdateParameters("FlagLINE").DefaultValue = RBSelectConditionLINE.SelectedValue
                .UpdateParameters("CusID").DefaultValue = frmCus.DataKey.Item(0)
                .Update()
            End With
        Else
            With SqlDataSourceLineID
                .UpdateParameters("LINEID").DefaultValue = txtLINEID.Text
                .UpdateParameters("FlagLINE").DefaultValue = RBSelectConditionLINE.SelectedValue
                .UpdateParameters("CusID").DefaultValue = frmCus.DataKey.Item(0)
                .Update()
            End With
        End If

    End Sub

    'TblRecruit
    Protected Sub InsertTblRecruit()
        If frmRecruit.DataItemCount = 0 And Request.Cookies("TypeTsr").Value = 6 Then
            Dim ddStatus As DropDownList = FunAll.ObjFindControl("ddStatus", frmRecruit)
            Dim txtComments As TextBox = FunAll.ObjFindControl("txtComments", frmRecruit)
            If ddStatus.SelectedValue > 0 Then
                With SqlRecruit
                    .InsertParameters("StatusID").DefaultValue = ddStatus.SelectedValue
                    .InsertParameters("ReDesc").DefaultValue = txtComments.Text.Trim
                    .Insert()
                End With
            End If

        End If

    End Sub

    'Check การกรอกข้อมูล
    Protected Function ChkData() As Boolean

        frmTel.DataBind()
        If frmTel.DataKey.Item(0).ToString = "" And frmTel.DataKey.Item(1).ToString = "" And frmTel.DataKey.Item(2).ToString = "" And frmTel.DataKey.Item(3).ToString = "" And frmTel.DataKey.Item(4).ToString = "" Then
            MsgBox("กรุณากรอกเบอร์ลูกค้าอย่างน้อย 1 เบอร์ในระบบ")
            Return False

        End If

        If ddStatus.SelectedValue = 6 And ddPercent.SelectedValue = 0 Then
            MsgBox("กรุณาใส่ Percent (%) การปิดApp")
            Return False
        End If

        If ddStatus.SelectedValue = 99 Then
            MsgBox("กรุณาเลือกสถานะ")
            Return False
        ElseIf ddStatus.SelectedValue <> 3 And ddStatus.SelectedValue <> 4 And ddStatus.SelectedValue <> 5 And ddStatus.SelectedValue <> 27 And ddStatus.SelectedValue <> 9 And ddStatus.SelectedValue <> 41 And ddStatus.SelectedValue <> 12 And ddStatus.SelectedValue <> 11 And ddStatus.SelectedValue <> 7 Then

            If txtMin.Text.Trim = "" Or txtHour.Text.Trim = "" Then
                MsgBox("กรุณากรอกวันและเวลาให้ครบ")
                Return False

            ElseIf txtMin.Text.Trim > 60 Then
                MsgBox("เวลาของคุณผิดพลาด : นาทีต้องไม่เกิน 60")
                Return False
            ElseIf txtHour.Text.Trim > 24 Then
                MsgBox("เวลาของคุณผิดพลาด : ชั่วโมงต้องไม่เกิน 24")
                Return False
            Else
                Return True
            End If
        ElseIf ddStatus.SelectedValue = 3 Or ddStatus.SelectedValue = 4 Or ddStatus.SelectedValue = 25 Or ddStatus.SelectedValue = 26 Then

            If txtMin.Text.Trim = "" Or txtHour.Text.Trim = "" Then
                MsgBox("กรุณาระบุวันที่")
                Return False
            ElseIf txtMin.Text.Trim > 59 Or txtHour.Text > 24 Then
                MsgBox("กรุณาระบุเวลาผิดพลาด")
                Return False
            End If

            frmApp.DataBind()
            If frmApp.DataItemCount = 0 Then
                MsgBox("ไม่สามารถบันทึกได้เนื่องจากยังไม่มี App")
                Return False
            Else
                If frmApp.DataKey.Item(6).ToString = "" And frmApp.DataKey.Item(8) = "True" Then
                    MsgBox("กรุณาระบุเลขบัตรประชาชน ประกันสมัครใจ")
                    Return False
                End If

                If frmApp.DataKey.Item(7).ToString = "" And frmApp.DataKey.Item(9) = "True" Then
                    MsgBox("กรุณาระบุเลขบัตรประชาชน พรบ.")
                    Return False
                End If

                If checkAppPay() = False Then
                    MsgBox("ไม่มีข้อมูลงวดชำระเงิน")
                    Return False
                End If


                Return True

            End If
        Else
            Return True
        End If
    End Function

    Protected Function checkAppPay() As Boolean
        SqlAppPay.SelectParameters("appid").DefaultValue = frmApp.DataKey.Item(0)
        Dim dvSql As DataView = DirectCast(SqlAppPay.Select(DataSourceSelectArguments.Empty), DataView)
        If dvSql.Count > 0 Then

            Return True
        Else
            Return False
        End If
    End Function

    'Check การกรอกวันที่
    Protected Function CheckAppointDate() As Boolean
        Try

            If ddStatus.SelectedValue <> 5 And ddStatus.SelectedValue <> 27 And ddStatus.SelectedValue <> 9 And ddStatus.SelectedValue <> 41 And ddStatus.SelectedValue <> 12 And ddStatus.SelectedValue <> 11 Or ddStatus.SelectedValue <> 7 Then
                Dim AppointDate As DateTime = CDate(SortDateAppoint())
                Dim DateNow As DateTime = CDate(ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy")) & " " & Now.Hour.ToString & ":" & Now.Minute.ToString)

                If AppointDate < DateNow Then
                    MsgBox("ไม่สามารถนัดเวลาน้อยกว่าเวลาปัจจุบันได้ : " & DateNow & " < " & AppointDate)
                    Return False

                Else
                    Return True
                End If
            Else
                Return True
            End If
        Catch ex As Exception
            MsgBox("fotmat วันที่ผิดพลาด : จะต้องเป็น วัน/เดือน/ปี")
            Return False
        End Try


    End Function

    'จัดการเรียง วันที่นัด  วว ดด ปปปป  hh:mm
    Protected Function SortDateAppoint() As String
        'Dim AppointDateCV As String = ISODate.SetISODate("th", tbDay.Text.Trim & "/" & ddMonth.SelectedValue & "/" & ddYear.SelectedValue) & " " & tbHour.Text.Trim & ":" & tbMin.Text.Trim

        Dim AppointDateCV As String = ""
        If ddStatus.SelectedValue <> 5 And ddStatus.SelectedValue <> 27 And ddStatus.SelectedValue <> 9 And ddStatus.SelectedValue <> 41 And ddStatus.SelectedValue <> 12 And ddStatus.SelectedValue <> 11 And ddStatus.SelectedValue <> 7 Then
            Dim strdate As DateTime = ISODate.SetISODate("th", txtAppoint.Text)
            AppointDateCV = ISODate.SetISODate("th", strdate.ToString("dd/MM/yyyy")) & " " & txtHour.Text.Trim & ":" & txtMin.Text.Trim
        ElseIf ddStatus.SelectedValue = 7 Then
            Dim date1 As DateTime
            If Date.Now.DayOfWeek = DayOfWeek.Friday And DateTime.Now.Hour >= 14 Then
                date1 = DateTime.Now.AddDays(2)
            Else
                date1 = DateTime.Now.AddHours(4)
            End If
            AppointDateCV = ISODate.SetISODate("th", date1.ToString("dd/MM/yyyy")) & " " & date1.Hour & ":" & date1.Minute
        Else
            AppointDateCV = ISODate.SetISODate("th", DateTime.Today.ToString("dd/MM/yyyy")) & " " & DateTime.Now.Hour & ":" & DateTime.Now.Minute
        End If


        Return AppointDateCV

    End Function

    'Script MsgBox
    Public Sub MsgBox(ByVal sMsg As String)

        Dim sb As New StringBuilder()
        Dim oFormObject As System.Web.UI.Control
        sMsg = sMsg.Replace("'", "\'")
        sMsg = sMsg.Replace(Chr(34), "\" & Chr(34))
        sMsg = sMsg.Replace(vbCrLf, "\n")
        sMsg = "<script language=javascript>alert(""" & sMsg & """)</script>"

        sb = New StringBuilder()
        sb.Append(sMsg)

        For Each oFormObject In Me.Controls
            If TypeOf oFormObject Is HtmlForm Then
                Exit For
            End If
        Next

        ' Add the javascript after the form object so that the 
        ' message doesn't appear on a blank screen.
        oFormObject.Controls.AddAt(oFormObject.Controls.Count, New LiteralControl(sb.ToString()))
    End Sub

    'gen RefNo
    Protected Function GetRefNo() As String
        If frmCus.DataKey.Item(5).ToString.Length <> 13 Then
            Return FunAll.GetRefCar(frmCus.DataKey.Item(3))
        Else
            Return frmCus.DataKey.Item(5)
        End If
    End Function

    'GetQc
    Protected Function GetUserQc() As String
        dt = New DataTable
        dt = DataAccess.DataRead(StrQuery.SelectUserQc(GetTblAppPay))
        If dt.Rows.Count > 0 Then
            Dim str As String = dt.Rows(0).Item("useridqc").ToString
            Return dt.Rows(0).Item("useridqc")
        Else
            dt = New DataTable
            dt = DataAccess.DataRead(StrQuery.SelectUserQc("5"))
            If dt.Rows.Count > 0 Then
                Return dt.Rows(0).Item("useridqc")
            Else
                Return "3293"  'Nusataqc
            End If


        End If
    End Function

    Protected Function GetTblAppPay() As String
        dt = New DataTable
        dt = DataAccess.DataRead(StrQuery.SelectTblTypetsr(frmApp.DataKey.Item(0)))
        Dim strAppPay As String = ""
        If dt.Rows.Count > 0 Then
            If dt.Rows(0).Item("TypeTsr") = 3 Then
                strAppPay = "1" 'renew
            Else
                strAppPay = "2" 'out
            End If
        Else
            MsgBox("ไม่พบข้อมูล")
        End If


        Return strAppPay
    End Function

#Region "TakePhoto"
    'CheckProTypeID
    Protected Function ChkProType(ByVal ProID As String) As Boolean

        dt = New DataTable
        dt = DataAccess.DataRead(StrQuery.SelectTblProduct(ProID))
        If dt.Rows.Count > 0 And frmApp.DataKey.Item(2) = 1 Then
            If dt.Rows(0).Item("StatusPhoto") = True Then
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If

    End Function

    Protected Function ChkRider() As Boolean
        If ddStatus.SelectedValue = 4 Or ddStatus.SelectedValue = 3 Then
            If ChkProType(frmApp.DataKey.Item(1)) = True And frmApp.DataKey.Item(2) = 1 And TakePhotoOldApp() = True Then
                Return ChkTblAppointTakePhoto(frmCar.DataKey.Item(0), frmApp.DataKey.Item(0))
            Else
                Return True
            End If
        Else
            Return True
        End If
    End Function

    'Check App Photo สำหรับ ปีต่ออายุ
    Protected Function TakePhotoOldApp() As Boolean
        If Request.Cookies("TypeTsr").Value = 3 Or Request.Cookies("TypeTsr").Value = 11 Then
            Dim strqry As String = "select * from  TmpApp_CustRenew a1 Where IdCar =  " & frmCar.DataKey.Item(0)
            strqry += "  and a1.AppStatus = 1 and a1.FlagNewApp = 0"
            strqry += "  order by a1.CreateDate DESC "
            dt = New DataTable
            dt = DataAccess.DataRead(strqry)
            If dt.Rows.Count > 0 Then
                If dt.Rows(0).Item("ProductID") = frmApp.DataKey.Item(1) Then
                    'กรณีต่ออายุ และบริษัทประกันเดิมไม่ต้องให้ ASN ถ่ายรูป
                    Return False
                Else
                    Return True
                End If
            Else
                Return True
            End If
        Else
            Return True

        End If
    End Function

    'Check TblAppointTakePhoto
    Protected Function ChkTblAppointTakePhoto(ByVal IdCar As Integer, ByVal AppID As Integer) As Boolean
        Dim dtChk As New DataTable
        dtChk = GetTblAppointPhotos(IdCar)
        If dtChk.Rows.Count > 0 Then
            If dtChk.Rows(0).Item("Flag") <> 0 Then
                SqlRecruitStatus.DeleteParameters("appID").DefaultValue = AppID
                SqlRecruitStatus.Delete()
                InsertTblTakePhoto(dtChk, AppID)
                Return True
            Else
                Return True
            End If

        Else
            MsgBox("ไม่สามารถบันทึกได้ ไม่มีข้อมูลถ่ายรูปรถ")
            Return False
        End If
    End Function

    'ค้นหา TblAppointTakephoto
    Protected Function GetTblAppointPhotos(ByVal IdCar As String) As DataTable
        dtGetAppPhotos = New DataTable
        dtGetAppPhotos = DataAccess.DataRead(StrQuery.BindTblAppointTakephoto(IdCar))
        Return dtGetAppPhotos
    End Function

    Protected Sub InsertTblTakePhoto(ByVal dtPhoto As DataTable, ByVal AppID As Integer)
        com = New SqlCommand(StrQuery.InsertTblTakePhoto, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@CusID", SqlDbType.VarChar).Value = frmCus.DataKey.Item(0)
            .Parameters.Add("@idCAR", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("IdCar")
            .Parameters.Add("@appID", SqlDbType.VarChar).Value = AppID
            .Parameters.Add("@phID", SqlDbType.VarChar).Value = 2
            .Parameters.Add("@tID", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("tID")
            .Parameters.Add("@createID", SqlDbType.VarChar).Value = Request.Cookies("userID").Value
            .Parameters.Add("@appointDATE", SqlDbType.DateTime).Value = ISODate.SetISODate("th", CDate(dtPhoto.Rows(0).Item("appointDATE")).ToString("dd/MM/yyyy"))
            .Parameters.Add("@appointCOMMENT", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("Name")
            .Parameters.Add("@provinceDEST", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("Province")
            .Parameters.Add("@mainDEST", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("Dist")
            .Parameters.Add("@Destination", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("SubDist")
            .ExecuteNonQuery()
        End With


        com = New SqlCommand(StrQuery.UpdateAppTakePhoto, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@AppID", SqlDbType.VarChar).Value = AppID
            .ExecuteNonQuery()
        End With
    End Sub

#End Region
#End Region

    Protected Sub WebImageButton2_Click(ByVal sender As Object, e As System.EventArgs) Handles WebImageButton2.Click
        Select Case Request.Cookies("UserLevel").Value
            Case 5
                Response.Redirect("frmCase.aspx")
            Case 12
                Response.Redirect("frmCase.aspx")
            Case Else
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.close();</script>")
        End Select

    End Sub

    Protected Sub frmComments_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmComments.DataBound
        Dim txtComments As TextBox = FunAll.ObjFindControl("txtComments", frmComments)
        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)
        Dim strAddr As String = ""
        If ddDist.Items.Count = 0 Then

            strAddr += "|" & frmAddr.DataKey.Item(0).ToString.Trim
        End If

        If ddSubDist.Items.Count = 0 Then

            strAddr += "|" & frmAddr.DataKey.Item(1).ToString.Trim
        End If

        If ddZipCode.Items.Count = 0 Then

            strAddr += "|" & frmAddr.DataKey.Item(2).ToString.Trim
        End If

        If InStr(txtComments.Text.Trim, strAddr) Then
            txtComments.Text = Replace(txtComments.Text, strAddr, strAddr)
        Else
            txtComments.Text += strAddr
        End If
    End Sub

    Protected Sub WebImageButton4_Click(sender As Object, e As System.EventArgs) Handles WebImageButton4.Click
        Dim strlink As String = ""
        strlink = Request.QueryString("IdCar").ToString
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script> window.open ('http://10.17.1.230/tm4/" & strlink & "');</script>")
        'Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script> window.open ('file:///D:/" & strlink & "');</script>")
    End Sub

    Protected Sub WebImageButton5_Click(sender As Object, e As System.EventArgs) Handles WebImageButton5.Click
        Dim strLink As String = "Edit=0&Buy=3"
        strLink += "&IdCar=" & frmCar.DataKey.Item(5)
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.open('../Application/frmApplication.aspx?" & strLink & "','Application');</script>")
    End Sub


    Protected Sub ddSubStatus_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddSubStatus.SelectedIndexChanged
        'LinkSoftPhone()
    End Sub



    'Protected Sub Button3_Click(sender As Object, e As System.EventArgs) Handles Button3.Click
    '    With SqlDataMining
    '        .SelectParameters("FNameTH").DefaultValue = frmCus.DataKey.Item(7)
    '        .SelectParameters("LNameTH").DefaultValue = frmCus.DataKey.Item(8)
    '        .SelectParameters("BRAND_D").DefaultValue = frmCar.DataKey.Item(1)
    '    End With
    '    GvDataMind.Visible = True
    '    GvDataMind.DataBind()
    'End Sub

    Protected Sub frmCar_DataBound(sender As Object, e As System.EventArgs) Handles frmCar.DataBound
        If frmCar.DataItemCount > 0 Then
            SqlStatus.SelectParameters("StatusID").DefaultValue = frmCar.DataKey.Item(2)
        End If
    End Sub
    Protected Sub btnScript_Click(sender As Object, e As System.EventArgs) Handles btnScript.Click
        '1.ค้นหา APP
        Dim dtAppID As New System.Data.DataTable
        Dim dv As DataView = DirectCast(SqlAppConfirm.Select(DataSourceSelectArguments.Empty), DataView)
        dtAppID = dv.ToTable()
        If dtAppID.Rows.Count > 0 Then
            strappid = dtAppID.Rows(0)("AppID").ToString()
            '2.
            SetScript(strappid)
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "sett", "sett();", True)
        Else
            SetScript(0)
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "sett", "sett();", True)
            'Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ค้นหา APP ไม่พบกรุณาตรวจสอบ');", True)
        End If

    End Sub
    Protected Sub Date_S_E_Calendar()

        If Request.Cookies("TypeTsr").Value <> 3 And Request.Cookies("TypeTsr").Value <> 6 Then
            Dim DProtect As DateTime = frmCar.DataKey.Item(4)
            Dim DStatr As DateTime = DateTime.Now
            Dim DEnd As DateTime = DateTime.Now
            If ddStatus.SelectedValue = 6 Then
                '
                If DStatr.AddDays(6) <= DProtect Then
                    DEnd = DEnd.AddDays(7)
                Else
                    Dim DiffDate As Integer = DateDiff(DateInterval.Day, DStatr.AddDays(7), DProtect)
                    If DiffDate > 0 Then
                        DEnd = DEnd.AddDays(DiffDate)

                    Else

                        DEnd = DEnd.AddDays(7 + DiffDate - 1)

                    End If
                End If
                txtAppoint_CalendarExtender.StartDate = DStatr
                txtAppoint_CalendarExtender.EndDate = DEnd
            Else
                txtAppoint_CalendarExtender.StartDate = DStatr
                txtAppoint_CalendarExtender.EndDate = DStatr.AddDays(180)
            End If
        End If
    End Sub
    Protected Sub SetScript(ByVal strappid As String)

        Dim query = New System.Text.StringBuilder()

        query.Append("  select a.AppID,a.Idcar,d.InitTH+' '+c.FNameTH+' '+c.LNameTH as cusname,b.CarID, ")
        query.Append("  b.CarBrand,")
        query.Append("  b.CarSeries,")
        query.Append("  isnull(b.CarSize,'') as CarSize")
        query.Append("  ,b.CarYear")
        query.Append("  ,a8.Cartypename")
        query.Append("  ,e.ProTypeName,a7.TypeName,")
        query.Append("  case a.IsCarpet when 1 then '(รวม พรบ.)' else '(ไม่รวม พรบ.)'  end as lblCarpet,")
        query.Append(" case a.IsProvalue when 1 then CAST(a.ProValue as money)  else 0 end + case a.IsCarpet when 1 then CAST(a.CarPet as money)  else 0 end as ProValue,")

        query.Append(" day(a.ProtectDate) as PD,month(a.ProtectDate) as PM,year(a.ProtectDate)+543 as PY,")
        query.Append(" case a.IsProvalue when 1 then CAST(a.Car_Fire as money) else 0 end as Car_Fire,")
        query.Append(" case b.CarFixIn when '1' then 'อู่ ในเครือ'  else 'ศูนย์' end as IsFixIn ,")
        query.Append(" (select count(*) from tblapppay where appid=a.AppID) as CPay,")
        query.Append(" case b.CarDriverNo when 0  then 'ไม่ระบุผู้ขับขี่'  else 'ระบุผู้ขับขี่' end as lblCarDriverNo ")
        query.Append(" ,a.chkDeviceAdd,a.DetDeviceAdd,a.PriceDeviceAdd")
        query.Append("  ,tmp01.paycount ,a9.TotalPay,a7.TypeID  ")
        query.Append("  from tblapplication a  ")
        query.Append("  inner join tblcar b on a.Idcar=b.idcar ")
        query.Append("  inner join tblcustomer c on b.CusID=c.cusid ")
        query.Append("  inner join TblCustomerInit d on d.InitID=c.InitID")
        query.Append("  Inner Join Tbl_ProductType a6 on a.ProductID = a6.ProTypeID")
        query.Append("  Inner Join Tbl_Type a7 on a.Typeprovalue = a7.TypeID")
        query.Append("  inner join Tbl_CarType a8 on a8.Carno=b.CarType")
        query.Append("  Left  Join Tbl_ProductType e on  e.ProTypeID=a.ProDuctID ")
        query.Append("  inner join (select appid,count(*) as 'paycount' from tblapppay   group by appid) tmp01 on tmp01.appid=a.appid")
        query.Append("  inner join tblapppay a9 on a.appid=a9.appid and a9.PayID=1")
        query.Append("  Left  Join TblAppCard f on a.AppID=f.AppID")
        query.Append("  where  a.appid= " & strappid)


        Dim da As SqlDataAdapter = New SqlDataAdapter(query.ToString, Conn)
        Dim table As DataTable = New DataTable
        da.Fill(table)
        If table.Rows.Count > 0 Then
            txtpd.Text = table.Rows(0)("PD").ToString
            txtpm.Text = setMThai(table.Rows(0)("PM"))
            txtpy.Text = table.Rows(0)("PY").ToString
            txtCarYear.Text = table.Rows(0)("CarYear").ToString
            txtCarTYpe.Text = table.Rows(0)("Cartypename").ToString
            txtCarID.Text = table.Rows(0)("CarID").ToString
            txtCarBrand.Text = table.Rows(0)("CarBrand").ToString
            txtCarSeries.Text = table.Rows(0)("CarSeries").ToString
            txtCarSize.Text = table.Rows(0)("CarSize").ToString


            frmAddrConfirm.DataSource = SqlCustomerConfirm
            frmAddrConfirm.DataBind()

            frmAddrConfirms.DataSource = SqlCustomerConfirm
            frmAddrConfirms.DataBind()

            frmCusNameConfirm.DataSource = SqlCustomerConfirm
            frmCusNameConfirm.DataBind()

            If table.Rows(0)("TypeID").ToString() = "1" Then
                tb6etc.Visible = False
                tb61.Visible = True
                tb71.Visible = True
                tb81.Visible = True
                h1.Text = "บทปิดการขาย ประกันภัยประเภทชั้น 1"
               

                d4.Text = "ได้ยืนยันการต่ออายุประกันภัยรถยนต์ประเภท 1 แบบ <font color='red'>" & table.Rows(0)("lblCarDriverNo").ToString & "</font>&nbsp;กับ บริษัท&nbsp;<font color='red'>" & table.Rows(0)("ProTypeName").ToString & "</font><br />"
                d4.Text &= "&ensp;เป็นแบบซ่อม&nbsp;<font color='red'>" & table.Rows(0)("IsFixIn").ToString & "</font>&nbsp;ทุนประกันภัย&nbsp;<font color='red'>" & String.Format(CultureInfo.InvariantCulture, "{0:0,0.00}", table.Rows(0)("Car_Fire")) & "</font>"
                'txtProTypeName.Text = table.Rows(0)("ProTypeName").ToString
                d6.Text = "คุ้มครองอุปกรณ์ตกแต่งเพิ่มเติม"
                d7.Text = "7.&nbsp;เบี้ยประกนภัย <font color='red'>" & String.Format(CultureInfo.InvariantCulture, "{0:0,0.00}", table.Rows(0)("ProValue")) + " " + table.Rows(0)("lblCarpet").ToString & "</font>"
                'txtProTypeNameA.Text = table.Rows(0)("ProTypeName").ToString
                SqlAppPayDGVPay.SelectParameters("Appid").DefaultValue = strappid
                DGVPay.DataSource = SqlAppPayDGVPay
                DGVPay.DataBind()
                SqlAppCard2Confirm.SelectParameters("AppID").DefaultValue = strappid
                DGVAppCard.DataSource = SqlAppCard2Confirm
                DGVAppCard.DataBind()
               
                txtpaypeo.Text = String.Format(CultureInfo.InvariantCulture, "{0:0,0.00}", table.Rows(0)("TotalPay"))
                txtcountpay.Text = table.Rows(0)("paycount").ToString

                If table.Rows(0)("chkDeviceAdd").ToString = "1" Then
                    txtDeviceDetail.Text = table.Rows(0)("DetDeviceAdd").ToString + ": " + table.Rows(0)("PriceDeviceAdd").ToString
                Else
                    txtDeviceDetail.Text = ""
                End If

               
                d8.Text = "8.&nbsp;หลังจากชําระเงินแล้ว จะมีเจ้าหน้าที่ประงานงานถ่ายรูปรถอีกครั้ง"
                d9.Text = "9.&nbsp;กรมธรรม์เดิมปีที่แล้วเป็นของบริษัทอะไรครับ/คะ"

                d10.Text = "10.&nbsp;เพื่อยืนยันการเป็นผู้ครองครองรถยนต์ รบกวนแจ้งเลขบัตรประจําตัวประชาชน 13 หลักด้วย ครับ/ค่ะ"
                d11.Text = "11.&nbsp;บริษัท ASN Broker จํากัด (มหาชน) เลขที่ใบอนุญาตของบริษัท ว. 00027/2548 ขออนุญาตแจ้งงานเข้าบริษัทประกันภัยเลย"
                d12.Text = "12.&nbsp;แจ้งชื่อ-สกุล และเลขที่ใบอนุญาตตัวเอง เป็นเจ้าหน้าที่ดูแลลูกค้าในปีนี้"
                d13.Text = "13.&nbsp;หากได้รับเอกสารเรียบร้อยแล้ว รบกวนตรวจสอบความถูกต้องในเอกสารอยางละเอียดอีกครั้ง หากมีข้อมูลส่วนใดไม่ถูกต้องรบกวนติดต่อกลับเพื่อดําเนินการแก้ไข<br />ที่เบอร์ 02-4948377 ในวันและเวลาทําการ ครับ/ค่ะ"
                d14.Text = "14.&nbsp;ทางบริษัท ASN Broker จํากัด(มหาชน) และบริษัทประกันภัย&nbsp;<font color='red'>" & table.Rows(0)("ProTypeName").ToString & "</font>" & " เป็นผู้ดูแลลูกค้าในปีนี้ หากมีเจ้าหน้าที่ท่านอื่นติดต่อเข้ามา <br />รบกวนแจ้งว่า ได้ทําประกันภัยไปแล้ว นะครับ/คะ และบริษัทของเราไม่มีระบบส่งเจ้าหน้าที่ไปเก็บเงินลุกค้าที่บ้านนะครับ/คะ อย่าหลงเชื่อถ้ามีเจ้าหน้าที่ไปเก็บเงินที่บ้าน<br />"

            Else
                tb6etc.Visible = True
                tb6etc.Visible = True
                tb61.Visible = False
                tb71.Visible = False
                tb81.Visible = False

                '2: ชั้น(3)
                '3	ชั้น 3+   
                '4	ชั้น 2+   
                '6: ชั้น(2 + DD)
                '7: ชั้น(3 + DD)
                '9	ชั้น 1+ 
                '14	ชั้น 1 DD 
                If table.Rows(0)("TypeID").ToString() = "2" Then 'ชั้น(3)
                    h1.Text = "บทปิดการขาย ประกันภัยประเภท 3 ธรรมดา"
                    d4.Text = "ได้ยืนยันการต่ออายุประกันภัยรถยนต์ประเภท 3 ไม่คุ้มครองรถยนต์ผู้เอาประกันภัย"
                ElseIf table.Rows(0)("TypeID").ToString() = "3" Or table.Rows(0)("TypeID").ToString() = "7" Then 'ชั้น(3+) ชั้น(3 + DD)
                    h1.Text = "บทปิดการขาย ประกันภัยประเภท 3+"
                    d4.Text = "ได้ยืนยันการต่ออายุประกันภัยรถยนต์ <b><u>ประเภท 3+ </u></b>เป็นประเภทเคลมสด รถชนรถเท่านั้น &nbsp;กับ บริษัท&nbsp;<font color='red'>" & table.Rows(0)("ProTypeName").ToString & "</font>&nbsp;ทุนประกันภัย&nbsp;<font color='red'>" & String.Format(CultureInfo.InvariantCulture, "{0:0,0.00}", table.Rows(0)("Car_Fire")) & "</font>"

                ElseIf table.Rows(0)("TypeID").ToString() = "4" Or table.Rows(0)("TypeID").ToString() = "6" Then 'ชั้น(2+) ชั้น(2 + DD)
                    h1.Text = "บทปิดการขาย ประกันภัยประเภท 2+"
                    d4.Text = "ได้ยืนยันการต่ออายุประกันภัยรถยนต์ประเภท 2+ เป็นประเภทเคลมสด รถชนรถเท่านั้น คุ้มครองศูนย์หายไฟไหม้ตามทุนประกัน &nbsp;กับ บริษัท&nbsp;<font color='red'>" & table.Rows(0)("ProTypeName").ToString & "</font>&nbsp;ทุนประกันภัย&nbsp;<font color='red'>" & String.Format(CultureInfo.InvariantCulture, "{0:0,0.00}", table.Rows(0)("Car_Fire")) & "</font>"

                ElseIf table.Rows(0)("TypeID").ToString() = "9" Or table.Rows(0)("TypeID").ToString() = "14" Then 'ชั้น 1+  	ชั้น 1 DD 
                    h1.Text = "บทปิดการขาย ประกันภัยประเภท 1+"
                    d4.Text = "ได้ยืนยันการต่ออายุประกันภัยรถยนต์ประเภท 1 พิเศษ ซึ่งผู้เอาประกันภัยต้องรับผิดชอบต่อความเสียหายส่วนแรก 3,000 บาท ทุกกรณียกเว้นการเคลมที่เกิดจากกรณีรถชนรถ &nbsp;กับ บริษัท&nbsp;<font color='red'>" & table.Rows(0)("ProTypeName").ToString & "</font>&nbsp; เป็นประกันภัยแบบซ่อมอู่ ในเครือ ทุนประกันภัย&nbsp;<font color='red'>" & String.Format(CultureInfo.InvariantCulture, "{0:0,0.00}", table.Rows(0)("Car_Fire")) & "</font> (ทวนความถูกต้องของข้อมูลที่ได้นำสนอไป)"
                    d61.Text = "<b><u>กรณี</u></b> ประเภท 1 พิเศษ หลังจากชำระเงินแล้ว<br/>"
                    d61.Text &= "- <b>กรณี ไม่มีหน้าตารางกรมธรรม์เดิมแนบ</b> จะมีเจ้าหน้าที่นัดตรวจสภาพรถ ให้เตรียมสำเนาบัตรประชาชนและรายการจดทะเบียน ให้กับเจ้าหน้าที่ด้วยคะ /ครับ<br/>"
                    d61.Text &= "- <b>กรณี มีหน้าตารางกรมธรรม์เดิม ที่เป็นประกันภัยประเภท 1 แนบ</b> รบกวนให้ลูกค้าแนบหน้าตารางกรมธรรม์เดิม ส่งมาทางเจ้าหน้าทีฝ่ายขายเพื่อแจ้งงานเข้าบริษัทประกันภัย เพื่อออก กรมธรรม์"
                End If
                d6.Text = "เบี้ยประกนภัย <font color='red'>" & String.Format(CultureInfo.InvariantCulture, "{0:0,0.00}", table.Rows(0)("ProValue")) + " " + table.Rows(0)("lblCarpet").ToString & "</font>"


                HFAppID.Value = table.Rows(0)("AppID").ToString
              
                SqlAppPayDGVPay.SelectParameters("Appid").DefaultValue = strappid
                GridView1.DataSource = SqlAppPayDGVPay
                GridView1.DataBind()

                SqlAppCard2Confirm.SelectParameters("AppID").DefaultValue = strappid
                GridView2.DataSource = SqlAppCard2Confirm
                GridView2.DataBind()


                d8.Text = "7.&nbsp;กรมธรรม์เดิมปีที่แล้วเป็นของบริษัทอะไรครับ/คะ"

                d9.Text = "8.&nbsp;เพื่อยืนยันการเป็นผู้ครองครองรถยนต์ รบกวนแจ้งเลขบัตรประจําตัวประชาชน 13 หลักด้วย ครับ/ค่ะ"
                d10.Text = "9.&nbsp;บริษัท ASN Broker จํากัด (มหาชน) เลขที่ใบอนุญาตของบริษัท ว. 00027/2548 ขออนุญาตแจ้งงานเข้าบริษัทประกันภัยเลย"
                d11.Text = "10.&nbsp;แจ้งชื่อ-สกุล และเลขที่ใบอนุญาตตัวเอง เป็นเจ้าหน้าที่ดูแลลูกค้าในปีนี้"
                d12.Text = "11.&nbsp;หากได้รับเอกสารเรียบร้อยแล้ว รบกวนตรวจสอบความถูกต้องในเอกสารอยางละเอียดอีกครั้ง หากมีข้อมูลส่วนใดไม่ถูกต้องรบกวนติดต่อกลับเพื่อดําเนินการแก้ไข<br />ที่เบอร์ 02-4948377 ในวันและเวลาทําการ ครับ/ค่ะ"
                d13.Text = "12.&nbsp;ทางบริษัท ASN Broker จํากัด(มหาชน) และบริษัทประกันภัย&nbsp;<font color='red'>" & table.Rows(0)("ProTypeName").ToString & "</font>" & " เป็นผู้ดูแลลูกค้าในปีนี้ หากมีเจ้าหน้าที่ท่านอื่นติดต่อเข้ามา<br />รบกวนแจ้งว่า ได้ทําประกันภัยไปแล้ว นะครับ/คะ และบริษัทของเราไม่มีระบบส่งเจ้าหน้าที่ไปเก็บเงินลุกค้าที่บ้านนะครับ/คะ อย่าหลงเชื่อถ้ามีเจ้าหน้าที่ไปเก็บเงินที่บ้าน<br />"

                d14.Text = ""
                txtpaypeo_etc.Text = String.Format(CultureInfo.InvariantCulture, "{0:0,0.00}", table.Rows(0)("TotalPay"))
                txtcountpay_etc.Text = table.Rows(0)("paycount").ToString
            End If
          

        Else

            query = New System.Text.StringBuilder()
            query.Append(" select b.Idcar,b.CarID, ")
            query.Append(" b.CarBrand,")
            query.Append(" b.CarSeries,")
            query.Append(" isnull(b.CarSize,'') as CarSize")
            query.Append(" From  tblcar b ")
            query.Append(" inner join tblcustomer c on b.CusID=c.cusid ")
            query.Append(" where b.Idcar =" & Request.QueryString("IdCar").ToString())
            Dim da1 As SqlDataAdapter = New SqlDataAdapter(query.ToString, Conn)
            Dim table1 As DataTable = New DataTable
            da1.Fill(table1)
            HFAppID.Value = "0"
           
            txtCarID.Text = table1.Rows(0)("CarID").ToString
            txtCarBrand.Text = table1.Rows(0)("CarBrand").ToString
            txtCarSeries.Text = table1.Rows(0)("CarSeries").ToString
            txtCarSize.Text = table1.Rows(0)("CarSize").ToString

            txtpaypeo_etc.Text = ""
            txtcountpay_etc.Text = ""
            txtpaypeo.Text = ""
            txtcountpay.Text = ""
            txtCarTYpe.Text = ""
            txtCarYear.Text = ""
            txtDeviceDetail.Text = ""
            txtpd.Text = ""
            txtpm.Text = ""
            txtpy.Text = ""

            d4.Text = ""
            d6.Text = ""

            d7.Text = ""
            d8.Text = ""
            d9.Text = ""
            d10.Text = ""
            d11.Text = ""
            d12.Text = ""
            d13.Text = ""
            d14.Text = ""

           
            GridView1.DataSource = SqlAppPayDGVPay
            GridView1.DataBind()

            DGVPay.DataSource = SqlAppPayDGVPay
            DGVPay.DataBind()
            frmAddrConfirm.DataSource = SqlCustomerConfirm
            frmAddrConfirm.DataBind()

            frmAddrConfirms.DataSource = SqlCustomerConfirm
            frmAddrConfirms.DataBind()

            DGVAppCard.DataSource = SqlAppCard2Confirm
            DGVAppCard.DataBind()

            GridView2.DataSource = SqlAppCard2Confirm
            GridView2.DataBind()

            frmCusNameConfirm.DataSource = SqlCustomerConfirm
            frmCusNameConfirm.DataBind()
        End If

    End Sub
Function setMThai(nummonth As Int16) As String


        Select Case nummonth
            Case 1 : Return "มกราคม"
            Case 2 : Return "กุมภาพันธ์"
            Case 3 : Return "มีนาคม"
            Case 4 : Return "เมษายน"
            Case 5 : Return "พฤษภาคม"
            Case 6 : Return "มิถุนายน"
            Case 7 : Return "กรกฎาคม"
            Case 8 : Return "สิงหาคม"
            Case 9 : Return "กันยายน"
            Case 10 : Return "ตุลาคม"
            Case 11 : Return "พฤศจิกายน"
            Case 12 : Return "ธันวาคม"

            Case Else
                Return ""

        End Select


    End Function
    Public Sub DaiNgernPoll()
        Dim IsDaiNgern As Int32
        Dim strSQL As String
        Dim dtReader As SqlDataReader
        Conn.Open()
        strSQL = "SELECT * FROM tblDaiNgern_poll where IdCar =" + Convert.ToString(frmCar.DataKey.Item(0))
        com = New SqlCommand(strSQL, Conn)
        dtReader = com.ExecuteReader()

        If dtReader.HasRows Then

            Try
                If RdPollDaiNgern.SelectedValue = 1 Then
                    IsDaiNgern = 1
                ElseIf RdPollDaiNgern.SelectedValue = 2 Then
                    IsDaiNgern = 0
                Else
                    Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('เลือกคำตอบความสนใจโปรเจค-ได้เงิน-ด้วยค่ะ');", True)
                End If
            Catch ex As Exception
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้เนื่องจาก : " & ex.Message & "');", True)
            End Try

            With pollDaiNgern
                .UpdateParameters("IsDaiNgern").DefaultValue = IsDaiNgern
                .Update()
            End With
        Else

            Try

                If RdPollDaiNgern.SelectedValue = 1 Then
                    IsDaiNgern = 1
                ElseIf RdPollDaiNgern.SelectedValue = 2 Then
                    IsDaiNgern = 0
                Else
                    Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('เลือกคำตอบความสนใจโปรเจค-ได้เงิน-ด้วยค่ะ');", True)
                End If

                With pollDaiNgern
                    .InsertParameters("IsDaiNgern").DefaultValue = IsDaiNgern
                    .InsertParameters("IdCar").DefaultValue = IsDaiNgern
                    .Insert()
                End With

            Catch ex As Exception
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้เนื่องจาก : " & ex.Message & "');", True)
            End Try


            dtReader.Close()
            dtReader = Nothing
            Conn.Close()
            Conn = Nothing
        End If
    End Sub
    Protected Function selectTelephone(ByVal ID As Integer) As String
        Dim chk As Boolean
        Conn.Open()

        Dim strqrychk As String = ""
        strqrychk += "  SELECT isnull(a1.Tel,'') as Tel , isnull(a1.OTel,'') as OTel ,isnull(a1.Mobile,'') as Mobile ,isnull(a1.OthTel1,'') as OthTel1 ,isnull(a1.OthTel2,'') as OthTel2 FROM TblCustomer a1 Inner Join TblCar a2 on a1.CusID = a2.CusID Where   a2.IdCar = " & frmCar.DataKey.Item(0)



        Dim Command As SqlCommand
        Dim DataReader As SqlDataReader
        Dim Tel As String = ""
        Dim OTel As String = ""
        Dim Mobile As String = ""
        Dim OthTel1 As String = ""
        Dim OthTel2 As String = ""

        Command = New SqlCommand(strqrychk, Conn)
        DataReader = Command.ExecuteReader()
        If DataReader.HasRows Then
            While DataReader.Read

                Tel = DataReader("Tel")
                OTel = DataReader("OTel")
                Mobile = DataReader("Mobile")
                OthTel1 = DataReader("OthTel1")
                OthTel2 = DataReader("OthTel2")

            End While
        End If
        DataReader.Close()
        Conn.Close()
        If ID = 1 Then
            Return Tel
        ElseIf ID = 2 Then
            Return OTel
        ElseIf ID = 5 Then
            Return Mobile
        ElseIf ID = 4 Then
            Return OthTel1
        ElseIf ID = 8 Then
            Return OthTel2
        End If
    End Function

    Protected Function chkTelephone(ByVal phoneno As String) As Boolean
        Dim chk As Boolean
        Conn.Open()

        Dim strqrychk As String = ""
        strqrychk += "select count(*) as ncount from TblCallControl where  cctbillsec>0 and cctcallerid='" & phoneno & "'"
        Dim Command As SqlCommand
        Dim DataReader As SqlDataReader
        Dim ncount As Integer = 0
        Command = New SqlCommand(strqrychk, Conn)
        DataReader = Command.ExecuteReader()
        If DataReader.HasRows Then
            While DataReader.Read
                If IsDBNull(DataReader("ncount")) = False Then
                    ncount = DataReader("ncount")
                End If
            End While
        End If
        DataReader.Close()
        If ncount > 0 Then
            chk = False
        Else
            chk = True
        End If

        Conn.Close()
        Return chk
    End Function

    Protected Sub RBSelectConditionLINE_SelectedIndexChanged(sender As Object, e As System.EventArgs)
        DefalutLINEID()
    End Sub

    Protected Sub RBSelectConditionLINE_SelectedIndexChanged1(sender As Object, e As System.EventArgs)
        DefalutLINEID()
    End Sub
    Private Sub DefalutLINEID()
        Dim txtLINEID As TextBox = FunAll.ObjFindControl("txtLINEID", formviewLine)
        Dim RBSelectConditionLINE As RadioButtonList = FunAll.ObjFindControl("RBSelectConditionLINE", formviewLine)

        If RBSelectConditionLINE.SelectedValue = "3" Then
            txtLINEID.Text = ""
        End If
    End Sub


    Protected Sub LinkButton99_Click(sender As Object, e As System.EventArgs) Handles LinkButton99.Click
        strProtype = "../Product/frmProType1Plus.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    End Sub
    'Protected Sub LinkButton6_Click(sender As Object, e As System.EventArgs) Handles LinkButton6.Click
    '    strProtype = "../Product/frmProType1DD.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    'End Sub

    Protected Sub LinkButton7_Click(sender As Object, e As System.EventArgs) Handles LinkButton7.Click
        strProtype = "../Product/frmProType20.aspx?IdCar=" & frmCar.DataKey.Item(0) & "&ProCode=" & frmCar.DataKey.Item(3)
    End Sub
	
	
	Private Sub ToShow(ByVal str As String)

        lblPhone.Font.Bold = True
        lblPhone.Font.Name = "PROMPT-MEDIUM"
        btntryit.Font.Name = "PROMPT-MEDIUM"

        If str = "consent" Then
            lblPhone.Text = "[ยินยอมให้ติดต่อ] " & GetPhoneNumber()
            lblPhone.ForeColor = System.Drawing.Color.Green
            ImageButton1.Visible = True
            btntryit.Visible = False
        ElseIf str = "unconsent" Then
            lblPhone.Text = "[ไม่ยินยอมให้ติดต่อ] " & GetPhoneNumber()
            lblPhone.ForeColor = System.Drawing.Color.Red
            ImageButton1.Visible = False
            btntryit.Visible = False
        Else
            lblPhone.Text = str
            lblPhone.Font.Bold = True
            lblPhone.ForeColor = System.Drawing.Color.Coral
            ImageButton1.Visible = False
            btntryit.Visible = True
        End If

    End Sub
    'check_conent

    Protected Function check_conent() As String
        Dim strr As String = ""
        If IsNumeric(GetPhoneNumber()) AndAlso GetPhoneNumber() Is Nothing = False Then
            Dim callapi As New callAPI_pdpa_
            strr = callapi.callapi_check(GetPhoneNumber(), Request.Cookies("userID").Value, 0)
        End If

        Return strr
    End Function

    Protected Sub ddCall_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddCall.SelectedIndexChanged
	
		If checkPhoneNumber() = True Then
	
			check_data_toconsent()
		else
			lblPhone.Text = "Blacklist"
            ImageButton1.Visible = False
            btntryit.Visible = False
		End If
    End Sub
    Private Sub check_data_toconsent()
        Dim strr As String = ""
        strr = check_conent()
        If strr = "" Then
            lblPhone.Text = ""
            ImageButton1.Visible = False
            btntryit.Visible = False
        Else
            ToShow(strr)
        End If
    End Sub
	Protected Sub btntryit_Click(sender As Object, e As System.EventArgs) Handles btntryit.Click
        check_data_toconsent()
    End Sub
	
	 ' add new start 03/05/2022
    Protected Sub btnscriptopen_Click(sender As Object, e As System.EventArgs) Handles btnscriptopen.Click
        Dim Query = New System.Text.StringBuilder()

        Query.Append(" select top 1 isnull(a1.fname ,'')+' '+isnull(a1.lname ,'') as 'emp'")
        Query.Append(" ,isnull(a4.InitTH ,'คุณ')+ isnull(a3.FNameTH ,'')+' '+isnull(a3.LNameTH ,'') as 'cus'")
        Query.Append(" ,isnull(a2.CarBrand,'') as 'brand',isnull(a2.CarSeries,'') as 'model',isnull(a2.CarYear,'') as 'caryears'")
        Query.Append(" from tbluser a1 inner join tblcar a2 on a1.userid=a2.assignto")
        Query.Append(" inner join tblcustomer a3 on a2.cusid=a3.cusid ")
        Query.Append(" inner join TblCustomerInit a4 on a4.InitID=a3.InitID")
        Query.Append(" where a2.Idcar =" & Request.QueryString("IdCar").ToString())

        Dim adapter_openscript As SqlDataAdapter = New SqlDataAdapter(Query.ToString, Conn)
        Dim dt_openscript As DataTable = New DataTable
        adapter_openscript.Fill(dt_openscript)

        Dim emp As String = "" & dt_openscript.Rows(0)("emp").ToString()
        Dim cus As String = "" & dt_openscript.Rows(0)("cus").ToString()


        Dim html As New System.Text.StringBuilder()
        html.Append("<table >")
        html.Append("<tr><td valign=\'top\'>พนักงานขาย :</td><td style=\'border-bottom: 1pt dashed;\' >สวัสดีค่ะ / ครับ <font color=\'red\'>" & emp & "</font> ติดต่อจากบริษัท ASN Broker นะคะ / นะครับ</td></tr>")
        html.Append("<tr><td valign=\'top\'><font color=\'green\'>ลูกค้า :</font></td><td style=\'border-bottom: 1pt dashed;\' >ค่ะ / ครับ</td></tr>")
        html.Append("<tr><td valign=\'top\'>พนักงานขาย :</td><td style=\'border-bottom: 1pt dashed;\' >จากข้อมูลรถยนต์ ยี่ห้อ <font color=\'red\'>" & dt_openscript.Rows(0)("brand").ToString() & "</font> รุ่น <font color=\'red\'>" & dt_openscript.Rows(0)("model").ToString() & "</font> ปี <font color=\'red\'>" & dt_openscript.Rows(0)("caryears").ToString() & "</font> เป็นรถยนต์ของ <font color=\'red\'>" & cus & "</font> ถูกต้องนะคะ / นะครับ</td></tr>")
        html.Append("<tr><td valign=\'top\'><font color=\'green\'>ลูกค้า :</font></td><td style=\'border-bottom: 1pt dashed;\' >ค่ะ / ครับ</td></tr>")
        html.Append("<tr><td valign=\'top\'>พนักงานขาย :</td><td style=\'border-bottom: 1pt dashed;\' >ขออนุญาตนำาเสนอประกันภัยรถยนต์และโปรโมชั่น พร้อม<b><u><font color=\'blue\'>บันทึกการสนทนา</font></u></b>เพื่อปรับปรุงคุณภาพและบริการ คะ / ครับ<br></td></tr>")
        html.Append("<tr><td valign=\'top\'><font color=\'green\'>ลูกค้า :</font></td><td style=\'border-bottom: 1pt dashed;\' >ค่ะ / ครับ</td></tr>")
        html.Append("<tr height=\'30px\'><td></td></tr>")

        html.Append("<tr><td valign=\'top\' colspan=3 style=\'border: 1pt dashed;\'><table>")
        html.Append("<tr><td valign=\'top\'><b><u><font color=\'red\'>**กรณีลูกค้าปฎิเสธ</font></u></b></td><td>: ให้เอาข้อมูลออกจากระบบ / ไม่ต้องการให้ติดต่อมาอีก / ไม่ต้องการให้นำาเสนอ ฯลฯ</td></tr>")
        html.Append("<tr><td></td><td valign=\'top\' >พนักงานขาย :รับทราบคะ / ครับ เจ้าหน้าที่จะนำรายชื่อลูกค้าออกจากระบบเพื่อไม่ให้ทำาการติดต่อกลับไปอีก ขอบคุณมากค่ะ / ครับ</td></tr>")


        html.Append("</table></td></tr></table>")

        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "scriptopen", "scriptopen('" & html.ToString() & "');", True)
    End Sub
	
    Protected Sub btnunconsent1_Click(sender As Object, e As System.EventArgs) Handles btnunconsent1.Click
        'btnunconsent1=> unconsent loan
        call_pdpa_insertuncon_etc()
    End Sub
    Protected Sub btnunconsent2_Click(sender As Object, e As System.EventArgs) Handles btnunconsent2.Click
        call_pdpa_insertuncon()
    End Sub
    Protected Sub btnconcent_Click(sender As Object, e As System.EventArgs) Handles btnconcent.Click
        'consent 
        Dim callapi As New callAPI_pdpa_
        Dim reponse As String
        reponse = callapi.callfunction_insertpdpa_all(frmCus.DataKey.Item(0), FunAll.ObjFindControl("Label1", frmCus).Text, FunAll.ObjFindControl("Label2", frmCus).Text,
                                                      Request.Cookies("userID").Value, GetPhoneNumber(), 1, 4)
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('" & reponse & "');", True)

    End Sub
  
    Private Sub call_pdpa_insertuncon() 'unconsent ของ callsoft 
        Dim reponse As String
        Dim callapi As New callAPI_pdpa_
        reponse = callapi.callfunction_insertpdpa_all(frmCus.DataKey.Item(0), FunAll.ObjFindControl("Label1", frmCus).Text, FunAll.ObjFindControl("Label2", frmCus).Text,
                                                      Request.Cookies("userID").Value, GetPhoneNumber(), 0, 4)
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('" & reponse & "');", True)
    End Sub

    Private Sub call_pdpa_insertuncon_etc() 'unconsent สินเชื่อ 
        Dim reponse As String
        Dim callapi As New callAPI_pdpa_
        reponse = callapi.callfunction_insertpdpa_all(frmCus.DataKey.Item(0), FunAll.ObjFindControl("Label1", frmCus).Text, FunAll.ObjFindControl("Label2", frmCus).Text,
                                                      Request.Cookies("userID").Value, GetPhoneNumber(), 0, 1)

        reponse = callapi.callfunction_insertpdpa_all(frmCus.DataKey.Item(0), FunAll.ObjFindControl("Label1", frmCus).Text, FunAll.ObjFindControl("Label2", frmCus).Text,
                                                      Request.Cookies("userID").Value, GetPhoneNumber(), 0, 2)

        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('" & reponse & "');", True)
    End Sub
	
	
End Class
