﻿
Partial Class Modules_Sale_Tsr_frmViewTsr
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            BindTsr()
        End If
    End Sub

    Protected Sub BindTsr()
        'edit by na 2565/08/25
        'OLD=>>
        'SqlUser.SelectParameters("TsrName").DefaultValue = "%" + TsrName + "%"
        'GvCall.DataBind()

        Dim str As String = ""
        Dim chk As Boolean = True
        If ddType.SelectedValue = "1" Then
            SqlUser.SelectParameters("TsrName").DefaultValue = "%" + txtSearch.Text.Trim + "%"
            GvCall.DataSource = SqlUser

        ElseIf ddType.SelectedValue = "2" And IsNumeric(txtSearch.Text.Trim) Then
            'APPID       
            SqlUser_APPID.SelectParameters("TsrName").DefaultValue = txtSearch.Text.Trim
            GvCall.DataSource = SqlUser_APPID
        Else
            chk = False
        End If

        If chk Then
            GvCall.DataBind()
        Else

        End If

    End Sub

   
    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click
        'edit by na 2565/08/25
        'OLD=>>BindTsr(txtSearch.Text.Trim)
        If txtSearch.Text.Trim <> "" Then
            BindTsr()
        End If
    End Sub
End Class
