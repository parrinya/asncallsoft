﻿
Partial Class Modules_Manager_Manage_Tsr_frmMonitorPayment
    Inherits System.Web.UI.Page

End Class
