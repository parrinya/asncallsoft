﻿Imports System.Data
Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Text

Partial Class Modules_Manager_Report_SaleSource
    Inherits System.Web.UI.Page
    Dim SourceID As Integer
    Dim Connection As New SqlConnection(ConfigurationManager.ConnectionStrings("asnbroker").ConnectionString)
    Dim ISODate As New ISODate
    Dim DataAccess As New DataAccess
    Dim dt, dt1 As New DataTable
    Dim Command As SqlCommand
    Dim SourceName As String
    Dim myReport As New ReportDocument
 
    Dim appSet As New AppSettingsReader()
    Dim users As String = appSet.GetValue("usernameRpt", GetType(String))
    Dim pass As String = appSet.GetValue("passwordRpt", GetType(String))

    Dim rdt As String = ""
    Dim txtDate1 As String = ""
    Dim txtDate2 As String = ""
    Dim txtDate3 As String = ""
    Dim txtDate4 As String = ""
    Dim ConvertDate As ISODate = New ISODate()
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        SourceID = Request.QueryString("ID")
        SourceName = Request.QueryString("name")
        rdt = Request.QueryString("rdt")


        If Not IsPostBack Then
            If rdt = "1" Then
                'sou
                Process()
            ElseIf rdt = "2" Then
                'วันคุ้มครอง
                txtDate1 = Request.QueryString("txtDate1").ToString
                txtDate2 = Request.QueryString("txtDate2").ToString
                Process2()
            ElseIf rdt = "3" Then
                'วันASSI
                txtDate3 = Request.QueryString("txtDate3").ToString
                txtDate4 = Request.QueryString("txtDate4").ToString
                Process3()
            End If

        End If
    End Sub
    Protected Sub CrystalReportViewer1_ReportRefresh(ByVal source As Object, ByVal e As CrystalDecisions.Web.ViewerEventArgs) Handles CrystalReportViewer1.ReportRefresh
        CrystalReportViewer1.RefreshReport()
    End Sub
    Protected Sub Process()
        Dim sql As String = ""
        Dim tmp1 As String = ""
        Dim tmp2 As String = ""
        Dim ncount, sp, countIn, countSuccess, countWait, countRefuse, countFollow, countCallback, countNocontact, countNotupdate As Decimal

        'new code
        Dim countlist As Decimal


        Dim countNew_Case, countTry_Again, countNot_Target, countAlready_Applied, countDuplicated As Decimal
        Dim countAbandon As Decimal
        Dim countUnreachable As Decimal
        Dim countMore3 As Decimal
        Dim countCANCEL As Decimal
        Dim countPayment As Decimal
        Dim countWaitCANCEL As Decimal
        Dim countSuccessWaitApp As Decimal
        Dim countWaitWaitApp As Decimal
        Dim countReFinance As Decimal

        Dim Leadername As String = ""

      
        Try
            '2.ลบ tblreportadminretentsr
            sql = " delete from tblsalereporttsr where creatid=" & Request.Cookies("userID").Value
            Connection.Open()
            Command = New SqlCommand(sql, Connection)
            Command.ExecuteNonQuery()
            Connection.Close()

            'If SourceID = 1 Or SourceID = 2 Or SourceID = 3 Or SourceID = 4 Or SourceID = 5 Then
            '    If Request.Cookies("UserLevel").Value = 2 Then
            '        sql = " select   userid,fname+' '+lname +case when UserStatus=0 then ' (ยกเลิก)'else '' end  as nameuser,supid  from tbluser "
            '        sql += " where userid in (select distinct assignto  from tblcar where groupid = 99)"
            '        sql += " and leaderid=" & Request.Cookies("userID").Value
            '        sql += " and  " & SourceID & " = ()"
            '        sql += " and UserLevelID=5 "

            '        sql += " order by userlevelid,fname "

            '    ElseIf Request.Cookies("UserLevel").Value = 1 Then
            '        sql = " select   userid,fname+' '+lname +case when UserStatus=0 then ' (ยกเลิก)'else '' end as  nameuser,SupID  from tbluser "
            '        sql += " where userid in (select distinct assignto  from tblcar where groupid = 99)"
            '        sql += " and UserLevelID=5 "
            '        sql += " order by userlevelid,fname "

            '    ElseIf Request.Cookies("UserLevel").Value = 3 Then
            '        sql = " select   userid,fname+' '+lname +case when UserStatus=0 then ' (ยกเลิก)'else '' end as  nameuser,SupID  from tbluser "
            '        sql += " where userid in (select distinct assignto  from tblcar where groupid = 99)"
            '        sql += " and  supid=" & Request.Cookies("userID").Value
            '        sql += " and UserLevelID=5 "
            '        sql += " order by userlevelid,fname "

            '    End If
            'Else

            'End If
            If SourceID = 1 Or SourceID = 2 Or SourceID = 3 Or SourceID = 4 Or SourceID = 5 Then
                If Request.Cookies("UserLevel").Value = 2 Then
                    sql = " select   userid,fname+' '+lname +case when UserStatus=0 then ' (ยกเลิก)'else '' end  as nameuser,supid  from tbluser "
                    sql += " where userid in (select distinct assignto  from tblcar inner join tblcustomer on  tblcar.cusid=tblcustomer.CusID inner join TblAddNewSourceData on TblAddNewSourceData.cusid=tblcustomer.CusID where tblcar.groupid = 99 )"
                    sql += " and leaderid=" & Request.Cookies("userID").Value
                    sql += " and SupID in (select userid from tbluser where userstatus=1) and UserLevelID=5 "

                    sql += " order by userlevelid,fname "

                ElseIf Request.Cookies("UserLevel").Value = 1 Then
                    sql = " select   userid,fname+' '+lname +case when UserStatus=0 then ' (ยกเลิก)'else '' end as  nameuser,SupID  from tbluser "
                    sql += " where userid in (select distinct assignto  from tblcar inner join tblcustomer on  tblcar.cusid=tblcustomer.CusID inner join TblAddNewSourceData on TblAddNewSourceData.cusid=tblcustomer.CusID where tblcar.groupid = 99)"
                    sql += " and UserLevelID=5 "
                    sql += " order by userlevelid,fname "

                ElseIf Request.Cookies("UserLevel").Value = 3 Then
                    sql = " select   userid,fname+' '+lname +case when UserStatus=0 then ' (ยกเลิก)'else '' end as  nameuser,SupID  from tbluser "
                    sql += " where userid in (select distinct assignto  from tblcar inner join tblcustomer on  tblcar.cusid=tblcustomer.CusID inner join TblAddNewSourceData on TblAddNewSourceData.cusid=tblcustomer.CusID where tblcar.groupid = 99)"
                    sql += " and  supid=" & Request.Cookies("userID").Value
                    sql += " and UserLevelID=5 "
                    sql += " order by userlevelid,fname "

                End If
            Else
                If Request.Cookies("UserLevel").Value = 2 Then
                    sql = " select   userid,fname+' '+lname +case when UserStatus=0 then ' (ยกเลิก)'else '' end  as nameuser,supid  from tbluser "
                    sql += " where userid in (select distinct assignto  from tblcar where groupid = " & SourceID & ")"
                    sql += " and leaderid=" & Request.Cookies("userID").Value
                    sql += " and SupID in (select userid from tbluser where userstatus=1) and UserLevelID=5 "

                    sql += " order by userlevelid,fname "

                ElseIf Request.Cookies("UserLevel").Value = 1 Then
                    sql = " select   userid,fname+' '+lname +case when UserStatus=0 then ' (ยกเลิก)'else '' end as  nameuser,SupID  from tbluser "
                    sql += " where userid in (select distinct assignto  from tblcar where groupid = " & SourceID & ")"
                    sql += " and UserLevelID=5 "
                    sql += " and SupID in (select userid from tbluser where userstatus=1) order by userlevelid,fname "

                ElseIf Request.Cookies("UserLevel").Value = 3 Then
                    sql = " select   userid,fname+' '+lname +case when UserStatus=0 then ' (ยกเลิก)'else '' end as  nameuser,SupID  from tbluser "
                    sql += " where userid in (select distinct assignto  from tblcar where groupid = " & SourceID & ")"
                    sql += " and  supid=" & Request.Cookies("userID").Value
                    sql += " and UserLevelID=5 "
                    sql += " order by userlevelid,fname "

                End If
            End If

            Dim SourceIDStr As String = ""
            If SourceID = 1 Or SourceID = 2 Or SourceID = 3 Or SourceID = 4 Or SourceID = 5 Then

                SourceIDStr = " '99'  and TblCar.CusID in (select cusid from TblAddNewSourceData where SourceDataID='" & SourceID & "')"
            Else
                SourceIDStr = SourceID
            End If
            dt = DataAccess.DataRead(sql)
            If dt.Rows.Count > 0 Then

                For i = 0 To dt.Rows.Count - 1
                    ncount = 0
                    sp = 0
                    countIn = 0

                    'newcode
                    countlist = 0

                    sql = " SELECT     count(*) as ncount "
                    sql += " FROM TblApplication "
                    sql += " inner join TblCar ON TblApplication.Idcar = TblCar.IdCar "
                    sql += " INNER JOIN TblCustomer ON TblCar.CusID = TblCustomer.CusID "
                    sql += " WHERE "
                    sql += " (TblApplication.AppStatus = 1) "
                    sql += " AND (TblApplication.IsProvalue = 1) "
                    sql += " AND (TblApplication.AppID IN (SELECT DISTINCT AppID FROM TblPayment)) "
                    sql += " and groupid = " & SourceIDStr & " and assignto = " & dt.Rows(i).Item("userid")

                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    ncount = dt1.Rows(0).Item("ncount")

                    sql = " SELECT      isnull(sum(provalue+carpet),0) as sp "
                    sql += " FROM TblApplication"
                    sql += " inner join TblCar ON TblApplication.Idcar = TblCar.IdCar "
                    sql += " INNER JOIN TblCustomer ON TblCar.CusID = TblCustomer.CusID "
                    sql += " WHERE "
                    sql += " (TblApplication.AppStatus = 1) "
                    sql += " AND (TblApplication.IsProvalue = 1) "
                    sql += " AND (TblApplication.AppID IN (SELECT DISTINCT AppID FROM TblPayment)) "
                    sql += " and groupid = " & SourceIDStr & " and assignto = " & dt.Rows(i).Item("userid")

                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    sp = dt1.Rows(0).Item("sp")


                    sql = " select count (distinct TblCar.CusID) as countIn  from tblcar where groupid = " & SourceIDStr & " and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countIn = dt1.Rows(0).Item("countIn")

                    'new code----------------
                    'list used
                    sql = " select count (distinct TblCar.CusID) as countlist  from tblcar where groupid = " & SourceIDStr & " and curstatus<>1 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countlist = dt1.Rows(0).Item("countlist")

                    '-------------------------

                    sql = " select  count (distinct TblCar.CusID) as countSuccess  from tblcar where groupid = " & SourceIDStr & " and curstatus=3 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countSuccess = dt1.Rows(0).Item("countSuccess")

                    ' 
                    sql = " select  count (distinct TblCar.CusID) as countWait  from tblcar where groupid = " & SourceIDStr & " and curstatus=4 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countWait = dt1.Rows(0).Item("countWait")

                    sql = " select  count (distinct TblCar.CusID) as countRefuse  from tblcar where groupid = " & SourceIDStr & " and curstatus=5 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countRefuse = dt1.Rows(0).Item("countRefuse")

                    sql = " select  count (distinct TblCar.CusID) as countFollow  from tblcar where groupid = " & SourceIDStr & " and curstatus=6 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countFollow = dt1.Rows(0).Item("countFollow")

                    sql = " select  count (distinct TblCar.CusID) as countCallback  from tblcar where groupid = " & SourceIDStr & " and curstatus=8 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countCallback = dt1.Rows(0).Item("countCallback")

                    sql = " select  count (distinct TblCar.CusID) as countNocontact  from tblcar where groupid = " & SourceIDStr & " and curstatus=7 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countNocontact = dt1.Rows(0).Item("countNocontact")


                    sql = " select  count (distinct TblCar.CusID) as countNotupdate  from tblcar where groupid = " & SourceIDStr & " and curstatus=9 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countNotupdate = dt1.Rows(0).Item("countNotupdate")

                    sql = " select  count (distinct TblCar.CusID) as countNew_Case  from tblcar where groupid = " & SourceIDStr & " and curstatus=1 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countNew_Case = dt1.Rows(0).Item("countNew_Case")

                    sql = " select  count (distinct TblCar.CusID) as countTry_Again   from tblcar where groupid = " & SourceIDStr & " and curstatus=2 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countTry_Again = dt1.Rows(0).Item("countTry_Again")

                    sql = " select  count (distinct TblCar.CusID) as countNot_Target   from tblcar where groupid = " & SourceIDStr & " and curstatus=10 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countNot_Target = dt1.Rows(0).Item("countNot_Target")

                    sql = " select  count (distinct TblCar.CusID) as countAlready_Applied   from tblcar where groupid = " & SourceIDStr & " and curstatus=11 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countAlready_Applied = dt1.Rows(0).Item("countAlready_Applied")

                    sql = " select count (distinct TblCar.CusID) as countDuplicated   from tblcar where groupid = " & SourceIDStr & " and curstatus=12 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countDuplicated = dt1.Rows(0).Item("countDuplicated")

                    sql = " select count (distinct TblCar.CusID) as countAbandon   from tblcar where groupid = " & SourceIDStr & " and curstatus=13 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countAbandon = dt1.Rows(0).Item("countAbandon")

                    sql = " select count (distinct TblCar.CusID) as countUnreachable   from tblcar where groupid = " & SourceIDStr & " and curstatus=14 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countUnreachable = dt1.Rows(0).Item("countUnreachable")

                    sql = " select  count (distinct TblCar.CusID) as countMore3   from tblcar where groupid = " & SourceIDStr & " and curstatus=15 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countMore3 = dt1.Rows(0).Item("countMore3")

                    sql = " select  count (distinct TblCar.CusID) as countCANCEL   from tblcar where groupid = " & SourceIDStr & " and curstatus=16 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countCANCEL = dt1.Rows(0).Item("countCANCEL")

                    sql = " select  count (distinct TblCar.CusID) as countPayment   from tblcar where groupid = " & SourceIDStr & " and curstatus=19 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countPayment = dt1.Rows(0).Item("countPayment")

                    sql = " select  count (distinct TblCar.CusID) as countWaitCANCEL   from tblcar where groupid = " & SourceIDStr & " and curstatus=20 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countWaitCANCEL = dt1.Rows(0).Item("countWaitCANCEL")

                    sql = " select  count (distinct TblCar.CusID) as countWaitWaitApp    from tblcar where groupid = " & SourceIDStr & " and curstatus=26 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countWaitWaitApp = dt1.Rows(0).Item("countWaitWaitApp")

                    sql = " select  count (distinct TblCar.CusID) as countSuccessWaitApp   from tblcar where groupid = " & SourceIDStr & " and curstatus=25 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countSuccessWaitApp = dt1.Rows(0).Item("countSuccessWaitApp")

                    sql = " select  count (distinct TblCar.CusID) as countReFinance   from tblcar where groupid = " & SourceIDStr & " and curstatus=27 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countReFinance = dt1.Rows(0).Item("countReFinance")

                    'sql = " insert into tblsalereporttsr(tsrid,tsrname, countin, countapprove,approve,source,countSuccess,countWait,countRefuse,countFollow,countCallback,countNocontact,countNotupdate,Leadername) values ('" & dt.Rows(i).Item("userid") & "','" & dt.Rows(i).Item("nameuser") & "','" & countIn & "','" & ncount & "','" & sp & "','" & SourceName & "','" & countSuccess & "','" & countWait & "','" & countRefuse & "','" & countFollow & "','" & countCallback & "','" & countNocontact & "','" & countNotupdate & "','" & Leadername & "')"
                    sql = " insert into tblsalereporttsr(tsrid,tsrname, countin, countapprove,approve,source,countSuccess,countWait,countRefuse,countFollow,"
                    sql += " countCallback,countNocontact,countNotupdate,Leadername,countNew_Case,countTry_Again,countNot_Target,countAlready_Applied,countDuplicated,countAbandon,countUnreachable,"
                    sql += " countMore3,countCANCEL,countPayment,countWaitCANCEL,countWaitWaitApp,countSuccessWaitApp,countReFinance,creatid,countlist,supid) "
                    sql += " values ('" & dt.Rows(i).Item("userid") & "','" & dt.Rows(i).Item("nameuser") & "','" & countIn & "','" & ncount & "','" & sp & "','" & SourceName & "','" & countSuccess & "','" & countWait & "','" & countRefuse & "','" & countFollow & "',"
                    sql += " '" & countCallback & "','" & countNocontact & "','" & countNotupdate & "','" & Leadername & "',"
                    sql += " '" & countNew_Case & "','" & countTry_Again & "','" & countNot_Target & "','" & countAlready_Applied & "','" & countDuplicated & "',"
                    sql += " '" & countAbandon & "','" & countUnreachable & "','" & countMore3 & "','" & countCANCEL & "','" & countPayment & "','" & countWaitCANCEL & "',"
                    sql += " '" & countWaitWaitApp & "','" & countSuccessWaitApp & "','" & countReFinance & "','" & Request.Cookies("userID").Value & "','" & countlist & "', '" & dt.Rows(i).Item("supid") & "')"

                    Connection.Open()
                    Command = New SqlCommand(sql, Connection)
                    Command.ExecuteNonQuery()
                    Connection.Close()

                Next
                'If CompID = 0 Then
                '    MyReportLoad0()
                'Else
                '    MyReportLoad()
                'End If
                MyReportLoad()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub Process2()
        'Dim sql As String = ""
        Dim sql As New StringBuilder
        Dim tmp1 As String = ""
        Dim tmp2 As String = ""

        'new code
        Dim countlist As Decimal

        Dim ncount, sp, countIn, countSuccess, countWait, countRefuse, countFollow, countCallback, countNocontact, countNotupdate As Decimal

        Dim countNew_Case, countTry_Again, countNot_Target, countAlready_Applied, countDuplicated As Decimal
        Dim countAbandon As Decimal
        Dim countUnreachable As Decimal
        Dim countMore3 As Decimal
        Dim countCANCEL As Decimal
        Dim countPayment As Decimal
        Dim countWaitCANCEL As Decimal
        Dim countSuccessWaitApp As Decimal
        Dim countWaitWaitApp As Decimal
        Dim countReFinance As Decimal

        Dim Leadername As String = ""
        If (Format(CDate(txtDate1), "yyyy") > 2300) Then
            txtDate1 = Format(CDate(txtDate1), "yyyy") - 543 & Format(CDate(txtDate1), "MMdd")
            txtDate2 = Format(CDate(txtDate2), "yyyy") - 543 & Format(CDate(txtDate2), "MMdd") + " 23:59"
        Else
            txtDate1 = Format(CDate(Request.QueryString("txtDate1").ToString), "yyyyMMdd")
            txtDate2 = Format(CDate(Request.QueryString("txtDate2").ToString), "yyyyMMdd") + " 23:59"
        End If
       
        Try
            sql = New StringBuilder()
            sql.Append(" delete from tblsalereporttsr where creatid=" & Request.Cookies("userID").Value)
            Connection.Open()
            Command = New SqlCommand(sql.ToString(), Connection)
            Command.ExecuteNonQuery()
            Connection.Close()
            sql = New StringBuilder()
            'select tsr list...
            If Request.Cookies("UserLevel").Value = 2 Then 'PL
                If Request.QueryString("assig3") = 0 Then 'Select All sup
                    sql.Append(" select   userid,fname+' '+lname as nameuser,supid  from tbluser ")
                    sql.Append(" where UserStatus=1 and userlevelid=5 and leaderid =" & Request.Cookies("userID").Value)
                    sql.Append(" union( select userid,nameuser,supid from tbltsrout ")
                    sql.Append(" where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "' and leaderid =" & Request.Cookies("userID").Value)
                    sql.Append(" ) order by nameuser ")
                Else
                    sql.Append(" select   userid,fname+' '+lname as nameuser,supid  from tbluser ")
                    sql.Append(" where  UserStatus=1 and userlevelid=5 and ")
                    sql.Append("  (SupID=" & Request.QueryString("assig3") & " )")
                    sql.Append(" union( select userid,nameuser,supid from tbltsrout ")
                    sql.Append(" where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "' and SupID =" & Request.QueryString("assig3"))
                    sql.Append(" ) order by nameuser ")
                End If
            ElseIf Request.Cookies("UserLevel").Value = 1 Then 'OM
                If Request.QueryString("assig") = 0 And Request.QueryString("assig2") = 0 Then 'Select All pl and All sup
                    sql.Append(" select   userid,fname+' '+lname as nameuser,supid  from tbluser ")
                    sql.Append(" where UserStatus=1 and userlevelid=5")
                    sql.Append(" union( select userid,nameuser,supid from tbltsrout ")
                    sql.Append(" where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "')")
                    sql.Append(" order by nameuser ")
                ElseIf Request.QueryString("assig2") = 0 Then 'Select All sup
                    sql.Append(" select   userid,fname+' '+lname as nameuser,supid  from tbluser ")
                    sql.Append(" where UserStatus=1 and userlevelid=5 and leaderid =" & Request.QueryString("assig"))
                    sql.Append(" union( select userid,nameuser,supid from tbltsrout ")
                    sql.Append(" where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "' and leaderid =" & Request.QueryString("assig"))
                    sql.Append(" ) order by nameuser ")
                Else 'Select pl and sup
                    sql.Append(" select   userid,fname+' '+lname as nameuser,supid  from tbluser ")
                    sql.Append(" where UserStatus=1 and userlevelid=5 and supID =" & Request.QueryString("assig2"))
                    sql.Append(" union( select userid,nameuser,supid from tbltsrout ")
                    sql.Append(" where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "' and supID =" & Request.QueryString("assig2"))
                    sql.Append(" ) order by nameuser ")
                End If
            ElseIf Request.Cookies("UserLevel").Value = 3 Then 'Sup
                sql.Append(" select   userid,fname+' '+lname as nameuser,supid  from tbluser ")
                sql.Append(" where UserStatus=1 and userlevelid=5 ")
                sql.Append(" and (supid=" & Request.Cookies("userID").Value & " )")
                sql.Append(" union( select userid,nameuser,supid from tbltsrout ")
                sql.Append(" where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "' and supid=" & Request.Cookies("userID").Value)
                sql.Append(" ) order by nameuser ")

            End If


            dt = DataAccess.DataRead(sql.ToString())

                If dt.Rows.Count > 0 Then

                For i = 0 To dt.Rows.Count - 1
                    sql = New StringBuilder()
                    ncount = 0
                    sp = 0
                    countIn = 0

                    'newcode
                    countlist = 0

                    'Leadername = "Sup Name: "
                    sql.Append(" SELECT     count(*) as ncount ")
                    sql.Append(" FROM TblApplication ")
                    sql.Append(" inner join vwProtectDatesourceTSR ON TblApplication.Idcar = vwProtectDatesourceTSR.IdCar ")
                    sql.Append(" INNER JOIN TblCustomer ON vwProtectDatesourceTSR.CusID = TblCustomer.CusID ")
                    sql.Append(" WHERE ")
                    sql.Append(" (TblApplication.AppStatus = 1) ")
                    sql.Append(" AND (TblApplication.IsProvalue = 1) ")
                    sql.Append(" AND (TblApplication.AppID IN (SELECT DISTINCT AppID FROM TblPayment)) ")
                    sql.Append(" and vwProtectDatesourceTSR.ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and assignto = " & dt.Rows(i).Item("userid"))



                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())

                    sql = New StringBuilder()
                    ncount = dt1.Rows(0).Item("ncount")

                    'sql.Append(" SELECT      isnull(sum(provalue+carpet),0) as sp ")
                    'sql.Append(" FROM TblApplication")
                    'sql.Append(" inner join vwProtectDatesourceTSR ON TblApplication.Idcar = vwProtectDatesourceTSR.IdCar ")
                    'sql.Append(" INNER JOIN TblCustomer ON vwProtectDatesourceTSR.CusID = TblCustomer.CusID ")
                    'sql.Append(" WHERE ")
                    'sql.Append(" (TblApplication.AppStatus = 1) ")
                    'sql.Append(" AND (TblApplication.IsProvalue = 1) ")
                    'sql.Append(" AND (TblApplication.AppID IN (SELECT DISTINCT AppID FROM TblPayment)) ")
                    'sql.Append(" and  vwProtectDatesourceTSR.ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'   and assignto = " & dt.Rows(i).Item("userid"))

                    sql.Append(" select isnull(sum(v),0) as sp ")
                    sql.Append(" from ( ")
                    sql.Append(" select sum( provalue) as v ")
                    sql.Append(" from TblApplication ")
                    sql.Append(" inner join tblcar  on tblcar.idcar=tblapplication.idcar ")
                    sql.Append(" INNER JOIN TblCustomer ON tblcar.CusID = TblCustomer.CusID  ")

                    sql.Append("    where  ")
                    sql.Append("    TblApplication.AppStatus = 1 ")
                    sql.Append("    and TblApplication.IsProvalue = 1 ")
                    sql.Append("    and TblApplication.ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'   ")
                    sql.Append(" 	and assignto = " & dt.Rows(i).Item("userid"))
                    sql.Append(" 	and curstatus in (3,4,20) and statusqc not in (0,2,3)  ")
                    sql.Append(" 	AND (TblApplication.AppID IN (SELECT DISTINCT AppID FROM TblPayment))  ")
                    sql.Append("    union ")
                    sql.Append(" select sum( carpet) as v ")
                    sql.Append(" from TblApplication ")
                    sql.Append(" inner join tblcar  on tblcar.idcar=tblapplication.idcar ")
                    sql.Append(" INNER JOIN TblCustomer ON tblcar.CusID = TblCustomer.CusID  ")

                    sql.Append("                   where ")
                    sql.Append("                   TblApplication.AppStatus = 1 ")
                    sql.Append("   and TblApplication.IsCarpet = 1 ")
                    sql.Append("    and TblApplication.ProtectDateCarpet between '" & txtDate1 & "' and '" & txtDate2 & "'   ")
                    sql.Append(" 	and assignto = " & dt.Rows(i).Item("userid"))
                    sql.Append(" 	and curstatus in (3,4,20) and statusqc not in (0,2,3)  ")
                    sql.Append(" 	AND (TblApplication.AppID IN (SELECT DISTINCT AppID FROM TblPayment))  ")
                    sql.Append(" ) tmp")


                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    sp = dt1.Rows(0).Item("sp")


                    sql.Append(" select  count(*) as countIn  from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'   and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()

                    countIn = dt1.Rows(0).Item("countIn")

                    'new code----------------
                    'list used
                    sql.Append(" select  count(*) as countlist  from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus<>1 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countlist = dt1.Rows(0).Item("countlist")

                    '-------------------------



                    'success
                    sql.Append(" select  count(*) as countSuccess  from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=3 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countSuccess = dt1.Rows(0).Item("countSuccess")

                    'wait
                    sql.Append(" select  count(*) as countWait  from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=4 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countWait = dt1.Rows(0).Item("countWait")

                    'refuse
                    sql.Append(" select  count(*) as countRefuse  from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=5 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countRefuse = dt1.Rows(0).Item("countRefuse")

                    'follow
                    sql.Append(" select  count(*) as countFollow  from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=6 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countFollow = dt1.Rows(0).Item("countFollow")

                    'call back
                    sql.Append(" select  count(*) as countCallback  from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=8 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countCallback = dt1.Rows(0).Item("countCallback")

                    'no contact
                    sql.Append(" select  count(*) as countNocontact  from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=7 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countNocontact = dt1.Rows(0).Item("countNocontact")

                    'not update
                    sql.Append(" select  count(*) as countNotupdate  from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=9 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countNotupdate = dt1.Rows(0).Item("countNotupdate")

                    'new case
                    sql.Append(" select  count(*) as countNew_Case  from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=1 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countNew_Case = dt1.Rows(0).Item("countNew_Case")

                    'try again
                    sql.Append(" select  count(*) as countTry_Again   from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=2 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countTry_Again = dt1.Rows(0).Item("countTry_Again")

                    'not target
                    sql.Append(" select  count(*) as countNot_Target   from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=10 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countNot_Target = dt1.Rows(0).Item("countNot_Target")

                    'already applied
                    sql.Append(" select  count(*) as countAlready_Applied  from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=11 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countAlready_Applied = dt1.Rows(0).Item("countAlready_Applied")

                    'duplicated
                    sql.Append(" select  count(*) as countDuplicated   from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=12 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countDuplicated = dt1.Rows(0).Item("countDuplicated")

                    'abandon
                    sql.Append(" select  count(*) as countAbandon   from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=13 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countAbandon = dt1.Rows(0).Item("countAbandon")

                    'unreachable
                    sql.Append(" select  count(*) as countUnreachable   from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=14 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countUnreachable = dt1.Rows(0).Item("countUnreachable")

                    'more 3
                    sql.Append(" select  count(*) as countMore3   from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=15 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countMore3 = dt1.Rows(0).Item("countMore3")

                    'cancel
                    sql.Append(" select  count(*) as countCANCEL   from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=16 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countCANCEL = dt1.Rows(0).Item("countCANCEL")

                    'payment
                    sql.Append(" select  count(*) as countPayment   from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=19 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countPayment = dt1.Rows(0).Item("countPayment")

                    'wait cancel
                    sql.Append(" select  count(*) as countWaitCANCEL   from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=20 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countWaitCANCEL = dt1.Rows(0).Item("countWaitCANCEL")

                    'wait app
                    sql.Append(" select  count(*) as countWaitWaitApp    from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=26 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countWaitWaitApp = dt1.Rows(0).Item("countWaitWaitApp")

                    'success wait app
                    sql.Append(" select  count(*) as countSuccessWaitApp   from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=25 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countSuccessWaitApp = dt1.Rows(0).Item("countSuccessWaitApp")

                    're-finance
                    sql.Append(" select  count(*) as countReFinance   from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=27 and assignto = " & dt.Rows(i).Item("userid"))
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql.ToString())
                    sql = New StringBuilder()
                    countReFinance = dt1.Rows(0).Item("countReFinance")

                    sql.Append(" insert into tblsalereporttsr(tsrid,tsrname, countin, countapprove,approve,source,countSuccess,countWait,countRefuse,countFollow,")
                    sql.Append(" countCallback,countNocontact,countNotupdate,Leadername,countNew_Case,countTry_Again,countNot_Target,countAlready_Applied,countDuplicated,countAbandon,countUnreachable,")
                    sql.Append(" countMore3,countCANCEL,countPayment,countWaitCANCEL,countWaitWaitApp,countSuccessWaitApp,countReFinance,creatid,countlist,supid) ")
                    sql.Append(" values ('" & dt.Rows(i).Item("userid") & "','" & dt.Rows(i).Item("nameuser") & "','" & countIn & "','" & ncount & "','" & sp & "','" & SourceName & "','" & countSuccess & "','" & countWait & "','" & countRefuse & "','" & countFollow & "',")
                    sql.Append(" '" & countCallback & "','" & countNocontact & "','" & countNotupdate & "','" & Leadername & "',")
                    sql.Append(" '" & countNew_Case & "','" & countTry_Again & "','" & countNot_Target & "','" & countAlready_Applied & "','" & countDuplicated & "',")
                    sql.Append(" '" & countAbandon & "','" & countUnreachable & "','" & countMore3 & "','" & countCANCEL & "','" & countPayment & "','" & countWaitCANCEL & "',")
                    sql.Append(" '" & countWaitWaitApp & "','" & countSuccessWaitApp & "','" & countReFinance & "','" & Request.Cookies("userID").Value & "','" & countlist & "', '" & dt.Rows(i).Item("supid") & "' )")

                    Connection.Open()
                    Command = New SqlCommand(sql.ToString(), Connection)
                    Command.ExecuteNonQuery()
                    Connection.Close()

                Next
                    MyReportLoad()
                End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub Process3()
        Dim sql As String = ""
        Dim tmp1 As String = ""
        Dim tmp2 As String = ""

        'new code
        Dim countlist As Decimal

        Dim ncount, sp, countIn, countSuccess, countWait, countRefuse, countFollow, countCallback, countNocontact, countNotupdate As Decimal

        Dim countNew_Case, countTry_Again, countNot_Target, countAlready_Applied, countDuplicated As Decimal
        Dim countAbandon As Decimal
        Dim countUnreachable As Decimal
        Dim countMore3 As Decimal
        Dim countCANCEL As Decimal
        Dim countPayment As Decimal
        Dim countWaitCANCEL As Decimal
        Dim countSuccessWaitApp As Decimal
        Dim countWaitWaitApp As Decimal
        Dim countReFinance As Decimal

        Dim Leadername As String = ""
        If (Format(CDate(txtDate3), "yyyy") > 2300) Then
            txtDate3 = Format(CDate(txtDate3), "yyyy") - 543 & Format(CDate(txtDate3), "MMdd")
            txtDate4 = Format(CDate(txtDate4), "yyyy") - 543 & Format(CDate(txtDate4), "MMdd") + " 23:59"
        Else
            txtDate3 = Format(CDate(Request.QueryString("txtDate3").ToString), "yyyyMMdd")
            txtDate4 = Format(CDate(Request.QueryString("txtDate4").ToString), "yyyyMMdd") + " 23:59"
        End If
        'txtDate3 = Request.QueryString("txtDate3").ToString()
        'txtDate4 = Request.QueryString("txtDate4").ToString()
        Try

            sql = " delete from tblsalereporttsr where creatid=" & Request.Cookies("userID").Value
            Connection.Open()
            Command = New SqlCommand(sql, Connection)
            Command.ExecuteNonQuery()
            Connection.Close()

            If Request.Cookies("UserLevel").Value = 2 Then
                sql = " select   userid,fname+' '+lname +case when UserStatus=0 then ' (ยกเลิก)'else '' end as  nameuser,supid,UserStatus  from tbluser "
                sql += " where  "
                sql += "  (SupID=" & Request.QueryString("assig3") & " "
                sql += " ) order by userlevelid,fname "
            ElseIf Request.Cookies("UserLevel").Value = 1 Then
                sql = " select   userid,fname+' '+lname +case when UserStatus=0 then ' (ยกเลิก)'else '' end as  nameuser,supid,UserStatus  from tbluser "
                sql += " where  supID =" & Request.QueryString("assig2")
                sql += " order by userlevelid,fname "
            ElseIf Request.Cookies("UserLevel").Value = 3 Then
                sql = " select   userid,fname+' '+lname +case when UserStatus=0 then ' (ยกเลิก)'else '' end as  nameuser,supid,UserStatus  from tbluser "
                sql += " where  "
                sql += "  (supid=" & Request.Cookies("userID").Value & " "
                sql += " ) order by userlevelid,fname "

            End If


            dt = DataAccess.DataRead(sql)
            If dt.Rows.Count > 0 Then
                Dim Ustatus As Int16 = 0
                For i = 0 To dt.Rows.Count - 1
                    Ustatus = dt.Rows(i).Item("UserStatus")
                    ncount = 0
                    sp = 0
                    countIn = 0

                    'newcode
                    countlist = 0

                    'Leadername = "Sup Name: "
                    'If Request.Cookies("UserLevel").Value = 2 Then 'PL
                    '    sql = " select  fname+' '+lname as Leadername  from tbluser  where userid =" & Request.QueryString("assig3")
                    '    dt1 = New DataTable
                    '    dt1 = DataAccess.DataRead(sql)
                    '    ' Leadername = "Sup Name: " + dt1.Rows(0).Item("Leadername")
                    'ElseIf Request.Cookies("UserLevel").Value = 1 Then 'OM
                    '    sql = " select  fname+' '+lname as Leadername  from tbluser  where userid =" & Request.QueryString("assig2")
                    '    dt1 = New DataTable
                    '    dt1 = DataAccess.DataRead(sql)
                    '    'Leadername += dt1.Rows(0).Item("Leadername")
                    'ElseIf Request.Cookies("UserLevel").Value = 3 Then 'Sup
                    '    sql = " select  fname+' '+lname as Leadername  from tbluser  where userid  =" & Request.Cookies("userID").Value
                    '    dt1 = New DataTable
                    '    dt1 = DataAccess.DataRead(sql)
                    '    'Leadername = "Sup Name: " + dt1.Rows(0).Item("Leadername")
                    'End If

                    'sql = "  select isnull(count(tmp.IdCar),0) as ncount   "
                    'sql += " from ("
                    'sql += " SELECT  distinct tblCar.IdCar  "
                    'sql += " FROM TblApplication"
                    'sql += " inner join tblCar ON TblApplication.Idcar = tblCar.IdCar "
                    'sql += " INNER JOIN TblCustomer ON tblCar.CusID = TblCustomer.CusID "
                    'sql += " WHERE "
                    'sql += " TblApplication.AppStatus = 1 "
                    'sql += " AND (TblApplication.AppID IN (SELECT DISTINCT AppID FROM TblPayment)) "
                    'sql += " and CONVERT(VARCHAR, TblApplication.ProtectDate, 111) between '" & ConvertDate.SetISODate("en", Format(txtDate1, "dd/MM/yyyy")) & "' and '" & ConvertDate.SetISODate("en", Format(txtDate2, "dd/MM/yyyy")) & "'   and assignto = " & dt.Rows(i).Item("userid")
                    'sql += " ) tmp"

                    sql = " SELECT     count(*) as ncount "
                    sql += " FROM TblApplication "
                    sql += " inner join vwProtectDatesourceTSR ON TblApplication.Idcar = vwProtectDatesourceTSR.IdCar "
                    sql += " INNER JOIN TblCustomer ON vwProtectDatesourceTSR.CusID = TblCustomer.CusID "
                    sql += " WHERE "
                    sql += " (TblApplication.AppStatus = 1) "
                    sql += " AND (TblApplication.IsProvalue = 1) "
                    sql += " AND (TblApplication.AppID IN (SELECT DISTINCT AppID FROM TblPayment)) "
                    sql += " and vwProtectDatesourceTSR.AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and assignto = " & dt.Rows(i).Item("userid")

                    'sql = "  select isnull(count(tmp.sp),0) as ncount "
                    'sql += " from ("
                    'sql += " SELECT  "
                    'sql += " case 	when TblApplication.IsProvalue=1 and TblApplication.IsCarpet=1 then isnull((provalue+carpet),0) "
                    'sql += "  		when TblApplication.IsProvalue=1 and TblApplication.IsCarpet=0 then isnull((provalue),0) "
                    'sql += " 		when TblApplication.IsProvalue=0 and TblApplication.IsCarpet=1 then isnull((carpet),0) end"
                    'sql += " as sp "
                    'sql += " FROM TblApplication"
                    'sql += " inner join tblCar ON TblApplication.Idcar = tblCar.IdCar "
                    'sql += " INNER JOIN TblCustomer ON tblCar.CusID = TblCustomer.CusID "
                    'sql += " left  join tblpayment a8 on TblApplication.appid = a8.appid and a8.payno  = 1  "
                    'sql += " WHERE(TblApplication.AppStatus = 1)"
                    'sql += " and  a8.paydate  is not null   and curstatus in (4,3) "
                    'sql += " and CONVERT(VARCHAR, TblApplication.ProtectDate, 111) between '" & ConvertDate.SetISODate("en", txtDate1) & "' and '" & ConvertDate.SetISODate("en", txtDate2) & "'   and assignto = " & dt.Rows(i).Item("userid")
                    'sql += " ) tmp"

                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    ncount = dt1.Rows(0).Item("ncount")

                    sql = " SELECT      isnull(sum(provalue+carpet),0) as sp "
                    sql += " FROM TblApplication"
                    sql += " inner join vwProtectDatesourceTSR ON TblApplication.Idcar = vwProtectDatesourceTSR.IdCar "
                    sql += " INNER JOIN TblCustomer ON vwProtectDatesourceTSR.CusID = TblCustomer.CusID "
                    sql += " WHERE "
                    sql += " (TblApplication.AppStatus = 1) "
                    sql += " AND (TblApplication.IsProvalue = 1) "
                    sql += " AND (TblApplication.AppID IN (SELECT DISTINCT AppID FROM TblPayment)) "
                    sql += " and  vwProtectDatesourceTSR.AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'   and assignto = " & dt.Rows(i).Item("userid")

                    'sql = " select isnull(sum(tmp.sp),0) as sp "
                    'sql += " from ("
                    'sql += " SELECT   "
                    'sql += " case 	when TblApplication.IsProvalue=1 and TblApplication.IsCarpet=1 then isnull((provalue+carpet),0) "
                    'sql += "  		when TblApplication.IsProvalue=1 and TblApplication.IsCarpet=0 then isnull((provalue),0) "
                    'sql += "  		when TblApplication.IsProvalue=0 and TblApplication.IsCarpet=1 then isnull((carpet),0) end"
                    'sql += " 		as sp "
                    'sql += " FROM TblApplication"
                    'sql += " inner join tblCar ON TblApplication.Idcar = tblCar.IdCar "
                    'sql += " INNER JOIN TblCustomer ON tblCar.CusID = TblCustomer.CusID "
                    'sql += " WHERE "
                    'sql += " TblApplication.AppStatus = 1 "
                    'sql += " AND (TblApplication.AppID IN (SELECT DISTINCT AppID FROM TblPayment)) "
                    'sql += " and  TblApplication.ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'   and assignto = " & dt.Rows(i).Item("userid")
                    'sql += " ) tmp"
                    'sql = "  select isnull(sum(tmp.sp),0) as sp "
                    'sql += " from ("
                    'sql += " SELECT  "
                    'sql += " case 	when TblApplication.IsProvalue=1 and TblApplication.IsCarpet=1 then isnull((provalue+carpet),0) "
                    'sql += "  		when TblApplication.IsProvalue=1 and TblApplication.IsCarpet=0 then isnull((provalue),0) "
                    'sql += " 		when TblApplication.IsProvalue=0 and TblApplication.IsCarpet=1 then isnull((carpet),0) end"
                    'sql += " as sp "
                    'sql += " FROM TblApplication"
                    'sql += " inner join tblCar ON TblApplication.Idcar = tblCar.IdCar "
                    'sql += " INNER JOIN TblCustomer ON tblCar.CusID = TblCustomer.CusID "
                    'sql += " left  join tblpayment a8 on TblApplication.appid = a8.appid and a8.payno  = 1  "
                    'sql += " WHERE(TblApplication.AppStatus = 1)"
                    'sql += " and  a8.paydate  is not null   and curstatus in (4,3) "
                    'sql += " and CONVERT(VARCHAR, TblApplication.ProtectDate, 111) between '" & ConvertDate.SetISODate("en", txtDate1) & "' and '" & ConvertDate.SetISODate("en", txtDate2) & "'   and assignto = " & dt.Rows(i).Item("userid")
                    'sql += " ) tmp"

                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    sp = dt1.Rows(0).Item("sp")


                    sql = " select  count(*) as countIn  from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'   and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countIn = dt1.Rows(0).Item("countIn")

                    'new code----------------
                    'list used
                    sql = " select  count(*) as countlist  from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus<>1 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countlist = dt1.Rows(0).Item("countlist")

                    '-------------------------

                    'sql = " select  count(*) as countSuccess  from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=3 and assignto = " & dt.Rows(i).Item("userid")
                    'sql = " Select count(tblCar.IdCar) as countSuccess"
                    'sql = " select isnull(count(tmp.IdCar),0) as countSuccess "
                    'sql += " from ("
                    'sql += " SELECT DISTINCT tblCar.IdCar"
                    'sql += " FROM TblApplication"
                    'sql += " inner join tblCar ON TblApplication.Idcar = tblCar.IdCar "
                    'sql += " INNER JOIN TblCustomer ON tblCar.CusID = TblCustomer.CusID "
                    'sql += " WHERE TblApplication.AppStatus = 1"
                    'sql += " and curstatus in (3) "
                    'sql += " and CONVERT(VARCHAR, TblApplication.ProtectDate, 111) between '" & ConvertDate.SetISODate("en", txtDate1) & "' and '" & ConvertDate.SetISODate("en", txtDate2) & "'   and assignto = " & dt.Rows(i).Item("userid")
                    'sql += " ) tmp "
                    'sql += " FROM TblApplication"
                    'sql += " inner join tblCar ON TblApplication.Idcar = tblCar.IdCar "
                    'sql += " INNER JOIN TblCustomer ON tblCar.CusID = TblCustomer.CusID "
                    'sql += " WHERE  TblApplication.AppStatus = 1 and tblCar.CurStatus=3"
                    'sql += " and  TblApplication.ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'   and assignto = " & dt.Rows(i).Item("userid")

                    'success
                    'sql = " select  count(*) as countSuccess  from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=3 and assignto = " & dt.Rows(i).Item("userid")
                    'dt1 = New DataTable
                    'dt1 = DataAccess.DataRead(sql)
                    'countSuccess = dt1.Rows(0).Item("countSuccess")

                    ' 
                    'sql = " select  count(*) as countWait  from vwProtectDatesourceTSR where ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'  and curstatus=4 and assignto = " & dt.Rows(i).Item("userid")
                    'sql = " Select count(tblCar.IdCar) as countWait "
                    'sql += " FROM TblApplication"
                    'sql += " inner join tblCar ON TblApplication.Idcar = tblCar.IdCar "
                    'sql += " INNER JOIN TblCustomer ON tblCar.CusID = TblCustomer.CusID "
                    'sql += " WHERE  TblApplication.AppStatus = 1 and tblCar.CurStatus=4"
                    'sql += " and  TblApplication.ProtectDate between '" & txtDate1 & "' and '" & txtDate2 & "'   and assignto = " & dt.Rows(i).Item("userid")

                    'sql = " select isnull(count(tmp.IdCar),0) as countWait "
                    'sql += " from ("
                    'sql += " SELECT DISTINCT tblCar.IdCar"
                    'sql += " FROM TblApplication"
                    'sql += " inner join tblCar ON TblApplication.Idcar = tblCar.IdCar "
                    'sql += " INNER JOIN TblCustomer ON tblCar.CusID = TblCustomer.CusID "
                    'sql += " WHERE TblApplication.AppStatus = 1"
                    'sql += " and curstatus in (4) "
                    'sql += " and CONVERT(VARCHAR, TblApplication.ProtectDate, 111) between '" & ConvertDate.SetISODate("en", txtDate1) & "' and '" & ConvertDate.SetISODate("en", txtDate2) & "'   and assignto = " & dt.Rows(i).Item("userid")
                    'sql += " ) tmp "

                    'success
                    sql = " select  count(*) as countSuccess  from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=3 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countSuccess = dt1.Rows(0).Item("countSuccess")

                    'wait
                    sql = " select  count(*) as countWait  from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=4 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countWait = dt1.Rows(0).Item("countWait")

                    'refuse
                    sql = " select  count(*) as countRefuse  from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=5 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countRefuse = dt1.Rows(0).Item("countRefuse")

                    'follow
                    sql = " select  count(*) as countFollow  from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=6 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countFollow = dt1.Rows(0).Item("countFollow")

                    'call back
                    sql = " select  count(*) as countCallback  from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=8 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countCallback = dt1.Rows(0).Item("countCallback")

                    'no contact
                    sql = " select  count(*) as countNocontact  from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=7 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countNocontact = dt1.Rows(0).Item("countNocontact")

                    'not update
                    sql = " select  count(*) as countNotupdate  from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=9 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countNotupdate = dt1.Rows(0).Item("countNotupdate")

                    'new case
                    sql = " select  count(*) as countNew_Case  from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=1 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countNew_Case = dt1.Rows(0).Item("countNew_Case")

                    'try again
                    sql = " select  count(*) as countTry_Again   from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=2 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countTry_Again = dt1.Rows(0).Item("countTry_Again")

                    'not target
                    sql = " select  count(*) as countNot_Target   from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=10 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countNot_Target = dt1.Rows(0).Item("countNot_Target")

                    'already applied
                    sql = " select  count(*) as countAlready_Applied  from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=11 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countAlready_Applied = dt1.Rows(0).Item("countAlready_Applied")

                    'duplicated
                    sql = " select  count(*) as countDuplicated   from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=12 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countDuplicated = dt1.Rows(0).Item("countDuplicated")

                    'abandon
                    sql = " select  count(*) as countAbandon   from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=13 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countAbandon = dt1.Rows(0).Item("countAbandon")

                    'unreachable
                    sql = " select  count(*) as countUnreachable   from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=14 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countUnreachable = dt1.Rows(0).Item("countUnreachable")

                    'more 3
                    sql = " select  count(*) as countMore3   from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=15 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countMore3 = dt1.Rows(0).Item("countMore3")

                    'cancel
                    sql = " select  count(*) as countCANCEL   from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=16 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countCANCEL = dt1.Rows(0).Item("countCANCEL")

                    'payment
                    sql = " select  count(*) as countPayment   from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=19 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countPayment = dt1.Rows(0).Item("countPayment")

                    'wait cancel
                    sql = " select  count(*) as countWaitCANCEL   from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=20 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countWaitCANCEL = dt1.Rows(0).Item("countWaitCANCEL")

                    'wait app
                    sql = " select  count(*) as countWaitWaitApp    from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=26 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countWaitWaitApp = dt1.Rows(0).Item("countWaitWaitApp")

                    'success wait app
                    sql = " select  count(*) as countSuccessWaitApp   from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=25 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countSuccessWaitApp = dt1.Rows(0).Item("countSuccessWaitApp")

                    're-finance
                    sql = " select  count(*) as countReFinance   from vwProtectDatesourceTSR where AssUpdateDate between '" & txtDate3 & "' and '" & txtDate4 & "'  and curstatus=27 and assignto = " & dt.Rows(i).Item("userid")
                    dt1 = New DataTable
                    dt1 = DataAccess.DataRead(sql)
                    countReFinance = dt1.Rows(0).Item("countReFinance")

                    'sql = " insert into tblsalereporttsr(tsrid,tsrname, countin, countapprove,approve,source,countSuccess,countWait,countRefuse,countFollow,countCallback,countNocontact,countNotupdate,Leadername) values ('" & dt.Rows(i).Item("userid") & "','" & dt.Rows(i).Item("nameuser") & "','" & countIn & "','" & ncount & "','" & sp & "','" & SourceName & "','" & countSuccess & "','" & countWait & "','" & countRefuse & "','" & countFollow & "','" & countCallback & "','" & countNocontact & "','" & countNotupdate & "','" & Leadername & "')"
                    If sp > 0 And Ustatus = 0 Then
                        sql = " insert into tblsalereporttsr(tsrid,tsrname, countin, countapprove,approve,source,countSuccess,countWait,countRefuse,countFollow,"
                        sql += " countCallback,countNocontact,countNotupdate,Leadername,countNew_Case,countTry_Again,countNot_Target,countAlready_Applied,countDuplicated,countAbandon,countUnreachable,"
                        sql += " countMore3,countCANCEL,countPayment,countWaitCANCEL,countWaitWaitApp,countSuccessWaitApp,countReFinance,creatid,countlist,supid) "
                        sql += " values ('" & dt.Rows(i).Item("userid") & "','" & dt.Rows(i).Item("nameuser") & "','" & countIn & "','" & ncount & "','" & sp & "','" & SourceName & "','" & countSuccess & "','" & countWait & "','" & countRefuse & "','" & countFollow & "',"
                        sql += " '" & countCallback & "','" & countNocontact & "','" & countNotupdate & "','" & Leadername & "',"
                        sql += " '" & countNew_Case & "','" & countTry_Again & "','" & countNot_Target & "','" & countAlready_Applied & "','" & countDuplicated & "',"
                        sql += " '" & countAbandon & "','" & countUnreachable & "','" & countMore3 & "','" & countCANCEL & "','" & countPayment & "','" & countWaitCANCEL & "',"
                        sql += " '" & countWaitWaitApp & "','" & countSuccessWaitApp & "','" & countReFinance & "','" & Request.Cookies("userID").Value & "','" & countlist & "' , '" & dt.Rows(i).Item("supid") & "')"

                    ElseIf Ustatus <> 0 Then
                        sql = " insert into tblsalereporttsr(tsrid,tsrname, countin, countapprove,approve,source,countSuccess,countWait,countRefuse,countFollow,"
                        sql += " countCallback,countNocontact,countNotupdate,Leadername,countNew_Case,countTry_Again,countNot_Target,countAlready_Applied,countDuplicated,countAbandon,countUnreachable,"
                        sql += " countMore3,countCANCEL,countPayment,countWaitCANCEL,countWaitWaitApp,countSuccessWaitApp,countReFinance,creatid,countlist,supid) "
                        sql += " values ('" & dt.Rows(i).Item("userid") & "','" & dt.Rows(i).Item("nameuser") & "','" & countIn & "','" & ncount & "','" & sp & "','" & SourceName & "','" & countSuccess & "','" & countWait & "','" & countRefuse & "','" & countFollow & "',"
                        sql += " '" & countCallback & "','" & countNocontact & "','" & countNotupdate & "','" & Leadername & "',"
                        sql += " '" & countNew_Case & "','" & countTry_Again & "','" & countNot_Target & "','" & countAlready_Applied & "','" & countDuplicated & "',"
                        sql += " '" & countAbandon & "','" & countUnreachable & "','" & countMore3 & "','" & countCANCEL & "','" & countPayment & "','" & countWaitCANCEL & "',"
                        sql += " '" & countWaitWaitApp & "','" & countSuccessWaitApp & "','" & countReFinance & "','" & Request.Cookies("userID").Value & "','" & countlist & "' , '" & dt.Rows(i).Item("supid") & "')"

                    End If

                   
                    Connection.Open()
                    Command = New SqlCommand(sql, Connection)
                    Command.ExecuteNonQuery()
                    Connection.Close()

                Next
                MyReportLoad()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub Page_PreInit(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreInit
        CrystalReportViewer1.ReportSource = Session("Report")
        CrystalReportViewer1.DataBind()
    End Sub
    Protected Sub MyReportLoad()
        Dim strQuery As String
        Dim Command As SqlCommand
        Connection.Open()
        strQuery = "Select Count(*) From tblsalereporttsr where creatid=" & Request.Cookies("userID").Value
        Command = New SqlCommand(strQuery, Connection)
        Dim Check As Integer = Command.ExecuteScalar()
        Connection.Close()
        If Check <= 0 Then
            ScriptManager.RegisterStartupScript(Page, Page.GetType, "Alert", "alert('ไม่พบข้อมูลที่ต้องการออกรายงาน !!');", True)
            Exit Sub
        End If

        Dim reportname As String = Server.MapPath("rptsalereportbySource.rpt")
        myReport.Load(reportname)
        myReport.SetDatabaseLogon(users, pass)
       
        Session("Report") = myReport
        CrystalReportViewer1.ReportSource = Session("Report")
        CrystalReportViewer1.SelectionFormula = " {tblsalereporttsr.creatid}=" & Request.Cookies("userID").Value
        CrystalReportViewer1.DataBind()
    End Sub
End Class
