﻿
Partial Class Modules_Manager_Report_frmGraph
    Inherits System.Web.UI.Page

End Class
