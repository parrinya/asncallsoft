﻿Imports AjaxControlToolkit
Partial Class Modules_Manager_News_frmNewsTop
    Inherits System.Web.UI.Page
    Dim FunAll As New FuntionAll
   Protected Sub GridView1_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridView1.RowCommand
        If e.CommandName = "Update" Then
            Dim Editor As HTMLEditor.Editor = FunAll.ObjFindControl("Editor2", GridView1.Rows(e.CommandArgument).Cells(2))
            SqlNews.UpdateParameters("Detail").DefaultValue = Replace(Editor1.Content, "<br />", "")
            SqlNews.UpdateParameters("NewsID").DefaultValue = GridView1.DataKeys(e.CommandArgument).Item(0)
            SqlNews.Update()
        End If
    End Sub

   
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        SqlNews.InsertParameters("Detail").DefaultValue = Replace(Editor1.Content, "<br />", "")
        SqlNews.InsertParameters("userID").DefaultValue = ddUser.SelectedValue
        SqlNews.Insert()
        Editor1.Content = ""
    End Sub
End Class
