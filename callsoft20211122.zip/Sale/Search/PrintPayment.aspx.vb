﻿Imports System.IO
Imports System.Data
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports System.Data.SqlClient
Imports GenCode128
Partial Class Modules_Sale_Search_PrintPayment
    Inherits System.Web.UI.Page
    Dim dt As DataTable
    Dim DataAccess As New DataAccess
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If (Not IsPostBack) Then
            Dim Appid As String = Request.QueryString("AppID")
            Dim PayID As String = Request.QueryString("PayID")
            Payment(Appid, PayID)
        End If

    End Sub
    Protected Sub Payment(ByVal tmpAppid As String, ByVal tmpPayID As String)
        Dim str As New StringBuilder

        str.Append(" Select a4.Sname ")
        str.Append(" ,case when len(a4.SAddress) > 0 then 'เลขที่ ' + a4.SAddress else '' end")
        str.Append("        +case when len(a4.SMoo) > 0 then ' หมู่. ' + a4.SMoo else '' end")
        str.Append("        +case when len(a4.SSoi) > 0 then ' ซ. ' + a4.SSoi else '' end")
        str.Append("        +case when len(a4.SRoad) > 0 then ' ถ. ' + a4.SRoad else '' end        ")
        str.Append("        +case when len(a4.Svillege) > 0 then ' ' + a4.Svillege else '' end as Addr   ")
        str.Append(" ,case when a4.SProvince = 'กรุงเทพมหานคร' then a4.SSubDist else 'ต.'+a4.SSubDist end  as SubDistrict ")
        str.Append(" ,case when a4.SProvince = 'กรุงเทพมหานคร' then a4.SDist  else 'อ.'+a4.SDist  end as District  ")
        str.Append(" ,case when a4.SProvince = 'กรุงเทพมหานคร' then a4.SProvince  else 'จ.'+a4.SProvince  end as Province  ")
        str.Append(" ,a4.SZip as PostalDesc ")
        str.Append(" ,a3.CarBrand ")
        str.Append(" ,a3.CarSeries ")
        str.Append(" ,a3.CarID ")
        str.Append(" ,a5.ProTypeName ")
        str.Append(" ,case  when a2.iscarpet=1 and a2.IsProvalue=1 then  'ประกัน'+ a6.TypeName +' รวม พ.ร.บ.' ")
        str.Append("        when a2.iscarpet=0 and a2.IsProvalue=1 then  'ประกัน'+ a6.TypeName ")
        str.Append("        when a2.iscarpet=1 and a2.IsProvalue=0 then  'พ.ร.บ.' ")
        str.Append("        else '-' end as TypeName ")
        str.Append(" ,convert(varchar,a2.ProtectDate,103)  as ProtectDate ")
        str.Append(" ,convert(varchar,a2.ExpProtectDate,103)  as ExpProtectDate ")
        str.Append(" ,case when a2.IsProvalue=1 then a2.ProValue else '0.00' end as ProValue")
        str.Append(" ,a2.IsProvalue")
        str.Append(" ,case when a2.iscarpet=1 then a2.CarPet else '0.00' end as CarPet")
        str.Append(" ,(case when a2.IsProvalue=1 then a2.ProValue else 0 end + case when a2.iscarpet=1 then a2.CarPet else 0 end) as TotalProValue")
        str.Append(" ,a3.RefNo ")
        str.Append(" ,CONVERT (VarChar,a2.AppID) as appid")
        str.Append(" ,a1.PayID")
        str.Append(" ,convert(varchar,a1.AppointDate,103)  as AppointDate")
        str.Append(" ,a1.TotalPay ")
        str.Append(" from TblAppPay a1")
        str.Append(" Inner Join TblApplication a2 on a1.AppID = a2.AppID")
        str.Append(" Inner Join TblCar a3 on a2.Idcar = a3.IdCar ")
        str.Append(" Inner Join TblCustomer a4 on a3.CusID = a4.CusID ")
        str.Append(" Inner Join Tbl_ProductType a5 on a2.ProDuctID = a5.ProTypeID")
        str.Append(" Inner Join Tbl_Type a6 on a2.Typeprovalue = a6.Typeid ")
        str.Append(" Where a2.AppID = '" + tmpAppid + "' and a1.PayID ='" + tmpPayID + "'")

        dt = New DataTable
        dt = DataAccess.DataRead(str.ToString())

        If dt.Rows.Count > 0 Then
            'Set Background Image...
            Dim jpg1 As Image

            jpg1 = Image.GetInstance(HttpContext.Current.Server.MapPath("../../../images/Pay_Resize.jpg"))
            jpg1.ScaleToFit(595, 842)
            jpg1.Alignment = iTextSharp.text.Image.UNDERLYING
            jpg1.SetAbsolutePosition(0, 0)


            'Set Font...
            Dim bf As BaseFont
            bf = BaseFont.CreateFont(HttpContext.Current.Server.MapPath("../../../font/angsana_new.ttf"), BaseFont.IDENTITY_H, BaseFont.EMBEDDED)

            'Set file...
            Dim strFileName As String
            strFileName = "Payment_" + dt.Rows(0)("AppID").ToString() + ".pdf"
            Dim fs As New FileStream(HttpContext.Current.Server.MapPath("../../../pdf/" + strFileName), FileMode.Create, FileAccess.Write, FileShare.None)

            'Set document...
            Dim doc As New Document(PageSize.A4)

            Dim writer As PdfWriter
            writer = PdfWriter.GetInstance(doc, fs)

            'Start...
            doc.Open()
            'Add Image...
            doc.Add(jpg1)

            Dim cb As PdfContentByte = writer.DirectContent

            cb.SetFontAndSize(bf, 13)
            cb.BeginText()


            '2.1
            cb.SetTextMatrix(20, 700)
            cb.ShowText(dt.Rows(0)("Sname").ToString() & " ") 'Sname

            '2.2
            cb.SetTextMatrix(20, 685)
            cb.ShowText(dt.Rows(0)("Addr").ToString() & " ") 'Addr

            '2.3
            cb.SetTextMatrix(20, 670)
            cb.ShowText(dt.Rows(0)("SubDistrict").ToString() & " " & dt.Rows(0)("District").ToString() & " " & dt.Rows(0)("Province").ToString()) 'SubDistrict  District Province

            '2.4
            cb.SetTextMatrix(20, 655)
            cb.ShowText(dt.Rows(0)("PostalDesc").ToString() & " ")



            '1.1
            cb.SetTextMatrix(220, 700)
            cb.ShowText("ทะเบียนรถยนต์/License No.: " & dt.Rows(0)("CarID").ToString() & " ")

            '1.2
            cb.SetTextMatrix(220, 685)
            cb.ShowText("บริษัทผู้ประกันภัย/Insurer: " & dt.Rows(0)("ProTypeName").ToString() & " ")

            '1.3
            cb.SetTextMatrix(220, 670)
            cb.ShowText("วันคุ้มครอง/Period Insured: " & dt.Rows(0)("ProtectDate").ToString() & " - " & dt.Rows(0)("ExpProtectDate").ToString())

            '1.4
            cb.SetTextMatrix(220, 655)
            cb.ShowText("ประเภทประกัน/Type: " & dt.Rows(0)("TypeName").ToString() & " ")

            '1.5
            cb.SetTextMatrix(220, 640)
            cb.ShowText("ราคาเบี้ยประกันภัย/Premium: " & FormatNumber(CDbl(dt.Rows(0)("ProValue").ToString()), 2) & " บาท")

            '1.6
            cb.SetTextMatrix(220, 625)
            cb.ShowText("พ.ร.บ./Compulsory: " & FormatNumber(CDbl(dt.Rows(0)("CarPet").ToString()), 2) & " บาท")

            '1.7
            cb.SetTextMatrix(220, 610)
            cb.ShowText("รวมทั้งสิ้น/Total: " & FormatNumber(CDbl(dt.Rows(0)("TotalProValue").ToString()), 2) & " บาท")



            '3.1
            cb.SetTextMatrix(390, 479)
            cb.ShowText(dt.Rows(0)("AppointDate").ToString() & " (งวดที่ " & dt.Rows(0)("PayID").ToString() & ")")

            '3.2
            cb.SetTextMatrix(390, 461)
            cb.ShowText(dt.Rows(0)("Sname").ToString() & " ")

            '3.3
            cb.SetTextMatrix(390, 443)
            cb.ShowText(dt.Rows(0)("RefNo").ToString() & " ")

            '3.4
            cb.SetTextMatrix(390, 425)
            cb.ShowText(dt.Rows(0)("Appid").ToString() & " ")

            '4.1
            cb.SetTextMatrix(410, 360)
            cb.ShowText(FormatNumber(CDbl(dt.Rows(0)("TotalPay").ToString()), 2))

            '5.1
            Dim dd As String = ThaiBath(dt.Rows(0)("TotalPay"))
            cb.SetTextMatrix(320, 325)
            cb.ShowText(dd)

            '6.1
            cb.SetTextMatrix(390, 210)
            cb.ShowText(dt.Rows(0)("AppointDate").ToString() & " (งวดที่ " & dt.Rows(0)("PayID").ToString() & ")")

            '6.2
            cb.SetTextMatrix(390, 190)
            cb.ShowText(dt.Rows(0)("Sname").ToString() & " ")


            '6.3
            cb.SetTextMatrix(390, 172)
            cb.ShowText(dt.Rows(0)("RefNo").ToString() & " ")

            '6.4
            cb.SetTextMatrix(390, 154)
            cb.ShowText(dt.Rows(0)("APPID").ToString() & " ")

            '7.1
            cb.SetTextMatrix(410, 90)
            cb.ShowText(FormatNumber(CDbl(dt.Rows(0)("TotalPay").ToString()), 2))

            '8.1
            cb.SetTextMatrix(320, 55)
            cb.ShowText(dd)


            'QR CODE 
            '11.1
            'dt.Rows(0)("TotalPay").ToString()
            Dim strMoney As String = "0"
            strMoney = FormatNumber(CDbl(dt.Rows(0)("TotalPay").ToString()), 2)
            strMoney = Replace(strMoney, ".", "")
            strMoney = Replace(strMoney, ",", "")

            Dim qe As MessagingToolkit.QRCode.Codec.QRCodeEncoder = New MessagingToolkit.QRCode.Codec.QRCodeEncoder
            Dim L1_T1 As String = "|010755800027000" & Chr(13) & dt.Rows(0)("RefNo").ToString() & Chr(13) & dt.Rows(0)("AppID").ToString() & Chr(13) & strMoney

            Dim ALL As String = L1_T1
            Dim pic As iTextSharp.text.Image = iTextSharp.text.Image.GetInstance(qe.Encode(ALL), System.Drawing.Imaging.ImageFormat.Jpeg)

            pic.ScaleToFit(80, 80)
            pic.SetAbsolutePosition(490, 625)
            doc.Add(pic)

            'BARCODE
            '9.1
            Dim pic1 As iTextSharp.text.Image = iTextSharp.text.Image.GetInstance(Code128Rendering.MakeBarcodeImage(L1_T1, 1, True), System.Drawing.Imaging.ImageFormat.Jpeg)
            pic1.ScaleToFit(170, 5000)
            pic1.SetAbsolutePosition(310, 293)
            doc.Add(pic1)

            Dim str_Barcode As String = "|010755800027000" & dt.Rows(0)("RefNo").ToString() & dt.Rows(0)("AppID").ToString() & strMoney
            cb.SetTextMatrix(308, 285)
            cb.ShowText(str_Barcode)

            '10.1
            Dim pic2 As iTextSharp.text.Image = iTextSharp.text.Image.GetInstance(Code128Rendering.MakeBarcodeImage(L1_T1, 1, True), System.Drawing.Imaging.ImageFormat.Jpeg)
            pic2.ScaleToFit(170, 5000)
            pic2.SetAbsolutePosition(310, 23)
            doc.Add(pic2)

            cb.SetTextMatrix(308, 16)
            cb.ShowText(str_Barcode)

            cb.EndText()

            'Close...
            doc.Close()

            'Display pdf...
            ShowPdf(strFileName)
        End If
    End Sub
    Public Function ThaiBath(ByVal pamt As Double) As String

        '//---- จำกัดตัวเลขไว้ที่ 999,999 ล้าน ----
        Dim valstr As String, vLen As Integer, vNO As Integer, syslge As String
        Dim i As Integer, j As Integer, v As Integer
        Dim wnumber(10) As String, wdigit(10) As String, spcdg(5) As String
        Dim vword(20) As String
        Dim ThaiBaht As String
        If pamt <= 0.0# Then
            ThaiBaht = ""
        Else
            valstr = Trim(Format$(pamt, "##########0.00"))
            vLen = Len(valstr) - 3
            For i = 1 To 20
                vword(i) = ""
            Next i
            wnumber(1) = "หนึ่ง" : wnumber(2) = "สอง" : wnumber(3) = "สาม" : wnumber(4) = "สี่"
            wnumber(5) = "ห้า" : wnumber(6) = "หก" : wnumber(7) = "เจ็ด" : wnumber(8) = "แปด"
            wnumber(9) = "เก้า" : wdigit(1) = "บาท" : wdigit(2) = "สิบ" : wdigit(3) = "ร้อย" : wdigit(4) = "พัน"
            wdigit(5) = "หมื่น" : wdigit(6) = "แสน" : wdigit(7) = "ล้าน" : spcdg(1) = "สตางค์" : spcdg(2) = "เอ็ด"
            spcdg(3) = "ยี่" : spcdg(4) = "ถ้วน"
            For i = 1 To vLen
                vNO = Int(Val(Mid$(valstr, i, 1)))
                If vNO = 0 Then
                    vword(i) = ""
                    If (vLen - i + 1) = 7 Then
                        vword(i) = wdigit(7)             '--ล้าน
                    End If
                Else
                    If (vLen - i + 1) > 7 Then
                        j = vLen - i - 5               '--เกินหลักล้าน
                    Else
                        j = vLen - i + 1               '--หลักแสน
                    End If
                    vword(i) = wnumber(vNO) + wdigit(j) '-30ถึง90
                    If vNO = 1 And j = 2 Then
                        vword(i) = wdigit(2)             '--สิบ
                    End If
                    If vNO = 2 And j = 2 Then
                        vword(i) = spcdg(3) + wdigit(j)  '--ยี่สิบ
                    End If
                    If j = 1 Then                       ' สิยเอ็ค -->เก้าสิบเอ็ด
                        vword(i) = wnumber(vNO)
                        If vNO = 1 And vLen > 1 Then
                            If Mid$(valstr, i - 1, 1) <> "0" Then
                                vword(i) = spcdg(2)
                            End If
                        End If
                    End If
                    If j = 7 Then         '-แก้บักกรณี 11,111,111.00 สิบเอ็ด
                        vword(i) = wnumber(vNO) + wdigit(j)   '-ล้าน
                        If vNO = 1 And vLen > 7 Then
                            If Mid$(valstr, i - 1, 1) <> "0" Then
                                vword(i) = spcdg(2) + wdigit(j)
                            End If
                        End If
                    End If
                End If
            Next i

            If Int(pamt) > 0 Then
                vword(vLen) = vword(vLen) + wdigit(1)
            End If
            '--------------ทศนิยม --------------
            valstr = Mid$(valstr, vLen + 2, 2)
            vLen = Len(valstr)
            For i = 1 To vLen
                vNO = Int(Val(Mid$(valstr, i, 1)))
                If vNO = 0 Then
                    vword(i + 10) = ""
                Else
                    j = vLen - i + 1
                    vword(i + 10) = wnumber(vNO) + wdigit(j)
                    If vNO = 1 And j = 2 Then
                        vword(i + 10) = wdigit(2)
                    End If
                    If vNO = 2 And j = 2 Then
                        vword(i + 10) = spcdg(3) + wdigit(j)
                    End If
                    If j = 1 Then
                        If vNO = 1 And Int(Val(Mid$(valstr, i - 1, 1))) <> 0 Then
                            vword(i + 10) = spcdg(2)
                        Else
                            vword(i + 10) = wnumber(vNO)
                        End If
                    End If
                End If
            Next i
            If pamt <> 0 Then
                If Val(valstr) = 0 Then
                    vword(13) = spcdg(4)
                Else
                    vword(13) = spcdg(1)
                End If
            End If
            '*** เผื่อใช้กรณียาวมาก และต้องการตัดประโยค
            valstr = ""
            For i = 1 To 20
                'IF LEN(valstr) < 70 AND LEN(valstr + vword(i)) > 70 Then
                '   valstr = valstr + REPLICATE(" ",70 - LEN(valstr))
                'END IF
                valstr = valstr + vword(i)
            Next i

            ThaiBaht = valstr
        End If

        Return ThaiBaht
    End Function
    Public Sub ShowPdf(ByVal strFileName As String)
        Response.ClearContent()
        Response.ClearHeaders()
        Response.AddHeader("Content-Disposition", "inline;filename=" + HttpContext.Current.Server.MapPath("../../../pdf/" + strFileName))
        Response.ContentType = "application/pdf"
        Response.WriteFile(HttpContext.Current.Server.MapPath("../../../pdf/" + strFileName))
        Response.Flush()
        Response.Clear()
    End Sub

End Class
