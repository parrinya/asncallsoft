﻿Imports System.Data
Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports CrystalDecisions.Web
Imports System.IO
Partial Class Modules_Sale_Search_frmFaxPayment
    Inherits System.Web.UI.Page
    Dim funAll As New FuntionAll
    Protected Sub GvApp_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvApp.RowCommand
        If e.CommandName = "Select" Then
            SqlAppPay.SelectParameters("AppID").DefaultValue = e.CommandArgument

        End If
    End Sub

    Protected Sub GvPayment_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvPayment.RowCommand
        If e.CommandName = "Select" Then
            Dim txtFax As TextBox = funAll.ObjFindControl("txtFax", GvPayment.Rows(e.CommandArgument))
            If txtFax.Text.Trim = "" Then
                MsgBox("กรุณากรอกเบอร์ Fax")
            Else
                GenReport(GvPayment.DataKeys(e.CommandArgument).Item(0), (e.CommandArgument) + 1)
                InsertTblSendFax(e.CommandArgument)
            End If

        ElseIf e.CommandName = "Select2" Then
            'GenReport(GvPayment.DataKeys(e.CommandArgument).Item(0), (e.CommandArgument) + 1)
            'Response.Redirect("~/FaxPayment/" & GvPayment.DataKeys(e.CommandArgument).Item(0) & ".doc")
	    Dim AppID As Integer = GvPayment.DataKeys(e.CommandArgument).Item(0)
            Dim PayID As Integer = (e.CommandArgument) + 1
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.open('PrintPayment.aspx?AppID=" & AppID & "&PayID=" & PayID & "');</script>")
        
        End If
    End Sub
    'Script MsgBox
    Public Sub MsgBox(ByVal sMsg As String)

        Dim sb As New StringBuilder()
        Dim oFormObject As System.Web.UI.Control
        sMsg = sMsg.Replace("'", "\'")
        sMsg = sMsg.Replace(Chr(34), "\" & Chr(34))
        sMsg = sMsg.Replace(vbCrLf, "\n")
        sMsg = "<script language=javascript>alert(""" & sMsg & """)</script>"

        sb = New StringBuilder()
        sb.Append(sMsg)

        For Each oFormObject In Me.Controls
            If TypeOf oFormObject Is HtmlForm Then
                Exit For
            End If
        Next

        ' Add the javascript after the form object so that the 
        ' message doesn't appear on a blank screen.
        oFormObject.Controls.AddAt(oFormObject.Controls.Count, New LiteralControl(sb.ToString()))
    End Sub

    Protected Sub GenReport(AppID As String, PayID As String)
        'This Code is used to Convert to word document
        Dim reportWord As New ReportDocument  ' Report Name 
        Dim reportname As String
        reportname = Server.MapPath("~/Modules/Manager/Report/rptPayment.rpt")

        Dim users As String = "sa"
        'Dim pass As String = "DTS2009"
        Dim pass As String = "asn@sr1"

        'Dim rpt As New CrystalReportViewer

        reportWord.Load(reportname)
        reportWord.SetDatabaseLogon(users, pass)
        reportWord.SetParameterValue("AppID", AppID)
        reportWord.SetParameterValue("PayID", PayID)


        Dim strExportFile As String = Server.MapPath("~/FaxPayment/" & AppID & ".doc")
        reportWord.ExportOptions.ExportDestinationType = ExportDestinationType.DiskFile
        reportWord.ExportOptions.ExportFormatType = ExportFormatType.WordForWindows
        Dim objOptions As DiskFileDestinationOptions = New DiskFileDestinationOptions()
        objOptions.DiskFileName = strExportFile
        reportWord.ExportOptions.DestinationOptions = objOptions
        'reportWord.SetDataSource(myDS)
        reportWord.Export()
        objOptions = Nothing
        reportWord = Nothing

        'Dim CrExportOptions As ExportOptions
        'Dim CrDiskFileDestinationOptions As New DiskFileDestinationOptions()
        'Dim CrFormatTypeOptions As New PdfRtfWordFormatOptions()
        'CrDiskFileDestinationOptions.DiskFileName = Server.MapPath("~/TestWord.pdf")
        'CrExportOptions = reportWord.ExportOptions
        'With CrExportOptions
        '    .ExportDestinationType = ExportDestinationType.DiskFile
        '    .ExportFormatType = ExportFormatType.PortableDocFormat
        '    .DestinationOptions = CrDiskFileDestinationOptions
        '    .FormatOptions = CrFormatTypeOptions
        'End With
        'reportWord.Export()

        'Dim f As New SautinSoft.PdfFocus
        'f.OpenPdf(Server.MapPath("~/TestWord.pdf"))
        ''If f.PageCount > 0 Then
        'f.ImageOptions.Dpi = 300
        'f.ToMultipageTiff(Server.MapPath("~/TestWord.tiff"))
        'Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('บันทึกข้อมูลเรียบร้อย');", True)
        'End If



    End Sub

    Protected Sub InsertTblSendFax(i As Integer)
        Dim txtFax As TextBox = funAll.ObjFindControl("txtFax", GvPayment.Rows(i))
        With SqlAppPay
            .InsertParameters("FNameth").DefaultValue = GvPayment.DataKeys(i).Item(1)
            .InsertParameters("FaxNo").DefaultValue = txtFax.Text.Trim
            .InsertParameters("filename1").DefaultValue = GvPayment.DataKeys(i).Item(0) & ".doc"
            .InsertParameters("idcar").DefaultValue = GvPayment.DataKeys(i).Item(2)
            .Insert
        End With
    End Sub
End Class
