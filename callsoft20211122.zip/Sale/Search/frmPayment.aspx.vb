﻿Imports System.Drawing

Partial Class Modules_Sale_Search_frmPayment
    Inherits System.Web.UI.Page
    Dim FunAll As New FuntionAll
    Protected Sub GvApp_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvApp.RowCommand
        If e.CommandName = "Select" Then
            Dim urlLink As String = "../Application/frmApplication.aspx?"
            urlLink += "Edit=1&Buy=2"
            urlLink += "&&IdCar=" & GvApp.DataKeys(e.CommandArgument).Item(0)
            urlLink += "&&AppID=" & GvApp.DataKeys(e.CommandArgument).Item(1)
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.open('" & urlLink & "','Application');</script>")
        ElseIf e.CommandName = "btnshow" Then
            SqlAppPay.SelectParameters("AppID").DefaultValue = GvApp.DataKeys(e.CommandArgument).Item(1)
        End If
    End Sub

    Protected Sub GvApp_DataBound(sender As Object, e As System.EventArgs) Handles GvApp.DataBound
        For i As Integer = 0 To GvApp.Rows.Count - 1
            If GvApp.DataKeys(i).Item(2).ToString = "0" Or GvApp.DataKeys(i).Item(2).ToString = "2" Then
                Dim ImageButton1 As Button = FunAll.ObjFindControl("Button1", GvApp.Rows(i).Cells(0))
                ImageButton1.Visible = True
            Else
                Dim ImageButton1 As Button = FunAll.ObjFindControl("Button1", GvApp.Rows(i).Cells(0))
                ImageButton1.Visible = False
            End If
        Next
    End Sub

End Class
