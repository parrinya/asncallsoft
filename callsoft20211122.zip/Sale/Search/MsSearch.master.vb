﻿
Partial Class Modules_Sale_Search_MsSearch
    Inherits System.Web.UI.MasterPage

    Protected Sub NavigationMenu_MenuItemClick(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.MenuEventArgs) Handles NavigationMenu.MenuItemClick
        Select Case NavigationMenu.SelectedValue
            Case 1
                Response.Redirect("frmCustomer.aspx?IdCar=" & Request.QueryString("IdCar").ToString)
            Case 2
                Response.Redirect("frmApplication.aspx?IdCar=" & Request.QueryString("IdCar").ToString)
            Case 3
                Response.Redirect("frmPayment.aspx?IdCar=" & Request.QueryString("IdCar").ToString)
            Case 4
                Response.Redirect("frmFaxPayment.aspx?IdCar=" & Request.QueryString("IdCar").ToString)
        End Select
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        'If Request.Cookies("UserLevel").Value = 5 Or Request.Cookies("UserLevel").Value = 3 Then
        '   NavigationMenu.Items.RemoveAt(2)
        'End If


        'If Request.Cookies("UserLevel").Value = 5 Then
        'NavigationMenu.Items.RemoveAt(2)
        'End If

    End Sub
End Class

