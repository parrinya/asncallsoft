﻿
Partial Class Modules_Sale_CheckApp_frmCaseCancel
    Inherits System.Web.UI.Page
    Dim ISODate As New ISODate

    Protected Sub BtnShow_Click(sender As Object, e As System.EventArgs) Handles BtnShow.Click

        SqlselectCancel.SelectParameters.Item("TypeSearch").DefaultValue = 1
        SqlselectCancel.SelectParameters.Item("date1").DefaultValue = ISODate.SetISODate("en", txtdateWaitTocancels.Text.Trim)
        SqlselectCancel.SelectParameters.Item("date2").DefaultValue = ISODate.SetISODate("en", txtdateWaitTocancele.Text.Trim)
        GVAppcancel.DataSource = SqlselectCancel
        GVAppcancel.DataBind()

    End Sub

    Protected Sub Sqlselect_Selected(sender As Object, e As System.Web.UI.WebControls.SqlDataSourceStatusEventArgs) Handles SqlselectCancel.Selected
        lblCase.Text = e.AffectedRows & " รายการ "
    End Sub

    Protected Sub Button1_Click(sender As Object, e As System.EventArgs) Handles Button1.Click
        SqlselectCancel.SelectParameters.Item("TypeSearch").DefaultValue = 2
        SqlselectCancel.SelectParameters.Item("date1").DefaultValue = ISODate.SetISODate("en", txtdateProtects.Text.Trim)
        SqlselectCancel.SelectParameters.Item("date2").DefaultValue = ISODate.SetISODate("en", txtdateProtecte.Text.Trim)
        GVAppcancel.DataSource = SqlselectCancel
        GVAppcancel.DataBind()
    End Sub
End Class
