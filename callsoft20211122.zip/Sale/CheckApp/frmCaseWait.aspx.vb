﻿
Partial Class Modules_Sale_CheckApp_frmCaseWait
    Inherits System.Web.UI.Page

    Protected Sub GVAppWait_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GVAppWait.RowCommand
        If e.CommandName = "Select" Then
            Dim urlLink As String = "../Application/frmApplication.aspx?"
            urlLink += "Edit=0&Buy=2"
            urlLink += "&&IdCar=" & GVAppWait.DataKeys(e.CommandArgument).Item(0)
            urlLink += "&&AppID=" & GVAppWait.DataKeys(e.CommandArgument).Item(1)
          
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  window.open('" & urlLink & "','Application');</script>")
        ElseIf e.CommandName = "History" Then
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.iframeShow('" & GVAppWait.DataKeys(e.CommandArgument).Item(0) & "');</script>")
        End If
    End Sub
End Class
