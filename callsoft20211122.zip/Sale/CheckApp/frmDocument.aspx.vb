﻿Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Security.Cryptography

Partial Class Modules_Sale_Phone_frmHistory
    Inherits System.Web.UI.Page
    Dim proxy As New thailandpost.track.TrackandTraceService
    Dim dt As DataTable

    Protected Sub GvDoc_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvDoc.RowCommand
        If e.CommandName = "Select" Then
            Try
                Dim lsv As thailandpost.track.TrackItem = proxy.GetItems("asnbroker", "K3mEFHSMKexeM/D1ymS6gQ==", "TH", e.CommandArgument.ToString)
                If lsv.ItemsData.Length > 0 Then
                    dt = New DataTable
                    dt.Columns.Add("Barcode")
                    dt.Columns.Add("DateTime")
                    dt.Columns.Add("DeliveryDateTime")
                    dt.Columns.Add("Description")
                    dt.Columns.Add("Location")
                    dt.Columns.Add("Signature")
                    dt.Columns.Add("StatusName")

                    For i As Integer = 0 To lsv.ItemsData.Length - 1
                        Dim dtr As DataRow = dt.NewRow
                        dtr("Barcode") = lsv.ItemsData(i).Barcode
                        dtr("DateTime") = lsv.ItemsData(i).DateTime
                        dtr("DeliveryDateTime") = lsv.ItemsData(i).DeliveryDateTime
                        dtr("Description") = lsv.ItemsData(i).Description
                        dtr("Location") = lsv.ItemsData(i).Location
                        dtr("Signature") = lsv.ItemsData(i).Signature
                        dtr("StatusName") = lsv.ItemsData(i).StatusName
                        dt.Rows.Add(dtr)
                    Next
                    GvTrackPost.DataSource = dt
                    GvTrackPost.DataBind()
                End If
            Catch ex As Exception
                MsgBox("การประมวลผลผิดพลาด กรุณาลองใหม่อีกครั้ง")
            End Try

        End If
    End Sub

    'Script MsgBox
    Public Sub MsgBox(ByVal sMsg As String)

        Dim sb As New StringBuilder()
        Dim oFormObject As System.Web.UI.Control
        sMsg = sMsg.Replace("'", "\'")
        sMsg = sMsg.Replace(Chr(34), "\" & Chr(34))
        sMsg = sMsg.Replace(vbCrLf, "\n")
        sMsg = "<script language=javascript>alert(""" & sMsg & """)</script>"

        sb = New StringBuilder()
        sb.Append(sMsg)

        For Each oFormObject In Me.Controls
            If TypeOf oFormObject Is HtmlForm Then
                Exit For
            End If
        Next

        ' Add the javascript after the form object so that the 
        ' message doesn't appear on a blank screen.
        oFormObject.Controls.AddAt(oFormObject.Controls.Count, New LiteralControl(sb.ToString()))
    End Sub
End Class
