﻿
Partial Class Modules_Sale_CheckApp_frmCaseAppPayRenew
    Inherits System.Web.UI.Page
    Dim ISODate As New ISODate
    Protected Sub BindGvAppPay()

        Select Case ddTypeApp.SelectedValue
            Case 1
                SqlAppPay.SelectParameters.Item("date3").DefaultValue = ISODate.SetISODate("en", txtdate3.Text.Trim)
                SqlAppPay.SelectParameters.Item("date4").DefaultValue = ISODate.SetISODate("en", txtdate4.Text.Trim)
                SqlAppPay.SelectParameters.Item("TypeSearch").DefaultValue = 1
                GVAppPayment.DataSource = SqlAppPay
                GVAppPayment.DataBind()
            Case 2
                SqlAppPay2.SelectParameters.Item("date3").DefaultValue = ISODate.SetISODate("en", txtdate3.Text.Trim)
                SqlAppPay2.SelectParameters.Item("date4").DefaultValue = ISODate.SetISODate("en", txtdate4.Text.Trim)
                SqlAppPay2.SelectParameters.Item("TypeSearch").DefaultValue = 1
                GVAppPayment.DataSource = SqlAppPay2
                GVAppPayment.DataBind()
            Case 3
                SqlAppPay3.SelectParameters.Item("date3").DefaultValue = ISODate.SetISODate("en", txtdate3.Text.Trim)
                SqlAppPay3.SelectParameters.Item("date4").DefaultValue = ISODate.SetISODate("en", txtdate4.Text.Trim)
                SqlAppPay3.SelectParameters.Item("TypeSearch").DefaultValue = 1
                GVAppPayment.DataSource = SqlAppPay3
                GVAppPayment.DataBind()
        End Select

    End Sub

    Protected Sub Button10_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button10.Click
        GVAppPayment.Columns(17).Visible = True
        GVAppPayment.Columns(18).Visible = True
        GVAppPayment.Columns(19).Visible = True
        GVAppPayment.Columns(20).Visible = True
        Select Case ddTypeApp.SelectedValue
            Case 1
                SqlAppPay.SelectParameters.Item("date3").DefaultValue = 0
                SqlAppPay.SelectParameters.Item("date4").DefaultValue = 0
                SqlAppPay.SelectParameters.Item("TypeSearch").DefaultValue = 2
                SqlAppPay.SelectParameters.Item("date1").DefaultValue = ISODate.SetISODate("en", txtdate1.Text.Trim)
                SqlAppPay.SelectParameters.Item("date2").DefaultValue = ISODate.SetISODate("en", txtdate2.Text.Trim)
                GVAppPayment.DataSource = SqlAppPay
                GVAppPayment.DataBind()
            Case 2
                SqlAppPay2.SelectParameters.Item("date3").DefaultValue = 0
                SqlAppPay2.SelectParameters.Item("date4").DefaultValue = 0
                SqlAppPay2.SelectParameters.Item("TypeSearch").DefaultValue = 2
                SqlAppPay2.SelectParameters.Item("date1").DefaultValue = ISODate.SetISODate("en", txtdate1.Text.Trim)
                SqlAppPay2.SelectParameters.Item("date2").DefaultValue = ISODate.SetISODate("en", txtdate2.Text.Trim)
                GVAppPayment.DataSource = SqlAppPay2
                GVAppPayment.DataBind()
            Case 3
                SqlAppPay3.SelectParameters.Item("date3").DefaultValue = 0
                SqlAppPay3.SelectParameters.Item("date4").DefaultValue = 0
                SqlAppPay3.SelectParameters.Item("TypeSearch").DefaultValue = 2
                SqlAppPay3.SelectParameters.Item("date1").DefaultValue = ISODate.SetISODate("en", txtdate1.Text.Trim)
                SqlAppPay3.SelectParameters.Item("date2").DefaultValue = ISODate.SetISODate("en", txtdate2.Text.Trim)
                GVAppPayment.DataSource = SqlAppPay3
                GVAppPayment.DataBind()


        End Select

    End Sub

    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click
        GVAppPayment.Columns(17).Visible = True
        GVAppPayment.Columns(18).Visible = True
        GVAppPayment.Columns(19).Visible = True
        GVAppPayment.Columns(20).Visible = True
        BindGvAppPay()
    End Sub





    Protected Sub GVAppPayment_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GVAppPayment.RowCommand
        If e.CommandName = "Select" Then
            Dim urlLink As String = "../Application/frmApplication.aspx?"
            urlLink += "Edit=0&Buy=2"
            urlLink += "&&IdCar=" & GVAppPayment.DataKeys(e.CommandArgument).Item(0)
            urlLink += "&&AppID=" & GVAppPayment.DataKeys(e.CommandArgument).Item(1)
            ScriptManager.RegisterClientScriptBlock(UpdatePanel5, GetType(UpdatePanel), UpdatePanel5.ClientID, " window.open('" & urlLink & "','Application');", True)

            'Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  window.open('" & urlLink & "','Application');</script>")
        ElseIf e.CommandName = "History" Then
            ScriptManager.RegisterClientScriptBlock(UpdatePanel5, GetType(UpdatePanel), UpdatePanel5.ClientID, "javascript:parent.iframePending('" & GVAppPayment.DataKeys(e.CommandArgument).Item(1) & "');", True)
            'Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.iframeShow('" & GVAppPayment.DataKeys(e.CommandArgument).Item(0) & "');</script>")
        ElseIf e.CommandName = "Doc" Then
            ScriptManager.RegisterClientScriptBlock(UpdatePanel5, GetType(UpdatePanel), UpdatePanel5.ClientID, "javascript:parent.iframeDoc('" & GVAppPayment.DataKeys(e.CommandArgument).Item(1) & "');", True)
        ElseIf e.CommandName = "Tel" Then
            ScriptManager.RegisterClientScriptBlock(UpdatePanel5, GetType(UpdatePanel), UpdatePanel5.ClientID, "javascript:parent.iframePhone('" & GVAppPayment.DataKeys(e.CommandArgument).Item(0) & "');", True)
        End If
    End Sub


    Protected Sub SqlAppPay_Selected(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.SqlDataSourceStatusEventArgs) Handles SqlAppPay.Selected
        lblCase.Text = e.AffectedRows
    End Sub

    Protected Sub SqlAppPay2_Selected(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.SqlDataSourceStatusEventArgs) Handles SqlAppPay2.Selected
        lblCase.Text = e.AffectedRows
    End Sub

    Protected Sub SqlAppPay3_Selected(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.SqlDataSourceStatusEventArgs) Handles SqlAppPay3.Selected
        lblCase.Text = e.AffectedRows
    End Sub


    Protected Sub GVAppPayment_DataBound(sender As Object, e As System.EventArgs) Handles GVAppPayment.DataBound


        Dim IsProvalue As Integer = 0
        Dim IsCarpet As Integer = 0
        Dim IsCarpetProvalue As Integer = 0
        Dim Premium As Double = 0
        Dim Premium1 As Double = 0
        For i As Integer = 0 To GVAppPayment.Rows.Count - 1
            If CInt(GVAppPayment.Rows(i).Cells(17).Text) = 1 And CInt(GVAppPayment.Rows(i).Cells(19).Text) = 0 Then
                IsCarpet = IsCarpet + 1
                Premium1 = Premium1 + CDbl((GVAppPayment.Rows(i).Cells(18).Text.Trim.Replace("&quot;", "")))

            ElseIf CInt(GVAppPayment.Rows(i).Cells(19).Text) = 1 And CInt(GVAppPayment.Rows(i).Cells(17).Text) = 0 Then
                IsProvalue = IsProvalue + 1
                Premium = Premium + CDbl((GVAppPayment.Rows(i).Cells(20).Text.Trim.Replace("&quot;", "")))
            ElseIf CInt(GVAppPayment.Rows(i).Cells(19).Text) = 1 And CInt(GVAppPayment.Rows(i).Cells(17).Text.Trim) = 1 Then
                IsCarpetProvalue = IsCarpetProvalue + 1
                Premium = Premium + CDbl((GVAppPayment.Rows(i).Cells(20).Text.Trim.Replace("&quot;", ""))) + CDbl((GVAppPayment.Rows(i).Cells(18).Text.Trim.Replace("&quot;", "")))
            End If

        Next
        If ddTypeApp.SelectedValue = 1 Then
            Label1.Text = "Caseพรบ:" + IsCarpet.ToString + ",Premium(พรบ.):" + Format((Premium1), "##,##0.00")
            Label2.Text = "Caseภาคสมัครใจ+ภาคสมัครใจและพรบ.:" + (IsProvalue + IsCarpetProvalue).ToString + ","
            Label3.Text = "Premium(เบี้ยขาย+พรบ.):" + Format((Premium), "##,##0.00")
        Else
            Label1.Text = ""
            Label2.Text = ""
            Label3.Text = ""
        End If

        GVAppPayment.Columns(17).Visible = False
        GVAppPayment.Columns(18).Visible = False
        GVAppPayment.Columns(19).Visible = False
        GVAppPayment.Columns(20).Visible = False
    End Sub
End Class

