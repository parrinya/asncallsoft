﻿
Partial Class Modules_Sale_Phone_frmNewCaseCall2
    Inherits System.Web.UI.Page
    Dim FunAll As New FuntionAll
    Protected Sub GvNewCase_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvNewCase.RowCommand
        If e.CommandName = "Select" Then

        ElseIf e.CommandName = "Phone" Then

            Dim strLink As String = "?IdCar=" & GvNewCase.DataKeys(e.CommandArgument).Item(0)
            strLink += "&&RunNo=" & GvNewCase.DataKeys(e.CommandArgument).Item(5)
            strLink += "&Call=1"
            If GvNewCase.DataKeys(e.CommandArgument).Item(3).ToString = "0" Then
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.change_parent_url('frmPhone.aspx" & strLink & "');</script>")

            ElseIf GvNewCase.DataKeys(e.CommandArgument).Item(3).ToString = "Pending" Then
                strLink += "&&AppID=" & GvNewCase.DataKeys(e.CommandArgument).Item(4)
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.change_parent_url('../Pending/frmPending.aspx" & strLink & "');</script>")

            ElseIf GvNewCase.DataKeys(e.CommandArgument).Item(3).ToString = "2" Then
                strLink += "&&AppID=" & GvNewCase.DataKeys(e.CommandArgument).Item(4)
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.change_parent_url('../Pending/frmPending.aspx" & strLink & "');</script>")

            ElseIf GvNewCase.DataKeys(e.CommandArgument).Item(3).ToString = "10" Then
                strLink += "&&AppID=" & GvNewCase.DataKeys(e.CommandArgument).Item(4)
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.change_parent_url('../Pending/frmQc.aspx" & strLink & "');</script>")

            ElseIf GvNewCase.DataKeys(e.CommandArgument).Item(3).ToString = "4" Then
                strLink += "&&AppID=" & GvNewCase.DataKeys(e.CommandArgument).Item(4)
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.change_parent_url('../Pending/frmCallCenter.aspx" & strLink & "');</script>")

            End If
        End If
    End Sub

    Protected Sub LinkGv()
        Dim strLink As String = "?IdCar=" & GvNewCase.DataKeys(0).Item(0)
        strLink += "&&RunNo=" & GvNewCase.DataKeys(0).Item(5)
        strLink += "&Call=1"


        If GvNewCase.DataKeys(0).Item(3).ToString = "0" Then
            ScriptManager.RegisterClientScriptBlock(UpdatePanel1, GetType(UpdatePanel), UpdatePanel1.ClientID, "javascript:parent.change_parent_url('frmPhone.aspx" & strLink & "');", True)
            'Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  </script>")
            'Response.Redirect("frmPhone.aspx" & strLink)
        ElseIf GvNewCase.DataKeys(0).Item(3).ToString = "Pending" Then
            strLink += "&&AppID=" & GvNewCase.DataKeys(0).Item(4)
            ScriptManager.RegisterClientScriptBlock(UpdatePanel1, GetType(UpdatePanel), UpdatePanel1.ClientID, "javascript:parent.change_parent_url('../Pending/frmPending.aspx" & strLink & "');", True)

            'Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.change_parent_url('frmPending.aspx" & strLink & "');</script>")
            'Response.Redirect("frmPending.aspx" & strLink & "&&AppID=" & GvNewCase.DataKeys(e.CommandArgument).Item(4))
        ElseIf GvNewCase.DataKeys(0).Item(3).ToString = "2" Then
            strLink += "&&AppID=" & GvNewCase.DataKeys(0).Item(4)
            ScriptManager.RegisterClientScriptBlock(UpdatePanel1, GetType(UpdatePanel), UpdatePanel1.ClientID, "javascript:parent.change_parent_url('../Pending/frmPending.aspx" & strLink & "');", True)

            'Response.Redirect("frmPending.aspx" & strLink & "&&AppID=" & GvNewCase.DataKeys(e.CommandArgument).Item(4))
        ElseIf GvNewCase.DataKeys(0).Item(3).ToString = "10" Then
            strLink += "&&AppID=" & GvNewCase.DataKeys(0).Item(4)
            ScriptManager.RegisterClientScriptBlock(UpdatePanel1, GetType(UpdatePanel), UpdatePanel1.ClientID, "javascript:parent.change_parent_url('../Pending/frmQc.aspx" & strLink & "');", True)

            'Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.change_parent_url('../Pending/frmQc.aspx" & strLink & "');</script>")
            'Response.Redirect("../Pending/frmQc.aspx" & strLink & "&&AppID=" & GvNewCase.DataKeys(e.CommandArgument).Item(4))
        ElseIf GvNewCase.DataKeys(0).Item(3).ToString = "4" Then
            strLink += "&&AppID=" & GvNewCase.DataKeys(0).Item(4)
            ScriptManager.RegisterClientScriptBlock(UpdatePanel1, GetType(UpdatePanel), UpdatePanel1.ClientID, "javascript:parent.change_parent_url('../Pending/frmCallCenter.aspx" & strLink & "');", True)

            'Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.change_parent_url('../Pending/frmCallCenter.aspx" & strLink & "');</script>")
            'Response.Redirect("../Pending/frmCallCenter.aspx" & strLink & "&&AppID=" & GvNewCase.DataKeys(e.CommandArgument).Item(4))

        End If
    End Sub
  
    Protected Sub GvNewCase_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles GvNewCase.DataBound
        For i As Integer = 1 To GvNewCase.Rows.Count - 1
            Dim ImageButton4 As Button = FunAll.ObjFindControl("Button4", GvNewCase.Rows(i).Cells(0))
            ImageButton4.Visible = False
        Next

        'If Request.Cookies("TypeTsr").Value = 1 Then
        '    GvNewCase.Columns(0).Visible = False
        'End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            'If Session("chkNewCall") IsNot Nothing Then
            '    chkNewCall.Checked = Session("chkNewCall")
            'End If
        End If
    End Sub
End Class
