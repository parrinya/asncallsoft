﻿
Partial Class Modules_Sale_Case_frmCaseInsurance
    Inherits System.Web.UI.Page
    Public TelAjax As String

    Protected Sub GvInsurance_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvInsurance.RowCommand
        Dim CallUrl As String = ""
        If e.CommandName = "Tel1" Then


            CallUrl += Replace(ConfigurationManager.AppSettings("WebCall"), "@IpAsserisk", Request.Cookies("IpAsterisk").Value)
            CallUrl += "to=" & GvInsurance.DataKeys(e.CommandArgument).Item(1) & "&&from=" & Request.Cookies("Extension").Value
            CallUrl += "&&refer1=" & GvInsurance.DataKeys(e.CommandArgument).Item(0)
            CallUrl += "&refer2=" & Request.Cookies("userID").Value
            TelAjax = CallUrl
        ElseIf e.CommandName = "Tel2" Then

            CallUrl += Replace(ConfigurationManager.AppSettings("WebCall"), "@IpAsserisk", Request.Cookies("IpAsterisk").Value)
            CallUrl += "to=" & GvInsurance.DataKeys(e.CommandArgument).Item(2) & "&&from=" & Request.Cookies("Extension").Value
            CallUrl += "&&refer1=" & GvInsurance.DataKeys(e.CommandArgument).Item(0)
            CallUrl += "&refer2=" & Request.Cookies("userID").Value
            TelAjax = CallUrl
        End If
    End Sub
End Class
