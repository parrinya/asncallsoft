﻿
Partial Class Modules_Sale_Phone_frmExpireCall
    Inherits System.Web.UI.Page
    Dim FunAll As New FuntionAll

    Protected Sub GvEXCase_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvEXCase.RowCommand
        If e.CommandName = "Select" Then

        ElseIf e.CommandName = "Phone" Then
            Dim strLink As String = "?IdCar=" & GvEXCase.DataKeys(e.CommandArgument).Item(0)
            strLink += "&&RunNo=" & GvEXCase.DataKeys(e.CommandArgument).Item(5)
            strLink += "&Call=1"
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.change_parent_url('frmPhone.aspx" & strLink & "');</script>")

        End If
    End Sub

    Protected Sub GvEXCase_DataBound(sender As Object, e As System.EventArgs) Handles GvEXCase.DataBound
        For i As Integer = 1 To GvEXCase.Rows.Count - 1
            Dim ImageButton4 As Button = FunAll.ObjFindControl("Button4", GvEXCase.Rows(i).Cells(0))
            ImageButton4.Visible = False
        Next
    End Sub


    Protected Sub btnnameCus_Click(sender As Object, e As System.EventArgs) Handles btnnameCus.Click
        'ค้นหาข้อมูลลูกค้า
        If ddTypeID.SelectedValue = 0 Then
            SqlExCase.SelectParameters.Item("typeID").DefaultValue = ddTypeID.SelectedValue
            SqlExCase.SelectParameters.Item("serchtxt").DefaultValue = "%" + txtnameCus.Text.Trim + "%"
            GvEXCase.DataSource = SqlExCase
            GvEXCase.DataBind()
        ElseIf ddTypeID.SelectedValue = 1 Then
            'ชื่อ ลูกค้า
            SqlExCase.SelectParameters.Item("typeID").DefaultValue = ddTypeID.SelectedValue
            SqlExCase.SelectParameters.Item("serchtxt").DefaultValue = "%" + txtnameCus.Text.Trim + "%"
            GvEXCase.DataSource = SqlExCase
            GvEXCase.DataBind()
        ElseIf ddTypeID.SelectedValue = 2 Then
            'สกุล ลูกค้า
            SqlExCase.SelectParameters.Item("typeID").DefaultValue = ddTypeID.SelectedValue
            SqlExCase.SelectParameters.Item("serchtxt").DefaultValue = "%" + txtnameCus.Text.Trim + "%"
            GvEXCase.DataSource = SqlExCase
            GvEXCase.DataBind()
        ElseIf ddTypeID.SelectedValue = 3 Then
            'ทะเบียน
            SqlExCase.SelectParameters.Item("typeID").DefaultValue = ddTypeID.SelectedValue
            SqlExCase.SelectParameters.Item("serchtxt").DefaultValue = "%" + txtnameCus.Text.Trim + "%"
            GvEXCase.DataSource = SqlExCase
            GvEXCase.DataBind()
        End If
      
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            SqlExCase.SelectParameters.Item("typeID").DefaultValue = 0
            SqlExCase.SelectParameters.Item("serchtxt").DefaultValue = "%0%"
            GvEXCase.DataSource = SqlExCase
            GvEXCase.DataBind()
        End If
      
    End Sub
End Class
