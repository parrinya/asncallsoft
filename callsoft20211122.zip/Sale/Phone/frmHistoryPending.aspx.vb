﻿
Partial Class Modules_Sale_Phone_frmHistoryPending
    Inherits System.Web.UI.Page

End Class
