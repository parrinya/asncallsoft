﻿
Partial Class Modules_Sale_Phone_frmCaseCall
    Inherits System.Web.UI.Page
    Dim FunAll As New FuntionAll
    Protected Sub GvCase_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvCase.RowCommand
        If e.CommandName = "Select" Then
         
        ElseIf e.CommandName = "Phone" Then

            Dim strLink As String = "?IdCar=" & GvCase.DataKeys(e.CommandArgument).Item(0)
            strLink += "&&RunNo=" & GvCase.DataKeys(e.CommandArgument).Item(5)
            strLink += "&Call=2"
            If GvCase.DataKeys(e.CommandArgument).Item(3).ToString = "0" Then
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.change_parent_url('frmPhone.aspx" & strLink & "');</script>")
                'Response.Redirect("frmPhone.aspx" & strLink)
            ElseIf GvCase.DataKeys(e.CommandArgument).Item(3).ToString = "Pending" Then
                strLink += "&&AppID=" & GvCase.DataKeys(e.CommandArgument).Item(4)
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.change_parent_url('frmPending.aspx" & strLink & "');</script>")
                'Response.Redirect("frmPending.aspx" & strLink & "&&AppID=" & GvCase.DataKeys(e.CommandArgument).Item(4))
            ElseIf GvCase.DataKeys(e.CommandArgument).Item(3).ToString = "2" Then
                strLink += "&&AppID=" & GvCase.DataKeys(e.CommandArgument).Item(4)
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.change_parent_url('frmPending.aspx" & strLink & "');</script>")
                'Response.Redirect("frmPending.aspx" & strLink & "&&AppID=" & GvCase.DataKeys(e.CommandArgument).Item(4))
            ElseIf GvCase.DataKeys(e.CommandArgument).Item(3).ToString = "10" Then
                strLink += "&&AppID=" & GvCase.DataKeys(e.CommandArgument).Item(4)
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.change_parent_url('../Pending/frmQc.aspx" & strLink & "');</script>")
                'Response.Redirect("../Pending/frmQc.aspx" & strLink & "&&AppID=" & GvCase.DataKeys(e.CommandArgument).Item(4))
            ElseIf GvCase.DataKeys(e.CommandArgument).Item(3).ToString = "4" Then
                strLink += "&&AppID=" & GvCase.DataKeys(e.CommandArgument).Item(4)
                Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>  javascript:parent.change_parent_url('../Pending/frmCallCenter.aspx" & strLink & "');</script>")
                'Response.Redirect("../Pending/frmCallCenter.aspx" & strLink & "&&AppID=" & GvCase.DataKeys(e.CommandArgument).Item(4))
            End If
        End If
    End Sub

    
End Class
