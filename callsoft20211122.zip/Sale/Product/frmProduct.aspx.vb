﻿
Partial Class Modules_Sale_Product_frmProduct
    Inherits System.Web.UI.Page
    Public strProtype As String

    Protected Sub LinkButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton2.Click
        strProtype = "../Product/frmProType2.aspx?IdCar=0"
    End Sub

    Protected Sub LinkButton3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton3.Click
        strProtype = "../Product/frmProType3Plus.aspx?IdCar=0"
    End Sub

    Protected Sub LinkButton4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton4.Click
        strProtype = "../Product/frmProType3.aspx?IdCar=0"
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        strProtype = "../Product/frmProType1.aspx?IdCar=0"
    End Sub

    Protected Sub LinkButton6_Click(sender As Object, e As System.EventArgs) Handles LinkButton6.Click
        strProtype = "../Product/frmProType1Plus.aspx?IdCar=0"
    End Sub

    'Protected Sub LinkButton7_Click(sender As Object, e As System.EventArgs) Handles LinkButton7.Click
    '    strProtype = "../Product/frmProType1DD.aspx?IdCar=0"
    'End Sub

    Protected Sub LinkButton8_Click(sender As Object, e As System.EventArgs) Handles LinkButton8.Click
        strProtype = "../Product/frmProType20.aspx?IdCar=0"
    End Sub
End Class
