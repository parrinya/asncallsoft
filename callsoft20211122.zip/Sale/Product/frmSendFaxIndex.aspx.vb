﻿Imports CrystalDecisions.Shared
Imports CrystalDecisions.CrystalReports.Engine

Partial Class Modules_Sale_Product_frmSendFaxIndex
    Inherits System.Web.UI.Page
    Dim ISODate As New ISODate
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub



    Protected Sub BindTblGvHistory()
        SqlSendFax2.SelectParameters.Item("date1").DefaultValue = ISODate.SetISODate("en", txtdate1.Text.Trim)
        SqlSendFax2.SelectParameters.Item("date2").DefaultValue = ISODate.SetISODate("en", txtdate2.Text.Trim)
        GvSendFax.DataBind()
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        BindTblGvHistory()
    End Sub

    Protected Sub GvSendFax_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles GvSendFax.DataBound
        'If GvSendFax.Rows.Count > 0 Then
        '    If Request.Cookies("TypeTsr").Value = 6 Or Request.Cookies("UserLevel").Value <> 5 Then
        '        GvSendFax.Columns(0).Visible = True
        '    Else
        '        GvSendFax.Columns(0).Visible = False
        '    End If
        'End If
    End Sub

    Protected Sub GvSendFax_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvSendFax.RowCommand
        If e.CommandName = "Select" Then
            If Request.Cookies("UserLevel").Value <> 5 Then
                SqlSendFax2.UpdateParameters("FaxID").DefaultValue = e.CommandArgument
                SqlSendFax2.Update()
            ElseIf Request.Cookies("TypeTsr").Value = 6 Then
                SqlSendFax2.UpdateParameters("FaxID").DefaultValue = e.CommandArgument
                SqlSendFax2.Update()
            End If

            GenReport(e.CommandArgument)
        End If
    End Sub

    Protected Sub GenReport(FaxID As String)
        'This Code is used to Convert to word document
        Dim reportWord As New ReportDocument  ' Report Name 
        Dim reportname As String
        reportname = Server.MapPath("~/Modules/Sale/Report/rptQuotation2.rpt")

        Dim users As String = "sa"
        'Dim pass As String = "DTS2009"
        Dim pass As String = "asn@sr1"

        'Dim rpt As New CrystalReportViewer

        reportWord.Load(reportname)
        reportWord.SetDatabaseLogon(users, pass)
        reportWord.SetParameterValue("FaxID", FaxID)

        Dim CrExportOptions As ExportOptions
        Dim CrDiskFileDestinationOptions As New DiskFileDestinationOptions()
        Dim CrFormatTypeOptions As New PdfRtfWordFormatOptions()
        CrDiskFileDestinationOptions.DiskFileName = Server.MapPath("~/Tmp/Fax/Pdf/" & FaxID & ".pdf")
        CrExportOptions = reportWord.ExportOptions
        With CrExportOptions
            .ExportDestinationType = ExportDestinationType.DiskFile
            .ExportFormatType = ExportFormatType.PortableDocFormat
            .DestinationOptions = CrDiskFileDestinationOptions
            .FormatOptions = CrFormatTypeOptions
        End With
        reportWord.Export()
        reportWord.Close()
        reportWord.Dispose()
        'Response.Redirect("~/Tmp/Fax/Pdf/" & FaxID & ".pdf")

        Dim urlLink As String = "../../../Tmp/Fax/Pdf/" & FaxID & ".pdf"
       
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.open('" & urlLink & "','Fax');</script>")

    End Sub
End Class
