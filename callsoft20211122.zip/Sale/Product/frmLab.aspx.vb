﻿
Partial Class Modules_Sale_Product_frmLab
    Inherits System.Web.UI.Page

End Class
