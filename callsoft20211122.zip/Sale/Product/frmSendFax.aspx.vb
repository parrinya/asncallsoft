﻿Imports System.Data.SqlClient
Imports System.Data
Imports Infragistics.WebUI.WebDataInput
Imports CrystalDecisions.Shared
Imports CrystalDecisions.CrystalReports.Engine

Partial Class Modules_Sale_Product_frmProType2
    Inherits System.Web.UI.Page
    Dim Conn As SqlConnection
    Dim com As SqlCommand
    Dim DataAccess As New DataAccess
    Dim FunAll As New FuntionAll
    Dim StrQryProvince As New QueryProvince
    Dim StrQuery As New QuerySendFax
    Dim ISODate As New ISODate
    Dim dt As DataTable
    Dim StrQryProValue As New QueryProValue1
    Dim FNameTH, LNameTH As String

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
         
        End If
    End Sub

    Protected Sub ddPackage1_DataBound(sender As Object, e As System.EventArgs) Handles ddPackage1.DataBound

        Dim ddCarType As DropDownList = DirectCast(frmCustomer.FindControl("ddCarType"), DropDownList)
        With SqlPackage
            .SelectParameters("CarTypeID").DefaultValue = ddCarType.SelectedValue

        End With
        frmPackage.DataBind()
    End Sub

    Protected Sub Button1_Click(sender As Object, e As System.EventArgs)

        If DataList1.Items.Count < 4 Then


            Dim txtProValue As WebNumericEdit = FunAll.ObjFindControl("txtProValue", frmPackage)
            Dim txtProvalueTotal As WebNumericEdit = FunAll.ObjFindControl("txtProvalueTotal", frmPackage)
            Dim txtdesc1 As WebNumericEdit = FunAll.ObjFindControl("txtdesc1", frmPackage)
            Dim txtdesc2 As WebNumericEdit = FunAll.ObjFindControl("txtdesc2", frmPackage)
            Dim txtdesc3 As WebNumericEdit = FunAll.ObjFindControl("txtdesc3", frmPackage)
            Dim txtdesc4 As WebNumericEdit = FunAll.ObjFindControl("txtdesc4", frmPackage)
            Dim txtLostfire As WebNumericEdit = FunAll.ObjFindControl("txtLostfire", frmPackage)
            Dim txtLostCar As WebNumericEdit = FunAll.ObjFindControl("txtLostCar", frmPackage)
            Dim txtPayValue As WebNumericEdit = FunAll.ObjFindControl("txtPayValue", frmPackage)
            Dim ddPay As DropDownList = FunAll.ObjFindControl("ddPay", frmPackage)


            With SqlSendFaxDetail
                .InsertParameters("PkID").DefaultValue = frmPackage.DataKey.Item(0)
                .InsertParameters("IdCar").DefaultValue = Request.QueryString("IdCar").ToString
                .InsertParameters("FaxComments").DefaultValue = ""
                .InsertParameters("ProValue").DefaultValue = txtProValue.Text.Trim
                .InsertParameters("ProValueTotal").DefaultValue = txtProvalueTotal.Text.Trim
                .InsertParameters("desc1").DefaultValue = txtdesc1.Text.Trim
                .InsertParameters("desc2").DefaultValue = txtdesc2.Text.Trim
                .InsertParameters("desc3").DefaultValue = txtdesc3.Text.Trim
                .InsertParameters("desc4").DefaultValue = txtdesc4.Text.Trim
                .InsertParameters("PayValue").DefaultValue = txtPayValue.Text.Trim
                .InsertParameters("PayNo").DefaultValue = ddPay.SelectedValue
                .InsertParameters("Lostfire").DefaultValue = txtLostfire.Text.Trim
                .InsertParameters("LostCar").DefaultValue = txtLostCar.Text.Trim

                .Insert()
            End With
        Else
            MsgBox("สามารถเพิ่มสูงสุดได้ 3 package")
        End If

    End Sub

    Protected Sub DataList1_ItemCommand(source As Object, e As System.Web.UI.WebControls.DataListCommandEventArgs) Handles DataList1.ItemCommand
        If e.CommandName = "Delete" Then
            SqlSendFaxDetail.DeleteParameters("FaxID").DefaultValue = e.CommandArgument
            SqlSendFaxDetail.Delete()
        End If
    End Sub

    Protected Sub Button3_Click(sender As Object, e As System.EventArgs) Handles Button3.Click
        If chkFax() = True Then
            InsertTblSendFax2()
            UpdateTblSendFaxDetail()
            GenReport()
            MsgBox("ดำเนินการส่งเรียบร้อยครับ")
        End If

    End Sub

    Protected Sub InsertTblSendFax2()
        Dim protectdate As DateTime = ISODate.SetISODate("th", txtProtectDate.Text.Trim)
        Dim ddCarBrand As DropDownList = DirectCast(frmCustomer.FindControl("ddCarBrand"), DropDownList)
        Dim ddCarSeries As DropDownList = DirectCast(frmCustomer.FindControl("ddCarSeries"), DropDownList)
        Dim ddCarType As DropDownList = DirectCast(frmCustomer.FindControl("ddCarType"), DropDownList)
        Dim ddYear As DropDownList = DirectCast(frmCustomer.FindControl("ddYear"), DropDownList)
        Dim ddCarID As DropDownList = DirectCast(frmCustomer.FindControl("ddCarID"), DropDownList)
       
        Dim txtCarsize As TextBox = DirectCast(frmCustomer.FindControl("txtCarsize"), TextBox)
        Dim txtCarID As TextBox = DirectCast(frmCustomer.FindControl("txtCarID"), TextBox)
        Dim txtCarboxno As TextBox = DirectCast(frmCustomer.FindControl("txtCarboxno"), TextBox)

        Dim ExpProtectDate As DateTime = protectdate.AddYears(1)
        With SqlSendFax
            .InsertParameters("FNameTH").DefaultValue = frmCustomer.DataKey.Item(2)
            .InsertParameters("LNameTH").DefaultValue = frmCustomer.DataKey.Item(3)
            .InsertParameters("FaxNo").DefaultValue = frmCustomer.DataKey.Item(1)
            .InsertParameters("IdCar").DefaultValue = frmCustomer.DataKey.Item(0)
            .InsertParameters("CarBrand").DefaultValue = ddCarBrand.SelectedValue
            .InsertParameters("CarSeries").DefaultValue = ddCarSeries.SelectedItem.Text
            .InsertParameters("Carsize").DefaultValue = txtCarsize.Text.Trim
            .InsertParameters("CarYear").DefaultValue = ddYear.SelectedValue
            .InsertParameters("TypeSend").DefaultValue = ddTypeSend.SelectedValue
            .InsertParameters("FileName").DefaultValue = frmCustomer.DataKey.Item(0) & ".doc"
            .InsertParameters("CarID").DefaultValue = txtCarID.Text.Trim & ddCarID.SelectedValue
            .InsertParameters("SendComment").DefaultValue = ""
            .InsertParameters("SendEmail").DefaultValue = txtEmail.Text.Trim
            .InsertParameters("CarBoxNo").DefaultValue = txtCarboxno.Text.Trim
            .InsertParameters("CarType").DefaultValue = ddCarType.SelectedValue
            .InsertParameters("ProtectDate").DefaultValue = protectdate.ToString("yyyy/MM/dd")
            .InsertParameters("ExpProtectDate").DefaultValue = ExpProtectDate.ToString("yyyy/MM/dd")
            .Insert()
        End With

        SqlGetRefno.Insert()


    End Sub

    Protected Function chkFax() As Boolean
        If ddTypeSend.SelectedValue = 0 And frmCustomer.DataKey.Item(1) = "" Then
            MsgBox("ไม่มีข้อมูลเบอร์ fax")
            Return False
        ElseIf DataList1.Items.Count = 0 Then
            MsgBox("คุณยังไม่ได้เพิ่มใบเสนอราคา กรุณากดปุ่มเพิ่ม")
            Return False
        Else
            Return True
        End If
    End Function

    Protected Function GetSendFax() As String
        Dim dvSql As DataView = DirectCast(SqlSendFax.Select(DataSourceSelectArguments.Empty), DataView)

        If dvSql.Count > 0 Then
            ViewState("FaxID") = dvSql(0).Item("FaxID").ToString
            ViewState("IdCar") = dvSql(0).Item("IdCar").ToString
            Return dvSql(0).Item("FaxID").ToString

        Else
            Return 0
        End If
    End Function

    Protected Sub UpdateTblSendFaxDetail()
        SqlSendFaxDetail.UpdateParameters("FaxID").DefaultValue = GetSendFax()
        SqlSendFaxDetail.Update()
    End Sub


    Protected Sub GenReport()
        'This Code is used to Convert to word document
        Dim reportWord As New ReportDocument  ' Report Name 
        Dim reportname As String
        reportname = Server.MapPath("~/Modules/Sale/Report/rptQuotation2.rpt")

        Dim users As String = "sa"
        'Dim pass As String = "DTS2009"
        Dim pass As String = "asn@sr1"

        'Dim rpt As New CrystalReportViewer

        reportWord.Load(reportname)
        reportWord.SetDatabaseLogon(users, pass)
        reportWord.SetParameterValue("FaxID", ViewState("FaxID"))


        Dim strExportFile As String = Server.MapPath("~/FaxPayment/" & ViewState("IdCar") & ".doc")
        reportWord.ExportOptions.ExportDestinationType = ExportDestinationType.DiskFile
        reportWord.ExportOptions.ExportFormatType = ExportFormatType.WordForWindows
        Dim objOptions As DiskFileDestinationOptions = New DiskFileDestinationOptions()
        objOptions.DiskFileName = strExportFile
        reportWord.ExportOptions.DestinationOptions = objOptions
        reportWord.Export()
        objOptions = Nothing
        reportWord.Close()
        reportWord.Dispose()



    End Sub



    'Script MsgBox
    Public Sub MsgBox(ByVal sMsg As String)

        Dim sb As New StringBuilder()
        Dim oFormObject As System.Web.UI.Control
        sMsg = sMsg.Replace("'", "\'")
        sMsg = sMsg.Replace(Chr(34), "\" & Chr(34))
        sMsg = sMsg.Replace(vbCrLf, "\n")
        sMsg = "<script language=javascript>alert(""" & sMsg & """)</script>"

        sb = New StringBuilder()
        sb.Append(sMsg)

        For Each oFormObject In Me.Controls
            If TypeOf oFormObject Is HtmlForm Then
                Exit For
            End If
        Next

        ' Add the javascript after the form object so that the 
        ' message doesn't appear on a blank screen.
        oFormObject.Controls.AddAt(oFormObject.Controls.Count, New LiteralControl(sb.ToString()))
    End Sub

    Protected Sub ddPay_SelectedIndexChanged(sender As Object, e As System.EventArgs)
        Dim txtProvalueTotal As WebNumericEdit = FunAll.ObjFindControl("txtProvalueTotal", frmPackage)
        Dim txtPayValue As WebNumericEdit = FunAll.ObjFindControl("txtPayValue", frmPackage)
        Dim txtdesc5 As WebNumericEdit = FunAll.ObjFindControl("txtdesc5", frmPackage)
        Dim txtProValue As WebNumericEdit = FunAll.ObjFindControl("txtProValue", frmPackage)
        Dim ddPay As DropDownList = FunAll.ObjFindControl("ddPay", frmPackage)
        txtPayValue.Text = txtProvalueTotal.Text.Trim / ddPay.SelectedValue
        txtdesc5.Text = txtProValue.Text.Trim
    End Sub

    Protected Sub frmCustomer_DataBound(sender As Object, e As System.EventArgs) Handles frmCustomer.DataBound
        If frmCustomer.DataItemCount > 0 Then
            txtEmail.Text = frmCustomer.DataKey.Item(4).ToString

            BindCarSeries()
            Dim ddYear As DropDownList = DirectCast(frmCustomer.FindControl("ddYear"), DropDownList)
            For i As Integer = Date.Now.Year To 1990 Step -1
                ddYear.Items.Add(i)

            Next

            If frmCustomer.DataItemCount > 0 Then
                Dim ddSeries As DropDownList = DirectCast(frmCustomer.FindControl("ddCarSeries"), DropDownList)
                Dim txtCarsize As TextBox = DirectCast(frmCustomer.FindControl("txtCarsize"), TextBox)
                Dim txtCarboxno As TextBox = DirectCast(frmCustomer.FindControl("txtCarsize"), TextBox)
                ddSeries.SelectedValue = frmCustomer.DataKey.Item(5)
                ddYear.SelectedValue = frmCustomer.DataKey.Item(6)
               
            End If
        End If
    End Sub

    Protected Sub ddCarBrand_SelectedIndexChanged(sender As Object, e As System.EventArgs)

        BindCarSeries()
    End Sub

    Protected Sub ddCarBrand_DataBound(sender As Object, e As System.EventArgs)
        BindCarSeries()
    End Sub
    Protected Sub BindCarSeries()
        Dim ddBrand As DropDownList = DirectCast(frmCustomer.FindControl("ddCarBrand"), DropDownList)
        Dim ddSeries As DropDownList = DirectCast(frmCustomer.FindControl("ddCarSeries"), DropDownList)
        Dim ddCarTypeNew As DropDownList = DirectCast(frmCustomer.FindControl("ddCarType"), DropDownList)

        FunAll.ListDropDown(ddSeries, StrQryProvince.SelectCarBrand(ddBrand.SelectedValue), "CarSeries", "CarSeries")


        Dim sql As String = "SELECT distinct TblCarBrand.CarType as CarTypeID,TblInsur_CarType.Cartype   as CarTypeName "
        sql += " FROM TblCarBrand "
        sql += " inner join TblInsur_CarType on TblCarBrand.CarType=TblInsur_CarType.CarTypeID"
        sql += " Where TblCarBrand.flag=2 and TblCarBrand.CarBrand=  '" & ddBrand.SelectedValue & "' and TblCarBrand.carSERIES = '" & ddSeries.SelectedValue & "' and TblCarBrand.carStatus = 1 "
         
        FunAll.ListDropDown(ddCarTypeNew, sql, "CarTypeName", "CarTypeID")

    End Sub
   
    Protected Sub ddCarType_SelectedIndexChanged(sender As Object, e As System.EventArgs)

    End Sub

    Protected Sub ddCarSeries_SelectedIndexChanged(sender As Object, e As System.EventArgs)
        Dim ddBrand As DropDownList = DirectCast(frmCustomer.FindControl("ddCarBrand"), DropDownList)
        Dim ddCarTypeNew As DropDownList = DirectCast(frmCustomer.FindControl("ddCarType"), DropDownList)
        Dim ddSeries As DropDownList = DirectCast(frmCustomer.FindControl("ddCarSeries"), DropDownList)

        Dim sql As String = "SELECT distinct TblCarBrand.CarType as CarTypeID,TblInsur_CarType.Cartype   as CarTypeName "
        sql += " FROM TblCarBrand "
        sql += " inner join TblInsur_CarType on TblCarBrand.CarType=TblInsur_CarType.CarTypeID"
        sql += " Where TblCarBrand.flag=2 and TblCarBrand.CarBrand=  '" & ddBrand.SelectedValue & "' and TblCarBrand.carSERIES = '" & ddSeries.SelectedValue & "' and TblCarBrand.carStatus = 1 "
        FunAll.ListDropDown(ddCarTypeNew, sql, "CarTypeName", "CarTypeID")

    End Sub
End Class
