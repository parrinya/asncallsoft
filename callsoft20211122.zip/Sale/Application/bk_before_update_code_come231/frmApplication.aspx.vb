﻿Imports System.Data.SqlClient
Imports System.Data
Imports Infragistics.Web
Imports Infragistics.WebUI.WebDataInput
Imports System.Globalization

Partial Class Modules_Sale_Application_frmApplication
    Inherits System.Web.UI.Page
    Dim FunAll As New FuntionAll
    Dim StrQryProvince As New QueryProvince
    Dim com As SqlCommand
    Dim Conn As New SqlConnection(ConfigurationManager.ConnectionStrings("asnbroker").ConnectionString)
    Dim StrQueryPhone As New QueryPhone
    Dim dt As DataTable
    Dim StrQuery As New QueryApplication
    Dim ISODate As New ISODate
    Dim DataAccess As New DataAccess
    Dim QueryCredit As New QureyCredit
    Dim dtGetAppPhotos As DataTable
    Dim StrQueryPhoto As New QueryPhone
    Private strappid As String = ""
    Private fpay As Integer = 0
#Region "ข้อมูลที่จัดส่ง"
    'ค้นหาอำเภอ
    Protected Sub ddProvince_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)

        FunAll.ListDropDown(ddDist, StrQryProvince.TblZipCodeBindDist(ddProvince.SelectedValue), "Dist", "Dist")
        FunAll.ListDropDown(ddSubDist, StrQryProvince.TblZipCodeBindSubDist(ddDist.SelectedValue, ddProvince.SelectedValue), "SubDist", "SubDist")
        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(ddSubDist.SelectedValue, ddProvince.SelectedValue, ddDist.SelectedValue), "ZipCode", "ZipCode")
    End Sub
    'ค้นหาตำบล
    Protected Sub ddDist_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)
        FunAll.ListDropDown(ddSubDist, StrQryProvince.TblZipCodeBindSubDist(ddDist.SelectedValue, ddProvince.SelectedValue), "SubDist", "SubDist")
        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(ddSubDist.SelectedValue, ddProvince.SelectedValue, ddDist.SelectedValue), "ZipCode", "ZipCode")

    End Sub
    'ค้นหารหัสไปรษณีย์
    Protected Sub ddSubDist_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)

        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(ddSubDist.SelectedValue, ddProvince.SelectedValue, ddDist.SelectedValue), "ZipCode", "ZipCode")

    End Sub
    'ผูกข้อมูลเริ่มต้น
    Protected Sub frmAddr_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmAddr.DataBound
        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)

        FunAll.ListDropDown(ddDist, StrQryProvince.TblZipCodeBindDist(ddProvince.SelectedValue), "Dist", "Dist")
        'Dim str As String = frmAddr.DataKey.Item(0)
        FunAll.ListDropDown(ddSubDist, StrQryProvince.TblZipCodeBindSubDist(frmAddr.DataKey.Item(0).ToString.Trim, ddProvince.SelectedValue), "SubDist", "SubDist")

        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(frmAddr.DataKey.Item(1).ToString.Trim, ddProvince.SelectedValue, frmAddr.DataKey.Item(0).ToString.Trim), "ZipCode", "ZipCode")

        If ddDist.Items.Count > 0 Then
            ddDist.SelectedValue = frmAddr.DataKey.Item(0).ToString.Trim
        End If

        If ddSubDist.Items.Count > 0 Then
            Dim txt As String = frmAddr.DataKey.Item(1).ToString.Trim
            ddSubDist.SelectedValue = frmAddr.DataKey.Item(1).ToString.Trim
        End If

        If ddZipCode.Items.Count > 0 Then
            ddZipCode.SelectedValue = frmAddr.DataKey.Item(2).ToString.Trim
        End If


    End Sub

    Protected Sub Button11_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim txtSName As TextBox = FunAll.ObjFindControl("txtSName", frmAddr)
        Dim ddInit As DropDownList = FunAll.ObjFindControl("ddInit", frmCusName)
        txtSName.Text = ddInit.SelectedItem.ToString & " " & frmCusName.DataKey.Item(1) & " " & frmCusName.DataKey.Item(2)
    End Sub
#End Region

#Region "ข้อมูลที่อยู่กรมธรรม์"
    'ค้นหาอำเภอ
    Protected Sub SddProvince_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddProvince As DropDownList = DirectCast(frmSAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmSAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmSAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmSAddr.FindControl("ddZipcode"), DropDownList)

        FunAll.ListDropDown(ddDist, StrQryProvince.TblZipCodeBindDist(ddProvince.SelectedValue), "Dist", "Dist")
        FunAll.ListDropDown(ddSubDist, StrQryProvince.TblZipCodeBindSubDist(ddDist.SelectedValue, ddProvince.SelectedValue), "SubDist", "SubDist")
        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(ddSubDist.SelectedValue, ddProvince.SelectedValue, ddDist.SelectedValue), "ZipCode", "ZipCode")
    End Sub
    'ค้นหาตำบล
    Protected Sub SddDist_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddProvince As DropDownList = DirectCast(frmSAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmSAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmSAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmSAddr.FindControl("ddZipcode"), DropDownList)
        FunAll.ListDropDown(ddSubDist, StrQryProvince.TblZipCodeBindSubDist(ddDist.SelectedValue, ddProvince.SelectedValue), "SubDist", "SubDist")
        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(ddSubDist.SelectedValue, ddProvince.SelectedValue, ddDist.SelectedValue), "ZipCode", "ZipCode")

    End Sub
    'ค้นหารหัสไปรษณีย์
    Protected Sub SddSubDist_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddProvince As DropDownList = DirectCast(frmSAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmSAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmSAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmSAddr.FindControl("ddZipcode"), DropDownList)

        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(ddSubDist.SelectedValue, ddProvince.SelectedValue, ddDist.SelectedValue), "ZipCode", "ZipCode")

    End Sub
    'ผูกข้อมูลเริ่มต้น
    Protected Sub frmSAddr_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmSAddr.DataBound
        Dim ddProvince As DropDownList = DirectCast(frmSAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmSAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmSAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmSAddr.FindControl("ddZipcode"), DropDownList)
        FunAll.ListDropDown(ddDist, StrQryProvince.TblZipCodeBindDist(ddProvince.SelectedValue), "Dist", "Dist")
        'Dim str As String = frmAddr.DataKey.Item(0)
        FunAll.ListDropDown(ddSubDist, StrQryProvince.TblZipCodeBindSubDist(frmSAddr.DataKey.Item(7).ToString.Trim, ddProvince.SelectedValue), "SubDist", "SubDist")

        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(frmSAddr.DataKey.Item(8).ToString.Trim, ddProvince.SelectedValue, frmSAddr.DataKey.Item(7).ToString.Trim), "ZipCode", "ZipCode")

        If ddDist.Items.Count > 0 Then
            ddDist.SelectedValue = frmSAddr.DataKey.Item(7).ToString.Trim
        End If

        If ddSubDist.Items.Count > 0 Then
            ddSubDist.SelectedValue = frmSAddr.DataKey.Item(8).ToString.Trim
        End If

        If ddZipCode.Items.Count > 0 Then
            ddZipCode.SelectedValue = frmSAddr.DataKey.Item(9).ToString.Trim
        End If



    End Sub



    Protected Sub CopyAddr()
        Dim ddProvince As DropDownList = DirectCast(frmAddr.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmAddr.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmAddr.FindControl("ddZipcode"), DropDownList)

        Dim ddSProvince As DropDownList = DirectCast(frmSAddr.FindControl("ddProvince"), DropDownList)
        Dim ddSDist As DropDownList = DirectCast(frmSAddr.FindControl("ddDist"), DropDownList)
        Dim ddSSubDist As DropDownList = DirectCast(frmSAddr.FindControl("ddSubDist"), DropDownList)
        Dim ddSZipCode As DropDownList = DirectCast(frmSAddr.FindControl("ddZipcode"), DropDownList)

        Dim txtAddr As TextBox = FunAll.ObjFindControl("txtAddr", frmAddr)
        Dim txtMoo As TextBox = FunAll.ObjFindControl("txtMoo", frmAddr)
        Dim txtVillege As TextBox = FunAll.ObjFindControl("txtVillege", frmAddr)
        Dim txtSoi As TextBox = FunAll.ObjFindControl("txtSoi", frmAddr)
        Dim txtRoad As TextBox = FunAll.ObjFindControl("txtRoad", frmAddr)


        Dim txtSAddr As TextBox = FunAll.ObjFindControl("txtAddr", frmSAddr)
        Dim txtSMoo As TextBox = FunAll.ObjFindControl("txtMoo", frmSAddr)
        Dim txtSVillege As TextBox = FunAll.ObjFindControl("txtVillege", frmSAddr)
        Dim txtSSoi As TextBox = FunAll.ObjFindControl("txtSoi", frmSAddr)
        Dim txtSRoad As TextBox = FunAll.ObjFindControl("txtRoad", frmSAddr)

        txtSAddr.Text = txtAddr.Text.Trim
        txtSMoo.Text = txtMoo.Text.Trim
        txtSVillege.Text = txtVillege.Text.Trim
        txtSSoi.Text = txtSoi.Text.Trim
        txtSRoad.Text = txtRoad.Text.Trim


        FunAll.ListDropDown(ddSDist, StrQryProvince.TblZipCodeBindDist(ddProvince.SelectedValue), "Dist", "Dist")
        FunAll.ListDropDown(ddSSubDist, StrQryProvince.TblZipCodeBindSubDist(ddDist.SelectedValue, ddProvince.SelectedValue), "SubDist", "SubDist")
        FunAll.ListDropDown(ddSZipCode, StrQryProvince.TblZipCOdeBindZipCode(ddSubDist.SelectedValue, ddProvince.SelectedValue, ddDist.SelectedValue), "ZipCode", "ZipCode")



        ddSProvince.SelectedValue = ddProvince.SelectedValue
        ddSDist.SelectedValue = ddDist.SelectedValue
        ddSSubDist.SelectedValue = ddSubDist.SelectedValue
        ddSZipCode.SelectedValue = ddZipCode.SelectedValue
    End Sub

    Protected Sub chkAddr_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        CopyAddr()
    End Sub

#End Region

#Region "Update Phone Customer"
    Protected Sub UpdateTblCustomer(ByVal UpdateID As Integer)

        Try
            Dim txtTel As TextBox = FunAll.ObjFindControl("txtTel", frmTel)
            Dim txtTelExt As TextBox = FunAll.ObjFindControl("txtTelExt", frmTel)
            Dim txtOTel As TextBox = FunAll.ObjFindControl("txtOTel", frmTel)
            Dim txtOTelExt As TextBox = FunAll.ObjFindControl("txtOTelExt", frmTel)
            Dim txtMobile As TextBox = FunAll.ObjFindControl("txtMobile", frmTel)
            Dim txtFax As TextBox = FunAll.ObjFindControl("txtFax", frmTel)
            Dim txtOther As TextBox = FunAll.ObjFindControl("txtOther", frmTel)
            Dim txtOtherExt As TextBox = FunAll.ObjFindControl("txtOtherExt", frmTel)

            CheckConnectionState()
            com = New SqlCommand(StrQueryPhone.UpdateTblCustomer(UpdateID), Conn)
            With com
                .Parameters.Clear()
                .Parameters.Add("@Tel", SqlDbType.VarChar).Value = txtTel.Text.Trim
                .Parameters.Add("@TelExt", SqlDbType.VarChar).Value = txtTelExt.Text.Trim
                .Parameters.Add("@OTel", SqlDbType.VarChar).Value = txtOTel.Text.Trim
                .Parameters.Add("@OTelExt", SqlDbType.VarChar).Value = txtOTelExt.Text.Trim
                .Parameters.Add("@Mobile", SqlDbType.VarChar).Value = txtMobile.Text.Trim
                .Parameters.Add("@OthTel1", SqlDbType.VarChar).Value = txtOther.Text.Trim
                .Parameters.Add("@OthTel1Ext", SqlDbType.VarChar).Value = txtOtherExt.Text.Trim
                .Parameters.Add("@Fax", SqlDbType.VarChar).Value = txtFax.Text.Trim
                .Parameters.Add("@CusID", SqlDbType.VarChar).Value = frmCusName.DataKey.Item(0)
                .ExecuteNonQuery()

            End With

            frmTel.ChangeMode(FormViewMode.ReadOnly)
            frmTel.DataBind()

            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('บันทึกข้อมูลเรียบร้อย');", True)
        Catch ex As Exception
            Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "alert('ไม่สามารถบันทึกได้เนื่องจาก : " & ex.Message & "');", True)

        End Try


        'BindLink()
    End Sub

    Protected Sub ImageButton2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(1)
    End Sub

    Protected Sub ImageButton3_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(2)
    End Sub

    Protected Sub ImageButton4_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(5)
    End Sub

    Protected Sub ImageButton5_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(4)
    End Sub

    Protected Sub ImageButton6_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        UpdateTblCustomer(3)
    End Sub

#End Region



    Protected Sub frmCar_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmCar.DataBound
        Dim ddYear As DropDownList = FunAll.ObjFindControl("ddYears", frmCar)
        Dim ddColor As DropDownList = FunAll.ObjFindControl("ddColor", frmCar)
        For i As Integer = Date.Now.Year To 1960 Step -1
            ddYear.Items.Add(i)
        Next
        If frmCar.DataItemCount > 0 Then
            ddYear.SelectedValue = frmCar.DataKey.Item(2)
            ddColor.SelectedValue = frmCar.DataKey.Item(6)
        End If
    End Sub

    Public Sub CheckConnectionState()
        If Conn.State = ConnectionState.Open Then
            Conn.Close()
        Else
            Conn.Open()
        End If
    End Sub

    Protected Sub frmCarDriver_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmCarDriver.DataBound
        Dim txtCarDBorn1 As TextBox = FunAll.ObjFindControl("txtCarDBorn1", frmCarDriver)
        Dim txtCarBornDate1 As TextBox = FunAll.ObjFindControl("txtCarBornDate1", frmCarDriver)
        Dim txtCarDBorn2 As TextBox = FunAll.ObjFindControl("txtCarDBorn2", frmCarDriver)
        Dim txtCarBornDate2 As TextBox = FunAll.ObjFindControl("txtCarBornDate2", frmCarDriver)
        If frmCarDriver.DataKey.Item(0) = 0 Then
            txtCarBornDate1.Text = ""
            txtCarBornDate2.Text = ""
            txtCarDBorn1.Text = ""
            txtCarDBorn2.Text = ""
        ElseIf frmCarDriver.DataKey.Item(0) = 1 Then
            txtCarBornDate2.Text = ""
            txtCarDBorn2.Text = ""
        End If
    End Sub

    Protected Sub frmCusName_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmCusName.DataBound
        If Request.QueryString("CarPet") IsNot Nothing Then
            SqlPackage.SelectParameters("IsCappet").DefaultValue = Request.QueryString("Carpet").ToString
        End If
        Dim chkPA As CheckBox = FunAll.ObjFindControl("chkPA", frmCusName)
        If frmCusName.DataKey.Item(3) <> 0 Then
            chkPA.Checked = True
        Else
            chkPA.Checked = False
        End If
    End Sub

    Protected Sub frmPackage_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmPackage.DataBound
        If (frmPackage.DataKey.Item(17).ToString = 1 And Request.QueryString("Buy").ToString = 1) Or (frmPackage.DataKey.Item(17).ToString = 14 And Request.QueryString("Buy").ToString = 1) Then
            Dim txtProValue As WebNumericEdit = FunAll.ObjFindControl("txtProValue", frmPackage)
            Dim txtTotalValue As WebNumericEdit = FunAll.ObjFindControl("txtTotalValue", frmPackage)

            Dim lblLostCar1 As Label = FunAll.ObjFindControl("lblLostCar1", frmPackage)
            Dim lblCarFire As Label = FunAll.ObjFindControl("lblCarFire", frmPackage)


            txtProValue.Text = Request.QueryString("ProValue").ToString
            txtTotalValue.Text = Request.QueryString("ProValue").ToString

            lblLostCar1.Text = CDbl(Request.QueryString("ProPrice").ToString).ToString("##,##.##")
            lblCarFire.Text = CDbl(Request.QueryString("ProPrice").ToString).ToString("##,##.##")


        End If

        If ChkProductPhotos() = True Then
            plTakePhoto.Visible = True
        Else
            plTakePhoto.Visible = False
        End If

        'สำหรับนัดถ่ายรูป KTC ชั้น
        If frmPackage.DataKey.Item(17) = 1 And frmPackage.DataKey.Item(16) = 63 Then
            plTakePhotKTC.Visible = True
        Else
            plTakePhotKTC.Visible = False
        End If

        If (frmPackage.DataKey.Item(17) = 3 Or frmPackage.DataKey.Item(17) = 4) And frmPackage.DataKey.Item(16) = 63 Then
            Dim lblLostProp2 As TextBox = FunAll.ObjFindControl("lblLostProp2", frmPackage)
            lblLostProp2.Enabled = True
        Else
            Dim lblLostProp2 As TextBox = FunAll.ObjFindControl("lblLostProp2", frmPackage)
            lblLostProp2.Enabled = False
        End If


        'Dim txtAge As TextBox = FunAll.ObjFindControl("txtAge", frmCusName)
        'txtAge.Text = GetAge()
    End Sub

    Protected Sub frmAppRela_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmAppRela.DataBound

        If Request.Cookies("TypeTsr").Value = 3 And frmAppRela.DataItemCount = 0 Then
            GetDataApplication()
        ElseIf Request.Cookies("TypeTsr").Value = 11 And frmAppRela.DataItemCount = 0 Then
            GetDataApplication()
        End If

        If Request.QueryString("CarPet") IsNot Nothing Then
            If Request.QueryString("CarPet").ToString = 0 Then
                Dim txtProtectDateCarpet As TextBox = FunAll.ObjFindControl("txtProtectDateCarpet", frmAppRela)
                txtProtectDateCarpet.Text = ""
            End If
        Else
            If frmAppRela.DataItemCount > 0 Then
                If frmAppRela.DataKey.Item(0) = 0 Then
                    Dim txtProtectDateCarpet As TextBox = FunAll.ObjFindControl("txtProtectDateCarpet", frmAppRela)
                    txtProtectDateCarpet.Text = ""
                End If
            End If
        End If
    End Sub

    'สำหรับดึงข้อมูล App เก่าของ ปีต่อ'

    Protected Sub GetDataApplication()
        Dim strqry As String = ""
        strqry += " SELECT a1.* "
        strqry += " ,case when a4.FName  is null then '' else a4.FName end   as AppRelaTH    "
        strqry += " ,case when a5.ProTypeName is null then '[ไม่ระบุ]' else a5.ProTypeName end as OldInsureTH  "
        strqry += " ,case a1.chkDeviceAdd when 1 then 'True' else 'False' end as chkDeviceStatus    "
        strqry += " FROM TmpApp_CustRenew a1"
        strqry += " Inner Join TblCar a2 on a1.IdCar = a2.IdCar"
        strqry += " Inner Join TblCustomer a3 on a3.CusID = a2.CusID"
        strqry += " Left Join TblFinance  a4 on a1.AppRela = a4.FName"
        strqry += " Left Join Tbl_ProductType a5 on a1.Old_Insu = a5.ProTypeName"
        strqry += " where a2.IdCar =  @IdCar and a1.AppStatus = 1 and a1.FlagNewApp = 0"
        strqry += " order by a1.CreateDate DESC"
        strqry = Replace(strqry, "@IdCar", Request.QueryString("IdCar").ToString)
        dt = New DataTable
        dt = DataAccess.DataRead(strqry)

        If dt.Rows.Count > 0 Then
            Dim txtProtectDate As TextBox = FunAll.ObjFindControl("txtProtectDate", frmAppRela)
            Dim txtProtectDateCarpet As TextBox = FunAll.ObjFindControl("txtProtectDateCarpet", frmAppRela)
            txtProtectDate.Text = CDate(dt.Rows(0).Item("ExpProtectDate")).ToString("dd/MM/yyyy")
            txtProtectDateCarpet.Text = CDate(dt.Rows(0).Item("ExpProtectDateCarpet")).ToString("dd/MM/yyyy")
        End If
    End Sub

    Protected Sub DropDownList1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddCarpet As DropDownList = FunAll.ObjFindControl("ddCarpet", frmProType)
        If Request.QueryString("Buy").ToString <> 1 Then
            SqlPackage.SelectParameters("changeCarpet").DefaultValue = 1
            SqlPackage.SelectParameters("IsCappet").DefaultValue = ddCarpet.SelectedValue

        Else
            SqlPackage.SelectParameters("IsCappet").DefaultValue = ddCarpet.SelectedValue
        End If




    End Sub



#Region "SendPreminum"

    Protected Sub Button12_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button12.Click
        If frmDoc.DataItemCount > 0 Then
            InsertSendPrimun()
            SqlSendPremium.SelectParameters("AppID").DefaultValue = frmOldInsure.DataKey.Item(0)
            GvPremium.DataSource = SqlSendPremium
            GvPremium.DataBind()
        Else
            AddRowPremium()
        End If

    End Sub

    Protected Sub InsertSendPrimun()
        With SqlSendPremium
            .InsertParameters("CusID").DefaultValue = frmCusName.DataKey.Item(0)
            .InsertParameters("IDcar").DefaultValue = frmCar.DataKey.Item(0)
            .InsertParameters("AppID").DefaultValue = frmOldInsure.DataKey.Item(0)
            .InsertParameters("PreID").DefaultValue = ddPremium.SelectedValue
            .InsertParameters("TotalSend").DefaultValue = txtAmount.Text.Trim
            .Insert()
        End With
    End Sub

    Protected Sub InsertTblSendPremium2()
        If frmDoc.DataItemCount <= 0 Then


            For i As Integer = 0 To GvPremium.Rows.Count - 1
                With SqlSendPremium
                    .InsertParameters("PreID").DefaultValue = GvPremium.DataKeys(i).Item(1)
                    .InsertParameters("TotalSend").DefaultValue = GvPremium.DataKeys(i).Item(2)
                    .InsertParameters("AppID").DefaultValue = frmOldInsure.DataKey.Item(0)
                    .Insert()
                End With
            Next

        End If
    End Sub

    Protected Sub DeletePreminum(ByVal i As Integer)
        With SqlSendPremium
            .DeleteParameters("runNO").DefaultValue = GvPremium.DataKeys(i).Item(0)
            .Delete()
        End With
    End Sub

    Protected Sub CreateDtPremium()
        dt = New DataTable
        dt.Columns.Add("PreID")
        dt.Columns.Add("TotalSend")
        dt.Columns.Add("PremiumName")
        dt.Columns.Add("runNO")
    End Sub

    Protected Sub AddRowPremium()
        If ViewState("dtPremium") Is Nothing Then
            CreateDtPremium()
        Else
            dt = New DataTable
            dt = ViewState("dtPremium")
        End If

        Dim dr As DataRow
        dr = dt.NewRow
        dr("PreID") = ddPremium.SelectedValue
        dr("TotalSend") = txtAmount.Text.Trim
        dr("PremiumName") = ddPremium.SelectedItem.ToString
        dr("runNO") = 0
        dt.Rows.Add(dr)
        ViewState("dtPremium") = dt
        GvPremium.DataSource = dt
        GvPremium.DataBind()
    End Sub

    Protected Sub GvPremium_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvPremium.RowCommand
        If e.CommandName = "remove1" Then
            If frmDoc.DataItemCount > 0 Then
                DeletePreminum(e.CommandArgument)
                SqlSendPremium.SelectParameters("AppID").DefaultValue = frmOldInsure.DataKey.Item(0)
                GvPremium.DataSource = SqlSendPremium
                GvPremium.DataBind()
            Else
                Dim dt As New DataTable
                dt = ViewState("dtPremium")
                dt.Rows(e.CommandArgument).Delete()
                ViewState("dtPremium") = dt
                GvPremium.DataSource = dt
                GvPremium.DataBind()
            End If


        End If
    End Sub
#End Region



    Protected Sub frmOldInsure_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmOldInsure.DataBound
        If Request.Cookies("TypeTsr").Value = 3 Then
            Dim chkSendDoc As CheckBox = FunAll.ObjFindControl("chkSendDoc", frmOldInsure)
            chkSendDoc.Visible = True
        Else
            Dim chkSendDoc As CheckBox = FunAll.ObjFindControl("chkSendDoc", frmOldInsure)
            chkSendDoc.Visible = False
        End If
    End Sub

    Protected Sub frmDoc_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmDoc.DataBound
        If frmDoc.DataItemCount > 0 Then
            'SendPremium
            SqlSendPremium.SelectParameters("AppID").DefaultValue = frmOldInsure.DataKey.Item(0)
            GvPremium.DataSource = SqlSendPremium
            GvPremium.DataBind()

            'AppPay
            BindGvPay()
            ddPay.SelectedValue = dt.Rows.Count

            'AppCard
            GvAppPayDataBind()

            SqlTakePhotoKTC.SelectParameters("AppID").DefaultValue = frmOldInsure.DataKey.Item(0)

            If Request.Cookies("UserLevel").Value = 8 And Not IsPostBack Then
                Dim txtProValue As WebNumericEdit = FunAll.ObjFindControl("txtProValue", frmPackage)
                Dim lblTotalValue As WebNumericEdit = FunAll.ObjFindControl("txtTotalValue", frmPackage)
                lblTotalValue.Text = frmDoc.DataKey.Item(1)
                txtProValue.Text = frmDoc.DataKey.Item(0)
            End If

        End If
        chkCredit.Visible = True
        'If Request.Cookies("TypeTsr").Value = 3 Or Request.Cookies("TypeTsr").Value = 6 Or Request.Cookies("TypeTsr").Value = 11 Then
        '    chkCredit.Visible = True
        'ElseIf Request.Cookies("UserLevel").Value = 2 Or Request.Cookies("UserLevel").Value = 1 Then
        '    chkCredit.Visible = True
        'Else
        '    chkCredit.Visible = False
        'End If


    End Sub
    Protected Sub SetScript(ByVal strappid As String)

        Dim query = New System.Text.StringBuilder()
        query.Append(" select a.AppID,a.Idcar,d.InitTH+' '+c.FNameTH+' '+c.LNameTH as cusname,b.CarID, ")
        query.Append(" b.CarBrand,")
        query.Append(" b.CarSeries,")
        query.Append(" isnull(b.CarSize,'') as CarSize")
        query.Append(" ,e.ProTypeName,a7.TypeName,")
        query.Append(" case a.IsCarpet when 1 then a.CarPet else 0 end as Carpet,")
        query.Append(" case a.IsCarpet when 1 then CONVERT(VARCHAR,a.ProtectDateCarpet,103) else 'ไม่ระบุ'  end as ProtectDateCarpet,")
        query.Append(" case a.IsCarpet when 1 then 'โดยเริ่มคุ้มครองวันที่(พรบ.)' else ''  end as lblProtectDateCarpet,")
        query.Append(" case a.IsCarpet when 1 then 'รวม พรบ.' else 'ไม่รวม พรบ.'  end as lblCarpet,")
        query.Append(" CAST(a.ProValue as money)+ CAST(a.CarPet as money) as ProValue,")
        query.Append(" case a.IsProvalue when 1 then CONVERT(VARCHAR,a.ProtectDate,103) else 'ไม่ระบุ' end as ProtectDate,")
        query.Append(" case a.IsProvalue when 1 then CAST(a.Car_Fire as money) else 0 end as Car_Fire,")
        query.Append(" case b.CarFixIn when '1' then 'ซ่อมอู่'  else 'ซ่อมห้าง' end as IsFixIn ,")
        query.Append(" (select count(*) from tblapppay where appid=a.AppID) as CPay,")
        query.Append(" case b.CarDriverNo when 0  then 'ไม่เป็นแบบระบุชื่อผู้ขับขี่'  else 'เป็นแบบระบุชื่อผู้ขับขี่' end as lblCarDriverNo ,")
        query.Append(" case b.CarDriverNo when 0  then ''  else CAST(b.CarDriverNo as varchar) end as CarDriverNo , ")
        query.Append(" case b.CarDriverNo when 0  then ''  else 'ท่าน(กรณีทำประกันประเภทระบุชื่อผู้ขับขี่)' end as lbl ,")
        query.Append(" case f.IsPayDate when 1 then CONVERT(VARCHAR, f.PayDate,103) else 'ไม่ระบุ' end as PayDate ")
        query.Append(" from tblapplication a  ")
        query.Append(" inner join tblcar b on a.Idcar=b.idcar ")
        query.Append(" inner join tblcustomer c on b.CusID=c.cusid ")
        query.Append(" inner join TblCustomerInit d on d.InitID=c.InitID")
        query.Append(" Inner Join Tbl_ProductType a6 on a.ProductID = a6.ProTypeID")
        query.Append(" Inner Join Tbl_Type a7 on a.Typeprovalue = a7.TypeID")
        query.Append(" Left  Join Tbl_ProductType e on  e.ProTypeID=a.ProDuctID")
        query.Append(" Left  Join TblAppCard f on a.AppID=f.AppID")
        query.Append(" where a.AppID =" & strappid)


        Dim da As SqlDataAdapter = New SqlDataAdapter(query.ToString, Conn)
        Dim table As DataTable = New DataTable
        da.Fill(table)
        If table.Rows.Count > 0 Then
            'HFAppID.Value = table.Rows(0)("AppID").ToString
            txtCarID.Text = table.Rows(0)("CarID").ToString
            txtCarBrand.Text = table.Rows(0)("CarBrand").ToString
            txtCarSeries.Text = table.Rows(0)("CarSeries").ToString
            txtCarSize.Text = table.Rows(0)("CarSize").ToString
            txtProTypeName.Text = table.Rows(0)("ProTypeName").ToString
            txtTypeName.Text = table.Rows(0)("TypeName").ToString
            txtProtectDate.Text = table.Rows(0)("ProtectDate").ToString
            lblProtectDateCarprt.Text = table.Rows(0)("lblProtectDateCarpet").ToString
            txtProtectDateCarprt.Text = table.Rows(0)("ProtectDateCarpet").ToString
            lblCarDriverNo.Text = table.Rows(0)("lblCarDriverNo").ToString
            txtCarDriverNo.Text = table.Rows(0)("CarDriverNo").ToString
            Label13.Text = table.Rows(0)("lbl").ToString
            lblCarpet.Text = table.Rows(0)("lblCarpet").ToString
            txtCar_Fire.Text = String.Format(CultureInfo.InvariantCulture, "{0:0,0.00}", table.Rows(0)("Car_Fire"))
            txtIsFixIn.Text = table.Rows(0)("IsFixIn").ToString
            txtProValue.Text = String.Format(CultureInfo.InvariantCulture, "{0:0,0.00}", table.Rows(0)("ProValue"))
            txtPayDate.Text = table.Rows(0)("PayDate").ToString

            SqlAppPayDGVPay.SelectParameters("Appid").DefaultValue = strappid
            DGVPay.DataSource = SqlAppPayDGVPay
            DGVPay.DataBind()

            SqlTblApplicationPA.SelectParameters("Appid").DefaultValue = strappid
            FormView1.DataSource = SqlTblApplicationPA
            FormView1.DataBind()


            frmAddrConfirm.DataSource = SqlCustomerConfirm
            frmAddrConfirm.DataBind()

            DGVAppCard.DataSource = SqlAppCard2Confirm
            DGVAppCard.DataBind()

            frmCusNameConfirm.DataSource = SqlCustomerConfirm
            frmCusNameConfirm.DataBind()

        Else

            query = New System.Text.StringBuilder()
            query.Append(" select b.Idcar,b.CarID, ")
            query.Append(" b.CarBrand,")
            query.Append(" b.CarSeries,")
            query.Append(" isnull(b.CarSize,'') as CarSize")
            query.Append(" From  tblcar b ")
            query.Append(" inner join tblcustomer c on b.CusID=c.cusid ")
            query.Append(" where b.Idcar =" & Request.QueryString("IdCar").ToString())
            Dim da1 As SqlDataAdapter = New SqlDataAdapter(query.ToString, Conn)
            Dim table1 As DataTable = New DataTable
            da1.Fill(table1)
            'HFAppID.Value = "0"
            ' HFidCar.Value = table1.Rows(0)("Idcar").ToString
            '3.
            txtCarID.Text = table1.Rows(0)("CarID").ToString
            txtCarBrand.Text = table1.Rows(0)("CarBrand").ToString
            txtCarSeries.Text = table1.Rows(0)("CarSeries").ToString
            txtCarSize.Text = table1.Rows(0)("CarSize").ToString
            '4.
            txtProTypeName.Text = ""
            txtTypeName.Text = ""
            '5.
            txtProtectDate.Text = ""
            lblProtectDateCarprt.Text = ""
            txtProtectDateCarprt.Text = ""
            lblCarDriverNo.Text = "การระบุผู้ขับขี่"
            txtCarDriverNo.Text = ""
            Label13.Text = ""
            lblCarpet.Text = ""
            txtCar_Fire.Text = ""
            txtIsFixIn.Text = ""
            txtProValue.Text = ""
            txtPayDate.Text = ""

            'DGVPay.DataSource = SqlAppPayDGVPay
            'DGVPay.DataBind()
            frmAddrConfirm.DataSource = SqlCustomerConfirm
            frmAddrConfirm.DataBind()
            DGVAppCard.DataSource = SqlAppCard2Confirm
            DGVAppCard.DataBind()
            frmCusNameConfirm.DataSource = SqlCustomerConfirm
            frmCusNameConfirm.DataBind()
        End If

    End Sub
    Protected Sub ShowSetScript()

        Dim dtAppID As New System.Data.DataTable
        Dim dv As DataView = DirectCast(SqlAppConfirm.Select(DataSourceSelectArguments.Empty), DataView)
        dtAppID = dv.ToTable()
        If dtAppID.Rows.Count > 0 Then
            strappid = dtAppID.Rows(0)("AppID").ToString()
            '2.
            SetScript(strappid)

        Else
            SetScript(0)

        End If
    End Sub
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            If CheckDup() = True And chkTakePhoto() = True And CheckApp() = True And checkTakePhotoKTC() = True And chkPayPL(2) = True And chkAppQc() = True And Checkbirthdate() = True And CheckProductPA() Then
                CheckConnectionState()
                SaveCustomer()
                SaveCar()
                btnApplication()
                btnApplicationPA()
                SaveTblAppPay()
                btnInsertTblAppCard()
                btnTakePhoto()
                InsertTblSendPremium2()
                SaveTblKTCTakePhoto()
                If Request.Cookies("UserLevel").Value = 2 Or Request.Cookies("UserLevel").Value = 1 Then
                    InsertTblLogAppPay()
                End If
                SqlCustomer.InsertParameters("IpAddr").DefaultValue = Request.ServerVariables("REMOTE_ADDR")
                SqlCustomer.Insert()

                'Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.close();</script>")

                If Request.Cookies("UserLevel").Value = 5 Then
                    scripttmp.Visible = True
                    ShowSetScript()
                End If
            Else
                MsgBox("ไม่สามารถบันทึกได้")
            End If

        Catch ex As Exception
            MsgBox("ไม่สามารถบันทึกได้เนื่องจาก : " & ex.Message.ToString)
        End Try

    End Sub

    'Script MsgBox
    Public Sub MsgBox(ByVal sMsg As String)

        Dim sb As New StringBuilder()
        Dim oFormObject As System.Web.UI.Control
        sMsg = sMsg.Replace("'", "\'")
        sMsg = sMsg.Replace(Chr(34), "\" & Chr(34))
        sMsg = sMsg.Replace(vbCrLf, "\n")
        sMsg = "<script language=javascript>alert(""" & sMsg & """)</script>"

        sb = New StringBuilder()
        sb.Append(sMsg)

        For Each oFormObject In Me.Controls
            If TypeOf oFormObject Is HtmlForm Then
                Exit For
            End If
        Next

        ' Add the javascript after the form object so that the 
        ' message doesn't appear on a blank screen.
        oFormObject.Controls.AddAt(oFormObject.Controls.Count, New LiteralControl(sb.ToString()))
    End Sub

    'check การตรวจงานของ Qc ห้ามบันทึก App
    Protected Function chkAppQc() As Boolean
        Dim dvSql As DataView = DirectCast(SqlGetApplication.Select(DataSourceSelectArguments.Empty), DataView)
        If dvSql.Count > 0 And Request.Cookies("UserLevel").Value <> 8 Then
            If dvSql.Item(0).Item("StatusQc") = 0 Or dvSql.Item(0).Item("StatusQc") = 2 Then
                Return True
            Else
                MsgBox("App นี้กำลังตรวจสอบจาก Qc หรืออยู่ในสถานะอื่นๆที่ไม่สามารถบันทึกได้")
                Return False
            End If

        Else
            Return True
        End If
    End Function


    Protected Function CheckDup() As Boolean
        Dim txtCarID As TextBox = FunAll.ObjFindControl("txtCarID", frmCar)
        Dim ddCarID As DropDownList = FunAll.ObjFindControl("ddCarID", frmCar)
        Dim strqry As String
        If ddCarID.SelectedValue <> "ป้ายแดง" Then
            strqry = "Select CarID from TblCar Where CarID   = '" & Replace(txtCarID.Text.Trim, " ", "") & ddCarID.Text.Trim & "'"
            strqry += " and (CurStatus not in(12)) and idcar not in (select carid from  [TblNotupdate14] )"
            dt = New DataTable
            dt = DataAccess.DataRead(strqry)
            If frmCar.DataKey.Item(5).ToString.Trim = Replace(txtCarID.Text.Trim, " ", "") & ddCarID.Text.Trim Then
                If dt.Rows.Count > 1 Then
                    MsgBox("ทะเบียนซ้ำกันในระบบ")
                    Return False
                Else
                    Return True
                End If
            Else
                If dt.Rows.Count > 0 Then
                    MsgBox("ทะเบียนซ้ำกันในระบบ")
                    Return False
                Else
                    Return True
                End If
            End If

        Else
            Return True
        End If

    End Function

    Protected Function CheckApp() As Boolean
        Dim lblCarPet As Label = FunAll.ObjFindControl("lblCappet", frmPackage)
        Dim lblTotalValue As WebNumericEdit = FunAll.ObjFindControl("txtTotalValue", frmPackage)

        Try
            If GvPay.Rows.Count > 0 And (CInt(lblCarPet.Text) + CInt(lblTotalValue.Text)) <= 0 Then
                MsgBox("ไม่สามารถบันทึก : เบี้ยขายกับงวดชำระไม่ถูกต้อง")
                Return False

            Else
                Dim TotalPay As Integer = 0
                Dim TotalValue As Integer = (CInt(lblCarPet.Text) + CInt(lblTotalValue.Text)) + 10
                For i As Integer = 0 To GvPay.Rows.Count - 1
                    TotalPay += GvPay.DataKeys(i).Item(1)
                Next
                If TotalPay > TotalValue Then
                    MsgBox("ไม่สามารถบันทึก : เบี้ยขายกับงวดชำระไม่ถูกต้อง")
                    Return False
                Else

                    If frmCar.DataKey.Item(4) = 3 Or frmCar.DataKey.Item(4) = 4 Then
                        Dim ddIsProValue As DropDownList = FunAll.ObjFindControl("ddIsProValue", frmProType)
                        Dim ddCarpet As DropDownList = FunAll.ObjFindControl("ddCarpet", frmProType)
                        Dim txtIDCard As TextBox = FunAll.ObjFindControl("txtIDCard", frmCusName)
                        Dim txtIDCardCarpet As TextBox = FunAll.ObjFindControl("txtIDCard", frmCusName)

                        If ddIsProValue.SelectedValue = 1 And txtIDCard.Text.Trim = "" Then
                            MsgBox("กรุณาระบุเลขบัตรประชาชน ประกันสมัครใจ")
                            Return False

                        End If

                        If ddCarpet.SelectedValue = 1 And txtIDCardCarpet.Text.Trim = "" Then
                            MsgBox("กรุณาระบุเลขบัตรประชาชน พรบ.")
                            Return False
                        End If

                    End If

                    Return True
                End If

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
            Return False
        End Try

    End Function

    Protected Function chkTakePhoto() As Boolean
        If ChkProductPhotos() = True Then
            If ChkWeekEnd() = True And ChkDateAppoint() = True Then
                Dim ddProvince As DropDownList = DirectCast(frmPhoto.FindControl("ddProvince"), DropDownList)
                Dim ddDist As DropDownList = DirectCast(frmPhoto.FindControl("ddDist"), DropDownList)
                Dim ddSubDist As DropDownList = DirectCast(frmPhoto.FindControl("ddSubDist"), DropDownList)
                If GetRiderPhoto(ddProvince.SelectedValue, ddDist.SelectedValue, ddSubDist.SelectedValue) = 0 Then
                    MsgBox("พื้นที่ถ่ายรูป : ไม่พบ agent ถ่ายรูปในพืีนที่นี้")
                    Return False
                Else
                    Return True
                End If
            Else
                Return False
            End If
        Else
            Return True
        End If

    End Function

#Region "SaveTblApplication"


    Protected Sub SaveCustomer()
        Dim txtFNameTH As TextBox = FunAll.ObjFindControl("txtFNameTH", frmCusName)
        Dim txtLNameTH As TextBox = FunAll.ObjFindControl("txtLNameTH", frmCusName)
        Dim ddInit As DropDownList = FunAll.ObjFindControl("ddInit", frmCusName)
        Dim txtIDCard As TextBox = FunAll.ObjFindControl("txtIDCard", frmCusName)
        Dim txtIDCardCarpet As TextBox = FunAll.ObjFindControl("txtIDCard", frmCusName)

        Dim txtbirthdate As TextBox = FunAll.ObjFindControl("txtbirthdate", frmCusName)
        Dim txtAge As TextBox = FunAll.ObjFindControl("txtAge", frmCusName)
        Dim ddSex As DropDownList = FunAll.ObjFindControl("ddSex", frmCusName)
        Dim ddOcc As DropDownList = FunAll.ObjFindControl("ddOcc", frmCusName)

        Dim txtSAddr As TextBox = FunAll.ObjFindControl("txtAddr", frmSAddr)
        Dim txtSMoo As TextBox = FunAll.ObjFindControl("txtMoo", frmSAddr)
        Dim txtSVliage As TextBox = FunAll.ObjFindControl("txtVillege", frmSAddr)
        Dim txtSRoad As TextBox = FunAll.ObjFindControl("txtRoad", frmSAddr)
        Dim txtSSoi As TextBox = FunAll.ObjFindControl("txtSoi", frmSAddr)
        Dim ddSProvince As DropDownList = FunAll.ObjFindControl("ddProvince", frmSAddr)
        Dim ddSDist As DropDownList = FunAll.ObjFindControl("ddDist", frmSAddr)
        Dim ddSSubDist As DropDownList = FunAll.ObjFindControl("ddSubDist", frmSAddr)
        Dim ddSZipcode As DropDownList = FunAll.ObjFindControl("ddZipcode", frmSAddr)

        Dim txtAddr As TextBox = FunAll.ObjFindControl("txtAddr", frmAddr)
        Dim txtMoo As TextBox = FunAll.ObjFindControl("txtMoo", frmAddr)
        Dim txtVliage As TextBox = FunAll.ObjFindControl("txtVillege", frmAddr)
        Dim txtRoad As TextBox = FunAll.ObjFindControl("txtRoad", frmAddr)
        Dim txtSoi As TextBox = FunAll.ObjFindControl("txtSoi", frmAddr)
        Dim ddProvince As DropDownList = FunAll.ObjFindControl("ddProvince", frmAddr)
        Dim ddDist As DropDownList = FunAll.ObjFindControl("ddDist", frmAddr)
        Dim ddSubDist As DropDownList = FunAll.ObjFindControl("ddSubDist", frmAddr)
        Dim ddZipcode As DropDownList = FunAll.ObjFindControl("ddZipcode", frmAddr)
        Dim txtSName As TextBox = FunAll.ObjFindControl("txtSName", frmAddr)

        Dim chkAddr As CheckBox = FunAll.ObjFindControl("chkAddr", frmSAddr)
        'Dim Booolean As Byte
        'If ddSex.SelectedValue = "False" Then
        '    Booolean = 0
        'Else
        '    Booolean = 1
        'End If


        com = New SqlCommand(StrQuery.UpdateCustomer, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@InitID", SqlDbType.VarChar).Value = ddInit.SelectedValue
            .Parameters.Add("@FNameTH", SqlDbType.VarChar).Value = txtFNameTH.Text.Trim
            .Parameters.Add("@LNameTH", SqlDbType.VarChar).Value = txtLNameTH.Text.Trim
            .Parameters.Add("@Address", SqlDbType.VarChar).Value = txtAddr.Text.Trim
            .Parameters.Add("@SAddress", SqlDbType.VarChar).Value = txtSAddr.Text.Trim
            .Parameters.Add("@Villege", SqlDbType.VarChar).Value = txtVliage.Text.Trim
            .Parameters.Add("@Svillege", SqlDbType.VarChar).Value = txtSVliage.Text.Trim
            .Parameters.Add("@Moo", SqlDbType.VarChar).Value = txtMoo.Text.Trim
            .Parameters.Add("@SMoo", SqlDbType.VarChar).Value = txtSMoo.Text.Trim
            .Parameters.Add("@Soi", SqlDbType.VarChar).Value = txtSoi.Text.Trim
            .Parameters.Add("@SSoi", SqlDbType.VarChar).Value = txtSSoi.Text.Trim
            .Parameters.Add("@Road", SqlDbType.VarChar).Value = txtRoad.Text.Trim
            .Parameters.Add("@SRoad", SqlDbType.VarChar).Value = txtSRoad.Text.Trim
            .Parameters.Add("@SubDist", SqlDbType.VarChar).Value = ddSubDist.SelectedValue
            .Parameters.Add("@SSubDist", SqlDbType.VarChar).Value = ddSSubDist.SelectedValue
            .Parameters.Add("@Dist", SqlDbType.VarChar).Value = ddDist.SelectedValue
            .Parameters.Add("@SDist", SqlDbType.VarChar).Value = ddSDist.SelectedValue
            .Parameters.Add("@Province", SqlDbType.VarChar).Value = ddProvince.SelectedValue
            .Parameters.Add("@SProvince", SqlDbType.VarChar).Value = ddSProvince.SelectedValue
            .Parameters.Add("@Zip", SqlDbType.VarChar).Value = ddZipcode.SelectedValue
            .Parameters.Add("@SZip", SqlDbType.VarChar).Value = ddSZipcode.SelectedValue
            .Parameters.Add("@sameAddr", SqlDbType.Bit).Value = chkAddr.Checked
            .Parameters.Add("@userID", SqlDbType.VarChar).Value = Request.Cookies("userID").Value
            .Parameters.Add("@SName", SqlDbType.VarChar).Value = txtSName.Text.Trim
            .Parameters.Add("@IDCard", SqlDbType.VarChar).Value = txtIDCard.Text.Trim
            .Parameters.Add("@IDCard_Carpet", SqlDbType.VarChar).Value = txtIDCardCarpet.Text.Trim
            .Parameters.Add("@CusID", SqlDbType.VarChar).Value = frmCusName.DataKey.Item(0)
            .Parameters.Add("@BirthDate", SqlDbType.DateTime).Value = ISODate.SetISODate("th", txtbirthdate.Text)
            .Parameters.Add("@IsMale", SqlDbType.Bit).Value = ddSex.SelectedValue
            .Parameters.Add("@OccID", SqlDbType.VarChar).Value = ddOcc.SelectedValue
            .Parameters.Add("@Age", SqlDbType.TinyInt).Value = txtAge.Text

            .ExecuteNonQuery()

        End With
    End Sub
    Protected Function Checkbirthdate() As Boolean

        Dim ProductID As String = frmProType.DataKey.Item(0)

        Dim txtbirthdate As TextBox = FunAll.ObjFindControl("txtbirthdate", frmCusName)
        Dim chkbirthdate As String = ISODate.SetISODate("th", txtbirthdate.Text)
        Dim datenow As DateTime = DateTime.Now

        If ProductID = 95 Then ' Product Gen
            If chkbirthdate <> "" Then ' Check date 
                If chkbirthdate >= ISODate.SetISODate("th", datenow.ToString("dd/MM/yyyy")) Then
                    MsgBox("กรุณาเลือกวันที่อีกครั้ง!")
                    Return False
                Else
                    Return True
                End If
            Else
                MsgBox("กรุณาระบุวันเดือนปีเกิด!")
                Return False
            End If
        ElseIf ProductID = 25 Then
            Dim txtnetPremium As WebNumericEdit = FunAll.ObjFindControl("txtnetPremium", frmPackage)
            Dim ddIsProValue As DropDownList = FunAll.ObjFindControl("ddIsProValue", frmProType)
            If (ddIsProValue.SelectedValue = "1") And (txtnetPremium.Text = "" Or txtnetPremium.Text = "0.00" Or txtnetPremium.Text = "0") Then
                MsgBox("กรุณากรอก เบี้ยประกัน!")
                Return False
            Else
                Return True
            End If
        Else ' Other Product
            Return True
        End If

    End Function
    Protected Sub SaveCar()
        'frmCar
        Dim txtCarID As TextBox = FunAll.ObjFindControl("txtCarID", frmCar)
        Dim txtCarNo As TextBox = FunAll.ObjFindControl("txtCarNo", frmCar)
        Dim txtCarBoxNo As TextBox = FunAll.ObjFindControl("txtCarBoxNo", frmCar)
        Dim txtCarSize As TextBox = FunAll.ObjFindControl("txtCarSize", frmCar)
        Dim ddCarID As DropDownList = FunAll.ObjFindControl("ddCarID", frmCar)
        Dim ddYears As DropDownList = FunAll.ObjFindControl("ddYears", frmCar)

        Dim ddColor As DropDownList = FunAll.ObjFindControl("ddColor", frmCar)

        'frmCarDriver1
        Dim txtCarDriver1 As TextBox = FunAll.ObjFindControl("txtCarDriver1", frmCarDriver)
        Dim txtCarLName1 As TextBox = FunAll.ObjFindControl("txtCarLName1", frmCarDriver)
        Dim txtIDCard1 As TextBox = FunAll.ObjFindControl("txtIDCard1", frmCarDriver)
        Dim txtCarDBorn1 As TextBox = FunAll.ObjFindControl("txtCarDBorn1", frmCarDriver)
        Dim txtCarBornNo1 As TextBox = FunAll.ObjFindControl("txtCarBornNo1", frmCarDriver)
        Dim txtCarBornDate1 As TextBox = FunAll.ObjFindControl("txtCarBornDate1", frmCarDriver)
        Dim ddCarBornAddr1 As DropDownList = FunAll.ObjFindControl("ddCarBornAddr1", frmCarDriver)


        'frmCarDriver2
        Dim txtCarDriver2 As TextBox = FunAll.ObjFindControl("txtCarDriver2", frmCarDriver)
        Dim txtCarLName2 As TextBox = FunAll.ObjFindControl("txtCarLName2", frmCarDriver)
        Dim txtIDCard2 As TextBox = FunAll.ObjFindControl("txtIDCard2", frmCarDriver)
        Dim txtCarDBorn2 As TextBox = FunAll.ObjFindControl("txtCarDBorn2", frmCarDriver)
        Dim txtCarBornNo2 As TextBox = FunAll.ObjFindControl("txtCarBornNo2", frmCarDriver)
        Dim txtCarBornDate2 As TextBox = FunAll.ObjFindControl("txtCarBornDate2", frmCarDriver)
        Dim ddCarBornAddr2 As DropDownList = FunAll.ObjFindControl("ddCarBornAddr2", frmCarDriver)

        'frmCarDriver
        Dim ddCarDriverNo As DropDownList = FunAll.ObjFindControl("ddCarDriverNo", frmCar)

        'frmRela
        Dim txtProtectDate As TextBox = FunAll.ObjFindControl("txtProtectDate", frmAppRela)
        Dim tst As String = frmPackage.DataKey.Item(22)
        com = New SqlCommand(StrQuery.UpdateTblcar, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@CarDriverNo", SqlDbType.VarChar).Value = ddCarDriverNo.SelectedValue
            .Parameters.Add("@CarDriver1", SqlDbType.VarChar).Value = txtCarDriver1.Text.Trim
            .Parameters.Add("@CarDriverLname1", SqlDbType.VarChar).Value = txtCarLName1.Text.Trim
            .Parameters.Add("@CarDriverBorn1", SqlDbType.DateTime).Value = ISODate.SetISODate("th", txtCarDBorn1.Text.Trim)
            .Parameters.Add("@CarDriver2", SqlDbType.VarChar).Value = txtCarDriver2.Text.Trim
            .Parameters.Add("@CarDriverLname2", SqlDbType.VarChar).Value = txtCarLName2.Text.Trim
            .Parameters.Add("@CarDriverBorn2", SqlDbType.DateTime).Value = ISODate.SetISODate("th", txtCarDBorn2.Text.Trim)
            .Parameters.Add("@DBornNO1", SqlDbType.VarChar).Value = txtCarBornNo1.Text.Trim
            .Parameters.Add("@DBornDate1", SqlDbType.DateTime).Value = ISODate.SetISODate("th", txtCarBornDate1.Text.Trim)
            .Parameters.Add("@DBornAddr1", SqlDbType.VarChar).Value = ddCarBornAddr1.SelectedValue
            .Parameters.Add("@DBornNO2", SqlDbType.VarChar).Value = txtCarBornNo2.Text.Trim
            .Parameters.Add("@DBornDate2", SqlDbType.DateTime).Value = ISODate.SetISODate("th", txtCarBornDate2.Text.Trim)
            .Parameters.Add("@DBornAddr2", SqlDbType.VarChar).Value = ddCarBornAddr2.SelectedValue
            .Parameters.Add("@CarID", SqlDbType.VarChar).Value = txtCarID.Text.Trim
            .Parameters.Add("@CarID1", SqlDbType.VarChar).Value = ddCarID.SelectedValue
            .Parameters.Add("@CarNo", SqlDbType.VarChar).Value = txtCarNo.Text.Trim
            .Parameters.Add("@CarBoxNo", SqlDbType.VarChar).Value = txtCarBoxNo.Text.Trim
            .Parameters.Add("@CarSize", SqlDbType.VarChar).Value = txtCarSize.Text.Trim
            .Parameters.Add("@IDCard1", SqlDbType.VarChar).Value = txtIDCard1.Text.Trim
            .Parameters.Add("@IDCard2", SqlDbType.VarChar).Value = txtIDCard2.Text.Trim
            .Parameters.Add("@CarFixIn", SqlDbType.VarChar).Value = frmPackage.DataKey.Item(22)
            .Parameters.Add("@ProtectDate", SqlDbType.DateTime).Value = ISODate.SetISODate("th", txtProtectDate.Text.Trim)
            .Parameters.Add("@CarYear", SqlDbType.VarChar).Value = ddYears.SelectedValue
            .Parameters.Add("@IdCar", SqlDbType.VarChar).Value = frmCar.DataKey.Item(0)
            .Parameters.Add("@CarColorID", SqlDbType.VarChar).Value = ddColor.SelectedValue
            .ExecuteNonQuery()
        End With

    End Sub

    Protected Sub btnApplication()
        dt = New DataTable
        dt = DataAccess.DataRead(StrQuery.SelectTblApplication(frmCar.DataKey.Item(0)))

        If frmOldInsure.DataItemCount > 0 Then
            SaveApplication(StrQuery.UpdateTblApplication, frmOldInsure.DataKey.Item(0))
        Else
            SaveApplication(StrQuery.InsertTblApplication, "")
            frmOldInsure.DataBind()
        End If
    End Sub
    Protected Sub btnApplicationPA()
       
            Dim chkPA As CheckBox = FunAll.ObjFindControl("chkPA", frmCusName)
            If chkPA.Checked Then
                dt = New DataTable
                dt = DataAccess.DataRead(StrQuery.SelectTblApplicationPa(frmCar.DataKey.Item(0)))
                DeleteTblApplicationPA()
                InsertTblApplicationPA()
            Else
                DeleteTblApplicationPA()
            End If

    End Sub

    Protected Sub SaveApplication(ByVal strqry As String, ByVal AppID As String)

        'Dim ddProID As DropDownList = FunAll.ObjFindControl("ddProType", frmProduct)
        Dim ddFinance As DropDownList = FunAll.ObjFindControl("ddFinance", frmAppRela)
        Dim txtProtectDate As TextBox = FunAll.ObjFindControl("txtProtectDate", frmAppRela)
        Dim txtProtectDateCarpet As TextBox = FunAll.ObjFindControl("txtProtectDateCarpet", frmAppRela)
        'Dim txtProtectDateCarpet As TextBox = FunAll.ObjFindControl("txtProtectDateCarpet", frmAppDateCarPet)

        Dim lblLostLife1 As Label = FunAll.ObjFindControl("lblLostLife1", frmPackage)
        Dim lblLostLife2 As Label = FunAll.ObjFindControl("lblLostLife2", frmPackage)
        Dim lblLostProp1 As Label = FunAll.ObjFindControl("lblLostProp1", frmPackage)
        Dim lblLostProp2 As TextBox = FunAll.ObjFindControl("lblLostProp2", frmPackage)

        Dim lblLostCar1 As Label = FunAll.ObjFindControl("lblLostCar1", frmPackage)
        Dim lblLostCar2 As Label = FunAll.ObjFindControl("lblLostCar2", frmPackage)
        Dim lblCarFire As Label = FunAll.ObjFindControl("lblCarFire", frmPackage)

        Dim lblAccLost1 As Label = FunAll.ObjFindControl("lblAccLost1", frmPackage)
        Dim lblAccLost2 As Label = FunAll.ObjFindControl("lblAccLost2", frmPackage)
        Dim lblAccLost3 As Label = FunAll.ObjFindControl("lblAccLost3", frmPackage)
        Dim lblAccLost4 As Label = FunAll.ObjFindControl("lblAccLost4", frmPackage)
        Dim lblMaintain As Label = FunAll.ObjFindControl("lblMaintain", frmPackage)
        Dim lblInsure As Label = FunAll.ObjFindControl("lblInsure", frmPackage)

        Dim txtProValue As WebNumericEdit = FunAll.ObjFindControl("txtProValue", frmPackage)
        Dim txtnetPremium As WebNumericEdit = FunAll.ObjFindControl("txtnetPremium", frmPackage)

        Dim lblCarPet As Label = FunAll.ObjFindControl("lblCappet", frmPackage)
        Dim lblTotalValue As WebNumericEdit = FunAll.ObjFindControl("txtTotalValue", frmPackage)

        Dim ddDisProfile As DropDownList = FunAll.ObjFindControl("ddDisProfile", frmProType)

        Dim ddOldInsur As DropDownList = FunAll.ObjFindControl("ddOldInsure", frmOldInsure)
        Dim txtOldPolicyNo As TextBox = FunAll.ObjFindControl("txtOldPolicy", frmOldInsure)
        Dim chkSendDoc As CheckBox = FunAll.ObjFindControl("chkSendDoc", frmOldInsure)
        Dim txtComments As TextBox = FunAll.ObjFindControl("txtComments", frmComments)
        Dim txtAppComments As TextBox = FunAll.ObjFindControl("txtAppComments", frmComments)

        Dim chkDoc1 As CheckBox = FunAll.ObjFindControl("chkDoc1", frmDoc)
        Dim chkDoc2 As CheckBox = FunAll.ObjFindControl("chkDoc2", frmDoc)
        Dim chkDoc3 As CheckBox = FunAll.ObjFindControl("chkDoc3", frmDoc)
        Dim chkDoc5 As CheckBox = FunAll.ObjFindControl("chkDoc5", frmDoc)
        Dim txtDoc5Comment As TextBox = FunAll.ObjFindControl("txtDoc5Comment", frmDoc)
        Dim chkProtect As CheckBox = FunAll.ObjFindControl("chkProtect", frmOldInsure)
        ' Dim FlagSendLINE As CheckBox = FunAll.ObjFindControl("chkSend", frmAddr)
        Dim chkCamera As CheckBox = FunAll.ObjFindControl("chkCamera", frmPackage)
        Dim chkDevice As CheckBox = FunAll.ObjFindControl("chkDevice", frmDevice)
        Dim txtDetDevice As TextBox = FunAll.ObjFindControl("txtDetDevice", frmDevice)
        Dim txtPriceDevice As WebNumericEdit = FunAll.ObjFindControl("txtPriceDevice", frmDevice)


        Dim ddCarpet As DropDownList = FunAll.ObjFindControl("ddCarpet", frmProType)

        Dim protectdate As DateTime = ISODate.SetISODate("th", txtProtectDate.Text.Trim)
        Dim ExpProtectDate As DateTime = protectdate.AddYears(1)
        Dim ProtectDateCarpet As DateTime = ISODate.SetISODate("th", txtProtectDateCarpet.Text.Trim)
        Dim ExpProtectDateCarpet As DateTime = ProtectDateCarpet.AddYears(1)

        Dim ddIsProValue As DropDownList = FunAll.ObjFindControl("ddIsProValue", frmProType)

        Dim ddSendCVPV As DropDownList = FunAll.ObjFindControl("ddSendCVPV", FormViewSendCVPV)
        'Dim chkSendCVPV As CheckBox = FunAll.ObjFindControl("chkSendCVPV", FormViewSendCVPV)
        'If chkSendCVPV.Checked = True Then
        '    chkSendCVPV.Checked = False
        'Else
        '    chkSendCVPV.Checked = True
        'End If

        com = New SqlCommand(strqry, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@Idcar", SqlDbType.VarChar).Value = frmCar.DataKey.Item(0)
            .Parameters.Add("@cusid", SqlDbType.VarChar).Value = frmCusName.DataKey.Item(0)
            .Parameters.Add("@ProDuctID", SqlDbType.VarChar).Value = frmProType.DataKey.Item(0)
            .Parameters.Add("@ProDuctIDCarpet", SqlDbType.VarChar).Value = frmProType.DataKey.Item(0)
            .Parameters.Add("@userID", SqlDbType.VarChar).Value = Request.Cookies("userID").Value
            .Parameters.Add("@IsProtect", SqlDbType.VarChar).Value = 1
            .Parameters.Add("@ProtectDate", SqlDbType.DateTime).Value = protectdate
            .Parameters.Add("@ExpProtectDate", SqlDbType.DateTime).Value = ExpProtectDate
            .Parameters.Add("@ProtectDateCarpet", SqlDbType.DateTime).Value = ProtectDateCarpet
            .Parameters.Add("@ExpProtectDateCarpet", SqlDbType.DateTime).Value = ExpProtectDateCarpet
            .Parameters.Add("@Comments", SqlDbType.VarChar).Value = txtComments.Text.Trim
            .Parameters.Add("@ProPrice", SqlDbType.VarChar).Value = lblLostCar1.Text
            .Parameters.Add("@IsProvalue", SqlDbType.VarChar).Value = ddIsProValue.SelectedValue
            .Parameters.Add("@ProValue", SqlDbType.VarChar).Value = lblTotalValue.Text
            .Parameters.Add("@Typeprovalue", SqlDbType.VarChar).Value = frmPackage.DataKey.Item(17)
            .Parameters.Add("@IsCarpet", SqlDbType.VarChar).Value = ddCarpet.SelectedValue
            .Parameters.Add("@CarPet", SqlDbType.VarChar).Value = lblCarPet.Text
            .Parameters.Add("@YearPay", SqlDbType.VarChar).Value = txtProValue.Text.Trim
            .Parameters.Add("@Premium", SqlDbType.VarChar).Value = txtnetPremium.Text.Trim
            .Parameters.Add("@Lost_Life1", SqlDbType.VarChar).Value = lblLostLife1.Text
            .Parameters.Add("@Lost_Life2", SqlDbType.VarChar).Value = lblLostLife2.Text
            .Parameters.Add("@Lost_Prop1", SqlDbType.VarChar).Value = lblLostProp1.Text
            .Parameters.Add("@Lost_Prop2", SqlDbType.VarChar).Value = CInt(lblLostProp2.Text)
            .Parameters.Add("@Lost_Car1", SqlDbType.VarChar).Value = lblLostCar1.Text
            .Parameters.Add("@Lost_Car2", SqlDbType.VarChar).Value = lblLostCar2.Text
            .Parameters.Add("@Car_Fire", SqlDbType.VarChar).Value = lblCarFire.Text
            .Parameters.Add("@Acc_Lost1", SqlDbType.VarChar).Value = CInt(lblAccLost1.Text)
            .Parameters.Add("@Acc_Lost2", SqlDbType.VarChar).Value = lblAccLost2.Text
            .Parameters.Add("@Acc_Lost3", SqlDbType.VarChar).Value = CInt(lblAccLost3.Text)
            .Parameters.Add("@Acc_Lost4", SqlDbType.VarChar).Value = lblAccLost4.Text
            .Parameters.Add("@Maintain", SqlDbType.VarChar).Value = lblMaintain.Text
            .Parameters.Add("@Insure", SqlDbType.VarChar).Value = lblInsure.Text
            .Parameters.Add("@Old_Insu", SqlDbType.VarChar).Value = ddOldInsur.SelectedValue
            .Parameters.Add("@Old_PolicyNO", SqlDbType.VarChar).Value = txtOldPolicyNo.Text.Trim
            .Parameters.Add("@Apprela", SqlDbType.VarChar).Value = ddFinance.SelectedValue
            .Parameters.Add("@AppComment", SqlDbType.VarChar).Value = txtAppComments.Text.Trim
            .Parameters.Add("@CarpetValue", SqlDbType.VarChar).Value = frmPackage.DataKey.Item(18)
            .Parameters.Add("@Carpetvat", SqlDbType.VarChar).Value = frmPackage.DataKey.Item(14)
            .Parameters.Add("@DiscountProfile", SqlDbType.VarChar).Value = ddDisProfile.SelectedValue
            .Parameters.Add("@PkgID", SqlDbType.VarChar).Value = frmPackage.DataKey.Item(23)
            .Parameters.Add("@Doc1", SqlDbType.Int).Value = chkDoc1.Checked
            .Parameters.Add("@Doc2", SqlDbType.Int).Value = chkDoc2.Checked
            .Parameters.Add("@Doc3", SqlDbType.Int).Value = chkDoc3.Checked
            .Parameters.Add("@Doc5", SqlDbType.Int).Value = chkDoc5.Checked
            .Parameters.Add("@protectChk", SqlDbType.Int).Value = chkProtect.Checked
            .Parameters.Add("@Doc5Comment", SqlDbType.VarChar).Value = txtDoc5Comment.Text.Trim
            .Parameters.Add("@DisCountType", SqlDbType.VarChar).Value = GetCarCode()
            .Parameters.Add("@chkDeviceAdd", SqlDbType.Int).Value = chkDevice.Checked
            .Parameters.Add("@detDeviceAdd", SqlDbType.VarChar).Value = txtDetDevice.Text.Trim
            .Parameters.Add("@PriceDeviceAdd", SqlDbType.VarChar).Value = txtPriceDevice.Text.Trim
            .Parameters.Add("@SendDoc", SqlDbType.Int).Value = chkSendDoc.Checked
            .Parameters.Add("@FlagSendLINE", SqlDbType.Int).Value = 0
            .Parameters.Add("@flagsend", SqlDbType.Int).Value = ddSendCVPV.SelectedValue
            .Parameters.Add("@flagDiscCamera", SqlDbType.Int).Value = chkCamera.Checked
            .Parameters.Add("@AppID", SqlDbType.VarChar).Value = AppID
            .ExecuteNonQuery()
        End With

    End Sub
    Protected Function ChkCarModel() As String
        Dim dttmp As DataTable
        dttmp = New DataTable
        dttmp = DataAccess.DataRead("(select  model from TblCarBrand where carno in(select carbrandno from tblcar where idcar='" & Request.QueryString("IdCar").ToString & "'))")
        If dttmp.Rows.Count > 0 Then
            Return dttmp.Rows(0).Item("model")
        Else
            Return "0"
        End If

    End Function
    Protected Function GetCarCode() As Integer
        'Dim ddCarType As DropDownList = DirectCast(frmCar.FindControl("ddSeries"), DropDownList)
        'dt = New DataTable
        'dt = DataAccess.DataRead(StrQryProvince.SelectTblCarBrandType(frmCar.DataKey.Item(1), ChkCarModel()))
        'If dt.Rows.Count > 0 Then
        '    Return dt.Rows(0).Item("CodeType")
        'Else
        '    Return 0
        'End If
        Dim Label8 As Label = DirectCast(frmCar.FindControl("Label8"), Label)
        If Label8.Text <> "" Then
            Return Label8.Text
        Else
            Return 0
        End If

    End Function
#End Region

    Protected Sub Button14_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button14.Click
        If ChkMaxPay() = True And chkPayPL(1) = True Then
            CalPay()
        End If
    End Sub


#Region "AppPay"

    'งวดชำระเพิ่มสำหรับ PL,PM
    Protected Function chkPayPL(Typebtn As Integer) As Boolean
        If ChkUser() = True Then
            Return True
        ElseIf ChkUserRenew() = True Then
            Return True
        Else
            Dim dateCreate As Date
            If frmCar.DataKey.Item(4) = 3 Or frmCar.DataKey.Item(4) = 4 Then
                If frmAppRela.DataItemCount > 0 Then
                    dateCreate = frmAppRela.DataKey.Item(1)
                    'dateCreate = ISODate.SetISODate("th", dateCreate.ToString("dd/MM/yyyy"))
                Else
                    dateCreate = DateTime.Today
                End If


            Else
                dateCreate = DateTime.Today
            End If

            Dim PayID As Integer
            If Typebtn = 1 Then
                PayID = ddPay.SelectedValue
                ViewState("btnPL") = True 'chk ว่า PL ได้กดคำนวนงวดหรือไม่่
            Else
                PayID = GvPay.Rows.Count

            End If

            Dim txtProtectDate As TextBox = FunAll.ObjFindControl("txtProtectDate", frmAppRela)
            Dim dateProtect As DateTime = ISODate.SetISODate("th", txtProtectDate.Text.Trim)
            Dim TypeID As Integer = frmPackage.DataKey.Item(17)

            Dim dateMax As Integer = DateDiff(DateInterval.Day, dateCreate, dateProtect)

            If Request.Cookies("UserLevel").Value = 1 Or Request.Cookies("UserLevel").Value = 2 And ViewState("btnPL") IsNot Nothing Then
                If PayID = 3 And dateMax < 30 Then 'เลือก 3 งวด วันคุ้มครองน้อย 30
                    Return True
                ElseIf PayID = 4 And dateMax >= 30 And dateMax < 60 Then 'เลือก 4 งวด วันคุ้มครองน้อย 30- 59
                    Return True
                ElseIf PayID = 5 And dateMax >= 60 And dateMax < 90 Then 'เลือก 5 งวด วันคุ้มครองน้อย 60-89
                    Return True
                ElseIf PayID = 6 And dateMax >= 90 Then 'เลือก 5 งวด วันคุ้มครองน้อย 90 ขึ้นไป
                    Return True
                Else
                    ScriptManager.RegisterClientScriptBlock(upAppPay, GetType(UpdatePanel), upAppPay.ClientID, "alert('งวดที่ชำระไม่ตรงตามเงื่อนไข วันคุ้มครอง " & dateMax & " วัน')", True)
                    Return False
                End If
            Else
                Return True
            End If

        End If


    End Function

    'คำนวนงวดชำระ
    Protected Function ChkMaxPay() As Boolean

        'Request.Cookies("TypeTsr").Value=1,11,15
        'ประกันชั้น1
        '>=60 
        If chkPay.Checked = True Then
            Dim ProTypeIDID As Integer = frmPackage.DataKey.Item(16)

            '
            Dim txtProtectDate_Chk As TextBox = FunAll.ObjFindControl("txtProtectDate", frmAppRela)
            Dim dateProtect_Chk As DateTime = ISODate.SetISODate("th", txtProtectDate_Chk.Text.Trim)

            Dim lblTypeID As Label = FunAll.ObjFindControl("lblTypeID", frmProType)
            Dim typeID As Int16 = lblTypeID.Text
            Dim dateCreate_Chk As DateTime

            If frmAppRela.DataItemCount > 0 Then
                dateCreate_Chk = frmAppRela.DataKey.Item(1)

            Else
                dateCreate_Chk = DateTime.Today
            End If

            Dim nDate As Integer = DateDiff(DateInterval.Day, dateCreate_Chk.Date, dateProtect_Chk)
            '
            If nDate > 59 And (typeID = 1) And (Request.Cookies("TypeTsr").Value = 1 Or Request.Cookies("TypeTsr").Value = 11 Or Request.Cookies("TypeTsr").Value = 15) Then
                chkPay.Checked = True
            Else
                If nDate < 60 Then
                    ScriptManager.RegisterClientScriptBlock(upAppPay, GetType(UpdatePanel), upAppPay.ClientID, "alert('กรุณาตรวจสอบเงื่อนไขไม่ถูกต้องจำนวนวัน<60')", True)
                ElseIf (typeID <> 1) Then
                    ScriptManager.RegisterClientScriptBlock(upAppPay, GetType(UpdatePanel), upAppPay.ClientID, "alert('กรุณาตรวจสอบเงื่อนไขไม่ถูกต้อง<>ป.1')", True)
                ElseIf (Request.Cookies("TypeTsr").Value <> 1 And Request.Cookies("TypeTsr").Value <> 11 And Request.Cookies("TypeTsr").Value <> 15) Then
                    ScriptManager.RegisterClientScriptBlock(upAppPay, GetType(UpdatePanel), upAppPay.ClientID, "alert('กรุณาตรวจสอบเงื่อนไขไม่ถูกต้อง TypeTsr')", True)

                End If
                chkPay.Checked = False
                Return False
                Exit Function
            End If
        End If

        If ChkUser() = True Then
            Return True
        ElseIf ChkUserRenew() = True Then
            Return True
        ElseIf ChkUserQC() = True Then
            Return True
        ElseIf chkPay1.Checked Then
            Dim txtProtectDate As TextBox = FunAll.ObjFindControl("txtProtectDate", frmAppRela)
            Dim dateProtect1 As DateTime = ISODate.SetISODate("th", txtProtectDate.Text.Trim)

            Dim dateCreate As DateTime
            If frmCar.DataKey.Item(4) = 3 Or frmCar.DataKey.Item(4) = 4 Then
                If frmAppRela.DataItemCount > 0 Then
                    dateCreate = frmAppRela.DataKey.Item(1)
                Else
                    dateCreate = DateTime.Today
                End If


            Else
                dateCreate = DateTime.Today
            End If
            If DateDiff(DateInterval.Day, dateCreate.Date, dateProtect1) < 31 Then

                Return True
            Else
                ScriptManager.RegisterClientScriptBlock(upAppPay, GetType(UpdatePanel), upAppPay.ClientID, "alert('วันคุ้มครอง >30 วัน (" & DateDiff(DateInterval.Day, dateCreate.Date, dateProtect1) & ")')", True)
                Return False
            End If


        Else

            Dim txtProtectDate As TextBox = FunAll.ObjFindControl("txtProtectDate", frmAppRela)

            Dim ProTypeID As Integer = frmPackage.DataKey.Item(16)
            Dim TypeID As Integer = frmPackage.DataKey.Item(17)
            Dim dateCreate As DateTime
            If frmCar.DataKey.Item(4) = 3 Or frmCar.DataKey.Item(4) = 4 Then
                If frmAppRela.DataItemCount > 0 Then
                    dateCreate = frmAppRela.DataKey.Item(1)
                Else
                    dateCreate = DateTime.Today
                End If


            Else
                dateCreate = DateTime.Today
            End If


            Dim dateProtect As DateTime = ISODate.SetISODate("th", txtProtectDate.Text.Trim)
            Dim MaxPay As Integer = 4
            If TypeID = 1 Then
                'ชั้น 1
                Dim nDayProtect As Integer = DateDiff(DateInterval.Day, dateCreate.Date, dateProtect)
                'Dim MaxPay As Integer = 4
                If (nDayProtect) < 31 Then
                    If ddTypePay.SelectedValue = 1 Then 'เงินสด
                        MaxPay = 2
                    Else
                        MaxPay = 3
                    End If
                ElseIf (nDayProtect) < 61 Then

                    If ddTypePay.SelectedValue = 1 Then 'เงินสด
                        MaxPay = 3
                    Else
                        MaxPay = 4
                    End If
                ElseIf (nDayProtect) > 60 Then

                    If ddTypePay.SelectedValue = 1 Then 'เงินสด
                        MaxPay = 4
                    Else
                        MaxPay = 5
                    End If

                End If
            Else

                'Add By na TM4(5) Add 1 งวด
                If Request.Cookies("TypeTsr").Value = 17 Then
                    MaxPay = 5
                End If


                If Request.Cookies("TypeTsr").Value = 3 Or Request.Cookies("TypeTsr").Value = 11 Then
                    If TypeID = 1 Then
                        MaxPay = 4
                    Else
                        MaxPay = 3
                    End If
                ElseIf Request.Cookies("TypeTsr").Value = 6 Then
                    If ddTypePay.SelectedValue = 2 Then
                        MaxPay = 6
                    Else : ddTypePay.SelectedValue = 1
                        MaxPay = 4
                    End If
                ElseIf Request.Cookies("UserLevel").Value = 2 Or Request.Cookies("UserLevel").Value = 1 Then
                    MaxPay = 6

                Else
                    If TypeID = 3 Or TypeID = 4 And ProTypeID <> 15 Then
                        MaxPay = 3
                        'Add By na TM4(5) Add 1 งวด
                        If Request.Cookies("TypeTsr").Value = 17 Then
                            MaxPay = 4
                        End If
                    ElseIf TypeID = 4 And ProTypeID = 15 Then
                        If DateDiff(DateInterval.Day, dateCreate.Date, dateProtect) < 45 Then
                            MaxPay = 3
                        Else
                            MaxPay = 3
                        End If
                        'Add By na TM4(5) Add 1 งวด
                        If Request.Cookies("TypeTsr").Value = 17 Then
                            MaxPay = 4
                        End If

                    ElseIf TypeID = 1 Then
                        If DateDiff(DateInterval.Day, dateCreate.Date, dateProtect) <= 30 Then
                            Dim itest As Integer = DateDiff(DateInterval.Day, dateCreate.Date, dateProtect)
                            MaxPay = 2
                            'Add By na TM4(5) Add 1 งวด
                            If Request.Cookies("TypeTsr").Value = 17 Then
                                MaxPay = 3
                            End If
                        ElseIf DateDiff(DateInterval.Day, dateCreate.Date, dateProtect) > 30 And DateDiff(DateInterval.Day, dateCreate.Date, dateProtect) <= 60 Then
                            MaxPay = 3
                            'Add By na TM4(5) Add 1 งวด
                            If Request.Cookies("TypeTsr").Value = 17 Then
                                MaxPay = 4
                            End If
                        ElseIf DateDiff(DateInterval.Day, dateCreate.Date, dateProtect) > 60 Then
                            MaxPay = 4
                            'Add By na TM4(5) Add 1 งวด
                            If Request.Cookies("TypeTsr").Value = 17 Then
                                MaxPay = 5
                            End If
                        End If
                    End If

                End If
            End If






            Dim dateMax As Integer = DateDiff(DateInterval.Month, dateProtect, dateCreate.AddMonths(ddPay.SelectedValue - 1))

            If ddPay.SelectedValue > MaxPay Then
                ScriptManager.RegisterClientScriptBlock(upAppPay, GetType(UpdatePanel), upAppPay.ClientID, "alert('งวดการชำเงินไม่ตรงตามเงื่อนไข: การชำระสูงสุดคือ " & MaxPay & " งวด')", True)

                Return False
            Else

                If ddPay.SelectedValue < 4 And chkPay.Checked = True Then
                    ScriptManager.RegisterClientScriptBlock(upAppPay, GetType(UpdatePanel), upAppPay.ClientID, "alert('งวดการชำระต่ำกว่า 4 งวด:ไม่สามารถกำหนดงวดแรก 3000 ได้')", True)
                    Return False
                ElseIf (Request.Cookies("UserLevel").Value = 1 Or Request.Cookies("UserLevel").Value = 2) And chkPay.Checked = True Then
                    ScriptManager.RegisterClientScriptBlock(upAppPay, GetType(UpdatePanel), upAppPay.ClientID, "alert('ไม่มีสิทธิ์กำหนดงวดแรก 3000')", True)

                    Return False
                ElseIf ddPay.SelectedValue > 4 And ddTypePay.SelectedValue = 1 Then
                    ScriptManager.RegisterClientScriptBlock(upAppPay, GetType(UpdatePanel), upAppPay.ClientID, "alert('งวดแรกจะต้องเป็น credit Card')", True)
                    Return False
                ElseIf (chkCredit.Checked = False Or ddTypePay.SelectedValue = 1) And (Request.Cookies("UserLevel").Value = 1 Or Request.Cookies("UserLevel").Value = 2) Then
                    ScriptManager.RegisterClientScriptBlock(upAppPay, GetType(UpdatePanel), upAppPay.ClientID, "alert('เพิ่มงวดจะต้องเป็น credit ทุกงวด')", True)
                    Return False

                Else
                    Return True
                End If
            End If
            End If


            'If MaxPay < 2 Then
            '    Dim chkFirstPay As CheckBox = FunAll.ObjFindControl("chkPay", frmAppPay)
            '    chkFirstPay.Enabled = False
            'End If
    End Function

    Protected Function CreateDtPay() As DataTable
        Dim dtPay As New DataTable
        Dim dtPayCl As New DataColumn
        dtPay.Columns.Add("PayNum", Type.GetType("System.Int32"))
        dtPay.Columns.Add("AppointDate", Type.GetType("System.DateTime"))
        dtPay.Columns.Add("ProValue", Type.GetType("System.Int32"))
        dtPay.Columns.Add("ProVat", Type.GetType("System.Int32"))
        dtPay.Columns.Add("TotalPay", Type.GetType("System.Int32"))
        dtPay.Columns.Add("Typepay")
        dtPay.Columns.Add("TypeName")
        Return dtPay
    End Function

    'คำนวนการแบ่งจ่ายเงิน
    Protected Sub CalPay()
        dt = New DataTable
        dt = CreateDtPay()

        Dim dateMonthAdd As DateTime
        Dim ProTypeID As Integer = frmPackage.DataKey.Item(16)
        Dim TypeID As Integer = frmPackage.DataKey.Item(17)
        Dim dateCreate As DateTime
        Dim txtProtectDate As TextBox = FunAll.ObjFindControl("txtProtectDate", frmAppRela)
        If frmCar.DataKey.Item(4) = 3 Or frmCar.DataKey.Item(4) = 4 Then
            If frmOldInsure.DataItemCount > 0 Then
                dateCreate = frmOldInsure.DataKey.Item(1)
            Else
                dateCreate = DateTime.Today
            End If


        Else
            dateCreate = DateTime.Today
        End If

        Dim dateProtect As DateTime = ISODate.SetISODate("th", txtProtectDate.Text.Trim)

        Dim dr As DataRow
        Dim DateAppoint As DateTime = DateTime.Today.AddDays(7)
        Dim i As Integer
        'If chkPay1.Checked Then
        '    ddPay.SelectedValue = 4
        'End If

        For i = 0 To ddPay.SelectedValue - 1
            dr = dt.NewRow
            dr("PayNum") = i + 1

            If DateDiff(DateInterval.Day, dateCreate, dateProtect) >= 61 And TypeID = 1 Then 'วันสมัครห่างจากวันคุ้มครอง มากกว่า 60 วันและเป็นชั้น1
                'งวด 1

                If i = 0 Then
                    If ddTypePay.SelectedValue = 1 Then
                        dr("AppointDate") = dateCreate.AddDays(7).ToString("dd/MM/yyyy")
                        If ddPay.SelectedValue > 3 Then
                            DateAppoint = dateCreate.AddDays(7).ToString("dd/MM/yyyy")
                        Else
                            DateAppoint = dateProtect.AddMonths(-2)
                        End If

                    Else
                        If Request.Cookies("TypeTsr").Value = 3 Or Request.Cookies("TypeTsr").Value = 6 Or Request.Cookies("TypeTsr").Value = 11 Then
                            Dim chdFristPay As CheckBox = FunAll.ObjFindControl("chdFristPay", frmAppCard)
                            Dim txtFristPay As TextBox = FunAll.ObjFindControl("txtFristPay", frmAppCard)
                            If chdFristPay.Checked = True And txtFristPay.Text.Trim <> "" Then
                                dr("AppointDate") = ISODate.SetISODate("th", txtFristPay.Text.Trim)
                                DateAppoint = ISODate.SetISODate("th", txtFristPay.Text.Trim)
                            Else
                                dr("AppointDate") = dateCreate.ToString("dd/MM/yyyy")
                                DateAppoint = dateProtect.AddMonths(-2)
                            End If

                        Else
                            dr("AppointDate") = dateCreate.ToString("dd/MM/yyyy")
                            If ddPay.SelectedValue > 4 Then
                                DateAppoint = dateCreate
                            ElseIf ddPay.SelectedValue <= 4 And (Request.Cookies("UserLevel").Value = 2 Or Request.Cookies("UserLevel").Value = 1) Then
                                DateAppoint = dateCreate
                            Else
                                DateAppoint = dateProtect.AddMonths(-2)
                            End If

                        End If

                    End If

                Else 'งวดต่อไป

                    dr("AppointDate") = DateAppoint.AddMonths(i).ToString("dd/MM/yyyy")

                End If



            Else
                If i = 0 Then 'งวดแรก
                    If DateDiff(DateInterval.Day, dateCreate, dateProtect) < 7 Then ' วันสมัครห่างจากวันคุ้มครอง < 7 วัน
                        dr("AppointDate") = dateCreate.ToString("dd/MM/yyyy")
                        dateMonthAdd = dateCreate
                        Dim chdFristPay As CheckBox = FunAll.ObjFindControl("chdFristPay", frmAppCard)
                        Dim txtFristPay As TextBox = FunAll.ObjFindControl("txtFristPay", frmAppCard)
                        If chdFristPay.Checked = True And txtFristPay.Text.Trim <> "" Then
                            dr("AppointDate") = ISODate.SetISODate("th", txtFristPay.Text.Trim)
                            dateMonthAdd = ISODate.SetISODate("th", txtFristPay.Text.Trim)
                        End If

                    Else
                        If ddTypePay.SelectedValue = 1 Then
                            dr("AppointDate") = dateCreate.AddDays(7).ToString("dd/MM/yyyy")
                            dateMonthAdd = dateCreate.AddDays(7)
                        Else
                            If Request.Cookies("TypeTsr").Value = 3 Or Request.Cookies("TypeTsr").Value = 6 Or Request.Cookies("TypeTsr").Value = 11 Then
                                Dim chdFristPay As CheckBox = FunAll.ObjFindControl("chdFristPay", frmAppCard)
                                Dim txtFristPay As TextBox = FunAll.ObjFindControl("txtFristPay", frmAppCard)
                                If chdFristPay.Checked = True And txtFristPay.Text.Trim <> "" Then
                                    dr("AppointDate") = ISODate.SetISODate("th", txtFristPay.Text.Trim)
                                    dateMonthAdd = ISODate.SetISODate("th", txtFristPay.Text.Trim)
                                Else
                                    dr("AppointDate") = dateCreate.ToString("dd/MM/yyyy")
                                    dateMonthAdd = dateCreate
                                End If
                            Else
                                dr("AppointDate") = dateCreate.ToString("dd/MM/yyyy")
                                dateMonthAdd = dateCreate
                            End If

                        End If

                    End If
                Else
                    If i = 2 Then
                        'If ProTypeID = 15 Then
                        '    dr("AppointDate") = dateProtect.AddMonths(-7).ToString("dd/MM/yyyy") 'งวด 3  น้องกว่า วันคุ้มครอง 7 วัน
                        '    dateMonthAdd = dateProtect.AddMonths(-7)
                        'Else
                        dr("AppointDate") = dateMonthAdd.AddMonths(i).ToString("dd/MM/yyyy")
                        'End If


                    Else
                        dr("AppointDate") = dateMonthAdd.AddMonths(i).ToString("dd/MM/yyyy")
                    End If
                End If



            End If

            dr("ProValue") = CalProValu(i)
            If ddTypePay.SelectedValue = 2 And i = 0 Then
                dr("ProVat") = 0
                dr("TotalPay") = CalProValu(i)

            Else
                If Request.Cookies("TypeTsr").Value = 3 And chkCredit.Checked = True And ddTypePay.SelectedValue = 2 Then
                    dr("ProVat") = 0
                    dr("TotalPay") = CalProValu(i)
                ElseIf Request.Cookies("TypeTsr").Value = 11 And chkCredit.Checked = True And ddTypePay.SelectedValue = 2 Then
                    dr("ProVat") = 0
                    dr("TotalPay") = CalProValu(i)
                ElseIf Request.Cookies("TypeTsr").Value = 6 And chkCredit.Checked = True And ddTypePay.SelectedValue = 2 Then
                    dr("ProVat") = 0
                    dr("TotalPay") = CalProValu(i)
                ElseIf Request.Cookies("TypeTsr").Value = 1 And chkCredit.Checked = True And ddTypePay.SelectedValue = 2 Then
                    dr("ProVat") = 0
                    dr("TotalPay") = CalProValu(i)
                ElseIf Request.Cookies("TypeTsr").Value = 15 And chkCredit.Checked = True And ddTypePay.SelectedValue = 2 Then
                    dr("ProVat") = 0
                    dr("TotalPay") = CalProValu(i)
                ElseIf Request.Cookies("TypeTsr").Value = 12 And chkCredit.Checked = True And ddTypePay.SelectedValue = 2 Then
                    dr("ProVat") = 0
                    dr("TotalPay") = CalProValu(i)
                ElseIf Request.Cookies("UserLevel").Value = 2 And chkCredit.Checked = True And ddTypePay.SelectedValue = 2 Then
                    dr("ProVat") = 0
                    dr("TotalPay") = CalProValu(i)
                ElseIf Request.Cookies("UserLevel").Value = 1 And chkCredit.Checked = True And ddTypePay.SelectedValue = 2 Then
                    dr("ProVat") = 0
                    dr("TotalPay") = CalProValu(i)
                ElseIf ChkUserQC() And chkCredit.Checked = True And ddTypePay.SelectedValue = 2 Then
                    dr("ProVat") = 0
                    dr("TotalPay") = CalProValu(i)
                Else
                    dr("ProVat") = 0
                    dr("TotalPay") = CalProValu(i)
                End If

            End If

            dr("Typepay") = GetPayType(i).Item(0)
            dr("TypeName") = GetPayType(i).Item(1)
            dt.Rows.Add(dr)

            GvPay.DataSource = dt
            GvPay.DataBind()
        Next

    End Sub

    Protected Function CalProValu(ByVal i As Integer) As Integer
        Dim lblCarPet As Label = FunAll.ObjFindControl("lblCappet", frmPackage)
        Dim lblTotalValue As WebNumericEdit = FunAll.ObjFindControl("txtTotalValue", frmPackage)
        Dim ProValue As Integer = CInt(lblCarPet.Text) + CInt(lblTotalValue.Text)
        Dim ProPay As Integer = CInt(lblCarPet.Text) + CInt(lblTotalValue.Text)


        If i = 0 Then

            If chkPay.Checked = True Then
                If ddPay.SelectedValue <> 1 Then
                    Return 3000
                End If
            ElseIf chkPay1.Checked = True Then

                If ddPay.SelectedValue <> 1 Then
                    fpay = chkPay1lbl.Text * ProValue / 100
                    Return fpay
                End If
            Else
                ProValue = ProValue / ddPay.SelectedValue
            End If
        Else
            If chkPay.Checked = True Then
                ProValue = (ProValue - 3000) / (ddPay.SelectedValue - 1)
            ElseIf chkPay1.Checked = True Then
                ProValue = (ProValue - fpay) / (ddPay.SelectedValue - 1)
            Else
                ProValue = ProValue / ddPay.SelectedValue
            End If
        End If


        If i = 0 Then
            If ProValue * ddPay.SelectedValue < ProPay Then
                ProPay = ProPay - (ProValue * ddPay.SelectedValue)
                ProValue = ProValue + ProPay
            End If

        End If
        Return ProValue
    End Function

    Protected Sub BindGvPay()
        dt = New DataTable
        dt = DataAccess.DataRead(Replace(SqlAppPay.SelectCommand, "@AppID", frmOldInsure.DataKey.Item(0)))
        GvPay.DataSource = dt
        GvPay.DataBind()

        If Not IsPostBack Then
            ViewState("PayNo") = dt.Rows.Count
        End If
    End Sub

    Protected Sub SaveTblAppPay()
        dt = New DataTable
        dt = DataAccess.DataRead("select * from Tblpayment Where AppID=" & frmOldInsure.DataKey.Item(0))
        If dt.Rows.Count = 0 Then
            DeleteAppPay()
            InsertTblAppPay()
        End If

    End Sub

    Protected Sub DeleteAppPay()
        With SqlAppPay
            .DeleteParameters("AppID").DefaultValue = frmOldInsure.DataKey.Item(0)
            .Delete()
        End With
    End Sub

    Protected Sub InsertTblAppPay()

        Dim i As Integer
        For i = 0 To GvPay.Rows.Count - 1
            Dim txtAppoint As TextBox = FunAll.ObjFindControl("txtAppoint", GvPay.Rows(i))
            With SqlAppPay
                .InsertParameters("PayID").DefaultValue = i + 1
                .InsertParameters("AppID").DefaultValue = frmOldInsure.DataKey.Item(0)
                .InsertParameters("TotalPay").DefaultValue = CInt(DirectCast(GvPay.Rows(i).Cells(4).FindControl("lblTotalPay"), Label).Text.Trim)
                .InsertParameters("AppointDate").DefaultValue = ISODate.SetISODate("en", txtAppoint.Text.Trim)
                .InsertParameters("Typepay").DefaultValue = GvPay.DataKeys(i).Item(0)
                .Insert()
            End With
        Next
    End Sub

    Protected Function GetPayType(ByVal i As Integer) As ArrayList
        Dim ar As New ArrayList
        If Request.Cookies("TypeTsr").Value = 3 Or Request.Cookies("TypeTsr").Value = 6 Or Request.Cookies("UserLevel").Value = 1 Or Request.Cookies("UserLevel").Value = 2 Or Request.Cookies("TypeTsr").Value = 11 Or Request.Cookies("TypeTsr").Value = 1 Or Request.Cookies("TypeTsr").Value = 12 Or Request.Cookies("TypeTsr").Value = 15 Or ChkUserQC() Then
            If ddTypePay.SelectedValue = 2 And i = 0 Then
                ar.Add(2)
                ar.Add("Credit")
            ElseIf ddTypePay.SelectedValue = 2 And chkCredit.Checked = True Then
                ar.Add(2)
                ar.Add("Credit")
            Else
                ar.Add(1)
                ar.Add("Payment")
            End If
        Else
            If ddTypePay.SelectedValue = 2 And i = 0 Then
                ar.Add(2)
                ar.Add("Credit")
            Else
                ar.Add(1)
                ar.Add("Payment")
            End If
        End If
        Return ar
    End Function

    'LogAppPay
    Protected Sub InsertTblLogAppPay()
        With SqlAppCard
            .InsertParameters("AppID").DefaultValue = frmOldInsure.DataKey.Item(0)
            .InsertParameters("PayNo1").DefaultValue = ViewState("PayNo")
            .InsertParameters("PayNo2").DefaultValue = GvPay.Rows.Count
            .Insert()
        End With
    End Sub
#End Region


#Region "AppCard"
    Protected Sub Button8_Click1(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim txtCardName As TextBox = FunAll.ObjFindControl("txtCardName", frmAppCard)
        Dim txtFNameTH As TextBox = FunAll.ObjFindControl("txtFNameTH", frmCusName)
        Dim txtLNameTH As TextBox = FunAll.ObjFindControl("txtLNameTH", frmCusName)
        txtCardName.Text = txtFNameTH.Text.Trim & " " & txtLNameTH.Text.Trim
    End Sub

    Protected Sub btnSaveCard_Click1(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            'ตรวจสอบแก้งาน qc
            If CheckApp() = True And chkCreditcard() = True Then

                If frmOldInsure.DataItemCount > 0 Then
                    If ChkMaxPay() = True Then
                        CalPay()
                    End If
                    CheckConnectionState()
                    InsertTblAppCard2(QueryCredit.UpdateAppCard, frmAppCard.DataKey.Item(0))
                    With SqlAppCard2
                        .SelectParameters("AppID").DefaultValue = frmOldInsure.DataKey.Item(0)
                    End With
                    With SqlAppCard
                        .SelectParameters("AppCardId").DefaultValue = 0
                    End With
                    GvAppCard.DataSource = SqlAppCard2
                    GvAppCard.DataBind()



                Else

                    If ChkMaxPay() = True Then
                        CalPay()
                    End If
                    EditAppCardTMP()
                    frmAppCard.DataSource = SqlAppCard
                    frmAppCard.DataBind()



                End If

            End If
        Catch ex As Exception
            ScriptManager.RegisterClientScriptBlock(UpdatePanel7, GetType(UpdatePanel), UpdatePanel7.ClientID, "alert('ไม่สามารถบันทึกได้')", True)


        End Try



    End Sub

    Protected Function chkCreditcard() As Boolean
        Dim txtCardID As TextBox = FunAll.ObjFindControl("txtCardID", frmAppCard)
        If txtCardID.Text.Trim = "" Then
            ScriptManager.RegisterClientScriptBlock(UpdatePanel7, GetType(UpdatePanel), UpdatePanel7.ClientID, "alert('กรุณากรอกหมายเลขบัตร')", True)
            Return False
        ElseIf txtCardID.Text.Trim = "0000000000000000" Then
            ScriptManager.RegisterClientScriptBlock(UpdatePanel7, GetType(UpdatePanel), UpdatePanel7.ClientID, "alert('เลขบัตรไม่ถูกต้อง')", True)
            Return False
        Else
            Return True
        End If

    End Function

    Protected Sub EditAppCardTMP()

        Dim ddTypeCard As DropDownList = FunAll.ObjFindControl("ddTypeCard", frmAppCard)
        Dim ddBank As DropDownList = FunAll.ObjFindControl("ddBank", frmAppCard)
        Dim ddNum As DropDownList = FunAll.ObjFindControl("ddNum", frmAppCard)

        Dim txtCardID As TextBox = FunAll.ObjFindControl("txtCardID", frmAppCard)
        Dim txtCardID3 As TextBox = FunAll.ObjFindControl("txtCardID3", frmAppCard)
        Dim txtExpCard As TextBox = FunAll.ObjFindControl("txtExpCard", frmAppCard)
        Dim txtExpCard2 As TextBox = FunAll.ObjFindControl("txtExpCard2", frmAppCard)
        Dim txtTel As TextBox = FunAll.ObjFindControl("txtTel", frmAppCard)
        Dim txtMobile As TextBox = FunAll.ObjFindControl("txtMobile", frmAppCard)
        Dim txtFristPay As TextBox = FunAll.ObjFindControl("txtFristPay", frmAppCard)
        Dim txtCommentCard As TextBox = FunAll.ObjFindControl("txtCommentCard", frmAppCard)
        Dim txtCardName As TextBox = FunAll.ObjFindControl("txtCardName", frmAppCard)

        dt = New DataTable
        dt = ViewState("AppCard")
        dt.Rows(frmAppCard.PageIndex).Item("Cardname") = txtCardName.Text.Trim
        dt.Rows(frmAppCard.PageIndex).Item("Cardno1") = txtCardID.Text.Trim
        dt.Rows(frmAppCard.PageIndex).Item("PayTypeId") = 1
        dt.Rows(frmAppCard.PageIndex).Item("CardNo2") = txtCardID3.Text.Trim
        dt.Rows(frmAppCard.PageIndex).Item("CardExp") = txtExpCard.Text.Trim
        dt.Rows(frmAppCard.PageIndex).Item("Cardid") = ddTypeCard.SelectedValue
        dt.Rows(frmAppCard.PageIndex).Item("Bankid") = ddBank.SelectedValue
        dt.Rows(frmAppCard.PageIndex).Item("Tel1") = txtTel.Text.Trim
        dt.Rows(frmAppCard.PageIndex).Item("Mobile") = txtMobile.Text.Trim
        dt.Rows(frmAppCard.PageIndex).Item("IsPayDate") = GetFirstPay()
        dt.Rows(frmAppCard.PageIndex).Item("PayDate") = ISODate.SetISODate("th", txtFristPay.Text.Trim)
        dt.Rows(frmAppCard.PageIndex).Item("BankName") = ddBank.SelectedItem.Text

        ViewState("AppCard") = dt
        GvAppCard.DataSource = dt
        GvAppCard.DataBind()
    End Sub

    Protected Sub btnInsertTblAppCard()
        If frmDoc.DataItemCount = 0 Then

            InsertTblAppCard()
        End If
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        If frmOldInsure.DataItemCount > 0 Then
            With SqlAppCard
                .SelectParameters("AppCardId").DefaultValue = 0
            End With

            frmAppCard.DataBind()
        Else
            frmAppCard.DataSource = SqlAppCard
            frmAppCard.DataBind()
        End If

    End Sub

    Protected Sub btnSaveCard_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            If chkCreditcard() = True Then
                If frmOldInsure.DataItemCount > 0 Then
                    'กรณีมี App
                    CheckConnectionState()
                    InsertTblAppCard2(QueryCredit.InsertAppCard, "")
                    With SqlAppCard2
                        .SelectParameters("AppID").DefaultValue = frmOldInsure.DataKey.Item(0)
                    End With
                    GvAppCard.DataSource = SqlAppCard2
                    GvAppCard.DataBind()

                    If ChkMaxPay() = True Then
                        CalPay()
                    End If
                Else
                    'กรณี ไม่มี App

                    If ViewState("AppCard") Is Nothing Then
                        CreateDtAppCard()
                        ViewState("AppCard") = dt
                    Else
                        dt = New DataTable
                        dt = ViewState("AppCard")

                    End If

                    InsertTmpAppCard()
                    GvAppCard.DataSource = dt
                    GvAppCard.DataBind()

                    If ChkMaxPay() = True Then
                        CalPay()
                    End If
                End If

            End If



        Catch ex As Exception
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "jsCall", "alert('ไม่สามารถบันทึกได้ : " & ex.Message & "')", True)
        End Try

    End Sub

    Protected Sub CreateDtAppCard()
        dt = New DataTable
        dt.Columns.Add("AppCardID")
        dt.Columns.Add("Cardname")
        dt.Columns.Add("Cardno1")
        dt.Columns.Add("PayTypeId")
        dt.Columns.Add("CardNo2")
        dt.Columns.Add("CardExp")
        dt.Columns.Add("Cardid")
        dt.Columns.Add("Bankid")
        dt.Columns.Add("Tel1")
        dt.Columns.Add("Mobile")
        dt.Columns.Add("IsPayDate")
        dt.Columns.Add("PayDate", Type.GetType("System.DateTime"))
        dt.Columns.Add("BankName")
        dt.Columns.Add("StatusEdit")

    End Sub

    Protected Sub InsertTmpAppCard()
        Dim dr As DataRow
        dr = dt.NewRow


        Dim ddTypeCard As DropDownList = FunAll.ObjFindControl("ddTypeCard", frmAppCard)
        Dim ddBank As DropDownList = FunAll.ObjFindControl("ddBank", frmAppCard)
        Dim ddNum As DropDownList = FunAll.ObjFindControl("ddNum", frmAppCard)

        Dim txtCardID As TextBox = FunAll.ObjFindControl("txtCardID", frmAppCard)
        Dim txtCardID3 As TextBox = FunAll.ObjFindControl("txtCardID3", frmAppCard)
        Dim txtExpCard As TextBox = FunAll.ObjFindControl("txtExpCard", frmAppCard)

        Dim txtTel As TextBox = FunAll.ObjFindControl("txtTel", frmAppCard)
        Dim txtMobile As TextBox = FunAll.ObjFindControl("txtMobile", frmAppCard)
        Dim txtFristPay As TextBox = FunAll.ObjFindControl("txtFristPay", frmAppCard)
        Dim txtCommentCard As TextBox = FunAll.ObjFindControl("txtCommentCard", frmAppCard)
        Dim txtCardName As TextBox = FunAll.ObjFindControl("txtCardName", frmAppCard)

        Dim paydate As Date = ISODate.SetISODate("th", txtFristPay.Text.Trim)

        dr("AppCardID") = 0
        dr("Cardname") = txtCardName.Text.Trim
        dr("Cardno1") = txtCardID.Text.Trim
        dr("PayTypeId") = 1
        dr("CardNo2") = txtCardID3.Text.Trim
        dr("CardExp") = txtExpCard.Text.Trim
        dr("Cardid") = ddTypeCard.SelectedValue
        dr("Bankid") = ddBank.SelectedValue
        dr("Tel1") = txtTel.Text.Trim
        dr("Mobile") = txtMobile.Text.Trim
        dr("IsPayDate") = GetFirstPay()
        dr("PayDate") = paydate
        dr("BankName") = ddBank.SelectedItem.Text
        dr("StatusEdit") = "True"
        dt.Rows.Add(dr)

    End Sub

    Protected Function GetFirstPay() As Integer
        Dim chdFristPay As CheckBox = FunAll.ObjFindControl("chdFristPay", frmAppCard)
        If chdFristPay.Checked = True Then
            Return 1
        Else
            Return 0
        End If

    End Function

    Protected Sub GvAppCard_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvAppCard.RowCommand
        If e.CommandName = "Remove" Then
            If frmOldInsure.DataItemCount > 0 Then
                SqlAppCard2.DeleteParameters("AppCardId").DefaultValue = GvAppCard.DataKeys(e.CommandArgument).Item(11)
                SqlAppCard2.Delete()
                GvAppPayDataBind()
            Else
                dt = New DataTable
                dt = ViewState("AppCard")
                dt.Rows(e.CommandArgument).Delete()
                ViewState("AppCard") = dt
                GvAppCard.DataSource = dt
                GvAppCard.DataBind()
            End If

        ElseIf e.CommandName = "Select" Then
            If frmOldInsure.DataItemCount > 0 Then
                With SqlAppCard
                    .SelectParameters("AppCardId").DefaultValue = GvAppCard.DataKeys(e.CommandArgument).Item(11)
                End With
                frmAppCard.DataBind()
            Else
                dt = New DataTable
                dt = ViewState("AppCard")
                frmAppCard.DataSourceID = Nothing
                frmAppCard.DataSource = dt
                frmAppCard.PageIndex = e.CommandArgument
                frmAppCard.DataBind()

            End If
        End If
    End Sub

    Protected Sub GvAppPayDataBind()
        With SqlAppCard2
            .SelectParameters("AppID").DefaultValue = frmOldInsure.DataKey.Item(0)
        End With
        GvAppCard.DataSource = SqlAppCard2
        GvAppCard.DataBind()
    End Sub

    'สำหรับกรณี ยังไม่มี App
    Protected Sub InsertTblAppCard()
        For i As Integer = 0 To GvAppCard.Rows.Count - 1
            Dim Paydate As DateTime = GvAppCard.DataKeys(i).Item(7)
            com = New SqlCommand(QueryCredit.InsertAppCard, Conn)
            With com
                .Parameters.Clear()
                .Parameters.Add("@Appid", SqlDbType.VarChar).Value = frmOldInsure.DataKey.Item(0)
                .Parameters.Add("@CardRun", SqlDbType.VarChar).Value = i + 1
                .Parameters.Add("@CardNo1", SqlDbType.VarChar).Value = GvAppCard.DataKeys(i).Item(0)
                .Parameters.Add("@CardNo2", SqlDbType.VarChar).Value = GvAppCard.DataKeys(i).Item(1)
                .Parameters.Add("@CardExp", SqlDbType.VarChar).Value = GvAppCard.DataKeys(i).Item(2)
                .Parameters.Add("@Cardname", SqlDbType.VarChar).Value = GvAppCard.DataKeys(i).Item(3)
                .Parameters.Add("@PayTypeId", SqlDbType.VarChar).Value = GvAppCard.DataKeys(i).Item(4)
                .Parameters.Add("@Cardid", SqlDbType.VarChar).Value = GvAppCard.DataKeys(i).Item(5)
                .Parameters.Add("@Bankid", SqlDbType.VarChar).Value = GvAppCard.DataKeys(i).Item(6)
                .Parameters.Add("@PayDate", SqlDbType.VarChar).Value = ISODate.SetISODate("en", Paydate.ToString("dd/MM/yyyy"))
                .Parameters.Add("@IsPayDate", SqlDbType.VarChar).Value = GvAppCard.DataKeys(i).Item(8)
                .Parameters.Add("@Createid", SqlDbType.VarChar).Value = Request.Cookies("userID").Value
                .Parameters.Add("@Updateid", SqlDbType.VarChar).Value = Request.Cookies("userID").Value
                .Parameters.Add("@Tel1", SqlDbType.VarChar).Value = GvAppCard.DataKeys(i).Item(9)
                .Parameters.Add("@Mobile", SqlDbType.VarChar).Value = GvAppCard.DataKeys(i).Item(10)
                .ExecuteNonQuery()

            End With
        Next
    End Sub

    'สำหรับกรณี  มี App
    Protected Sub InsertTblAppCard2(ByVal strqry As String, ByVal AppCardID As String)
        Dim ddTypeCard As DropDownList = FunAll.ObjFindControl("ddTypeCard", frmAppCard)
        Dim ddBank As DropDownList = FunAll.ObjFindControl("ddBank", frmAppCard)
        Dim ddNum As DropDownList = FunAll.ObjFindControl("ddNum", frmAppCard)

        Dim txtCardID As TextBox = FunAll.ObjFindControl("txtCardID", frmAppCard)
        Dim txtCardID3 As TextBox = FunAll.ObjFindControl("txtCardID3", frmAppCard)
        Dim txtExpCard As TextBox = FunAll.ObjFindControl("txtExpCard", frmAppCard)
        Dim txtExpCard2 As TextBox = FunAll.ObjFindControl("txtExpCard2", frmAppCard)
        Dim txtTel As TextBox = FunAll.ObjFindControl("txtTel", frmAppCard)
        Dim txtMobile As TextBox = FunAll.ObjFindControl("txtMobile", frmAppCard)
        Dim txtFristPay As TextBox = FunAll.ObjFindControl("txtFristPay", frmAppCard)
        Dim txtCommentCard As TextBox = FunAll.ObjFindControl("txtCommentCard", frmAppCard)
        Dim txtCardName As TextBox = FunAll.ObjFindControl("txtCardName", frmAppCard)

        com = New SqlCommand(strqry, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@Appid", SqlDbType.VarChar).Value = frmOldInsure.DataKey.Item(0)
            .Parameters.Add("@CardRun", SqlDbType.VarChar).Value = GvAppCard.Rows.Count + 1
            .Parameters.Add("@CardNo1", SqlDbType.VarChar).Value = txtCardID.Text.Trim
            .Parameters.Add("@CardNo2", SqlDbType.VarChar).Value = txtCardID3.Text.Trim
            .Parameters.Add("@CardExp", SqlDbType.VarChar).Value = txtExpCard.Text.Trim
            .Parameters.Add("@Cardname", SqlDbType.VarChar).Value = txtCardName.Text.Trim
            .Parameters.Add("@Cardid", SqlDbType.VarChar).Value = ddTypeCard.SelectedValue
            .Parameters.Add("@Bankid", SqlDbType.VarChar).Value = ddBank.SelectedValue
            .Parameters.Add("@PayDate", SqlDbType.VarChar).Value = ISODate.SetISODate("en", txtFristPay.Text.Trim)
            .Parameters.Add("@IsPayDate", SqlDbType.VarChar).Value = GetFirstPay()
            .Parameters.Add("@Createid", SqlDbType.VarChar).Value = Request.Cookies("userID").Value
            .Parameters.Add("@Updateid", SqlDbType.VarChar).Value = Request.Cookies("userID").Value
            .Parameters.Add("@Tel1", SqlDbType.VarChar).Value = txtTel.Text.Trim
            .Parameters.Add("@Mobile", SqlDbType.VarChar).Value = txtMobile.Text.Trim
            .Parameters.Add("@AppCardID", SqlDbType.VarChar).Value = AppCardID
            .ExecuteNonQuery()

        End With
    End Sub

#End Region


#Region "TakePhone"

#Region "ค้นหาพื้นที่ถ่ายรูป"
    'ค้นหาอำเภอ
    Protected Sub ddProvince_SelectedIndexChanged3(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddProvince As DropDownList = DirectCast(frmPhoto.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmPhoto.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmPhoto.FindControl("ddSubDist"), DropDownList)

        FunAll.ListDropDown(ddDist, StrQryProvince.SelectTblAreaDist(ddProvince.SelectedValue), "Dist", "Dist")
        FunAll.ListDropDown(ddSubDist, StrQryProvince.SelectTblAreaSubDist(ddDist.SelectedValue, ddProvince.SelectedValue), "SubDist", "SubDist")
    End Sub
    'ค้นหาตำบล
    Protected Sub ddDist_SelectedIndexChanged3(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddProvince As DropDownList = DirectCast(frmPhoto.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmPhoto.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmPhoto.FindControl("ddSubDist"), DropDownList)
        FunAll.ListDropDown(ddSubDist, StrQryProvince.SelectTblAreaSubDist(ddDist.SelectedValue, ddProvince.SelectedValue), "SubDist", "SubDist")

    End Sub

    Protected Sub frmCusPhoto_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmPhoto.DataBound
        Dim ddProvince As DropDownList = DirectCast(frmPhoto.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmPhoto.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmPhoto.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmPhoto.FindControl("ddZipcode"), DropDownList)


        If frmPhoto.DataItemCount > 0 Then

            FunAll.ListDropDown(ddDist, StrQryProvince.SelectTblAreaDist(ddProvince.SelectedValue), "Dist", "Dist")
            'Dim str As String = frmAddr.DataKey.Item(0)
            FunAll.ListDropDown(ddSubDist, StrQryProvince.SelectTblAreaSubDist(frmPhoto.DataKey.Item(0).ToString.Trim, ddProvince.SelectedValue), "SubDist", "SubDist")

            If ddDist.Items.Count > 0 Then
                ddDist.SelectedValue = frmPhoto.DataKey.Item(0).ToString.Trim
            End If

            If ddSubDist.Items.Count > 0 Then
                ddSubDist.SelectedValue = frmPhoto.DataKey.Item(1).ToString.Trim
            End If



        End If

    End Sub

    'ดึง Rider
    Protected Function GetRiderPhoto(ByVal Province As String, ByVal Dist As String, ByVal SubDist As String) As String
        Dim dtRiderPhoto As New DataTable
        dtRiderPhoto = DataAccess.DataRead(StrQryProvince.SelectTblAreaRider(SubDist, Dist, Province))
        If dtRiderPhoto.Rows.Count > 0 Then
            Return dtRiderPhoto.Rows(0).Item("tID")
        Else
            Return 0
        End If

    End Function


#End Region

#Region "ดึงข้อมูล ทั่วไปลูกค้า"
    Protected Sub Button1_Click1(ByVal sender As Object, ByVal e As System.EventArgs)
        BindCusName()
    End Sub

    Protected Sub BindCusName()
        Dim txtFNameTH As TextBox = FunAll.ObjFindControl("txtFNameTH", frmCusName)
        Dim txtLNameTH As TextBox = FunAll.ObjFindControl("txtLNameTH", frmCusName)
        Dim txtCusName As TextBox = DirectCast(frmPhotoCus.FindControl("txtCusName"), TextBox)
        txtCusName.Text = txtFNameTH.Text.Trim & " " & txtLNameTH.Text.Trim

    End Sub

    Protected Sub ddTel_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim txtTel As TextBox = FunAll.ObjFindControl("txtTel", frmPhotoCus)
        txtTel.Text = Left(GetTel(), 6) & "XXXX"
    End Sub

    Protected Function GetTel() As String
        Dim ddTel As DropDownList = FunAll.ObjFindControl("ddTel", frmPhotoCus)
        Select Case ddTel.SelectedValue
            Case 0
                Return frmTel.DataKey.Item(0)
            Case 1
                Return frmTel.DataKey.Item(1)
            Case 2
                Return frmTel.DataKey.Item(2)
            Case 3
                Return frmTel.DataKey.Item(3)
            Case Else
                Return ""

        End Select
    End Function
#End Region

#Region "บันทึก TakePhoto"
    Protected Function ChkProductPhotos() As Boolean
        Dim ProID As Integer = frmPackage.DataKey.Item(16)
        'If ProID = 9 Then
        '    ConditionUpdatePA.Visible = False
        'Else
        '    ConditionUpdatePA.Visible = True
        'End If

        dt = New DataTable
        dt = DataAccess.DataRead(StrQuery.SelectTblProduct(ProID))
        If dt.Rows.Count > 0 And frmPackage.DataKey.Item(17) = 1 Then
            If dt.Rows(0).Item("StatusPhoto") = True Then
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If

    End Function

    Protected Sub btnTakePhoto()
        Dim ddCusStatus As DropDownList = FunAll.ObjFindControl("ddCusStatus", frmPhotoCus)
        If ChkProductPhotos() = True Then
            If ChkWeekEnd() = True And ChkDateAppoint() = True Then
                If frmPhotoCus.DataItemCount > 0 Then
                    SaveTblAppointPhotos(StrQuery.UpdateTblAppointTakePhoto, frmPhotoCus.DataKey.Item(0))
                    UpdateTblTakePhoto()

                    If ddCusStatus.SelectedValue = 0 Then 'ลบ งานถ่ายรูป สำหรับ ASN ถ่าย TblTakePhoto
                        With SqlTakePhoto
                            .DeleteParameters("AppID").DefaultValue = frmOldInsure.DataKey.Item(0)
                            .Delete()
                        End With
                    Else
                        If Request.Cookies("UserLevel").Value <> 8 Then
                            ChkRider() 'สำหรับ Insert TblTakePhoto Success ไปแล้วให้ถ่ายรูป
                        End If

                    End If

                Else
                    SaveTblAppointPhotos(StrQuery.InsertTblAppointTakePhoto, "")
                End If
            End If
        End If


    End Sub

    Protected Sub SaveTblAppointPhotos(ByVal strqry As String, ByVal RunID As String)
        Dim ddProvince As DropDownList = DirectCast(frmPhoto.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmPhoto.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmPhoto.FindControl("ddSubDist"), DropDownList)
        Dim txtAppointDate As TextBox = FunAll.ObjFindControl("txtAppointDate", frmPhoto)
        Dim ddCusStatus As DropDownList = FunAll.ObjFindControl("ddCusStatus", frmPhotoCus)
        com = New SqlCommand(strqry, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@Cusid", SqlDbType.VarChar).Value = frmCusName.DataKey.Item(0)
            .Parameters.Add("@IdCar", SqlDbType.VarChar).Value = Request.QueryString("IdCar").ToString
            .Parameters.Add("@AppointDate", SqlDbType.VarChar).Value = ISODate.SetISODate("en", txtAppointDate.Text.Trim)
            .Parameters.Add("@AppointTime", SqlDbType.VarChar).Value = FunAll.ObjFindControl("ddAppoint", frmPhoto).SelectedValue
            .Parameters.Add("@Name", SqlDbType.VarChar).Value = FunAll.ObjFindControl("txtCusName", frmPhotoCus).Text.Trim
            .Parameters.Add("@Tel", SqlDbType.VarChar).Value = GetTel()
            .Parameters.Add("@Province", SqlDbType.VarChar).Value = ddProvince.SelectedValue
            .Parameters.Add("@Dist", SqlDbType.VarChar).Value = ddDist.SelectedValue
            .Parameters.Add("@SubDist", SqlDbType.VarChar).Value = ddSubDist.SelectedValue
            .Parameters.Add("@tid", SqlDbType.VarChar).Value = GetRiderPhoto(ddProvince.SelectedValue, ddDist.SelectedValue, ddSubDist.SelectedValue)
            .Parameters.Add("@Flag", SqlDbType.VarChar).Value = ddCusStatus.SelectedValue
            .Parameters.Add("@RunID", SqlDbType.VarChar).Value = RunID
            .ExecuteNonQuery()
        End With
    End Sub

    Protected Function ChkWeekEnd() As Boolean

        Try
            Dim txtAppointDate As TextBox = FunAll.ObjFindControl("txtAppointDate", frmPhoto)
            Dim AppointDate As Date = ISODate.SetISODate("th", txtAppointDate.Text.Trim)
            If AppointDate.DayOfWeek = DayOfWeek.Sunday Then
                MsgBox("ไม่สามารถนัดวันอาทิตย์ได้")
                Return False
            Else
                Return True
            End If
        Catch ex As Exception
            MsgBox("กรุณากรอกข้อมูลวันที่นัดให้ถูกต้อง")
            Return False
        End Try

    End Function

    Protected Function ChkDateAppoint() As Boolean
        Try
            Dim txtAppointDate As TextBox = FunAll.ObjFindControl("txtAppointDate", frmPhoto)
            Dim AppointDate As Date = ISODate.SetISODate("th", txtAppointDate.Text.Trim)
            Dim ddCusStatus As DropDownList = FunAll.ObjFindControl("ddCusStatus", frmPhotoCus)
            If DateDiff(DateInterval.Day, Date.Today, AppointDate) < 3 And ddCusStatus.SelectedValue <> 0 Then
                Dim diffdate As Integer = DateDiff(DateInterval.Day, AppointDate, Date.Today)
                MsgBox("วันนัดต้องห่างจากวันปัจจุบัน 2 วันขึ้นไป")
                Return False
            Else
                Dim diffdate As Integer = DateDiff(DateInterval.Day, AppointDate, Date.Today)
                Return True
            End If
        Catch ex As Exception
            MsgBox("กรุณากรอกข้อมูลวันที่นัดให้ถูกต้อง")
            Return False
        End Try

    End Function

    Protected Sub UpdateTblTakePhoto()
        Dim ddCusStatus As DropDownList = FunAll.ObjFindControl("ddCusStatus", frmPhotoCus)
        If frmOldInsure.DataItemCount > 0 And ddCusStatus.SelectedValue = 0 Then
            With SqlTakePhoto
                .UpdateParameters("AppID").DefaultValue = frmOldInsure.DataKey.Item(0)
                .Update()
            End With
        End If

    End Sub
#End Region

#Region "TakePhotoกรณี Success แล้ว Insert TblTakePhoto"
    'CheckProTypeID
    Protected Function ChkProType(ByVal ProID As String) As Boolean

        dt = New DataTable
        dt = DataAccess.DataRead(StrQuery.SelectTblProduct(ProID))
        If dt.Rows.Count > 0 And frmPackage.DataKey.Item(17) = 1 Then
            If dt.Rows(0).Item("StatusPhoto") = True Then
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If

    End Function

    Protected Function ChkRider() As Boolean
        If frmCar.DataKey.Item(4) = 4 Or frmCar.DataKey.Item(4) = 3 Then
            If ChkProType(frmProType.DataKey.Item(0)) = True And frmPackage.DataKey.Item(17) = 1 And TakePhotoOldApp() = True Then
                Return ChkTblAppointTakePhoto(frmCar.DataKey.Item(0), frmOldInsure.DataKey.Item(0))
            Else
                Return True
            End If
        Else
            Return True
        End If
    End Function

    'Check App Photo สำหรับ ปีต่ออายุ
    Protected Function TakePhotoOldApp() As Boolean
        If Request.Cookies("TypeTsr").Value = 3 Or Request.Cookies("TypeTsr").Value = 11 Then
            Dim strqry As String = "select * from  TmpApp_CustRenew a1 Where IdCar =  " & frmCar.DataKey.Item(0)
            strqry += "  and a1.AppStatus = 1 and a1.FlagNewApp = 0"
            strqry += "  order by a1.CreateDate DESC "
            dt = New DataTable
            dt = DataAccess.DataRead(strqry)
            If dt.Rows.Count > 0 Then
                If dt.Rows(0).Item("ProductID") = frmProType.DataKey.Item(0) Then
                    'กรณีต่ออายุ และบริษัทประกันเดิมไม่ต้องให้ ASN ถ่ายรูป
                    Return False
                Else
                    Return True
                End If
            Else
                Return True
            End If
        Else
            Return True

        End If
    End Function

    'Check TblAppointTakePhoto
    Protected Function ChkTblAppointTakePhoto(ByVal IdCar As Integer, ByVal AppID As Integer) As Boolean
        Dim dtChk As New DataTable
        dtChk = GetTblAppointPhotos(IdCar)
        If dtChk.Rows.Count > 0 Then
            If dtChk.Rows(0).Item("Flag") <> 0 Then
                InsertTblTakePhoto(dtChk, AppID)
                Return True
            Else
                Return True
            End If

        Else
            MsgBox("ไม่สามารถบันทึกได้ ไม่มีข้อมูลถ่ายรูปรถ")
            Return False
        End If
    End Function

    'ค้นหา TblAppointTakephoto
    Protected Function GetTblAppointPhotos(ByVal IdCar As String) As DataTable
        dtGetAppPhotos = New DataTable
        dtGetAppPhotos = DataAccess.DataRead(StrQueryPhoto.BindTblAppointTakephoto(IdCar))
        Return dtGetAppPhotos
    End Function

    Protected Sub InsertTblTakePhoto(ByVal dtPhoto As DataTable, ByVal AppID As Integer)

        With SqlTakePhoto
            .DeleteParameters("AppID").DefaultValue = frmOldInsure.DataKey.Item(0)
            .Delete()
        End With

        'CheckConnectionState()
        com = New SqlCommand(StrQueryPhoto.InsertTblTakePhoto, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@CusID", SqlDbType.VarChar).Value = frmCusName.DataKey.Item(0)
            .Parameters.Add("@idCAR", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("IdCar")
            .Parameters.Add("@appID", SqlDbType.VarChar).Value = AppID
            .Parameters.Add("@phID", SqlDbType.VarChar).Value = 2
            .Parameters.Add("@tID", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("tID")
            .Parameters.Add("@createID", SqlDbType.VarChar).Value = Request.Cookies("userID").Value
            .Parameters.Add("@appointDATE", SqlDbType.DateTime).Value = ISODate.SetISODate("th", CDate(dtPhoto.Rows(0).Item("appointDATE")).ToString("dd/MM/yyyy"))
            .Parameters.Add("@appointCOMMENT", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("Name")
            .Parameters.Add("@provinceDEST", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("Province")
            .Parameters.Add("@mainDEST", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("Dist")
            .Parameters.Add("@Destination", SqlDbType.VarChar).Value = dtPhoto.Rows(0).Item("SubDist")
            .ExecuteNonQuery()
        End With


        com = New SqlCommand(StrQueryPhoto.UpdateAppTakePhoto, Conn)
        With com
            .Parameters.Clear()
            .Parameters.Add("@AppID", SqlDbType.VarChar).Value = AppID
            .ExecuteNonQuery()
        End With
    End Sub

#End Region
#End Region

#Region "ข้อมูลนัดถ่ายรูปรถKTC"
    Protected Sub ddProvince_SelectedIndexChanged1(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddProvince As DropDownList = DirectCast(frmTakePhoto.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmTakePhoto.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmTakePhoto.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmTakePhoto.FindControl("ddZipcode"), DropDownList)

        FunAll.ListDropDown(ddDist, StrQryProvince.TblZipCodeBindDist(ddProvince.SelectedValue), "Dist", "Dist")
        FunAll.ListDropDown(ddSubDist, StrQryProvince.TblZipCodeBindSubDist(ddDist.SelectedValue, ddProvince.SelectedValue), "SubDist", "SubDist")
        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(ddSubDist.SelectedValue, ddProvince.SelectedValue, ddDist.SelectedValue), "ZipCode", "ZipCode")
    End Sub

    Protected Sub ddDist_SelectedIndexChanged1(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddProvince As DropDownList = DirectCast(frmTakePhoto.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmTakePhoto.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmTakePhoto.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmTakePhoto.FindControl("ddZipcode"), DropDownList)
        FunAll.ListDropDown(ddSubDist, StrQryProvince.TblZipCodeBindSubDist(ddDist.SelectedValue, ddProvince.SelectedValue), "SubDist", "SubDist")
        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(ddSubDist.SelectedValue, ddProvince.SelectedValue, ddDist.SelectedValue), "ZipCode", "ZipCode")
    End Sub

    Protected Sub ddSubDist_SelectedIndexChanged1(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddProvince As DropDownList = DirectCast(frmTakePhoto.FindControl("ddProvince"), DropDownList)
        Dim ddDist As DropDownList = DirectCast(frmTakePhoto.FindControl("ddDist"), DropDownList)
        Dim ddSubDist As DropDownList = DirectCast(frmTakePhoto.FindControl("ddSubDist"), DropDownList)
        Dim ddZipCode As DropDownList = DirectCast(frmTakePhoto.FindControl("ddZipcode"), DropDownList)
        FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(ddSubDist.SelectedValue, ddProvince.SelectedValue, ddDist.SelectedValue), "ZipCode", "ZipCode")
    End Sub

    Protected Sub frmTakePhoto_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles frmTakePhoto.DataBound
        If frmTakePhoto.DataItemCount > 0 Then
            Dim ddProvince As DropDownList = DirectCast(frmTakePhoto.FindControl("ddProvince"), DropDownList)
            Dim ddDist As DropDownList = DirectCast(frmTakePhoto.FindControl("ddDist"), DropDownList)
            Dim ddSubDist As DropDownList = DirectCast(frmTakePhoto.FindControl("ddSubDist"), DropDownList)
            Dim ddZipCode As DropDownList = DirectCast(frmTakePhoto.FindControl("ddZipcode"), DropDownList)
            FunAll.ListDropDown(ddDist, StrQryProvince.TblZipCodeBindDist(ddProvince.SelectedValue), "Dist", "Dist")
            'Dim str As String = frmAddr.DataKey.Item(0)
            FunAll.ListDropDown(ddSubDist, StrQryProvince.TblZipCodeBindSubDist(frmTakePhoto.DataKey.Item(1).ToString.Trim, ddProvince.SelectedValue), "SubDist", "SubDist")

            FunAll.ListDropDown(ddZipCode, StrQryProvince.TblZipCOdeBindZipCode(frmTakePhoto.DataKey.Item(2).ToString.Trim, ddProvince.SelectedValue, frmTakePhoto.DataKey.Item(1).ToString.Trim), "ZipCode", "ZipCode")

            If ddDist.Items.Count > 0 Then
                ddDist.SelectedValue = frmTakePhoto.DataKey.Item(1).ToString.Trim
            End If

            If ddSubDist.Items.Count > 0 Then
                ddSubDist.SelectedValue = frmTakePhoto.DataKey.Item(2).ToString.Trim
            End If

            If ddZipCode.Items.Count > 0 Then
                ddZipCode.SelectedValue = frmTakePhoto.DataKey.Item(3).ToString.Trim
            End If
        End If
    End Sub
#End Region

#Region "SaveTakePhoto"
    Protected Sub SaveTblKTCTakePhoto()
        Dim txtProtectDate As TextBox = FunAll.ObjFindControl("txtProtectDate", frmAppRela)
        Dim ProtectDate As Date = ISODate.SetISODate("th", txtProtectDate.Text.Trim)
        If frmPackage.DataKey.Item(17) = 1 And frmPackage.DataKey.Item(16) = 63 Then
            If frmTakePhoto.DataItemCount > 0 Then
                UpdateTblKTCTakePhoto()
            Else
                InsertTblKTCTakePhoto()
            End If
        Else
            If frmTakePhoto.DataItemCount > 0 Then
                DeleteTblKTCTakePhoto()
            End If


        End If

    End Sub

    Protected Function checkTakePhotoKTC() As Boolean
        Dim chkTakePhoto As CheckBox = FunAll.ObjFindControl("chkTakePhoto", frmTakePhoto)
        Dim txtProtectDate As TextBox = FunAll.ObjFindControl("txtProtectDate", frmAppRela)
        Dim ProtectDate As Date = ISODate.SetISODate("th", txtProtectDate.Text.Trim)
        Dim txtContactDate As TextBox = FunAll.ObjFindControl("txtContactDate", frmTakePhoto)
        Dim txtContactTime As TextBox = FunAll.ObjFindControl("txtContactTime", frmTakePhoto)
        If DateDiff(DateInterval.Day, Date.Today, ProtectDate) <= 5 And frmPackage.DataKey.Item(17) = 1 And frmPackage.DataKey.Item(16) = 63 Then 'วันคุ้มครองน้อยกว่า 5 วัน
            If chkTakePhoto.Checked = True Then
                Try
                    Dim txtAppoint As TextBox = FunAll.ObjFindControl("txtAppoint", frmTakePhoto)
                    Dim txtTime As TextBox = FunAll.ObjFindControl("txtTime", frmTakePhoto)
                    Dim AppointDate As DateTime = ISODate.SetISODate("th", txtAppoint.Text.Trim) & " " & txtTime.Text.Trim
                    Dim strTime As String = AppointDate.ToShortTimeString
                    If AppointDate.DayOfWeek = DayOfWeek.Saturday Or AppointDate.DayOfWeek = DayOfWeek.Sunday Then
                        '"
                        MsgBox("วันนัดต้องเป็นวันจันทร์-ศุกร์ เวลา 08.30-17.00")
                        Return False
                    ElseIf AppointDate.ToString("HH:mm") < "08:30" Or AppointDate.ToString("HH:mm") > "17:00" Then
                        MsgBox("วันนัดต้องเป็นวันจันทร์-ศุกร์ เวลา 08.30-17.00")
                        Return False
                    ElseIf txtContactDate.Text.Trim = "" Or txtContactTime.Text.Trim = "" Then
                        MsgBox("ประกันภัยชั้น 1 ต้องนัดวันและเวลาที่สะดวกติดต่อกลับ")
                        Return False
                    Else
                        Return True
                    End If

                Catch ex As Exception
                    MsgBox("format วันนัดที่นัดถ่ายรูปไม่ถูกต้อง")
                    Return False
                End Try

            Else
                MsgBox("วันคุ้มครองน้อยกว่า 5 วันจะต้องนัดถ่ายรูปรถ และติ๊กสถานะนัดถ่ายรูป")
                Return False
            End If
        ElseIf frmPackage.DataKey.Item(17) = 1 And frmPackage.DataKey.Item(16) = 63 Then

            If txtContactDate.Text.Trim = "" Or txtContactTime.Text.Trim = "" Then
                MsgBox("ประกันภัยชั้น 1 ต้องนัดวันและเวลาที่สะดวกติดต่อกลับ")
                Return False
            Else
                Return True
            End If
        Else
            Return True
        End If
    End Function

    Protected Sub InsertTblKTCTakePhoto()
        Dim txtAppoint As TextBox = FunAll.ObjFindControl("txtAppoint", frmTakePhoto)
        Dim txtTime As TextBox = FunAll.ObjFindControl("txtTime", frmTakePhoto)
        Dim ddProvince As DropDownList = FunAll.ObjFindControl("ddProvince", frmTakePhoto)
        Dim ddDist As DropDownList = FunAll.ObjFindControl("ddDist", frmTakePhoto)
        Dim ddSubDist As DropDownList = FunAll.ObjFindControl("ddSubDist", frmTakePhoto)
        Dim ddZipCode As DropDownList = FunAll.ObjFindControl("ddZipCode", frmTakePhoto)
        Dim txtTakeDesc As TextBox = FunAll.ObjFindControl("txtTakeDesc", frmTakePhoto)
        Dim chkTakePhoto As CheckBox = FunAll.ObjFindControl("chkTakePhoto", frmTakePhoto)
        Dim txtContactDate As TextBox = FunAll.ObjFindControl("txtContactDate", frmTakePhoto)
        Dim txtContactTime As TextBox = FunAll.ObjFindControl("txtContactTime", frmTakePhoto)
        With SqlTakePhotoKTC
            .InsertParameters("AppID").DefaultValue = frmOldInsure.DataKey.Item(0)
            .InsertParameters("IdCar").DefaultValue = frmCar.DataKey.Item(0)
            .InsertParameters("AppointDate").DefaultValue = GetDateAppoint()
            .InsertParameters("Province").DefaultValue = ddProvince.SelectedValue
            .InsertParameters("Dist").DefaultValue = ddDist.SelectedValue
            .InsertParameters("SubDist").DefaultValue = ddSubDist.SelectedValue
            .InsertParameters("Zipcode").DefaultValue = ddZipCode.SelectedValue
            .InsertParameters("TakeDesc").DefaultValue = txtTakeDesc.Text.Trim
            .InsertParameters("IsAppoint").DefaultValue = chkTakePhoto.Checked
            .InsertParameters("ContactDate").DefaultValue = ISODate.SetISODate("en", txtContactDate.Text.Trim) & " " & txtContactTime.Text.Trim
            .Insert()
        End With
    End Sub

    Protected Function GetDateAppoint() As String
        Dim txtAppoint As TextBox = FunAll.ObjFindControl("txtAppoint", frmTakePhoto)
        Dim txtTime As TextBox = FunAll.ObjFindControl("txtTime", frmTakePhoto)
        If txtAppoint.Text.Trim = "" Then
            Return Nothing
        Else
            Return ISODate.SetISODate("en", txtAppoint.Text.Trim) & " " & txtTime.Text.Trim
        End If

    End Function

    Protected Function GetIsAppoint() As Boolean
        Dim txtProtectDate As TextBox = FunAll.ObjFindControl("txtProtectDate", frmAppRela)
        Dim ProtectDate As Date = ISODate.SetISODate("th", txtProtectDate.Text.Trim)
        If DateDiff(DateInterval.Day, Date.Today, ProtectDate) <= 5 And frmPackage.DataKey.Item(17) = 1 Then 'วันคุ้มครองน้อยกว่า 5 วัน
            Return True
        Else
            Return False
        End If
    End Function

    Protected Sub UpdateTblKTCTakePhoto()
        Dim txtAppoint As TextBox = FunAll.ObjFindControl("txtAppoint", frmTakePhoto)
        Dim txtTime As TextBox = FunAll.ObjFindControl("txtTime", frmTakePhoto)
        Dim ddProvince As DropDownList = FunAll.ObjFindControl("ddProvince", frmTakePhoto)
        Dim ddDist As DropDownList = FunAll.ObjFindControl("ddDist", frmTakePhoto)
        Dim ddSubDist As DropDownList = FunAll.ObjFindControl("ddSubDist", frmTakePhoto)
        Dim ddZipCode As DropDownList = FunAll.ObjFindControl("ddZipCode", frmTakePhoto)
        Dim txtTakeDesc As TextBox = FunAll.ObjFindControl("txtTakeDesc", frmTakePhoto)
        Dim chkTakePhoto As CheckBox = FunAll.ObjFindControl("chkTakePhoto", frmTakePhoto)
        Dim txtContactDate As TextBox = FunAll.ObjFindControl("txtContactDate", frmTakePhoto)
        Dim txtContactTime As TextBox = FunAll.ObjFindControl("txtContactTime", frmTakePhoto)
        With SqlTakePhotoKTC
            .UpdateParameters("AppointDate").DefaultValue = GetDateAppoint()
            .UpdateParameters("Province").DefaultValue = ddProvince.SelectedValue
            .UpdateParameters("Dist").DefaultValue = ddDist.SelectedValue
            .UpdateParameters("SubDist").DefaultValue = ddSubDist.SelectedValue
            .UpdateParameters("Zipcode").DefaultValue = ddZipCode.SelectedValue
            .UpdateParameters("TakeDesc").DefaultValue = txtTakeDesc.Text.Trim
            .UpdateParameters("IsAppoint").DefaultValue = GetIsAppoint()
            .UpdateParameters("ContactDate").DefaultValue = ISODate.SetISODate("en", txtContactDate.Text.Trim) & " " & txtContactTime.Text.Trim
            .UpdateParameters("RunID").DefaultValue = frmTakePhoto.DataKey.Item(0)
            .Update()
        End With

    End Sub

    Protected Sub DeleteTblKTCTakePhoto()

        SqlTakePhotoKTC.DeleteParameters("RunID").DefaultValue = frmTakePhoto.DataKey.Item(0)
        SqlTakePhotoKTC.Delete()
    End Sub
#End Region

    Protected Sub Button15_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button15.Click
        Me.ClientScript.RegisterClientScriptBlock(Me.GetType(), "script", "<script>window.close();</script>")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            scripttmp.Visible = False
            If Request.QueryString("Edit").ToString = 0 Or Request.QueryString("Edit").ToString = 2 Then
                btnSave.Visible = False
            End If
            Dim lblTypeID As Label = FunAll.ObjFindControl("lblTypeID", frmProType)
            If lblTypeID Is Nothing Then
            Else
                If lblTypeID.Text = "1" Then
                    If Request.Cookies("TypeTsr").Value = 3 Then
                        chkPay.Visible = False
                    ElseIf (Request.Cookies("TypeTsr").Value <> 1 And Request.Cookies("TypeTsr").Value <> 11 And Request.Cookies("TypeTsr").Value <> 15) Then
                        chkPay.Visible = False
                    Else
                        chkPay.Visible = False
                    End If
                Else
                    chkPay.Visible = False
                End If
            End If
        End If

    End Sub

    Protected Sub GvPay_DataBound(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub

    Protected Sub GvPay_DataBound1(ByVal sender As Object, ByVal e As System.EventArgs) Handles GvPay.DataBound
        If Request.Cookies("UserLevel").Value = 2 Or Request.Cookies("UserLevel").Value = 1 Then
            For i As Integer = 0 To GvPay.Rows.Count - 1
                Dim txtAppoint As TextBox = FunAll.ObjFindControl("txtAppoint", GvPay.Rows(i))
                txtAppoint.ReadOnly = True
            Next

        End If
    End Sub

    Protected Sub SqlAppPay_Selected(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.SqlDataSourceStatusEventArgs) Handles SqlAppPay.Selected

    End Sub

    Protected Sub GvAppCard_Load(sender As Object, e As System.EventArgs) Handles GvAppCard.Load
        'If Request.QueryString("Edit").ToString = 0 Then
        '    GvAppCard.Columns(1).Visible = False
        '    GvAppCard.Columns(0).Visible = False
        'End If
    End Sub

    Protected Sub ddIsProValue_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ddIsProValue As DropDownList = FunAll.ObjFindControl("ddIsProValue", frmProType)
        Select Case ddIsProValue.SelectedValue
            Case 0
                Dim lblLostLife1 As Label = FunAll.ObjFindControl("lblLostLife1", frmPackage)
                Dim lblLostLife2 As Label = FunAll.ObjFindControl("lblLostLife2", frmPackage)
                Dim lblLostProp1 As Label = FunAll.ObjFindControl("lblLostProp1", frmPackage)
                Dim lblLostProp2 As TextBox = FunAll.ObjFindControl("lblLostProp2", frmPackage)

                Dim lblLostCar1 As Label = FunAll.ObjFindControl("lblLostCar1", frmPackage)
                Dim lblLostCar2 As Label = FunAll.ObjFindControl("lblLostCar2", frmPackage)
                Dim lblCarFire As Label = FunAll.ObjFindControl("lblCarFire", frmPackage)

                Dim lblAccLost1 As Label = FunAll.ObjFindControl("lblAccLost1", frmPackage)
                Dim lblAccLost2 As Label = FunAll.ObjFindControl("lblAccLost2", frmPackage)
                Dim lblAccLost3 As Label = FunAll.ObjFindControl("lblAccLost3", frmPackage)
                Dim lblAccLost4 As Label = FunAll.ObjFindControl("lblAccLost4", frmPackage)
                Dim lblMaintain As Label = FunAll.ObjFindControl("lblMaintain", frmPackage)
                Dim lblInsure As Label = FunAll.ObjFindControl("lblInsure", frmPackage)

                Dim txtProValue As WebNumericEdit = FunAll.ObjFindControl("txtProValue", frmPackage)
                Dim lblCarPet As Label = FunAll.ObjFindControl("lblCappet", frmPackage)
                Dim lblTotalValue As WebNumericEdit = FunAll.ObjFindControl("txtTotalValue", frmPackage)

                lblLostLife1.Text = 0
                lblLostProp1.Text = 0
                lblLostProp2.Text = 0

                lblLostCar1.Text = 0
                lblLostCar2.Text = 0
                lblCarFire.Text = 0

                lblAccLost1.Text = 0
                lblAccLost2.Text = 0
                lblAccLost3.Text = 0
                lblAccLost4.Text = 0
                lblMaintain.Text = 0
                lblInsure.Text = 0
                txtProValue.Text = 0
                lblTotalValue.Text = 0

                CalPay()
            Case 1
                frmPackage.DataBind()
                CalPay()
        End Select
    End Sub


    Protected Sub txtCopyCard_Click(sender As Object, e As System.EventArgs)
        Dim txtIDCard As TextBox = FunAll.ObjFindControl("txtIDCard", frmCusName)
        Dim txtIDCardCarpet As TextBox = FunAll.ObjFindControl("txtIDCard", frmCusName)

        txtIDCardCarpet.Text = txtIDCard.Text.Trim
    End Sub

    Protected Function ChkUser() As Boolean
        If Request.Cookies("TypeTsr").Value = 11 Or Request.Cookies("TypeTsr").Value = 12 Then
            Return False
        Else
            Return False
        End If

    End Function
    Protected Function ChkUserRenew() As Boolean
        If (Request.Cookies("UserID").Value = 544 And chkCredit.Checked = True) Or (Request.Cookies("UserID").Value = 2865 And chkCredit.Checked = True) Then
            Return True
        Else
            Return False
        End If
    End Function
    Protected Function ChkUserQC() As Boolean
        'Add By Na 24/12/2015 RD5812007   ถ้า มาจาก QC ไม่มีเงื่อนไขอะไร
        If Request.QueryString("UserID") IsNot Nothing Then
            Dim strQ As New System.Text.StringBuilder()
            strQ = New System.Text.StringBuilder()
            strQ.Append(" select UserID from tbluser where tbluser.UserLevelID=8")
            strQ.Append(" and tbluser.UserID=" & Request.QueryString("UserID").ToString)
            Dim dt20 As New DataTable
            dt20 = DataAccess.DataRead(strQ.ToString)
            If dt20.Rows.Count > 0 Then
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If

    End Function
    Protected Function GetAge() As Integer
        Dim txtbirthdate As TextBox = FunAll.ObjFindControl("txtbirthdate", frmCusName)
        Return calDate(ISODate.SetISODate("th", txtbirthdate.Text))
    End Function
    Public Function calDate(ByVal datebirth As Date) As Integer

        Dim years As Integer = DateTime.Now.Year - datebirth.Year

        If ((datebirth.Month > DateTime.Now.Month) Or (datebirth.Month = DateTime.Now.Month And datebirth.Day > DateTime.Now.Day)) Then
            years = years - 1
        End If
        Return years
    End Function
    Protected Sub btnAge_Click1(sender As Object, e As System.EventArgs)
        Dim txtAge As TextBox = FunAll.ObjFindControl("txtAge", frmCusName)
        txtAge.Text = GetAge()
    End Sub
    Protected Sub DeleteTblApplicationPA()
        With SqlTblApplicationPA
            .DeleteParameters("AppID").DefaultValue = frmOldInsure.DataKey.Item(0)
            .Delete()
        End With
    End Sub
    Protected Sub InsertTblApplicationPA()
        Dim ddPackagePA As DropDownList = FunAll.ObjFindControl("ddPackagePA", frmCusName)
        With SqlTblApplicationPA
            .InsertParameters("AppID").DefaultValue = frmOldInsure.DataKey.Item(0)
            .InsertParameters("PackageID").DefaultValue = ddPackagePA.SelectedValue
            .Insert()
        End With
    End Sub

    Protected Sub btnScript_Click(sender As Object, e As System.EventArgs) Handles btnScript.Click
        If scripttmp.Visible Then
            scripttmp.Visible = False
        Else
            scripttmp.Visible = True
            ShowSetScript()
        End If
    End Sub
    Protected Function CheckProductPA() As Boolean

        Dim ProductID As String = frmProType.DataKey.Item(0)
        Dim ddPackagePA As DropDownList = FunAll.ObjFindControl("ddPackagePA", frmCusName)
        Dim chkPA As CheckBox = FunAll.ObjFindControl("chkPA", frmCusName)
        If ddPackagePA.SelectedValue <> "0" And chkPA.Checked Then

            Dim strqry As String = ""
            strqry += " select ProTypeID from TblPackagePA where PackageID= " & ddPackagePA.SelectedValue
            dt = New DataTable
            dt = DataAccess.DataRead(strqry)

            If dt.Rows.Count > 0 Then

                If dt.Rows(0).Item("ProTypeID") = "9" Then
                    If ProductID = "9" Then
                        Return True
                    Else
                        MsgBox("ประกันบริษัทอื่น ไม่สามารถเสนอ PA วิริยะ ได้ค่ะ")
                        Return False
                    End If
                ElseIf dt.Rows(0).Item("ProTypeID") = "25" Then
                    If ProductID = "9" Then
                        MsgBox("ประกันวิริยะ ไม่สามารถเสนอ PA ธนชาต ได้ค่ะ")
                        Return False
                    Else
                        Return True
                    End If
                Else
                    Return False
                End If
            Else
                Return False
            End If
        Else
            Return True
        End If
    End Function

    Protected Sub chkPay1_CheckedChanged(sender As Object, e As System.EventArgs) Handles chkPay1.CheckedChanged
        Dim i As Int16 = ddPay.SelectedValue
        ddPay.SelectedValue = 4
    End Sub
End Class
