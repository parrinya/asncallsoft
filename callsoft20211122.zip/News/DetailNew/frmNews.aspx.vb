﻿
Partial Class Modules_News_DetailNew_frmNews
    Inherits System.Web.UI.Page

End Class
