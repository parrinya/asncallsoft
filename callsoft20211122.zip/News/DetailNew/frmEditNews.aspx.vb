﻿Imports Winthusiasm.HtmlEditor
Partial Class Modules_News_DetailNew_frmEditNews
    Inherits System.Web.UI.Page
    Dim FunAll As New FuntionAll
    Protected Sub GvNews_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GvNews.RowCommand
        If e.CommandName = "Select" Then
            SqlPromotion.SelectParameters("id").DefaultValue = GvNews.DataKeys(e.CommandArgument).Item(0)
            frmNew.DataBind()
        ElseIf e.CommandName = "Delete" Then
          
        End If
    End Sub

    Protected Sub Button5_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim txtTopic As TextBox = FunAll.ObjFindControl("txtTopic", frmNew)
        Dim HtmlEditor1 As HtmlEditor = FunAll.ObjFindControl("HtmlEditor1", frmNew)
        Dim ddUser As DropDownList = FunAll.ObjFindControl("ddUser", frmNew)
        With SqlPromotion
            .InsertParameters("Topic").DefaultValue = txtTopic.Text.Trim
            .InsertParameters("contents").DefaultValue = HtmlEditor1.Text.Trim
            .InsertParameters("Team").DefaultValue = ddUser.SelectedValue
            .Insert()
        End With
        GvNews.DataBind()
        ClearData()
    End Sub


    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim txtTopic As TextBox = FunAll.ObjFindControl("txtTopic", frmNew)
        Dim HtmlEditor1 As HtmlEditor = FunAll.ObjFindControl("HtmlEditor1", frmNew)
        Dim ddUser As DropDownList = FunAll.ObjFindControl("ddUser", frmNew)
        With SqlPromotion
            .UpdateParameters("Topic").DefaultValue = txtTopic.Text.Trim
            .UpdateParameters("contents").DefaultValue = HtmlEditor1.Text.Trim
            .UpdateParameters("Team").DefaultValue = ddUser.SelectedValue
            .UpdateParameters("id").DefaultValue = frmNew.DataKey.Item(0)
            .Update()
        End With
        GvNews.DataBind()
        ClearData()
    End Sub

    Protected Sub ClearData()
        SqlPromotion.SelectParameters("id").DefaultValue = 0
        frmNew.DataBind()
    End Sub
End Class
