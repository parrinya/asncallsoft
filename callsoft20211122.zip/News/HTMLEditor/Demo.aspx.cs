using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Drawing;
using Winthusiasm.HtmlEditor;

public partial class Demo : System.Web.UI.Page 
{
    protected string initialHtml = @"<h1>Heading 1</h1>
<p>This text is <strong>bold</strong>, this <em>italic</em>, and this <u>underlined</u>.</p>
<p>This text is <span style='font-family: Arial'>Arial</span>, this <span style='font-family: Garamond'>Garamond</span>, and this <span style='font-family: Verdana'>Verdana</span>.</p>
<ul>
<li>Bullet 1 </li>
<li>Bullet 2</li>
</ul>";

    protected string infoText = @"<h2>HTML Editor for ASP.NET AJAX</h2>
<p>This <strong>Professional Edition</strong> is designed specifically for ASP.NET AJAX.</p>
<p>Features:</p>
<ol>
<li>Implements the <strong>IScriptControl </strong>interface. </li>
<li>Creates a related client-side JavaScript object derived from <em>Sys.UI.Control</em>. </li>
<li>Runs within an <strong>UpdatePanel</strong>. </li>
<li>Runs in multiple instances.</li>
</ol>
<p>This initial text is set in the code-behind C# located in Demo.aspx.cs.</p>
<p>In this sample web page, a single HtmlEditor control is placed within an UpdatePanel. The page also includes a second UpdatePanel that contains the preview text displayed within the <strong>Preview</strong> box at the bottom of the page.</p>
<p>To test the editor:</p>
<ul>
<li>Click either the Design or Html tab to display the editor in either mode. </li>
<li>Modify the text in either mode. </li>
<li>Save changes by clicking the Save button.</li>
<li>Click the Preview button to display the saved text within the boxed area below, either as formatted or unformatted html, depending on the radio button settings. </li>
<li>Click the Clear button to clear the editor text. </li>
<li>Click the Info button to replace the text you currently see in the editor with the info text defined in the code-behind C#.</li>
<li>Click the Trigger Update button to trigger an Update of the editor UpdatePanel.</li>
</ul>";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Editor.Text = initialHtml;
        }

        RegisterAsyncPostBackButtons();
    }

    protected void RegisterAsyncPostBackButtons()
    {
        ScriptManager sm = ScriptManager.GetCurrent(this);
        sm.RegisterAsyncPostBackControl(SaveButton);
        sm.RegisterAsyncPostBackControl(ClearButton);
        sm.RegisterAsyncPostBackControl(InfoButton);
    }

    protected void ClearButton_Click(object sender, EventArgs e)
    {
        Editor.Text = String.Empty;
    }

    protected void InfoButton_Click(object sender, EventArgs e)
    {
        Editor.Text = infoText;
    }

    protected void UpdateButton_Click(object sender, EventArgs e)
    {
        Editor.Text = initialHtml;
        UpdatePanel1.Update();
    }

    protected void Editor_Save(object sender, HtmlEditor.SaveEventArgs e)
    {
        DataStore.StoreHtml(e.Text);
    }

    protected void SaveButton_Click(object sender, EventArgs e)
    {
        DataStore.StoreHtml(Editor.Text);
    }

    protected void PreviewButton_Click(object sender, EventArgs e)
    {
        switch (Selections.SelectedValue)
        {
            case "Formatted":
                TextPreview.InnerHtml = Editor.Text;
                break;
            case "Html":
                TextPreview.InnerText = Editor.Text;
                break;
            default:
                break;
        }
    }

    protected class DataStore
    {
        public static void StoreHtml(string html)
        {
        }
    }
}